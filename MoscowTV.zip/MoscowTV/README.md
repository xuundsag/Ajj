# MoscowTV

A combined anime, movie and web-series catalog at `/browse` with search, title details, episode lists, watchlist, genre-based suggestions and Continue Watching. Node 20+ recommended.

## Start

```sh
node start.js
```

Edit `PORT` at the top of `start.js` to change port 3000. The launcher installs dependencies if needed. The frontend is static; there is no build step. For a reliable OTT catalog, set your own `TMDB_API_KEY` environment variable; otherwise the server tries publicly shared keys from `freekeys`, which may fail or be rate-limited.

## Integrations

- Anime metadata: AniList. Anime playback: AnimeEmbed (`animeembed.com`) iframe, configured with orange accent, Sub/Dub, autoplay and `start`. An anime's linked sequel may appear as another season. Individual anime episode titles/images are not available from this metadata source.
- Movie/TV metadata and TV episode stills/titles: TMDB. Movie/TV embeds: VidCore (Stream 1) and Vidsrc (Stream 2).
- AnimeEmbed's documented versioned `postMessage` progress is validated by sender/origin and saved to `data/user.json`; time and duration appear in Continue Watching. VidCore accepts `startAt` when a saved position exists, but its public events do not establish reliable time reporting. Stream 2 OTT has no verified seek/progress integration. Opening a watch page creates history without fabricating progress.
- The app does not proxy streams or replace controls inside third-party iframes. The anime provider requires an unsandboxed iframe; this site cannot guarantee blocking its ads, redirects or popups. Playback availability varies by title and provider.

Watchlist and history are a single shared local profile, not per-user accounts. Do not expose a multi-user deployment without implementing authentication and private data storage. Verify content rights and provider terms before deploying.

## Attribution

The dark spotlight layout takes inspiration from Anipaca; its GPL-3.0 license is retained in `ANIPACA-LICENSE.txt`. MoscowTV's logo is a separate text wordmark.
