# Discord Rich Presence — setup guide

kozuTV V5.4.16 adds a **Discord** card to Settings. Connect your Discord
account with OAuth2, flip one switch, and your profile shows:

```
Watching kozuTV
One Piece
Episode 3
01:02 elapsed          [ Watch on kozuTV ]
```

Same shape as a streaming service's presence — the only difference is the app
name reads **kozuTV** instead of Crunchyroll.

There is **no bot** in this feature. Rich Presence is not a bot: it is a local
IPC call into the Discord **desktop** app that you are already logged into. The
"application" you create in the Discord Developer Portal exists only to own the
client ID and the uploaded assets. Skip the Bot tab entirely — do not create a
bot user, do not copy a bot token.

---

## 1. Create the application (2 minutes)

1. Open <https://discord.com/developers/applications> → **New Application**.
2. Name it **kozuTV**. The name is what appears as "Watching **kozuTV**", so
   spell it exactly that way.
3. Left sidebar → **OAuth2**. Copy the **Client ID** and **Client Secret**
   (press *Reset Secret* if it is not shown).
4. Still in **OAuth2 → Redirects**, add your exact callback URL:
   - local: `http://localhost:3000/api/discord/callback`
   - LAN: `http://192.168.x.x:3000/api/discord/callback`
   - public: `https://your-domain/api/discord/callback`

   It must match character for character, including `http` vs `https` and the
   absence of a trailing slash, or Discord answers *Invalid OAuth2 redirect_uri*.
5. Left sidebar → **Rich Presence → Art Assets**. Upload
   `public/images/kozutv-wordmark.png` (or any 512×512+ square logo) and name it
   `logo`. This is optional: presence artwork is taken from each title's own
   poster URL, and the `logo` key is only used as a fallback.

## 2. Fill in `.env`

```ini
DISCORD_CLIENT_ID=123456789012345678
DISCORD_CLIENT_SECRET=your_client_secret_here
DISCORD_REDIRECT_URI=http://localhost:3000/api/discord/callback
KOZUTV_PUBLIC_URL=https://your-domain-optional
DISCORD_APP_NAME=kozuTV
```

| Key | Required | What it does |
| --- | --- | --- |
| `DISCORD_CLIENT_ID` | yes | Identifies the app to Discord's IPC socket and to OAuth2. |
| `DISCORD_CLIENT_SECRET` | yes | Exchanged server-side for the access token. Never sent to the browser. |
| `DISCORD_REDIRECT_URI` | recommended | The exact URL from step 1.4. If omitted, kozuTV derives it from the incoming `Host` header, which works on any LAN address but not behind a proxy. |
| `KOZUTV_PUBLIC_URL` | optional | Adds the **Watch on kozuTV** button (Discord only accepts absolute https URLs) and is used as the fallback redirect base. |
| `DISCORD_APP_NAME` | optional | Defaults to `kozuTV`; that string is what Discord prints after "Watching". |

Restart the server after editing `.env`.

**While those two keys are missing the whole feature stays dormant**: the
Settings card says so, and nothing else in the app changes.

## 3. Use it

1. Start the **Discord desktop app** on the same machine as the kozuTV server
   (the browser alone is not enough — Discord's presence socket is local).
2. kozuTV → **Settings → Discord → Connect Discord**, approve `identify`.
3. The card shows your avatar and `@username`. Flip **Enable Discord Rich
   Presence**.
4. Play anything. The presence updates as the title and episode change and
   clears when you leave the player or switch the toggle off.

## 4. What each state means

| What you see | Meaning |
| --- | --- |
| "Add `DISCORD_CLIENT_ID` … to `.env`" | Server has no client credentials. |
| **Connect Discord** (Discord-blue button) | Ready, no account linked yet. |
| Avatar + `@name` + **Disconnect** | Linked. The toggle is now clickable. |
| Toggle on but nothing in Discord | The desktop app is closed, or it is open on a different machine/account. Presence is best-effort: it never blocks playback and never shows an error in the player. |

## 5. Security notes

- The client secret stays on the server; the browser only ever sees your public
  username and avatar URL.
- Tokens are stored in `data/discord-links.json`, mode `0600`, keyed by the
  visitor cookie — the same boundary as the watchlist and watch history.
- Scope requested is `identify` only.
- **Disconnect** clears the presence and deletes the stored tokens.
- Access tokens last 7 days; kozuTV refreshes them automatically and drops the
  link if you revoke the app in *Discord → Settings → Authorised Apps*.

## 6. Troubleshooting

| Symptom | Fix |
| --- | --- |
| *Invalid OAuth2 redirect_uri* | The value in the portal does not exactly match `DISCORD_REDIRECT_URI`, or you opened kozuTV on `127.0.0.1` while the portal holds `localhost`. |
| *The Discord desktop app is not running on this machine* | Open the desktop client (the web/browser version has no IPC socket). On Linux, Flatpak/Snap sockets are also checked; on WSL run Discord inside the same WSL session. |
| Presence shows the title but no artwork | The poster URL must be public https. Private/local CDN links cannot be fetched by Discord's proxy. |
| Nothing appears although the toggle is on | Discord shows Rich Presence only for the account you are logged into on *that* machine. Also check *Discord → Settings → Activity Privacy → Share your detected activities*. |
| Works over HTTP but not with a domain | Set `KOZUTV_PUBLIC_URL` to the https origin so the button URL is absolute. |

## 7. Files

| File | Role |
| --- | --- |
| `discord-rpc.js` | OAuth2 exchange, token storage/refresh, IPC framing and relay. |
| `server.js` | `/api/discord/status`, `/api/discord/callback`, `/api/discord/activity`, `/api/discord/clear`, `/api/discord/disconnect`. |
| `public/app.js` | Settings card, presence publishing from the player. |
| `scripts/test-discord.mjs` | Offline suite: URL, store, handshake, activity, and the quiet-failure paths. |
