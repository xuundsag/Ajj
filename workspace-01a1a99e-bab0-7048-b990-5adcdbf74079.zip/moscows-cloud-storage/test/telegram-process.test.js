import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { chmod, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { config } from '../src/config.js';
import { ensureTelegramServer, stopTelegramServer } from '../src/telegram-process.js';

async function freePort() {
  const server = createServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  await new Promise((resolve) => server.close(resolve));
  return port;
}

test('missing local Bot API process is started and stopped automatically', { timeout: 15_000 }, async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-process-'));
  const port = await freePort();
  const binary = path.join(directory, 'fake-api.cjs');
  await writeFile(binary, `#!/usr/bin/env node
const http = require('node:http');
const args = process.argv.slice(2);
const port = Number(args.find((arg) => arg.startsWith('--http-port=')).split('=')[1]);
const server = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify({ ok: true, result: { id: 1, is_bot: true } }));
});
server.listen(port, '127.0.0.1');
process.on('SIGTERM', () => server.close(() => process.exit(0)));
`);
  await chmod(binary, 0o755);

  const original = {
    botToken: config.botToken,
    telegramApiBase: config.telegramApiBase,
    telegramAutoStart: config.telegramAutoStart,
    telegramBinary: config.telegramBinary,
    telegramDataDir: config.telegramDataDir,
    telegramTempDir: config.telegramTempDir,
    telegramApiId: config.telegramApiId,
    telegramApiHash: config.telegramApiHash,
  };
  Object.assign(config, {
    botToken: 'TEST_TOKEN',
    telegramApiBase: `http://127.0.0.1:${port}`,
    telegramAutoStart: true,
    telegramBinary: binary,
    telegramDataDir: path.join(directory, 'data'),
    telegramTempDir: path.join(directory, 'tmp'),
    telegramApiId: '12345',
    telegramApiHash: 'hash',
  });

  t.after(async () => {
    await stopTelegramServer();
    Object.assign(config, original);
    await rm(directory, { recursive: true, force: true });
  });

  await ensureTelegramServer();
  const response = await fetch(`http://127.0.0.1:${port}/botTEST_TOKEN/getMe`, { method: 'POST' });
  assert.equal((await response.json()).ok, true);
  await stopTelegramServer();
  await assert.rejects(fetch(`http://127.0.0.1:${port}/botTEST_TOKEN/getMe`, { method: 'POST' }));
});
