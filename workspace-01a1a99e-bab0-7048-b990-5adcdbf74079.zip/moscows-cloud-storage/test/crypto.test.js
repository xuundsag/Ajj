import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createEncryptionKey, createFileKey, FILE_KEY_PATTERN, isEncryptionKey } from '../src/keys.js';
import { decryptSegment, encryptFile, SEGMENT_SIZE } from '../src/crypto.js';

test('FILE_KEY is eight uppercase alphanumeric characters', () => {
  for (let i = 0; i < 100; i += 1) assert.match(createFileKey(), FILE_KEY_PATTERN);
});

test('ENC_KEY contains 32 random bytes', () => {
  const key = createEncryptionKey();
  assert.equal(Buffer.from(key, 'base64url').length, 32);
  assert.equal(isEncryptionKey(key), true);
  assert.notEqual(key, createEncryptionKey());
});

test('streaming AES-GCM encryption preserves size and round-trips every segment', async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-crypto-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const inputPath = path.join(directory, 'plain.bin');
  const outputPath = path.join(directory, 'encrypted.bin');
  const plain = randomBytes(SEGMENT_SIZE + 123);
  await writeFile(inputPath, plain);
  const key = createEncryptionKey();
  const metadata = await encryptFile(inputPath, outputPath, key);
  const encrypted = await readFile(outputPath);

  assert.equal(encrypted.length, plain.length);
  assert.equal(metadata.tags.length, 2);
  const decrypted = [];
  for (let index = 0; index < metadata.tags.length; index += 1) {
    const start = index * SEGMENT_SIZE;
    const length = Math.min(SEGMENT_SIZE, plain.length - start);
    decrypted.push(decryptSegment(
      encrypted.subarray(start, start + length), key, Buffer.from(metadata.iv, 'base64url'), index, metadata.tags[index],
    ));
  }
  assert.deepEqual(Buffer.concat(decrypted), plain);
  encrypted[20] ^= 1;
  assert.throws(() => decryptSegment(encrypted.subarray(0, SEGMENT_SIZE), key, Buffer.from(metadata.iv, 'base64url'), 0, metadata.tags[0]));
});
