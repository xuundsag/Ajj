import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { JsonStore } from '../src/store.js';

test('meg.json store persists records and returns defensive copies', async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-store-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const file = path.join(directory, 'meg.json');
  const store = new JsonStore(file);
  await store.init();
  await store.put('A1B2C3D4', { name: 'test.bin', chunks: [] });
  assert.equal(store.has('A1B2C3D4'), true);
  const record = store.get('A1B2C3D4');
  record.name = 'changed';
  assert.equal(store.get('A1B2C3D4').name, 'test.bin');

  const reloaded = new JsonStore(file);
  await reloaded.init();
  assert.equal(reloaded.get('A1B2C3D4').name, 'test.bin');
  assert.deepEqual(Object.keys(JSON.parse(await readFile(file, 'utf8')).files), ['A1B2C3D4']);
});
