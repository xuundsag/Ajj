#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SOURCE_DIR="$ROOT_DIR/vendor/telegram-bot-api"
BINARY="$SOURCE_DIR/build/telegram-bot-api"
JOBS="${TELEGRAM_BUILD_JOBS:-2}"

if [[ ! "$JOBS" =~ ^[1-9][0-9]*$ ]]; then
  echo "TELEGRAM_BUILD_JOBS must be a positive integer" >&2
  exit 1
fi
if [[ -x "$BINARY" ]]; then
  exit 0
fi
for command in git cmake; do
  command -v "$command" >/dev/null 2>&1 || {
    echo "Missing required command: $command" >&2
    exit 1
  }
done
if ! command -v g++ >/dev/null 2>&1 && ! command -v clang++ >/dev/null 2>&1; then
  echo "A C++ compiler (g++ or clang++) is required" >&2
  exit 1
fi

mkdir -p "$ROOT_DIR/vendor"
if [[ ! -d "$SOURCE_DIR/.git" ]]; then
  rm -rf "$SOURCE_DIR"
  git clone --depth 1 --recurse-submodules --shallow-submodules \
    https://github.com/tdlib/telegram-bot-api.git "$SOURCE_DIR"
fi

# A bare --parallel uses every core and can exhaust RAM during TDLib compilation.
# Keep this bounded; use TELEGRAM_BUILD_JOBS=1 on machines with about 8 GB RAM.
export CMAKE_BUILD_PARALLEL_LEVEL="$JOBS"
if [[ "${TELEGRAM_LOW_MEMORY_LINKER:-true}" == "true" ]]; then
  export LDFLAGS="${LDFLAGS:-} -Wl,--no-keep-memory"
fi

echo "Building Telegram Bot API with $JOBS parallel job(s)..."
cmake -S "$SOURCE_DIR" -B "$SOURCE_DIR/build" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_FLAGS_RELEASE="-O2 -DNDEBUG"
cmake --build "$SOURCE_DIR/build" --parallel "$JOBS"

test -x "$BINARY"
