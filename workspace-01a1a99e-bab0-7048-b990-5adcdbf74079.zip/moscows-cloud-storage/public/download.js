const form = document.querySelector('#download-form');
const fileKeyInput = document.querySelector('#file-key-input');
const encKeyInput = document.querySelector('#enc-key-input');
const button = document.querySelector('#download-button');
const progress = document.querySelector('#progress');
const progressBar = document.querySelector('#progress-bar');
const progressValue = document.querySelector('#progress-value');
const status = document.querySelector('#status');

fileKeyInput.addEventListener('input', () => {
  fileKeyInput.value = fileKeyInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
});

function setProgress(bytes, total) {
  const percent = Math.min(100, Math.floor(bytes / total * 100));
  progressBar.style.width = `${percent}%`;
  progressValue.textContent = `${percent}%`;
}

async function request(body) {
  const response = await fetch('/api/download', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || 'Download failed');
  }
  return response;
}

function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  status.textContent = '';
  button.disabled = true;
  progress.hidden = true;
  let writable = null;

  try {
    const credentials = { fileKey: fileKeyInput.value, encKey: encKeyInput.value.trim() };
    const metadata = await (await request({ ...credentials, metadata: true })).json();
    const memoryOnly = !window.showSaveFilePicker;
    if (memoryOnly && metadata.size > 256 * 1024 ** 2) {
      throw new Error('Use a Chromium browser to download this file');
    }
    if (!memoryOnly) {
      const handle = await window.showSaveFilePicker({ suggestedName: metadata.name });
      writable = await handle.createWritable();
    }

    const response = await request(credentials);
    progress.hidden = false;
    setProgress(0, metadata.size);
    if (memoryOnly) {
      const blob = await response.blob();
      saveBlob(new Blob([blob], { type: metadata.mimeType }), metadata.name);
      setProgress(metadata.size, metadata.size);
    } else {
      const reader = response.body.getReader();
      let completed = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        await writable.write(value);
        completed += value.byteLength;
        setProgress(completed, metadata.size);
      }
      await writable.close();
      writable = null;
    }
    progress.hidden = true;
  } catch (error) {
    if (writable) await writable.abort().catch(() => {});
    status.textContent = error.name === 'AbortError' ? '' : (error.message || 'Download failed');
    progress.hidden = true;
  } finally {
    button.disabled = false;
  }
});
