import { rm } from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { config } from './config.js';
import { createEncryptionKey, createFileKey } from './keys.js';
import { encryptFile } from './crypto.js';

function cleanName(value) {
  const base = path.basename(String(value || 'file').replace(/\\/g, '/')).replace(/[\u0000-\u001f\u007f]/g, '').trim();
  return (base || 'file').slice(0, 255);
}

function cleanMime(value) {
  const mime = String(value || 'application/octet-stream');
  return /^[\w.+-]+\/[\w.+-]+$/.test(mime) ? mime.slice(0, 200) : 'application/octet-stream';
}

function boolean(value) {
  return value === true || value === 'true' || value === '1';
}

export class UploadManager {
  constructor(store, telegram) {
    this.store = store;
    this.telegram = telegram;
  }

  uniqueFileKey() {
    let key;
    do { key = createFileKey(); } while (this.store.has(key));
    return key;
  }

  async single(file) {
    if (file.size < 1) throw Object.assign(new Error('Empty files are not supported'), { status: 400 });
    if (file.size > config.maxFileSize) throw Object.assign(new Error('Maximum file size is 2 GB'), { status: 413 });

    const encrypted = boolean(file.fields.encrypted);
    const encKey = encrypted ? createEncryptionKey() : null;
    const fileKey = this.uniqueFileKey();
    const encryptedPath = encrypted ? `${file.path}.encrypted` : null;
    let uploadPath = file.path;
    let encryption = null;

    try {
      if (encrypted) {
        encryption = await encryptFile(file.path, encryptedPath, encKey);
        uploadPath = encryptedPath;
      }
      const telegram = await this.telegram.sendDocumentFile(uploadPath, file.size, `${randomUUID()}.bin`);
      const record = {
        name: cleanName(file.name),
        size: file.size,
        mimeType: cleanMime(file.mimeType),
        encrypted,
        encryption,
        createdAt: new Date().toISOString(),
        chunks: [{ index: 0, storedSize: file.size, ...telegram }],
      };
      await this.store.put(fileKey, record);
      return { fileKey, encKey };
    } finally {
      await Promise.all([
        rm(file.path, { force: true }),
        encryptedPath ? rm(encryptedPath, { force: true }) : Promise.resolve(),
      ]);
    }
  }
}
