import Busboy from 'busboy';
import { createWriteStream } from 'node:fs';
import { mkdir, rm } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { config } from './config.js';

export async function receiveFile(req, maxBytes) {
  await mkdir(config.tempDir, { recursive: true });
  const temporary = path.join(config.tempDir, `${randomUUID()}.part`);
  let busboy;
  try {
    busboy = Busboy({
      headers: req.headers,
      limits: { fileSize: maxBytes, files: 1, fields: 20, parts: 21 },
    });
  } catch {
    const error = new Error('Expected multipart/form-data');
    error.status = 400;
    throw error;
  }

  return new Promise((resolve, reject) => {
    const fields = {};
    let result = null;
    let pending = null;
    let truncated = false;
    let failure = null;

    const cleanup = () => rm(temporary, { force: true }).catch(() => {});

    busboy.on('field', (name, value) => {
      fields[name] = value;
    });

    busboy.on('file', (name, stream, info) => {
      if (name !== 'file' && name !== 'chunk') {
        stream.resume();
        return;
      }
      const output = createWriteStream(temporary, { flags: 'wx', mode: 0o600 });
      let size = 0;
      stream.on('data', (chunk) => { size += chunk.length; });
      stream.on('limit', () => { truncated = true; });
      result = { name: info.filename || 'file', mimeType: info.mimeType || 'application/octet-stream' };
      pending = pipeline(stream, output).then(() => { result.path = temporary; result.size = size; });
      pending.catch((error) => { failure = error; });
    });

    busboy.on('filesLimit', () => { failure = Object.assign(new Error('Only one file is allowed'), { status: 400 }); });
    busboy.on('error', (error) => { failure = error; cleanup(); reject(error); });
    req.on('aborted', () => { failure = Object.assign(new Error('Upload aborted'), { status: 400 }); });

    busboy.on('close', async () => {
      try {
        if (pending) await pending;
        if (failure) throw failure;
        if (truncated) throw Object.assign(new Error('Maximum file size is 2 GB'), { status: 413 });
        if (!result) throw Object.assign(new Error('No file supplied'), { status: 400 });
        resolve({ ...result, fields });
      } catch (error) {
        await cleanup();
        reject(error);
      }
    });

    req.pipe(busboy);
  });
}
