import { access, mkdir } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { config } from './config.js';

let managedProcess = null;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function healthy() {
  try {
    const response = await fetch(`${config.telegramApiBase}/bot${config.botToken}/getMe`, {
      method: 'POST',
      signal: AbortSignal.timeout(4000),
    });
    const body = await response.json();
    return response.ok && body.ok === true;
  } catch {
    return false;
  }
}

function run(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: 'inherit', ...options });
    child.once('error', reject);
    child.once('exit', (code) => code === 0 ? resolve() : reject(new Error(`${command} exited with code ${code}`)));
  });
}

export async function ensureTelegramServer() {
  if (await healthy()) {
    console.log('Telegram Bot API is ready.');
    return;
  }
  if (!config.telegramAutoStart) throw new Error('Telegram Bot API is unavailable and TELEGRAM_AUTO_START=false');

  const url = new URL(config.telegramApiBase);
  if (!['127.0.0.1', 'localhost', '::1'].includes(url.hostname)) {
    throw new Error('Automatic startup only supports a local TELEGRAM_API_BASE_URL');
  }

  try {
    await access(config.telegramBinary);
  } catch {
    console.log('Telegram Bot API binary not found; building it now...');
    await run('bash', [path.join(config.root, 'scripts', 'build-telegram-api.sh')], {
      cwd: config.root,
      env: { ...process.env, TELEGRAM_BUILD_JOBS: String(config.telegramBuildJobs) },
    });
  }

  await Promise.all([
    mkdir(config.telegramDataDir, { recursive: true }),
    mkdir(config.telegramTempDir, { recursive: true }),
  ]);
  const binary = path.resolve(config.root, config.telegramBinary);
  const child = spawn(binary, [
    '--local',
    `--http-ip-address=${url.hostname === 'localhost' ? '127.0.0.1' : url.hostname}`,
    `--http-port=${url.port || '8081'}`,
    `--dir=${config.telegramDataDir}`,
    `--temp-dir=${config.telegramTempDir}`,
    `--log=${path.join(config.telegramDataDir, 'server.log')}`,
  ], {
    cwd: config.root,
    env: {
      ...process.env,
      TELEGRAM_API_ID: String(config.telegramApiId),
      TELEGRAM_API_HASH: config.telegramApiHash,
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  managedProcess = child;
  child.stdout.on('data', (chunk) => process.stdout.write(`[telegram-api] ${chunk}`));
  child.stderr.on('data', (chunk) => process.stderr.write(`[telegram-api] ${chunk}`));

  let exited = false;
  child.once('exit', (code) => {
    exited = true;
    if (managedProcess === child) managedProcess = null;
    if (code && code !== 0) console.error(`Telegram Bot API exited with code ${code}`);
  });

  const deadline = Date.now() + 120_000;
  while (Date.now() < deadline) {
    if (await healthy()) {
      console.log('Telegram Bot API started successfully.');
      return;
    }
    if (exited) break;
    await sleep(1000);
  }
  if (managedProcess === child) child.kill('SIGTERM');
  throw new Error('Telegram Bot API did not become ready. Check API_ID, API_HASH, BOT_TOKEN and server.log.');
}

export async function stopTelegramServer() {
  const child = managedProcess;
  if (!child || child.exitCode !== null || child.signalCode !== null) return;
  managedProcess = null;
  await new Promise((resolve) => {
    const timer = setTimeout(() => {
      if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
      resolve();
    }, 5000);
    child.once('exit', () => {
      clearTimeout(timer);
      resolve();
    });
    child.kill('SIGTERM');
  });
}
