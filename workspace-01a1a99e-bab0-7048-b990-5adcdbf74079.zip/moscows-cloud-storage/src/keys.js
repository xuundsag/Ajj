import { randomBytes, randomInt } from 'node:crypto';

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
export const FILE_KEY_PATTERN = /^[A-Z0-9]{8}$/;

export function createFileKey() {
  let key = '';
  for (let i = 0; i < 8; i += 1) key += ALPHABET[randomInt(ALPHABET.length)];
  return key;
}

export function createEncryptionKey() {
  return randomBytes(32).toString('base64url');
}

export function isEncryptionKey(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{43}$/.test(value);
}
