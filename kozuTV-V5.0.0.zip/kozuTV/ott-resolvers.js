// OTT Stream, Multi-Audio & Subtitle Resolvers — Strictly 3 Providers Only:
// 1. vidcore  -> vidcore.org (DEFAULT)
// 2. vidlink  -> vidlink.pro
// 3. vidsrc   -> vidsrc.to

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

export const OTT_SERVERS = [
  ['vidcore', 'vidcore.org'],
  ['vidlink', 'vidlink.pro'],
  ['vidsrc', 'vidsrc.to']
];
export const OTT_SERVER_KEYS = new Set(OTT_SERVERS.map(([k]) => k));
export const DEFAULT_OTT_SERVER = 'vidcore';

const VIDSPARK_PRIMARY_KEY = '3a67e8866ae1d2bb9e81fe7f73315a56eb3bdf5e3e755c7554c8be6910aa6b13';
const VIDORA_CDN_KEY = 'f3b72e73c80c9a996574379798703796a1936efa3516a7105cb0e43048b46b5a';

const langDisplay = (() => {
  try { return new Intl.DisplayNames(['en'], { type: 'language' }); }
  catch { return null; }
})();

const LANG_FALLBACK = {
  en: 'English', eng: 'English', hi: 'Hindi', hin: 'Hindi', ko: 'Korean', kor: 'Korean',
  ja: 'Japanese', jpn: 'Japanese', es: 'Spanish', spa: 'Spanish', fr: 'French', fra: 'French', fre: 'French',
  de: 'German', deu: 'German', ger: 'German', it: 'Italian', ita: 'Italian', pt: 'Portuguese', por: 'Portuguese',
  pb: 'Portuguese (BR)', pob: 'Portuguese (BR)', ru: 'Russian', rus: 'Russian', ar: 'Arabic', ara: 'Arabic',
  zh: 'Chinese', zho: 'Chinese', chi: 'Chinese', tr: 'Turkish', tur: 'Turkish', th: 'Thai', tha: 'Thai',
  vi: 'Vietnamese', vie: 'Vietnamese', id: 'Indonesian', ind: 'Indonesian', ms: 'Malay', may: 'Malay',
  ta: 'Tamil', tam: 'Tamil', te: 'Telugu', tel: 'Telugu', ml: 'Malayalam', mal: 'Malayalam',
  kn: 'Kannada', kan: 'Kannada', bn: 'Bengali', ben: 'Bengali', mr: 'Marathi', mar: 'Marathi',
  pa: 'Punjabi', pan: 'Punjabi', ur: 'Urdu', urd: 'Urdu', nl: 'Dutch', nld: 'Dutch', dut: 'Dutch',
  pl: 'Polish', pol: 'Polish', sv: 'Swedish', swe: 'Swedish', no: 'Norwegian', nor: 'Norwegian',
  da: 'Danish', dan: 'Danish', fi: 'Finnish', fin: 'Finnish', cs: 'Czech', ces: 'Czech', cze: 'Czech',
  el: 'Greek', ell: 'Greek', gre: 'Greek', hu: 'Hungarian', hun: 'Hungarian', ro: 'Romanian', ron: 'Romanian', rum: 'Romanian',
  uk: 'Ukrainian', ukr: 'Ukrainian', he: 'Hebrew', heb: 'Hebrew', fa: 'Persian', per: 'Persian', fas: 'Persian'
};

function readableLanguage(code, rawLabel = '') {
  const cleanLabel = String(rawLabel || '').trim();
  if (cleanLabel && cleanLabel.length > 3 && !/^[a-z]{2,3}$/i.test(cleanLabel)) return cleanLabel;
  const norm = String(code || cleanLabel || '').trim().toLowerCase();
  if (!norm) return 'Unknown';
  if (LANG_FALLBACK[norm]) return LANG_FALLBACK[norm];
  const base = norm.split(/[-_]/)[0];
  if (LANG_FALLBACK[base]) return LANG_FALLBACK[base];
  try {
    const resolved = langDisplay?.of(base);
    if (resolved && resolved.toLowerCase() !== base) return resolved;
  } catch {}
  return cleanLabel || norm.toUpperCase();
}

function mediaPathFor({ type, id, season, episode }) {
  return type === 'tv' ? `tv/${id}/${season}/${episode}` : `movie/${id}`;
}

async function fetchJsonSafe(url, { headers = {}, timeout = 7500 } = {}) {
  const res = await fetch(url, {
    headers: { 'User-Agent': UA, Accept: 'application/json, text/plain, */*', ...headers },
    redirect: 'follow',
    signal: AbortSignal.timeout(timeout)
  });
  if (!res.ok) return null;
  const text = await res.text();
  try { return JSON.parse(text); } catch { return null; }
}

function sortAndDedupeTracks(tracks) {
  const seenUrl = new Set();
  const seenLabel = new Map();
  const out = [];
  for (const t of tracks) {
    if (!t?.src || !/^https:\/\//i.test(t.src)) continue;
    if (seenUrl.has(t.src)) continue;
    seenUrl.add(t.src);
    const baseLabel = readableLanguage(t.language, t.label);
    const count = (seenLabel.get(baseLabel.toLowerCase()) || 0) + 1;
    seenLabel.set(baseLabel.toLowerCase(), count);
    out.push({
      src: t.src,
      kind: 'subtitles',
      language: String(t.language || 'und').toLowerCase().slice(0, 12),
      label: count > 1 ? `${baseLabel} (${count})` : baseLabel,
      proxyProvider: t.proxyProvider,
      headers: t.headers || {}
    });
  }
  out.sort((a, b) => {
    const aEn = /^en\b|^english/i.test(a.language) || /^english/i.test(a.label);
    const bEn = /^en\b|^english/i.test(b.language) || /^english/i.test(b.label);
    if (aEn !== bEn) return aEn ? -1 : 1;
    return a.label.localeCompare(b.label);
  });
  return out;
}

const subtitleCache = new Map();

async function fetchVidsparkSubtitles(input) {
  const path = mediaPathFor(input);
  const cacheKey = 'vs-sub:' + path;
  const hit = subtitleCache.get(cacheKey);
  if (hit && Date.now() - hit.time < 20 * 60_000) return hit.tracks;

  const data = await fetchJsonSafe(`https://vidspark.to/api/vidora/v1/subtitles/${path}`, {
    headers: {
      'x-player-key': VIDSPARK_PRIMARY_KEY,
      Referer: `https://vidspark.to/${path}`
    },
    timeout: 5500
  }).catch(() => null);

  const rawTracks = Array.isArray(data?.tracks) ? data.tracks : [];
  const mapped = [];
  for (const tr of rawTracks) {
    if (!tr?.src || tr.kind === 'thumbnails') continue;
    let absUrl;
    try {
      absUrl = /^https?:\/\//i.test(tr.src)
        ? tr.src
        : new URL(String(tr.src).replace(/^\/+/, ''), 'https://vidspark.to/api/vidora/').href;
    } catch { continue; }
    mapped.push({
      src: absUrl,
      language: tr.language || tr.srclang || 'und',
      label: tr.languageName || tr.label || '',
      proxyProvider: 'vidcore',
      headers: { Referer: 'https://vidspark.to/' }
    });
  }
  const tracks = sortAndDedupeTracks(mapped);
  if (tracks.length) {
    subtitleCache.set(cacheKey, { tracks, time: Date.now() });
    if (subtitleCache.size > 300) subtitleCache.delete(subtitleCache.keys().next().value);
  }
  return tracks;
}

async function fetchOpenSubtitles(input, imdbId) {
  const cleanImdb = String(imdbId || '').replace(/^tt/i, '').replace(/\D/g, '');
  if (!cleanImdb) return [];
  const cacheKey = `os:${cleanImdb}:${input.type === 'tv' ? `${input.season}:${input.episode}` : 'movie'}`;
  const hit = subtitleCache.get(cacheKey);
  if (hit && Date.now() - hit.time < 30 * 60_000) return hit.tracks;

  const endpoint = input.type === 'tv'
    ? `https://rest.opensubtitles.org/search/episode-${input.episode}/imdbid-${cleanImdb}/season-${input.season}`
    : `https://rest.opensubtitles.org/search/imdbid-${cleanImdb}`;

  const rows = await fetchJsonSafe(endpoint, {
    headers: { 'X-User-Agent': 'TemporaryUserAgent' },
    timeout: 5000
  }).catch(() => null);

  if (!Array.isArray(rows) || !rows.length) return [];
  const bestByLang = new Map();
  for (const row of rows) {
    const dl = row?.SubDownloadLink;
    const fmt = String(row?.SubFormat || '').toLowerCase();
    if (!dl || !/^https:\/\//i.test(dl) || (fmt && !['srt', 'vtt', 'subrip'].includes(fmt))) continue;
    const langKey = String(row.ISO639 || row.SubLanguageID || row.LanguageName || 'und').toLowerCase();
    const downloads = Number(row.SubDownloadsCnt) || 0;
    const prev = bestByLang.get(langKey);
    if (!prev || downloads > prev.downloads) {
      bestByLang.set(langKey, {
        downloads,
        src: dl,
        language: row.ISO639 || langKey,
        label: row.LanguageName || readableLanguage(langKey),
        proxyProvider: 'opensubtitles',
        headers: {}
      });
    }
  }
  const sorted = [...bestByLang.values()]
    .sort((a, b) => {
      const aEn = /^en/i.test(a.language) || /^english/i.test(a.label);
      const bEn = /^en/i.test(b.language) || /^english/i.test(b.label);
      if (aEn !== bEn) return aEn ? -1 : 1;
      return b.downloads - a.downloads;
    })
    .slice(0, 28);

  const tracks = sortAndDedupeTracks(sorted);
  if (tracks.length) {
    subtitleCache.set(cacheKey, { tracks, time: Date.now() });
    if (subtitleCache.size > 300) subtitleCache.delete(subtitleCache.keys().next().value);
  }
  return tracks;
}

function mapSourceTracks(rawTracks = [], proxyProvider, referer) {
  const out = [];
  for (const t of rawTracks) {
    const rawUrl = t?.file || t?.src || t?.url;
    if (!rawUrl || t?.kind === 'thumbnails' || /thumbnails/i.test(t?.label || '')) continue;
    try {
      const abs = new URL(rawUrl, referer).href;
      out.push({
        src: abs,
        language: t.language || t.srclang || t.lang || 'und',
        label: t.languageName || t.label || '',
        proxyProvider,
        headers: { Referer: referer }
      });
    } catch {}
  }
  return out;
}

function mapSourceQualities(rawQualities = [], proxyProvider, headers = {}) {
  if (!Array.isArray(rawQualities) || !rawQualities.length) return [];
  const out = [];
  for (const q of rawQualities) {
    const u = q?.url || q?.file;
    const h = Number(q?.height || String(q?.quality || q?.label || '').replace(/\D/g, '')) || 0;
    if (!u || !/^https:\/\//i.test(u) || !h) continue;
    out.push({
      tier: h >= 2000 ? 2160 : h >= 1350 ? 1440 : h >= 1000 ? 1080 : h >= 680 ? 720 : h >= 440 ? 480 : 360,
      height: h,
      url: u,
      kind: /\.mp4(?:\?|$)/i.test(u) ? 'mp4' : 'hls',
      codec: 'h264',
      proxyProvider,
      headers
    });
  }
  out.sort((a, b) => b.tier - a.tier);
  return out;
}

function scoreVidoraCandidate(cand) {
  if (!cand?.url) return 0;
  const u = cand.url.toLowerCase();
  if (Array.isArray(cand.qualities) && cand.qualities.length >= 2) return 105;
  if (u.includes('hd4u.') || cand.sourceKey === 'w7dn' || cand.sourceKey === 'fq1k') return 100;
  if (u.includes('majorplay.') || cand.sourceKey === 'nzv4') return 85;
  if (u.includes('hscow.') || cand.sourceKey === 'vjej') return 72;
  if (u.includes('workers.dev')) return 25;
  return 55;
}

function refererForStreamUrl(streamUrl, refererBase) {
  if (/\.workers\.dev\b/i.test(streamUrl)) return 'https://vidspark.to/';
  return `${refererBase}/`;
}

async function queryVidoraSource(host, path, sourceKey, refererBase, timeout = 4600) {
  const url = `${host}/api/vidora/v1/${path}?source=${encodeURIComponent(sourceKey)}`;
  const data = await fetchJsonSafe(url, {
    headers: {
      'x-player-key': VIDORA_CDN_KEY,
      Referer: `${refererBase}/${path}`
    },
    timeout
  });
  const srcObj = data?.sources?.find(s => s?.url && /^https:\/\//i.test(s.url));
  if (!srcObj) throw Error(`${sourceKey} unavailable`);
  const resolvedReferer = refererForStreamUrl(srcObj.url, refererBase);
  const cand = {
    sourceKey,
    imdbId: data.imdb_id || '',
    url: srcObj.url,
    kind: /\.mp4(?:\?|$)/i.test(srcObj.url) && !/\.m3u8|proxy/i.test(srcObj.url) ? 'mp4' : 'hls',
    headers: { Referer: resolvedReferer },
    tracks: Array.isArray(srcObj.tracks) ? srcObj.tracks : [],
    qualities: Array.isArray(srcObj.qualities) ? srcObj.qualities : []
  };
  cand.score = scoreVidoraCandidate(cand);
  return cand;
}

function raceBestVidora(promises, graceMs = 850) {
  return new Promise(resolve => {
    let best = null;
    let remaining = promises.length;
    let settled = false;
    let graceTimer = null;

    const finish = val => {
      if (settled) return;
      settled = true;
      if (graceTimer) clearTimeout(graceTimer);
      resolve(val);
    };

    if (!remaining) return finish(null);

    for (const p of promises) {
      Promise.resolve(p).then(cand => {
        remaining--;
        if (cand?.url && (!best || (cand.score || 0) > (best.score || 0))) {
          best = cand;
        }
        if (best && (best.score || 0) >= 100) return finish(best);
        if (best && (best.score || 0) >= 70 && !graceTimer) {
          graceTimer = setTimeout(() => finish(best), graceMs);
        }
        if (remaining <= 0) finish(best);
      }).catch(() => {
        remaining--;
        if (remaining <= 0) finish(best);
      });
    }
  });
}

// ============================================================================
// 1. VIDCORE.ORG (DEFAULT)
// ============================================================================
async function resolveVidcore(input, meta = {}) {
  const path = mediaPathFor(input);
  const origLang = String(meta?.originalLanguage || '').toLowerCase();
  const isNonEnglish = Boolean(origLang && origLang !== 'en');

  const tier1Promise = (async () => {
    const d = await fetchJsonSafe(`https://vidspark.to/api/vidora/v1/${path}`, {
      headers: {
        'x-player-key': VIDSPARK_PRIMARY_KEY,
        Referer: `https://vidspark.to/${path}`
      },
      timeout: 4500
    });
    const validSources = (d?.sources || []).filter(s => s?.url && /^https:\/\//i.test(s.url));
    if (!validSources.length) throw Error('VidCore primary unavailable');
    const primary = {
      sourceKey: 'vidspark',
      url: validSources[0].url,
      kind: /\.mp4(?:\?|$)/i.test(validSources[0].url) && !/\.m3u8|proxy/i.test(validSources[0].url) ? 'mp4' : 'hls',
      headers: { Referer: 'https://vidspark.to/' },
      tracks: Array.isArray(validSources[0].tracks) ? validSources[0].tracks : [],
      qualities: Array.isArray(validSources[0].qualities) ? validSources[0].qualities : []
    };
    primary.score = scoreVidoraCandidate(primary);
    return {
      imdbId: d.imdb_id || '',
      sources: validSources,
      primary
    };
  })();

  // Original-language multi-res sources (w7dn = 1080p/720p/480p/360p, nzv4 = 720p/360p, b4tz/k2mq = backups)
  const origCdnPromise = raceBestVidora([
    queryVidoraSource('https://cdn.vidspark.to', path, 'w7dn', 'https://cdn.vidspark.to', 4200),
    queryVidoraSource('https://cdn.vidspark.to', path, 'nzv4', 'https://cdn.vidspark.to', 4200),
    new Promise((res, rej) => setTimeout(() => queryVidoraSource('https://cdn.vidspark.to', path, 'b4tz', 'https://cdn.vidspark.to', 4000).then(res, rej), 300)),
    new Promise((res, rej) => setTimeout(() => queryVidoraSource('https://cdn.vidspark.to', path, 'k2mq', 'https://cdn.vidspark.to', 4000).then(res, rej), 500))
  ]);

  // English-audio multi-res sources (fq1k = 1080p/720p/480p/360p, vjej = 720p HD)
  const engCdnPromise = raceBestVidora([
    queryVidoraSource('https://cdn.vidspark.to', path, 'fq1k', 'https://cdn.vidspark.to', 4200),
    queryVidoraSource('https://cdn.vidspark.to', path, 'vjej', 'https://cdn.vidspark.to', 4200)
  ]);

  const subsPromise = fetchVidsparkSubtitles(input).catch(() => []);

  const [tier1Res, origCdn, engCdn, vsSubs] = await Promise.all([
    tier1Promise.catch(() => null),
    origCdnPromise,
    engCdnPromise,
    subsPromise
  ]);

  const origCandidates = [origCdn, tier1Res?.primary].filter(Boolean).sort((a, b) => (b.score || 0) - (a.score || 0));
  const origStream = origCandidates[0] || null;
  const allRanked = [origStream, engCdn].filter(Boolean).sort((a, b) => (b.score || 0) - (a.score || 0));
  const chosen = isNonEnglish ? (origStream || engCdn) : (allRanked[0] || null);
  if (!chosen) throw Error('vidcore.org has no playable stream for this title right now.');

  const audioStreams = [];
  if (tier1Res?.sources?.length > 1) {
    for (const [idx, s] of tier1Res.sources.entries()) {
      audioStreams.push({
        language: s.lang || s.language || (idx === 0 ? (origLang || 'und') : `und-${idx}`),
        label: s.label || s.name || (idx === 0 ? `${readableLanguage(origLang || 'en')} (Original)` : `Audio ${idx + 1}`),
        url: s.url,
        proxyProvider: 'vidcore',
        headers: { Referer: 'https://vidspark.to/' }
      });
    }
  } else if (isNonEnglish && origStream && engCdn && origStream.url !== engCdn.url) {
    audioStreams.push(
      {
        language: origLang,
        label: `${readableLanguage(origLang)} (Original)`,
        url: origStream.url,
        proxyProvider: 'vidcore',
        headers: origStream.headers
      },
      {
        language: 'en',
        label: 'English (Dub)',
        url: engCdn.url,
        proxyProvider: 'vidcore',
        headers: engCdn.headers
      }
    );
  }

  const qualityStreams = mapSourceQualities(chosen.qualities, 'vidcore', chosen.headers);
  const inlineTracks = [
    ...mapSourceTracks(chosen.tracks, 'vidcore', chosen.headers.Referer || 'https://vidspark.to/'),
    ...(origCdn && origCdn !== chosen ? mapSourceTracks(origCdn.tracks, 'vidcore', 'https://cdn.vidspark.to/') : []),
    ...(engCdn && engCdn !== chosen ? mapSourceTracks(engCdn.tracks, 'vidcore', 'https://cdn.vidspark.to/') : [])
  ];

  let tracks = sortAndDedupeTracks([...vsSubs, ...inlineTracks]);
  if (!tracks.length) {
    const imdbId = tier1Res?.imdbId || origCdn?.imdbId || engCdn?.imdbId || meta?.imdbId || '';
    tracks = await fetchOpenSubtitles(input, imdbId).catch(() => []);
  }

  return {
    url: chosen.url,
    kind: chosen.kind,
    headers: chosen.headers,
    tracks,
    audioStreams,
    qualityStreams,
    provider: 'vidcore.org',
    sourceKey: 'vidcore',
    proxyProvider: 'vidcore',
    server: 'vidcore.org'
  };
}

// ============================================================================
// 2. VIDLINK.PRO
// ============================================================================
const vidlinkEncCache = new Map();
let sharedPlaywrightBrowser = null;

async function getVidlinkEncryptedId(tmdbId) {
  const key = String(tmdbId);
  const hit = vidlinkEncCache.get(key);
  if (hit && Date.now() - hit.time < 6 * 3600_000) return hit.token;
  const d = await fetchJsonSafe(`https://enc-dec.app/api/enc-vidlink?text=${encodeURIComponent(key)}`, { timeout: 5000 });
  const token = typeof d?.result === 'string' && d.result.length > 8 ? d.result : null;
  if (token) {
    vidlinkEncCache.set(key, { token, time: Date.now() });
    if (vidlinkEncCache.size > 500) vidlinkEncCache.delete(vidlinkEncCache.keys().next().value);
  }
  return token;
}

async function fetchVidlinkViaPlaywright({ type, id, season, episode }) {
  const { chromium } = await import('playwright');
  if (!sharedPlaywrightBrowser || !sharedPlaywrightBrowser.isConnected()) {
    sharedPlaywrightBrowser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  }
  const pageUrl = type === 'tv' ? `https://vidlink.pro/tv/${id}/${season}/${episode}` : `https://vidlink.pro/movie/${id}`;
  const context = await sharedPlaywrightBrowser.newContext({
    userAgent: UA,
    extraHTTPHeaders: { 'X-Playback-Environment': 'hls' }
  });
  const page = await context.newPage();
  try {
    await page.route('**/*', route => {
      const u = route.request().url();
      const rt = route.request().resourceType();
      if (['image', 'font', 'media', 'stylesheet'].includes(rt) || /yandex|clarity|google|analytics|doubleclick|mercury|venus|rapidad|intellipopup/i.test(u)) {
        return route.abort();
      }
      return route.continue();
    });
    const apiPromise = page.waitForResponse(r => r.url().includes('/api/b/') && r.status() === 200, { timeout: 14_000 });
    await page.goto(pageUrl, { waitUntil: 'domcontentloaded', timeout: 14_000 });
    const res = await apiPromise;
    return await res.json();
  } finally {
    await context.close().catch(() => {});
  }
}

function tierNumberFromKey(rawKey, valueObj = {}) {
  const k = String(rawKey || '').toLowerCase();
  if (k.includes('4k') || k.includes('2160') || k.includes('uhd')) return 2160;
  if (k.includes('2k') || k.includes('1440') || k.includes('qhd')) return 1440;
  const digits = Number(k.replace(/\D/g, '')) || Number(valueObj?.height) || 0;
  if (digits >= 2000) return 2160;
  if (digits >= 1350) return 1440;
  if (digits >= 1000) return 1080;
  if (digits >= 680) return 720;
  if (digits >= 440) return 480;
  if (digits >= 320) return 360;
  return digits > 0 ? 240 : 0;
}

function parseVidlinkStreamPayload(payload) {
  const stream = payload?.stream;
  if (!stream) return null;

  const captions = (Array.isArray(stream.captions) ? stream.captions : [])
    .filter(c => c?.url && /^https:\/\//i.test(c.url))
    .map(c => ({
      src: c.url,
      language: c.language || c.srclang || 'und',
      label: c.language || c.label || '',
      proxyProvider: 'vidlink',
      headers: {}
    }));

  const audioStreams = [];
  const rawDubs = payload?.dubs || stream?.dubs || stream?.audioTracks || payload?.audioTracks;
  if (Array.isArray(rawDubs)) {
    for (const dub of rawDubs) {
      const dubUrl = dub?.playlist || dub?.url || dub?.file;
      if (!dubUrl || !/^https:\/\//i.test(dubUrl)) continue;
      audioStreams.push({
        language: dub.language || dub.lang || 'und',
        label: readableLanguage(dub.language || dub.lang, dub.label || dub.name),
        url: dubUrl,
        proxyProvider: 'vidlink',
        headers: dub.headers || stream.playlistHeaders || {}
      });
    }
  }

  // Case 1: HLS playlist (e.g. vodvidl.site H.264 HLS)
  if (typeof stream.playlist === 'string' && /^https:\/\//i.test(stream.playlist) && (stream.type === 'hls' || /\.m3u8/i.test(stream.playlist))) {
    const playlistHeaders = stream.playlistHeaders && typeof stream.playlistHeaders === 'object'
      ? stream.playlistHeaders
      : { Referer: 'https://vidlink.pro/', Origin: 'https://vidlink.pro' };
    return {
      url: stream.playlist,
      kind: 'hls',
      codec: 'h264',
      headers: playlistHeaders,
      captions,
      audioStreams,
      qualityStreams: []
    };
  }

  // Case 2: DASH manifest (sacdn.hakunaymatata.com via vidlink's surge.flooderrr.store proxy -> repackaged as multi-res HLS by dashUrl)
  if (typeof stream.playlist === 'string' && /^https:\/\//i.test(stream.playlist) && (stream.type === 'dash' || /\.mpd(?:\?|$)/i.test(stream.playlist))) {
    const u = new URL(stream.playlist);
    const cookie = stream.playlistHeaders?.Cookie || stream.playlistHeaders?.cookie || '';
    let dashTarget = stream.playlist;
    if (/\.hakunaymatata\.com$/i.test(u.hostname)) {
      const sub = u.hostname.split('.')[0];
      const sc = cookie ? Buffer.from(cookie, 'utf8').toString('base64').replace(/\+/g, '-').replace(/\//g, '_') : '';
      dashTarget = `https://surge.flooderrr.store/${sub}${u.pathname}?host=${encodeURIComponent(u.origin)}${sc ? `&sc=${sc}` : ''}`;
    }
    const isHevc = /hevc|h265|x265|hev1|hvc1/i.test(String(stream.playbackMetadata?.codecName || stream.playlist));
    return {
      url: dashTarget,
      kind: 'dash',
      codec: isHevc ? 'hevc' : 'h264',
      headers: { Referer: 'https://vidlink.pro/', Origin: 'https://vidlink.pro' },
      captions,
      audioStreams,
      qualityStreams: []
    };
  }

  // Case 3: Multi-quality direct MP4 streams
  const qualitiesObj = stream.qualities && typeof stream.qualities === 'object' ? stream.qualities : {};
  const qualityStreams = [];
  for (const [key, val] of Object.entries(qualitiesObj)) {
    const qUrl = typeof val === 'string' ? val : val?.url;
    if (!qUrl || !/^https:\/\//i.test(qUrl) || /\.hakunaymatata\.com$/i.test(new URL(qUrl).hostname)) continue;
    const tier = tierNumberFromKey(key, val);
    if (!tier) continue;
    const isHevc = /hevc|h265|x265|hev1|hvc1/i.test(String(val?.codecName || val?.codec || qUrl));
    qualityStreams.push({
      tier,
      height: tier,
      url: qUrl,
      kind: 'mp4',
      codec: isHevc ? 'hevc' : 'h264',
      proxyProvider: 'vidlink',
      headers: { Referer: 'https://vidlink.pro/' }
    });
  }
  if (!qualityStreams.length) return null;

  qualityStreams.sort((a, b) => (b.tier - a.tier) || ((a.codec === 'h264' ? 0 : 1) - (b.codec === 'h264' ? 0 : 1)));
  const bestH264 = qualityStreams.find(q => q.codec === 'h264');
  const defaultPick = bestH264 || qualityStreams[0];

  return {
    url: defaultPick.url,
    kind: 'mp4',
    codec: defaultPick.codec,
    headers: { Referer: 'https://vidlink.pro/' },
    captions,
    audioStreams,
    qualityStreams
  };
}

async function resolveVidlink(input, meta = {}) {
  let parsed = null;
  const enc = await getVidlinkEncryptedId(input.id).catch(() => null);
  const pageRef = input.type === 'tv'
    ? `https://vidlink.pro/tv/${input.id}/${input.season}/${input.episode}`
    : `https://vidlink.pro/movie/${input.id}`;

  if (enc) {
    const baseApi = input.type === 'tv'
      ? `https://vidlink.pro/api/b/tv/${enc}/${input.season}/${input.episode}`
      : `https://vidlink.pro/api/b/movie/${enc}`;
    const [webkitData, hlsData] = await Promise.all([
      fetchJsonSafe(`${baseApi}?multiLang=0`, {
        headers: { Referer: pageRef, Origin: 'https://vidlink.pro', 'X-Playback-Environment': 'webkit' },
        timeout: 7500
      }).catch(() => null),
      fetchJsonSafe(`${baseApi}?multiLang=1`, {
        headers: { Referer: pageRef, Origin: 'https://vidlink.pro', 'X-Playback-Environment': 'hls' },
        timeout: 7500
      }).catch(() => null)
    ]);

    const pWebkit = parseVidlinkStreamPayload(webkitData);
    const pHls = parseVidlinkStreamPayload(hlsData);

    // Prefer H.264 HLS when available, otherwise use webkit DASH (1080p/720p/480p via surge.flooderrr.store -> dashUrl)
    if (pHls?.kind === 'hls') {
      parsed = { ...pHls, captions: [...pHls.captions, ...(pWebkit?.captions || [])] };
    } else if (pWebkit) {
      parsed = { ...pWebkit, captions: [...pWebkit.captions, ...(pHls?.captions || [])] };
    } else {
      parsed = pHls;
    }
  } else {
    const pwData = await fetchVidlinkViaPlaywright(input).catch(() => null);
    parsed = parseVidlinkStreamPayload(pwData);
  }

  if (!parsed) throw Error('vidlink.pro has no playable stream for this title right now.');

  let tracks = sortAndDedupeTracks(parsed.captions);
  if (!tracks.length) {
    tracks = await fetchVidsparkSubtitles(input).catch(() => []);
    if (!tracks.length && meta?.imdbId) {
      tracks = await fetchOpenSubtitles(input, meta.imdbId).catch(() => []);
    }
  }

  return {
    url: parsed.url,
    kind: parsed.kind,
    codec: parsed.codec || 'h264',
    headers: parsed.headers,
    tracks,
    audioStreams: parsed.audioStreams,
    qualityStreams: parsed.qualityStreams,
    provider: 'vidlink.pro',
    sourceKey: 'vidlink',
    proxyProvider: 'vidlink',
    server: 'vidlink.pro'
  };
}

// ============================================================================
// 3. VIDSRC.TO
// ============================================================================
async function fetchVidsrcShMeta({ type, id, season, episode }) {
  const qs = new URLSearchParams({ type, tmdb: String(id) });
  if (type === 'tv') {
    qs.set('season', String(season));
    qs.set('episode', String(episode));
  }
  return fetchJsonSafe(`https://data.vidsrc.sh/api.php?${qs}`, {
    headers: { Referer: 'https://vidsrc.sh/' },
    timeout: 4500
  }).catch(() => null);
}

async function resolveVidsrc(input, meta = {}) {
  const path = mediaPathFor(input);
  const origLang = String(meta?.originalLanguage || '').toLowerCase();
  const isNonEnglish = Boolean(origLang && origLang !== 'en');

  const origPromise = raceBestVidora([
    queryVidoraSource('https://vidsrc.pm', path, 'w7dn', 'https://vidsrc.pm', 4200),
    queryVidoraSource('https://vidsrc.pm', path, 'nzv4', 'https://vidsrc.pm', 4200),
    new Promise((res, rej) => setTimeout(() => queryVidoraSource('https://vidsrc.pm', path, 'b4tz', 'https://vidsrc.pm', 4000).then(res, rej), 300)),
    new Promise((res, rej) => setTimeout(() => queryVidoraSource('https://vidsrc.pm', path, 'k2mq', 'https://vidsrc.pm', 4000).then(res, rej), 500))
  ]);

  const engPromise = raceBestVidora([
    queryVidoraSource('https://vidsrc.pm', path, 'fq1k', 'https://vidsrc.pm', 4200),
    queryVidoraSource('https://vidsrc.pm', path, 'vjej', 'https://vidsrc.pm', 4200)
  ]);

  const [shMeta, origSrc, engSrc, vsSubs] = await Promise.all([
    fetchVidsrcShMeta(input),
    origPromise,
    engPromise,
    fetchVidsparkSubtitles(input).catch(() => [])
  ]);

  const allRanked = [origSrc, engSrc].filter(Boolean).sort((a, b) => (b.score || 0) - (a.score || 0));
  const chosen = isNonEnglish ? (origSrc || engSrc) : (allRanked[0] || null);
  if (!chosen) throw Error('vidsrc.to has no playable stream for this title right now.');

  const audioStreams = [];
  if (isNonEnglish && origSrc && engSrc && origSrc.url !== engSrc.url) {
    audioStreams.push(
      {
        language: origLang,
        label: `${readableLanguage(origLang)} (Original)`,
        url: origSrc.url,
        proxyProvider: 'vidsrc',
        headers: origSrc.headers
      },
      {
        language: 'en',
        label: 'English (Dub)',
        url: engSrc.url,
        proxyProvider: 'vidsrc',
        headers: engSrc.headers
      }
    );
  }

  const qualityStreams = mapSourceQualities(chosen.qualities, 'vidsrc', chosen.headers);
  const inlineTracks = [
    ...mapSourceTracks(chosen.tracks, 'vidsrc', 'https://vidsrc.pm/'),
    ...(origSrc && origSrc !== chosen ? mapSourceTracks(origSrc.tracks, 'vidsrc', 'https://vidsrc.pm/') : []),
    ...(engSrc && engSrc !== chosen ? mapSourceTracks(engSrc.tracks, 'vidsrc', 'https://vidsrc.pm/') : [])
  ];

  const imdbId = shMeta?.data?.imdb_id || chosen.imdbId || origSrc?.imdbId || engSrc?.imdbId || meta?.imdbId || '';
  let tracks = sortAndDedupeTracks([...inlineTracks, ...vsSubs]);
  if (!tracks.length && imdbId) {
    tracks = await fetchOpenSubtitles(input, imdbId).catch(() => []);
  }

  return {
    url: chosen.url,
    kind: chosen.kind,
    headers: chosen.headers,
    tracks,
    audioStreams,
    qualityStreams,
    provider: 'vidsrc.to',
    sourceKey: 'vidsrc',
    proxyProvider: 'vidsrc',
    server: 'vidsrc.to'
  };
}

// ============================================================================
// UNIFIED OTT ROUTER + STRICT 3-SERVER FAILOVER
// ============================================================================
const RESOLVER_BY_KEY = {
  vidcore: resolveVidcore,
  vidlink: resolveVidlink,
  vidsrc: resolveVidsrc
};

const resolvedCache = new Map();

export async function resolveOttWithFallback(input, requestedProvider = DEFAULT_OTT_SERVER, getTmdbMeta = null) {
  const startKey = OTT_SERVER_KEYS.has(requestedProvider) ? requestedProvider : DEFAULT_OTT_SERVER;
  const order = [startKey, ...['vidcore', 'vidlink', 'vidsrc'].filter(k => k !== startKey)];

  const meta = getTmdbMeta ? await getTmdbMeta(input).catch(() => ({})) : {};
  let lastError = null;

  for (const key of order) {
    const cacheKey = `${key}:${input.type}:${input.id}:${input.type === 'tv' ? `${input.season}:${input.episode}` : 'm'}`;
    const hit = resolvedCache.get(cacheKey);
    if (hit && Date.now() - hit.time < 180_000) return hit.value;

    try {
      const value = await RESOLVER_BY_KEY[key](input, meta);
      resolvedCache.set(cacheKey, { value, time: Date.now() });
      if (resolvedCache.size > 250) resolvedCache.delete(resolvedCache.keys().next().value);
      return value;
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || Error('No playable stream found across vidcore.org, vidlink.pro, or vidsrc.to.');
}
