import freekeys from 'freekeys';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { resolveMegaPlayDirect, enrichAnimeQualityStreams } from './megaplay-resolver.js';
import { mediaUrl, dashUrl, handleMedia, handleDash } from './media-proxy.js';
import { OTT_SERVER_KEYS, DEFAULT_OTT_SERVER, resolveOttWithFallback } from './ott-resolvers.js';

const root = path.resolve('public');
const db = path.resolve('data/user.json');
const statesDb = path.resolve('data/states.json');
const initial = { watchlist: [], history: [] };
if (!fs.existsSync(db)) fs.writeFileSync(db, JSON.stringify(initial));
if (!fs.existsSync(statesDb)) fs.writeFileSync(statesDb, JSON.stringify({ visitors: {}, meta: {} }));

const json = (res, data, status = 200, req = null) => {
  let body = JSON.stringify(data), accept = String(req?.headers?.['accept-encoding'] || '');
  if (body.length > 1024 && accept.includes('gzip')) {
    let gz = zlib.gzipSync(body, { level: 4 });
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Encoding': 'gzip', 'Vary': 'Accept-Encoding', 'Cache-Control': 'no-store' });
    return res.end(gz);
  }
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
};

const cache = new Map();
async function remote(url, options = {}) {
  let ttl = options.ttl ?? 300000, c = cache.get(url);
  if (c && Date.now() - c.time < (c.ttl || ttl)) return c.data;
  let r = await fetch(url, {
    headers: { 'User-Agent': 'kozuTV/5.0 (catalog app)', ...(options.headers || {}) },
    signal: AbortSignal.timeout(options.timeout || 12000)
  });
  let text = await r.text();
  if (!r.ok) throw Error('Catalog unavailable (' + r.status + ')');
  let data;
  try { data = JSON.parse(text); } catch { throw Error('A catalog service returned an invalid response.'); }
  cache.set(url, { data, time: Date.now(), ttl });
  return data;
}

const genreNames = { 28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy', 80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family', 14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music', 9648: 'Mystery', 10749: 'Romance', 878: 'Science Fiction', 10770: 'TV Movie', 53: 'Thriller', 10752: 'War', 37: 'Western', 10759: 'Action & Adventure', 10765: 'Sci-Fi & Fantasy' };
const catalogGenres = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Horror', 'Mecha', 'Music', 'Mystery', 'Psychological', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller'];
const movieGenreIds = { Action: 28, Adventure: 12, Animation: 16, Comedy: 35, Crime: 80, Documentary: 99, Drama: 18, Family: 10751, Fantasy: 14, Horror: 27, Music: 10402, Mystery: 9648, Romance: 10749, 'Sci-Fi': 878, Thriller: 53 };
const tvGenreIds = { Action: 10759, Adventure: 10759, Animation: 16, Comedy: 35, Crime: 80, Documentary: 99, Drama: 18, Family: 10751, Fantasy: 10765, Mystery: 9648, 'Sci-Fi': 10765 };

const today = () => new Date().toISOString().slice(0, 10);
const releasedDate = value => Boolean(value) && /^\d{4}-\d{2}-\d{2}$/.test(String(value).slice(0, 10)) && String(value).slice(0, 10) <= today();

function decodeEntities(value) {
  return String(value || '')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&(amp|quot|apos|lt|gt|hellip|mdash|ndash);/g, (_, name) => ({ amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', hellip: '…', mdash: '—', ndash: '–' })[name]);
}
function normalizeTitle(value) {
  return String(value || '').toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, ' ').trim();
}

const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
function parseAiredStartDate(aired, year) {
  const s = String(aired || '').split(/\s+to\s+/i)[0].trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  if (/^\d{4}-\d{2}$/.test(s)) return `${s}-01`;
  const m1 = s.match(/^([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})$/);
  if (m1) {
    const mo = MONTHS[m1[1].slice(0, 3).toLowerCase()];
    if (mo) return `${m1[3]}-${String(mo).padStart(2, '0')}-${String(m1[2]).padStart(2, '0')}`;
  }
  const m2 = s.match(/^([A-Za-z]{3,9})\s+(\d{4})$/);
  if (m2) {
    const mo = MONTHS[m2[1].slice(0, 3).toLowerCase()];
    if (mo) return `${m2[2]}-${String(mo).padStart(2, '0')}-01`;
  }
  if (/^\d{4}$/.test(s) && Number(s) > new Date().getFullYear()) return `${s}-01-01`;
  if (year && Number(year) > new Date().getFullYear()) return `${year}-01-01`;
  return '';
}

const megaCatalogPath = path.resolve('data/megaplay-catalog.json');
let megaEntries = [], megaAliases = [];
try {
  let d = JSON.parse(fs.readFileSync(megaCatalogPath));
  megaEntries = Array.isArray(d.entries) ? d.entries : [];
  megaAliases = Array.isArray(d.aliases) ? d.aliases : [];
} catch {}

// Build alias set across ALL anime entries (including unreleased) so unreleased/unavailable anime on TMDB never leaks into Movies/TV
const megaAliasSet = new Set(megaAliases.map(normalizeTitle).filter(Boolean));
for (let entry of megaEntries) {
  for (let raw of [entry.title, entry.english, entry.alternative, ...String(entry.titles || '').split(/[;,]/)]) {
    let norm = normalizeTitle(raw);
    if (norm && norm.length >= 3) megaAliasSet.add(norm);
  }
}

function animeAliasMatch(title) {
  let key = normalizeTitle(title);
  if (!key) return false;
  if (megaAliasSet.has(key)) return true;
  for (let alias of megaAliasSet) {
    if (alias.length > 4 && (key === alias || key.startsWith(alias + ' ') || key.endsWith(' ' + alias))) return true;
  }
  return false;
}

function validAnikotoEntry(entry) {
  let year = Number(entry?.year) || 0;
  if (!entry?.mal || !entry?.id || !entry?.poster) return false;
  if (!(Number(entry.episodes) > 0)) return false;
  if (year > new Date().getFullYear()) return false;
  if (/not yet|upcoming|unreleased/i.test(entry.status || '')) return false;
  let start = parseAiredStartDate(entry.aired, entry.year);
  if (start && start > today()) return false;
  return true;
}

// Strict MegaPlay playable maps ONLY contain released, streamable MegaPlay entries!
const megaByMal = new Map(), megaByAni = new Map();
const playableMegaEntries = megaEntries.filter(validAnikotoEntry);
for (let entry of playableMegaEntries) {
  if (entry.mal && !megaByMal.has(String(entry.mal))) megaByMal.set(String(entry.mal), entry);
  if (entry.ani && !megaByAni.has(String(entry.ani))) megaByAni.set(String(entry.ani), entry);
}
function megaForMedia(media) { return megaByAni.get(String(media?.id || '')) || megaByMal.get(String(media?.idMal || '')) || null; }
function megaForIds(mal, ani) { return megaByMal.get(String(mal || '')) || megaByAni.get(String(ani || '')) || null; }

const japaneseAnimation = x => {
  let animated = Boolean(x.genre_ids?.includes(16) || x.genres?.some(g => g.id === 16 || g.name === 'Animation'));
  if (!animated) return false;
  let origLang = String(x.original_language || '').toLowerCase();
  let countries = Array.isArray(x.origin_country) ? x.origin_country : [];
  if (['ja', 'zh', 'cn', 'ko'].includes(origLang) || countries.some(c => ['JP', 'CN', 'KR'].includes(c))) return true;
  if (origLang === 'en' && !countries.includes('JP')) return false;
  return animeAliasMatch(x.title || x.name) || animeAliasMatch(x.original_title || x.original_name);
};

const UNRELEASED_OTT_STATUSES = new Set(['rumored', 'planned', 'in production', 'post production', 'pilot', 'canceled']);
function releasedOtt(x, minVotes = 3) {
  if (!x || x.adult) return false;
  if (!x.poster_path) return false;
  if (!(x.title || x.name)) return false;
  if (!releasedDate(x.release_date || x.first_air_date)) return false;
  if (x.status && UNRELEASED_OTT_STATUSES.has(String(x.status).toLowerCase())) {
    if (!(String(x.status).toLowerCase() === 'canceled' && Number(x.number_of_episodes) > 0)) return false;
  }
  if ((x.media_type === 'tv' || (!x.media_type && x.first_air_date)) && x.number_of_episodes !== undefined && Number(x.number_of_episodes) <= 0) {
    return false;
  }
  let votes = Number(x.vote_count) || 0, pop = Number(x.popularity) || 0;
  if (minVotes > 0 && votes < minVotes && pop < 5) return false;
  if (japaneseAnimation(x)) return false;
  return true;
}

const ott = x => ({
  id: String(x.id),
  type: x.media_type === 'tv' || (!x.media_type && x.first_air_date) ? 'tv' : 'movie',
  title: x.title || x.name || '',
  originalTitle: x.original_title || x.original_name || '',
  poster: x.poster_path ? 'https://image.tmdb.org/t/p/w500' + x.poster_path : null,
  backdrop: x.backdrop_path ? 'https://image.tmdb.org/t/p/original' + x.backdrop_path : null,
  description: x.overview || '',
  rating: x.vote_average ? Number(x.vote_average.toFixed(1)) : null,
  popularity: Number(x.popularity) || 0,
  voteCount: Number(x.vote_count) || 0,
  year: (x.release_date || x.first_air_date || '').slice(0, 4),
  releaseDate: x.release_date || x.first_air_date || null,
  japaneseAnimation: japaneseAnimation(x),
  genres: x.genres?.map(g => g.name) || x.genre_ids?.map(id => genreNames[id]).filter(Boolean) || [],
  seasons: x.number_of_seasons
});

const aniCache = new Map();
async function anilist(query, variables = {}, timeout = 10000) {
  let key = JSON.stringify([query, variables]), cached = aniCache.get(key);
  if (cached && Date.now() - cached.time < 300000) return cached.data;
  let r = await fetch('https://graphql.anilist.co', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
    signal: AbortSignal.timeout(timeout)
  });
  if (!r.ok) throw Error('Anime catalog unavailable');
  let text = await r.text(), d;
  try { d = JSON.parse(text); } catch { throw Error('Anime catalog returned an invalid response.'); }
  if (d.errors) throw Error(d.errors[0].message);
  aniCache.set(key, { data: d.data, time: Date.now() });
  return d.data;
}

const fields = 'id idMal title{english romaji native} synonyms popularity coverImage{extraLarge large} bannerImage description(asHtml:false) averageScore format seasonYear startDate{year month day} episodes nextAiringEpisode{episode} genres status isAdult';
const positiveInt = value => Number.isInteger(Number(value)) && Number(value) > 0 ? Number(value) : null;
function animeEpisodeCount(media) {
  if (media.format === 'MOVIE' || media.status === 'NOT_YET_RELEASED') return null;
  let total = positiveInt(media.episodes);
  if (media.status === 'RELEASING') {
    let released = positiveInt((media.nextAiringEpisode?.episode || 1) - 1);
    if (released) return total ? Math.min(total, released) : released;
  }
  return total;
}

const spotlightCatalogPath = path.resolve('data/spotlight.json');
let spotlightCatalog = [];
try {
  let d = JSON.parse(fs.readFileSync(spotlightCatalogPath, 'utf8'));
  if (Array.isArray(d)) {
    spotlightCatalog = d.filter(x => x?.id && x?.type && x?.title && x?.backdrop && x?.spotlightBanner && (x.type !== 'anime' || megaByMal.has(String(x.id))));
  }
} catch {}

function cryptoShuffle(list) {
  let a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    let j = crypto.randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function buildRandomizedSpotlight() {
  if (!spotlightCatalog.length) return [];
  let isRomance = x => (x.genres || []).some(g => /romance/i.test(g));
  let romance = cryptoShuffle(spotlightCatalog.filter(isRomance));
  let others = cryptoShuffle(spotlightCatalog.filter(x => !isRomance(x)));
  let romCount = Math.min(romance.length, crypto.randomInt(2, 4));
  let lead = cryptoShuffle([...romance.slice(0, romCount), ...others.slice(0, Math.max(0, 6 - romCount))]);
  let tail = cryptoShuffle([...romance.slice(romCount), ...others.slice(Math.max(0, 6 - romCount))]);
  return [...lead, ...tail];
}

function releasedAnime(media) {
  if (!['FINISHED', 'RELEASING'].includes(media?.status)) return false;
  let d = media.startDate;
  if (!d?.year) return false;
  let date = `${d.year}-${String(d.month || 1).padStart(2, '0')}-${String(d.day || 1).padStart(2, '0')}`;
  if (date > today()) return false;
  if (media.status === 'RELEASING' && media.nextAiringEpisode?.episode === 1) return false;
  return true;
}

async function anikotoSeries(providerId) {
  let d = await remote(`https://anikotoapi.site/series/${encodeURIComponent(providerId)}`, { ttl: 21600000, timeout: 9000, headers: { Accept: 'application/json' } });
  if (!d.ok || !d.data?.anime || !Array.isArray(d.data.episodes)) throw Error('MegaPlay returned an invalid series response.');
  return d.data;
}

function cleanAnimeDisplayTitle(entry) {
  let primary = decodeEntities(entry.title || '').replace(/\s*\(TV\)\s*$/i, '').trim();
  let cjkIdx = primary.search(/[\u3040-\u30ff\u3400-\u9fff]/);
  if (cjkIdx > 6) primary = primary.slice(0, cjkIdx).trim();
  let engFirst = decodeEntities(String(entry.english || '').split(';')[0]).replace(/\s*\(TV\)\s*$/i, '').trim();
  if (primary && !/[\u3040-\u30ff\u3400-\u9fff]/.test(primary)) {
    if (
      engFirst.length > 4 &&
      !/^(Sorcery Fight|Blade of Demon Destruction|Na Honjaman|Naruto Hurricane|AoT$)/i.test(engFirst) &&
      /\b(Link Click|Bungo Stray Dogs|Kaguya-sama|My Dress-Up Darling|Frieren|Chainsaw Man|Spy x Family|My Hero Academia|Demon Slayer|Attack on Titan|Fullmetal Alchemist|Hunter x Hunter|Mob Psycho|Steins;Gate|Re:Zero|Konosuba|Mushoku Tensei|That Time I Got Reincarnated|Apothecary Diaries|Blue Box|Dandadan|Oshi no Ko|Haikyu|Vinland Saga| Rascal Does Not Dream|Fruits Basket|Violet Evergarden|Code Geass|Your Lie in April|Assassination Classroom|promised Neverland|Tokyo Ghoul|Black Clover|Fire Force|Dr\. Stone|Overlord|Classroom of the Elite|Horimiya|Toradora)\b/i.test(engFirst)
    ) {
      return engFirst;
    }
    return primary;
  }
  return engFirst.length > 2 ? engFirst : primary;
}

function anikotoItem(entry) {
  let format = String(entry.format || '').toUpperCase(), isMovie = format.includes('MOVIE');
  let score = Number.parseFloat(entry.score);
  let displayTitle = cleanAnimeDisplayTitle(entry);
  let status = /currently/i.test(entry.status) ? 'RELEASING' : 'FINISHED';
  let cleanDesc = decodeEntities(entry.description || '').replace(/\s*\[Written by MAL Rewrite\]\s*$/i, '').trim();
  return {
    id: String(entry.mal),
    anilistId: entry.ani ? String(entry.ani) : null,
    type: 'anime',
    title: displayTitle,
    poster: entry.poster || null,
    backdrop: entry.backdrop || null,
    description: cleanDesc,
    rating: Number.isFinite(score) && score > 0 ? score : null,
    year: entry.year || null,
    episodes: isMovie ? null : entry.episodes,
    episodeCountKind: 'available',
    genres: entry.genres || [],
    status,
    format,
    isMovie,
    playable: true,
    providerId: entry.id,
    dub: Boolean(entry.dub),
    updated: entry.updated || ''
  };
}

const anikotoItems = playableMegaEntries.map(anikotoItem);

const ani = x => {
  let isMovie = x.format === 'MOVIE', provider = megaForMedia(x);
  let episodes = animeEpisodeCount(x) || (isMovie ? null : positiveInt(provider?.episodes));
  return {
    id: String(x.idMal),
    anilistId: String(x.id),
    type: 'anime',
    title: x.title?.english || x.title?.romaji || provider?.english || provider?.title || '',
    poster: x.coverImage?.extraLarge || x.coverImage?.large || provider?.poster,
    backdrop: x.bannerImage || provider?.backdrop || x.coverImage?.extraLarge,
    description: (x.description || '').replace(/<[^>]*>/g, '') || provider?.description || '',
    rating: x.averageScore ? Number((x.averageScore / 10).toFixed(1)) : (provider?.score ? Number.parseFloat(provider.score) : null),
    popularity: Number(x.popularity) || 0,
    year: x.seasonYear || x.startDate?.year || provider?.year,
    episodes,
    episodeCountKind: x.status === 'RELEASING' ? 'released' : 'total',
    genres: x.genres?.length ? x.genres : (provider?.genres || []),
    status: x.status,
    format: x.format || provider?.format || null,
    isMovie,
    playable: Boolean(provider),
    providerId: provider?.id || null,
    dub: Boolean(provider?.dub)
  };
};

// ============================================================================
// High-Precision Multi-Source Search Index & Relevance Ranking Engine
// ============================================================================
const STOP_WORDS = new Set(['the', 'a', 'an', 'of', 'in', 'on', 'at', 'to', 'for', 'and', 'no', 'ni', 'wa', 'ga', 'wo']);

function buildAcronym(norm) {
  const words = norm.split(' ').filter(w => w.length > 0 && !/^\d+$/.test(w));
  if (words.length < 2 || words.length > 7) return '';
  const full = words.map(w => w[0]).join('');
  return full.length >= 2 ? full : '';
}

const indexedAnime = playableMegaEntries.map((entry, rankIdx) => {
  const item = anikotoItems[rankIdx];
  const primaryNorm = normalizeTitle(item.title);
  const rawNames = [
    item.title,
    entry.title,
    entry.english,
    entry.alternative,
    entry.native,
    ...String(entry.titles || '').split(/[;,]/),
  ];
  const candSet = new Set();
  for (const r of rawNames) {
    const n = normalizeTitle(r);
    if (n) {
      candSet.add(n);
      const ac = buildAcronym(n);
      if (ac.length >= 3) candSet.add(ac);
    }
  }
  const candidates = [...candSet];
  const compacts = candidates.map(c => c.replace(/\s+/g, '')).filter(Boolean);
  const wordSet = new Set();
  for (const c of candidates) {
    for (const w of c.split(' ')) if (w) wordSet.add(w);
  }
  // Popularity proxy combining MAL score + episode longevity + catalog recency
  const popProxy = ((item.rating || 6.5) ** 3) * (entry.dub ? 1.35 : 1) * (String(entry.format || '').toUpperCase() === 'TV' ? 1.25 : 1);
  return {
    entry,
    item,
    primaryNorm,
    primaryCompact: primaryNorm.replace(/\s+/g, ''),
    candidates,
    compacts,
    words: [...wordSet],
    popProxy
  };
});

function editDistanceAtMost(a, b, maxDist) {
  const la = a.length, lb = b.length;
  if (Math.abs(la - lb) > maxDist) return maxDist + 1;
  if (a === b) return 0;
  let prev = new Uint16Array(lb + 1);
  let curr = new Uint16Array(lb + 1);
  for (let j = 0; j <= lb; j++) prev[j] = j;
  for (let i = 1; i <= la; i++) {
    curr[0] = i;
    let rowMin = curr[0];
    const ca = a.charCodeAt(i - 1);
    for (let j = 1; j <= lb; j++) {
      const cost = ca === b.charCodeAt(j - 1) ? 0 : 1;
      const v = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
      curr[j] = v;
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > maxDist) return maxDist + 1;
    [prev, curr] = [curr, prev];
  }
  return prev[lb];
}

function scoreCandidateMatch(qNorm, qCompact, qWords, primaryNorm, primaryCompact, candidates, compacts, allWords) {
  if (!qNorm) return 0;
  let best = 0;

  // 1. Exact primary or alias match
  if (primaryNorm === qNorm || (qCompact.length >= 2 && primaryCompact === qCompact)) {
    best = Math.max(best, 2500);
  }
  for (let i = 0; i < candidates.length; i++) {
    const c = candidates[i], cc = compacts[i];
    if (c === qNorm || (qCompact.length >= 3 && cc === qCompact)) {
      best = Math.max(best, 2200);
    } else if (c.startsWith(qNorm + ' ') || c.startsWith(qNorm)) {
      const penalty = Math.min(220, Math.max(0, c.length - qNorm.length) * 3);
      best = Math.max(best, (c === primaryNorm ? 1720 : 1520) - penalty);
    } else if (qCompact.length >= 3 && cc.startsWith(qCompact)) {
      const penalty = Math.min(220, Math.max(0, cc.length - qCompact.length) * 3);
      best = Math.max(best, 1460 - penalty);
    } else if ((' ' + c + ' ').includes(' ' + qNorm + ' ')) {
      best = Math.max(best, c === primaryNorm ? 1280 : 1140);
    } else if (qCompact.length >= 4 && cc.includes(qCompact)) {
      best = Math.max(best, 960);
    }
  }
  if (best >= 1460) return best;

  // 2. Multi-word / prefix token match within a single candidate
  if (qWords.length >= 1) {
    for (const c of candidates) {
      const cWords = c.split(' ');
      if (qWords.every(qw => cWords.some(cw => cw.startsWith(qw)))) {
        const lenDiff = Math.min(180, Math.max(0, cWords.length - qWords.length) * 22);
        best = Math.max(best, (c === primaryNorm ? 1180 : 1060) - lenDiff);
      }
    }
  }
  if (best >= 1000) return best;

  // 3. Cross-alias prefix + fuzzy typo tolerance (handles "frieran", "interstelar", "jujtsu", "spider verse", etc.)
  const sigWords = qWords.filter(w => !STOP_WORDS.has(w));
  const checkWords = sigWords.length ? sigWords : qWords;
  let exactOrPrefixHits = 0;
  let fuzzyHits = 0;
  for (const qw of checkWords) {
    if (allWords.some(cw => cw === qw || (qw.length >= 2 && cw.startsWith(qw)))) {
      exactOrPrefixHits++;
      continue;
    }
    if (qw.length >= 4) {
      const maxEd = qw.length >= 7 ? 2 : 1;
      if (allWords.some(cw => cw.length >= 3 && editDistanceAtMost(qw, cw.slice(0, Math.max(cw.length, qw.length)), maxEd) <= maxEd)) {
        fuzzyHits++;
      }
    }
  }
  const totalMatched = exactOrPrefixHits + fuzzyHits;
  if (totalMatched === checkWords.length && checkWords.length > 0) {
    best = Math.max(best, fuzzyHits === 0 ? 880 : 660 - fuzzyHits * 35);
  } else if (checkWords.length >= 2 && totalMatched / checkWords.length >= 0.66) {
    best = Math.max(best, Math.round(420 * (totalMatched / checkWords.length)));
  }

  return best;
}

function finalizeSearchScore(baseMatchScore, item, qNorm, popValue = 50) {
  if (baseMatchScore <= 0) return 0;
  let score = baseMatchScore;
  const rating = Number(item.rating) || 0;
  score += rating * 13;
  score += Math.log10(Math.max(1, Number(popValue) || 10) + 1) * 42;

  // Subtle boost to root/main series over specials/recaps unless user explicitly searched for season/movie/ova/special
  const lowerTitle = String(item.title || '').toLowerCase();
  const wantsSubEntry = /\b(season|part|cour|ova|special|movie|film|recap)\b|\b[2-9]\b/.test(qNorm);
  if (!wantsSubEntry) {
    if (item.type === 'anime') {
      const fmt = String(item.format || '').toUpperCase();
      if (fmt === 'TV') score += 45;
      else if (fmt === 'MOVIE') score += 25;
      else if (fmt === 'SPECIAL' || fmt === 'OVA') score -= 45;
      if (/\b(season\s*[2-9]|2nd\s*season|3rd\s*season|4th\s*season|part\s*[2-9]|ova|special)\b/i.test(lowerTitle)) {
        score -= 35;
      }
    } else {
      score += 30;
    }
  }
  return score;
}

function searchLocalMegaPlay(term, extraAniMap = null) {
  const qNorm = normalizeTitle(term);
  if (!qNorm) return [];
  const qCompact = qNorm.replace(/\s+/g, '');
  const qWords = qNorm.split(' ').filter(Boolean);
  const results = [];

  for (const rec of indexedAnime) {
    let extraBoost = 0;
    const aniExtra = extraAniMap?.get(rec.item.id);
    let candidates = rec.candidates, compacts = rec.compacts, words = rec.words;
    if (aniExtra) {
      extraBoost = 120;
      if (aniExtra.extraCands.length) {
        const merged = new Set([...rec.candidates, ...aniExtra.extraCands]);
        candidates = [...merged];
        compacts = candidates.map(c => c.replace(/\s+/g, ''));
        const ws = new Set(rec.words);
        for (const c of aniExtra.extraCands) for (const w of c.split(' ')) if (w) ws.add(w);
        words = [...ws];
      }
    }
    let mScore = scoreCandidateMatch(qNorm, qCompact, qWords, rec.primaryNorm, rec.primaryCompact, candidates, compacts, words);
    if (mScore <= 0 && aniExtra) mScore = 760; // Matched via AniList synonym/native search!
    if (mScore <= 0) continue;
    const popVal = aniExtra?.popularity ? aniExtra.popularity / 100 : rec.popProxy;
    const total = finalizeSearchScore(mScore + extraBoost, rec.item, qNorm, popVal);
    const enrichedItem = aniExtra?.mediaItem ? {
      ...rec.item,
      backdrop: rec.item.backdrop || aniExtra.mediaItem.backdrop,
      rating: rec.item.rating || aniExtra.mediaItem.rating
    } : rec.item;
    results.push({ item: enrichedItem, score: total });
  }
  results.sort((a, b) => b.score - a.score);
  return results.slice(0, 32);
}

function scoreOttSearchItem(rawTmdb, qNorm, qCompact, qWords) {
  const item = ott(rawTmdb);
  const pNorm = normalizeTitle(item.title);
  const oNorm = normalizeTitle(item.originalTitle);
  const candidates = [pNorm, oNorm].filter(Boolean);
  const compacts = candidates.map(c => c.replace(/\s+/g, ''));
  const wordSet = new Set();
  for (const c of candidates) for (const w of c.split(' ')) if (w) wordSet.add(w);
  let mScore = scoreCandidateMatch(qNorm, qCompact, qWords, pNorm, pNorm.replace(/\s+/g, ''), candidates, compacts, [...wordSet]);
  // TMDB search sometimes matches translated/alternative titles not in title/original_title
  if (mScore <= 0) {
    if ((item.voteCount >= 50 || item.popularity >= 15) && qNorm.length >= 3) mScore = 520;
    else return null;
  }
  const popVal = (item.popularity || 5) + (item.voteCount || 0) / 25;
  return { item, score: finalizeSearchScore(mScore, item, qNorm, popVal) };
}

function sortAnikoto(items, sort) {
  let copy = [...items];
  if (sort === 'rating') copy.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  else if (sort === 'newest') copy.sort((a, b) => (b.year || 0) - (a.year || 0) || String(b.updated).localeCompare(String(a.updated)));
  return copy;
}

function dedupeCatalog(list) {
  let output = [], positions = new Map();
  for (let item of list) {
    if (!item?.id || !item?.title || !item?.poster) continue;
    if (item.type === 'anime' && !megaByMal.has(String(item.id))) continue;
    if (item.type !== 'anime' && item.japaneseAnimation) continue;
    let kind = item.type === 'movie' || item.isMovie ? 'movie' : 'series';
    let key = item.year ? `${normalizeTitle(item.title)}|${item.year}|${kind}` : `${item.type}:${item.id}`;
    let idKey = `${item.type}:${item.id}`;
    if (positions.has(idKey)) continue;
    if (!positions.has(key)) {
      positions.set(key, output.length);
      positions.set(idKey, output.length);
      output.push(item);
      continue;
    }
    let at = positions.get(key), old = output[at];
    if (old.type === 'anime' && item.type !== 'anime') output[at] = { ...old, backdrop: item.backdrop || old.backdrop };
    else if (item.type === 'anime' && old.type !== 'anime') output[at] = { ...item, backdrop: old.backdrop || item.backdrop };
  }
  return output;
}

async function animeRecord(id, withRelations = false) {
  let d = await anilist(`query($id:Int){Media(idMal:$id,type:ANIME){${fields}${withRelations ? ' relations{edges{relationType node{idMal type format}}}' : ''}}}`, { id: Number(id) });
  return d.Media;
}
function animeTitleKey(media) {
  let title = (media.title?.english || media.title?.romaji || '').toLowerCase().split(':')[0];
  return title.replace(/\bfinal season\b.*$/, '').replace(/\b(?:season|part|cour)\s*\d+\b.*$/, '').replace(/\s+(?:ii|iii|iv|v|vi|vii|viii|ix|x)$/, '').replace(/[^a-z0-9]+/g, ' ').trim();
}
function explicitAnimeSeason(media) { return /\b(?:season|part|cour)\s*\d+\b|\bfinal season\b|\s(?:ii|iii|iv|v|vi|vii|viii|ix|x)$/i.test(media.title?.english || media.title?.romaji || ''); }
function compatibleAnimeFormat(root, candidate) { return ['TV', 'TV_SHORT'].includes(root) ? ['TV', 'TV_SHORT'].includes(candidate) : root === candidate; }
function animeSeasonEntry(media) { let item = ani(media); return { id: String(media.idMal), anilistId: String(media.id), name: item.title, episodes: item.episodes, format: item.format }; }

async function animeSeasonFamily(media) {
  if (!media || media.format === 'MOVIE' || !['TV', 'TV_SHORT', 'ONA'].includes(media.format)) return [];
  let entries = new Map([[String(media.idMal), media]]), seen = new Set([String(media.idMal)]), queue = [media], key = animeTitleKey(media);
  while (queue.length && seen.size < 24) {
    let current = queue.shift();
    for (let edge of current.relations?.edges || []) {
      let node = edge.node, id = String(node.idMal || '');
      if (!['PREQUEL', 'SEQUEL'].includes(edge.relationType) || node.type !== 'ANIME' || !compatibleAnimeFormat(media.format, node.format) || !node.idMal || seen.has(id)) continue;
      seen.add(id);
      try {
        let linked = await animeRecord(id, true);
        if (linked && animeTitleKey(linked) === key) { entries.set(id, linked); queue.push(linked); }
      } catch {}
    }
  }
  let all = [...entries.values()].filter(m => releasedAnime(m) && megaForMedia(m));
  if (all.length < 2 || !all.some(explicitAnimeSeason)) return [];
  return all
    .sort((a, b) => (a.startDate?.year || 9999) - (b.startDate?.year || 9999) || (a.startDate?.month || 1) - (b.startDate?.month || 1) || (a.startDate?.day || 1) - (b.startDate?.day || 1) || Number(a.id) - Number(b.id))
    .map(animeSeasonEntry);
}

let sharedKey = null;
async function tmdbKey() {
  if (process.env.TMDB_API_KEY) return process.env.TMDB_API_KEY;
  if (!sharedKey) sharedKey = (await freekeys()).tmdb_key;
  return sharedKey;
}
async function tmdb(route, params = {}, timeout = 10000) {
  let key = await tmdbKey();
  let q = new URLSearchParams({ ...params, api_key: key, language: 'en-US' });
  try {
    return await remote('https://api.themoviedb.org/3/' + route + '?' + q, { timeout });
  } catch (e) {
    if (process.env.TMDB_API_KEY) throw e;
    sharedKey = (await freekeys()).tmdb_key;
    q.set('api_key', sharedKey);
    return remote('https://api.themoviedb.org/3/' + route + '?' + q, { timeout });
  }
}

async function getTmdbMetaForResolver(input) {
  let d = await tmdb(`${input.type}/${input.id}`, { append_to_response: 'external_ids' });
  return {
    title: d.title || d.name || d.original_title || d.original_name || '',
    year: String(d.release_date || d.first_air_date || '').slice(0, 4),
    imdbId: d.imdb_id || d.external_ids?.imdb_id || '',
    originalLanguage: String(d.original_language || '').toLowerCase()
  };
}

const readStates = () => {
  try { let d = JSON.parse(fs.readFileSync(statesDb)); return { visitors: d.visitors || {}, meta: d.meta || {} }; }
  catch { return { visitors: {}, meta: {} }; }
};
const cleanState = state => ({
  watchlist: Array.isArray(state?.watchlist) ? state.watchlist.slice(0, 100) : [],
  history: Array.isArray(state?.history) ? state.history.slice(0, 100) : []
});
function readState(owner) {
  let states = readStates(), existing = states.visitors[owner.id];
  if (!existing && !states.meta.legacyMigrated) {
    let legacy = null;
    try { legacy = JSON.parse(fs.readFileSync(db)); } catch {}
    states.meta.legacyMigrated = true;
    if (legacy && (legacy.watchlist?.length || legacy.history?.length)) states.visitors[owner.id] = cleanState(legacy);
    fs.writeFileSync(statesDb, JSON.stringify(states));
    return cleanState(states.visitors[owner.id]);
  }
  return cleanState(existing);
}
function writeState(owner, state) {
  let states = readStates();
  states.visitors[owner.id] = cleanState(state);
  fs.writeFileSync(statesDb, JSON.stringify(states));
  return states.visitors[owner.id];
}
const parseCookies = req => Object.fromEntries(String(req.headers.cookie || '').split(';').map(x => x.trim().split('=').map(decodeURIComponent)).filter(x => x.length === 2));
function appendCookie(res, value) {
  let old = res.getHeader('Set-Cookie'), all = old ? (Array.isArray(old) ? old : [old]) : [];
  res.setHeader('Set-Cookie', [...all, value]);
}
function visitorId(req, res) {
  let cookies = parseCookies(req), id = cookies.kozutv_visitor || cookies.moscowtv_visitor;
  if (!/^[a-f0-9]{32}$/.test(id || '')) {
    id = crypto.randomBytes(16).toString('hex');
  }
  if (cookies.kozutv_visitor !== id) {
    appendCookie(res, `kozutv_visitor=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=315360000`);
  }
  return id;
}
function stateOwner(req, res) { return { scope: 'visitors', id: visitorId(req, res) }; }
async function requestBody(req) {
  let chunks = [];
  for await (let chunk of req) {
    chunks.push(chunk);
    if (Buffer.concat(chunks).length > 50000) throw Error('Payload too large');
  }
  return JSON.parse(Buffer.concat(chunks).toString() || '{}');
}
function num(s) { return /^\d{1,10}$/.test(s || '') ? s : null; }

async function api(req, res, url) {
  let p = url.pathname, q = url.searchParams;
  try {
    if (p === '/api/state') return json(res, readState(stateOwner(req, res)), 200, req);

    if ((p === '/api/watchlist' && req.method === 'POST') || (p === '/api/history' && req.method === 'POST')) {
      let item = await requestBody(req);
      if (!['anime', 'movie', 'tv'].includes(item.type) || !num(String(item.id))) return json(res, { error: 'Invalid item' }, 400);
      let owner = stateOwner(req, res), state = readState(owner), field = p.endsWith('watchlist') ? 'watchlist' : 'history';
      let record = {
        id: String(item.id),
        type: item.type,
        title: String(item.title || '').slice(0, 200),
        poster: String(item.poster || '').slice(0, 500),
        episode: Math.max(1, Number(item.episode) || 1),
        season: Math.max(1, Number(item.season) || 1),
        updated: Date.now(),
        genres: Array.isArray(item.genres) ? item.genres.map(String).slice(0, 10) : [],
        format: typeof item.format === 'string' ? item.format.slice(0, 20) : null,
        isMovie: Boolean(item.isMovie),
        currentTime: Math.max(0, Number(item.currentTime) || 0),
        duration: Math.max(0, Number(item.duration) || 0)
      };
      let found = state[field].findIndex(x => x.id === record.id && x.type === record.type);
      let old = found >= 0 ? state[field].splice(found, 1)[0] : null;
      if (field === 'history' && old && old.episode === record.episode && old.season === record.season) {
        record.currentTime = item.currentTime == null ? old.currentTime || 0 : record.currentTime;
        record.duration = item.duration == null ? old.duration || 0 : record.duration;
      }
      if (!record.genres.length && old) record.genres = old.genres || [];
      if (field === 'history' || !item.remove) state[field].unshift(record);
      writeState(owner, state);
      return json(res, state, 200, req);
    }

    if (p === '/api/browse') {
      let [o] = await Promise.allSettled([tmdb('trending/all/week')]);
      let animeItems = anikotoItems.slice(0, 30);
      let ottItems = o.status === 'fulfilled'
        ? o.value.results.filter(x => ['tv', 'movie'].includes(x.media_type) && releasedOtt(x, 5)).map(ott)
        : [];
      if (!animeItems.length && !ottItems.length) throw Error('Catalogs are unavailable');
      let movies = ottItems.filter(x => x.type === 'movie'), shows = ottItems.filter(x => x.type === 'tv'), mixed = [];
      for (let i = 0; i < Math.max(animeItems.length, movies.length, shows.length); i++) {
        if (animeItems[i]) mixed.push(animeItems[i]);
        if (movies[i]) mixed.push(movies[i]);
        if (shows[i]) mixed.push(shows[i]);
      }
      mixed = dedupeCatalog(mixed);
      let history = readState(stateOwner(req, res)).history, watchedGenres = new Map();
      for (let [index, h] of history.entries()) {
        for (let g of h.genres || []) watchedGenres.set(g.toLowerCase(), (watchedGenres.get(g.toLowerCase()) || 0) + Math.max(1, 8 - index));
      }
      let watched = new Set(history.map(h => h.type + ':' + h.id));
      let suggestions = mixed
        .filter(x => !watched.has(x.type + ':' + x.id))
        .map(x => ({ ...x, match: (x.genres || []).reduce((n, g) => n + (watchedGenres.get(g.toLowerCase()) || 0), 0) }))
        .filter(x => x.match > 0)
        .sort((a, b) => b.match - a.match)
        .slice(0, 12);
      return json(res, { items: mixed, spotlight: buildRandomizedSpotlight(), suggestions, hasPreferences: watchedGenres.size > 0 }, 200, req);
    }

    if (p === '/api/search-all') {
      let term = (q.get('q') || '').trim().slice(0, 100);
      if (!term) return json(res, { items: [] }, 200, req);
      let qNorm = normalizeTitle(term), qCompact = qNorm.replace(/\s+/g, ''), qWords = qNorm.split(' ').filter(Boolean);

      const [aniRes, multiRes, movieRes, tvRes] = await Promise.allSettled([
        anilist(
          `query($q:String){Page(page:1,perPage:24){media(search:$q,type:ANIME,isAdult:false,status_in:[FINISHED,RELEASING],sort:[SEARCH_MATCH,POPULARITY_DESC]){${fields}}}}`,
          { q: term },
          2800
        ),
        tmdb('search/multi', { query: term, include_adult: 'false', page: '1' }, 3200),
        tmdb('search/movie', { query: term, include_adult: 'false', page: '1' }, 3200),
        tmdb('search/tv', { query: term, include_adult: 'false', page: '1' }, 3200)
      ]);

      // Map AniList search hits strictly to released MegaPlay-available anime
      const extraAniMap = new Map();
      if (aniRes.status === 'fulfilled') {
        for (const m of aniRes.value?.Page?.media || []) {
          if (!m?.idMal || !releasedAnime(m) || !megaForMedia(m)) continue;
          const extraCands = [
            m.title?.english,
            m.title?.romaji,
            m.title?.native,
            ...(Array.isArray(m.synonyms) ? m.synonyms : [])
          ].map(normalizeTitle).filter(Boolean);
          extraAniMap.set(String(m.idMal), {
            popularity: Number(m.popularity) || 0,
            extraCands,
            mediaItem: ani(m)
          });
        }
      }

      const scoredAnime = searchLocalMegaPlay(term, extraAniMap);

      // Merge & score released, streamable TMDB movies & web series
      const rawOttMap = new Map();
      for (const [srcRes, forcedType] of [[multiRes, null], [movieRes, 'movie'], [tvRes, 'tv']]) {
        if (srcRes.status !== 'fulfilled') continue;
        for (const raw of srcRes.value?.results || []) {
          const mediaType = forcedType || raw.media_type;
          if (!['movie', 'tv'].includes(mediaType)) continue;
          const enriched = { ...raw, media_type: mediaType };
          if (!releasedOtt(enriched, 2)) continue;
          const k = `${mediaType}:${raw.id}`;
          if (!rawOttMap.has(k)) rawOttMap.set(k, enriched);
        }
      }

      const scoredOtt = [];
      for (const raw of rawOttMap.values()) {
        const scored = scoreOttSearchItem(raw, qNorm, qCompact, qWords);
        if (scored) scoredOtt.push(scored);
      }
      // Also fuzzy-match curated OTT Spotlight titles (catches typos like "interstelar", "stranger thngs", "deadpol")
      for (const sp of spotlightCatalog) {
        if (sp.type === 'anime' || rawOttMap.has(`${sp.type}:${sp.id}`)) continue;
        const pNorm = normalizeTitle(sp.title);
        const pComp = pNorm.replace(/\s+/g, '');
        const pWords = pNorm.split(' ').filter(Boolean);
        const mScore = scoreCandidateMatch(qNorm, qCompact, qWords, pNorm, pComp, [pNorm], [pComp], pWords);
        if (mScore > 0) {
          scoredOtt.push({ item: sp, score: finalizeSearchScore(mScore, sp, qNorm, 180) });
        }
      }

      // If TMDB missed due to a mid-word spelling typo (e.g. "incepshun", "gladiater"), try a short stem prefix query
      if (scoredOtt.length < 2 && qWords.length === 1 && qWords[0].length >= 6) {
        const stem = qWords[0].slice(0, 5);
        const stemRes = await tmdb('search/multi', { query: stem, include_adult: 'false', page: '1' }, 2200).catch(() => null);
        for (const raw of stemRes?.results || []) {
          if (!['movie', 'tv'].includes(raw.media_type)) continue;
          if (!releasedOtt(raw, 5)) continue;
          const k = `${raw.media_type}:${raw.id}`;
          if (rawOttMap.has(k)) continue;
          rawOttMap.set(k, raw);
          const scored = scoreOttSearchItem(raw, qNorm, qCompact, qWords);
          if (scored) scoredOtt.push(scored);
        }
      }

      const combinedRanked = [...scoredAnime, ...scoredOtt]
        .sort((a, b) => b.score - a.score)
        .map(x => x.item);

      return json(res, { items: dedupeCatalog(combinedRanked).slice(0, 48) }, 200, req);
    }

    if (p === '/api/genre') {
      let g = q.get('name');
      if (!catalogGenres.includes(g)) return json(res, { error: 'Unknown genre' }, 400);
      let mId = movieGenreIds[g], tId = tvGenreIds[g];
      let [mRes, tRes] = await Promise.allSettled([
        mId ? tmdb('discover/movie', { with_genres: String(mId), sort_by: 'popularity.desc', page: '1', 'primary_release_date.lte': today(), 'vote_count.gte': '8', include_adult: 'false' }) : Promise.resolve(null),
        tId ? tmdb('discover/tv', { with_genres: String(tId), sort_by: 'popularity.desc', page: '1', 'first_air_date.lte': today(), 'vote_count.gte': '8', include_adult: 'false' }) : Promise.resolve(null)
      ]);
      let animeItems = anikotoItems.filter(x => x.genres.includes(g)).slice(0, 16);
      let movieItems = mRes.status === 'fulfilled' && mRes.value ? mRes.value.results.filter(x => releasedOtt({ ...x, media_type: 'movie' }, 5)).slice(0, 10).map(x => ott({ ...x, media_type: 'movie' })) : [];
      let tvItems = tRes.status === 'fulfilled' && tRes.value ? tRes.value.results.filter(x => releasedOtt({ ...x, media_type: 'tv' }, 5)).slice(0, 10).map(x => ott({ ...x, media_type: 'tv' })) : [];
      let mixed = [];
      for (let i = 0; i < 16; i++) {
        if (animeItems[i]) mixed.push(animeItems[i]);
        if (movieItems[i]) mixed.push(movieItems[i]);
        if (tvItems[i]) mixed.push(tvItems[i]);
      }
      return json(res, { items: dedupeCatalog(mixed).slice(0, 24) }, 200, req);
    }

    if (p === '/api/random') {
      let [o] = await Promise.allSettled([tmdb('trending/all/week')]);
      let ottItems = o.status === 'fulfilled' ? o.value.results.filter(x => ['movie', 'tv'].includes(x.media_type) && releasedOtt(x, 5)).map(ott) : [];
      let all = dedupeCatalog([...spotlightCatalog, ...anikotoItems.slice(0, 300), ...ottItems]);
      if (!all.length) throw Error('Catalogs are unavailable');
      return json(res, { item: all[crypto.randomInt(all.length)] }, 200, req);
    }

    if (p === '/api/schedule') {
      let now = Math.floor(Date.now() / 1000), week = now + 7 * 86400;
      let d = await anilist(`query($now:Int,$week:Int){Page(page:1,perPage:50){airingSchedules(airingAt_greater:$now,airingAt_lesser:$week,sort:TIME){id airingAt episode media{${fields}}}}}`, { now, week });
      let entries = d.Page.airingSchedules
        .filter(x => x.media?.idMal && !x.media.isAdult && releasedAnime(x.media) && megaForMedia(x.media))
        .map(x => ({ id: x.id, airingAt: x.airingAt, episode: x.episode, item: ani(x.media) }));
      return json(res, { entries }, 200, req);
    }

    if (p === '/api/filter') {
      let type = ['anime', 'movie', 'tv', 'all'].includes(q.get('type')) ? q.get('type') : 'all';
      let genre = catalogGenres.includes(q.get('genre')) ? q.get('genre') : '';
      let year = /^\d{4}$/.test(q.get('year') || '') && Number(q.get('year')) <= new Date().getFullYear() ? q.get('year') : '';
      let sort = ['popularity', 'rating', 'newest'].includes(q.get('sort')) ? q.get('sort') : 'popularity';
      let status = ['releasing', 'finished'].includes(q.get('status')) ? q.get('status') : '';
      if (q.get('year') && Number(q.get('year')) > new Date().getFullYear()) return json(res, { items: [] }, 200, req);

      let tasks = [];
      if (type === 'all' || type === 'anime') {
        let animeItems = anikotoItems.filter(x => (!genre || x.genres.includes(genre)) && (!year || String(x.year) === year) && (!status || x.status === status.toUpperCase()));
        tasks.push(Promise.resolve(sortAnikoto(animeItems, sort).slice(0, 40)));
      }
      for (let mediaType of type === 'all' ? ['movie', 'tv'] : type === 'anime' ? [] : [type]) {
        tasks.push((async () => {
          let genreMap = mediaType === 'movie' ? movieGenreIds : tvGenreIds;
          if (genre && !genreMap[genre]) return [];
          let params = {
            sort_by: { popularity: 'popularity.desc', rating: 'vote_average.desc', newest: mediaType === 'movie' ? 'primary_release_date.desc' : 'first_air_date.desc' }[sort],
            include_adult: 'false',
            'vote_count.gte': sort === 'rating' ? '25' : '6'
          };
          if (genre) params.with_genres = String(genreMap[genre]);
          if (year) params[mediaType === 'movie' ? 'primary_release_year' : 'first_air_date_year'] = year;
          params[mediaType === 'movie' ? 'primary_release_date.lte' : 'first_air_date.lte'] = today();
          let d = await tmdb('discover/' + mediaType, params);
          return d.results.filter(x => releasedOtt({ ...x, media_type: mediaType }, 4)).map(x => ott({ ...x, media_type: mediaType }));
        })());
      }
      let settled = await Promise.allSettled(tasks), groups = settled.filter(x => x.status === 'fulfilled').map(x => x.value), items = [];
      for (let i = 0; i < 50; i++) for (let group of groups) if (group[i]) items.push(group[i]);
      if (!items.length && settled.every(x => x.status === 'rejected')) throw Error('Catalogs are unavailable');
      return json(res, { items: dedupeCatalog(items).slice(0, 60) }, 200, req);
    }

    if (p === '/api/detail') {
      let id = num(q.get('id')), type = q.get('type');
      if (!id || !['anime', 'tv', 'movie'].includes(type)) return json(res, { error: 'Invalid title' }, 400);

      if (type === 'anime') {
        let provider = megaByMal.get(id);
        if (!provider) {
          return json(res, { error: 'This anime is not available on MegaPlay.' }, 404, req);
        }
        let [providerData, media] = await Promise.all([
          anikotoSeries(provider.id).catch(() => null),
          animeRecord(id, true).catch(() => null)
        ]);
        let item = anikotoItem(provider);
        let count = providerData?.episodes?.length || 0;
        if (count > 0) {
          if (!item.isMovie) item.episodes = count;
          item.playable = true;
          item.dub = providerData.episodes.some(x => x.embed_url?.dub) || Boolean(provider.dub);
        } else {
          let directOk = await resolveMegaPlayDirect({ malId: id, aniId: provider.ani || media?.id, episode: 1, lang: 'sub' }).then(() => true).catch(() => false);
          if (!directOk) {
            return json(res, { error: 'This anime has no released episodes available yet.' }, 404, req);
          }
          item.playable = true;
        }
        if (media) {
          let fallback = ani(media);
          item.poster = item.poster || fallback.poster;
          item.backdrop = item.backdrop || fallback.backdrop;
          item.description = item.description || fallback.description;
          if (!item.genres.length) item.genres = fallback.genres;
        }
        item.upcoming = false;
        let seasons = media ? await animeSeasonFamily(media) : [];
        return json(res, { item, episodes: [], seasons }, 200, req);
      }

      let d = await tmdb(type + '/' + id);
      if (!releasedOtt({ ...d, media_type: type }, 0)) {
        return json(res, { error: 'This title is unreleased or unavailable for streaming.' }, 404, req);
      }
      let item = ott({ ...d, media_type: type });
      item.upcoming = false;
      item.playable = true;
      let seasons = type === 'tv'
        ? (d.seasons || [])
            .filter(x => x.season_number >= 1 && Number(x.episode_count) > 0 && (!x.air_date || String(x.air_date).slice(0, 10) <= today()))
            .map(x => ({ number: x.season_number, name: x.name, episodes: x.episode_count }))
        : [];
      return json(res, { item, seasons }, 200, req);
    }

    if (p === '/api/anime-episodes') {
      let id = num(q.get('id')), page = Math.max(1, Math.min(10000, Math.floor(Number(q.get('page')) || 1))), limit = 20;
      if (!id) return json(res, { error: 'Invalid anime' }, 400);
      let provider = megaByMal.get(id);
      if (!provider) return json(res, { error: 'Episodes are not available for this title.' }, 404);
      let base = [];
      let data = await anikotoSeries(provider.id).catch(() => null);
      base = (data?.episodes || []).filter(x => Number.isInteger(Number(x.number)) && Number(x.number) > 0).sort((a, b) => Number(a.number) - Number(b.number));
      if (!base.length) {
        let media = await animeRecord(id, false).catch(() => null);
        let fallbackTotal = positiveInt(provider.episodes) || animeEpisodeCount(media) || 0;
        if (fallbackTotal > 0) {
          base = Array.from({ length: fallbackTotal }, (_, i) => ({
            number: i + 1,
            title: `Episode ${i + 1}`,
            episode_embed_id: '',
            embed_url: {
              sub: `https://megaplay.buzz/stream/mal/${id}/${i + 1}/sub`,
              dub: provider.dub ? `https://megaplay.buzz/stream/mal/${id}/${i + 1}/dub` : null
            }
          }));
        } else {
          return json(res, { error: 'Episodes are not available for this title.' }, 404);
        }
      }
      let offset = (page - 1) * limit, pageRows = base.slice(offset, offset + limit);
      let [jikanMap, anizipMap] = await Promise.all([jikanAnimeEpisodeMeta(id, pageRows.map(x => Number(x.number))), anizipEpisodeMeta(id)]);
      let sources = ['megaplay'];
      if (jikanMap?.size) sources.unshift('jikan');
      if (anizipMap?.size && !sources.includes('jikan')) sources.unshift('jikan-mal');
      let episodes = pageRows.map(x => {
        let n = Number(x.number), jk = jikanMap?.get(n), az = anizipMap?.get(n), fallbackTitle = decodeEntities(x.title);
        let cleanFallback = fallbackTitle && !/^episode\s*\d+$/i.test(fallbackTitle.trim()) ? fallbackTitle : '';
        let title = (jk?.title || az?.title || cleanFallback || `Episode ${n}`).replace(/`/g, "'").trim();
        let description = (jk?.description || az?.description || '').trim();
        let still = jk?.still || az?.still || null;
        return { number: n, title, description, still, embedId: String(x.episode_embed_id || ''), sub: Boolean(x.embed_url?.sub ?? true), dub: Boolean(x.embed_url?.dub) };
      });
      return json(res, { episodes, page, perPage: limit, total: base.length, hasNext: offset + limit < base.length, sources }, 200, req);
    }

    if (p === '/api/season') {
      let id = num(q.get('id')), season = q.get('season') === '0' ? '0' : num(q.get('season'));
      if (!id || season === null) return json(res, { error: 'Invalid season' }, 400);
      let d = await tmdb(`tv/${id}/season/${season}`);
      let rawEps = Array.isArray(d.episodes) ? d.episodes : [];
      let hasAnyDated = rawEps.some(e => Boolean(e.air_date));
      let airedEps = rawEps.filter(e => {
        if (!e.episode_number || e.episode_number <= 0) return false;
        if (e.air_date) return String(e.air_date).slice(0, 10) <= today();
        return !hasAnyDated;
      });
      return json(res, {
        episodes: airedEps.map(e => ({
          number: e.episode_number,
          title: e.name || `Episode ${e.episode_number}`,
          description: e.overview || '',
          still: e.still_path ? 'https://image.tmdb.org/t/p/w300' + e.still_path : null
        }))
      }, 200, req);
    }

    if (p === '/api/play') {
      let id = num(q.get('id')), type = q.get('type'), ep = num(q.get('episode') || '1'), season = q.get('season') === '0' ? '0' : num(q.get('season') || '1');
      let lang = q.get('lang') === 'dub' ? 'dub' : 'sub';
      let requestedProvider = q.get('provider'), provider = OTT_SERVER_KEYS.has(requestedProvider) ? requestedProvider : DEFAULT_OTT_SERVER;
      let aniId = num(q.get('anilistId'));
      if (!id || !ep || !season || !['anime', 'movie', 'tv'].includes(type)) return json(res, { error: 'Invalid playback request' }, 400);

      if (type === 'anime') {
        let available = megaForIds(id, aniId), effectiveAni = aniId || available?.ani || null, fallbackEmbed = null;
        if (!available) return json(res, { error: 'This anime is not available on MegaPlay.' }, 404, req);
        let isAnimeMovie = String(available.format || '').toUpperCase().includes('MOVIE');
        if (available.id) {
          let seriesData = await anikotoSeries(available.id).catch(() => null);
          let row = seriesData?.episodes?.find(x => Number(x.number) === Number(ep));
          fallbackEmbed = row?.embed_url?.[lang] || null;
        }
        let azPromise = remote(`https://api.ani.zip/mappings?mal_id=${encodeURIComponent(id)}`, { ttl: 21600000, timeout: 2200, headers: { Accept: 'application/json' } }).catch(() => null);
        try {
          let resolved = await resolveMegaPlayDirect({ malId: id, aniId: effectiveAni, episode: ep, lang, fallbackEmbed });
          let az = await azPromise;
          let tmdbId = az?.mappings?.themoviedb_id || null;
          let azEp = az?.episodes?.[String(ep)] || null;
          let tmdbMapping = tmdbId ? { tmdbId, type: isAnimeMovie || az?.mappings?.type === 'MOVIE' ? 'movie' : 'tv', season: Number(azEp?.seasonNumber) || 1, episode: Number(azEp?.episodeNumber) || Number(ep) || 1 } : null;
          let rawQualityStreams = await enrichAnimeQualityStreams({ primaryUrl: resolved.url, lang, tmdbMapping }).catch(() => []);
          let qualityStreams = rawQualityStreams.map(qs => {
            try { return { tier: qs.tier, height: qs.height, codec: qs.codec || 'h264', type: qs.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', src: mediaUrl(qs.url, qs.proxyProvider || 'megaplay', qs.headers || {}) }; }
            catch { return null; }
          }).filter(Boolean);
          let tracks = lang === 'sub' ? resolved.tracks.map(x => ({ ...x, src: mediaUrl(x.src, 'megaplay') })) : [];
          return json(res, { src: mediaUrl(resolved.url, 'megaplay'), type: /\.mp4(?:\?|$)/i.test(resolved.url) ? 'video/mp4' : 'application/x-mpegURL', kind: 'videojs', provider: 'MegaPlay', server: lang === 'dub' ? 'Dub' : 'Sub', tracks, qualityStreams, intro: resolved.intro, outro: resolved.outro }, 200, req);
        } catch {
          let otherLang = lang === 'dub' ? 'sub' : 'dub', otherFallback = null;
          if (available.id) {
            let seriesData = await anikotoSeries(available.id).catch(() => null);
            let row = seriesData?.episodes?.find(x => Number(x.number) === Number(ep));
            otherFallback = row?.embed_url?.[otherLang] || null;
          }
          let hasOpposite = await resolveMegaPlayDirect({ malId: id, aniId: effectiveAni, episode: ep, lang: otherLang, fallbackEmbed: otherFallback }).then(() => true).catch(() => false);
          if (hasOpposite) {
            return json(res, { error: lang === 'dub' ? 'Dub is not available for this episode.' : 'Sub is not available for this episode.', availableLang: otherLang }, 404, req);
          }
          return json(res, { error: 'This episode is not available on MegaPlay right now.' }, 404, req);
        }
      }

      let input = { type, id, season, episode: ep };
      let resolved = await resolveOttWithFallback(input, provider, getTmdbMetaForResolver);
      let proxyProvider = resolved.proxyProvider || resolved.sourceKey || DEFAULT_OTT_SERVER;
      let src = resolved.kind === 'dash' ? dashUrl(resolved.url, proxyProvider, resolved.headers) : mediaUrl(resolved.url, proxyProvider, resolved.headers);
      let tracks = (resolved.tracks || []).map(x => {
        try { return { kind: x.kind || 'subtitles', language: x.language || 'und', label: x.label || 'Subtitle', src: mediaUrl(x.src, x.proxyProvider || proxyProvider, x.headers || resolved.headers) }; }
        catch { return null; }
      }).filter(Boolean);
      let audioStreams = (resolved.audioStreams || []).map(a => {
        try { return { language: a.language, label: a.label, src: mediaUrl(a.url, a.proxyProvider || proxyProvider, a.headers || resolved.headers) }; }
        catch { return null; }
      }).filter(Boolean);
      let qualityStreams = (resolved.qualityStreams || []).map(qs => {
        try { return { tier: qs.tier, height: qs.height, codec: qs.codec || 'h264', type: qs.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', src: mediaUrl(qs.url, qs.proxyProvider || proxyProvider, qs.headers || resolved.headers || {}) }; }
        catch { return null; }
      }).filter(Boolean);
      return json(res, { src, type: resolved.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', codec: resolved.codec || 'h264', kind: 'videojs', provider: resolved.provider, sourceKey: resolved.sourceKey, server: resolved.server, tracks, audioStreams, qualityStreams }, 200, req);
    }

    return json(res, { error: 'Not found' }, 404);
  } catch (e) {
    return json(res, { error: e.message || 'Request failed' }, e.message?.includes('configured') ? 503 : 502);
  }
}

let jikanUnreachableUntil = 0;
async function jikanAnimeEpisodeMeta(malId, sliceNums) {
  if (Date.now() < jikanUnreachableUntil) return null;
  try {
    let jikanPage = Math.max(1, Math.ceil((sliceNums[0] || 1) / 100));
    let [epRes, vidRes] = await Promise.all([
      remote(`https://api.jikan.moe/v4/anime/${encodeURIComponent(malId)}/episodes?page=${jikanPage}`, { ttl: 21600000, timeout: 1800, headers: { Accept: 'application/json' } }).catch(err => {
        if (/timeout|abort|fetch/i.test(err.message)) jikanUnreachableUntil = Date.now() + 600000;
        return null;
      }),
      remote(`https://api.jikan.moe/v4/anime/${encodeURIComponent(malId)}/videos/episodes?page=1`, { ttl: 21600000, timeout: 1800, headers: { Accept: 'application/json' } }).catch(() => null)
    ]);
    if (!epRes?.data && !vidRes?.data) return null;
    let byNum = new Map();
    for (let row of epRes?.data || []) {
      let n = Number(row.mal_id);
      if (n > 0) byNum.set(n, { title: row.title || row.title_romanji || '', still: null, description: '' });
    }
    for (let row of vidRes?.data || []) {
      let n = Number(row.mal_id), img = row.images?.jpg?.image_url || null;
      if (n > 0) {
        let prev = byNum.get(n) || { title: '', still: null, description: '' };
        byNum.set(n, { title: prev.title || row.title || '', still: img || prev.still, description: prev.description });
      }
    }
    return byNum;
  } catch { return null; }
}

async function anizipEpisodeMeta(malId) {
  try {
    let d = await remote(`https://api.ani.zip/mappings?mal_id=${encodeURIComponent(malId)}`, { ttl: 21600000, timeout: 4500, headers: { Accept: 'application/json' } });
    let eps = d?.episodes || {};
    let byNum = new Map();
    for (let [k, ep] of Object.entries(eps)) {
      if (!/^\d+$/.test(k)) continue;
      let n = Number(k);
      if (!Number.isInteger(n) || n <= 0) continue;
      let rawTitle = typeof ep.title === 'string' ? ep.title : (ep.title?.en || ep.title?.['x-jat'] || ep.title?.ja || '');
      let rawDesc = String(ep.overview || ep.summary || '').replace(/\s*\(?\bSource:\s*[^)\n]+\)?\s*$/i, '').trim();
      let img = /^https:\/\//.test(ep.image || '') ? ep.image : null;
      byNum.set(n, { title: rawTitle, still: img, description: rawDesc });
    }
    return byNum;
  } catch { return null; }
}

const staticCache = new Map();
const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ttf': 'font/ttf',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2'
};
const CSP = "default-src 'self' https: data: blob:; frame-src 'none'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' https: data:; connect-src 'self' https: data: blob:; media-src 'self' https: data: blob:; worker-src 'self' blob:";

http.createServer((req, res) => {
  let u = new URL(req.url, 'http://localhost');
  if (u.pathname.startsWith('/browse/watch/')) {
    let dest = u.pathname.replace(/^\/browse\/watch\//, '/watch/');
    res.writeHead(301, { Location: dest + u.search });
    return res.end();
  }
  if (u.pathname === '/upcoming') {
    res.writeHead(302, { Location: '/browse' });
    return res.end();
  }
  if (/^\/(anime|ott)(\/|$)/.test(u.pathname)) {
    let dest = u.pathname.replace(/^\/(anime|ott)/, '/browse');
    res.writeHead(302, { Location: dest + u.search });
    return res.end();
  }
  if (u.pathname.startsWith('/api/dash/')) return handleDash(req, res, u);
  if (u.pathname === '/api/media') return handleMedia(req, res, u);
  if (u.pathname.startsWith('/api/')) return api(req, res, u);

  let pathname = u.pathname === '/' ? '/index.html' : u.pathname;
  let target = path.resolve(root, '.' + pathname);
  if (!target.startsWith(root + path.sep) || !fs.existsSync(target) || !fs.statSync(target).isFile()) {
    target = path.join(root, 'index.html');
  }
  let ext = path.extname(target), stat = fs.statSync(target), cached = staticCache.get(target);
  if (!cached || cached.mtime !== stat.mtimeMs) {
    let raw = fs.readFileSync(target), compressible = /^\.(?:html|js|css|svg|webmanifest)$/.test(ext);
    cached = { mtime: stat.mtimeMs, raw, gz: compressible ? zlib.gzipSync(raw, { level: 6 }) : null };
    staticCache.set(target, cached);
  }
  let immutable = u.pathname.startsWith('/vendor/') || u.pathname.startsWith('/fonts/') || u.pathname.startsWith('/images/') || u.searchParams.has('v');
  let headers = {
    'Content-Type': mimeTypes[ext] || 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-cache' : (immutable ? 'public, max-age=86400' : 'public, max-age=300'),
    'Content-Security-Policy': CSP
  };
  if (cached.gz && String(req.headers['accept-encoding'] || '').includes('gzip')) {
    headers['Content-Encoding'] = 'gzip';
    headers['Vary'] = 'Accept-Encoding';
    res.writeHead(200, headers);
    return res.end(cached.gz);
  }
  res.writeHead(200, headers);
  res.end(cached.raw);
}).listen(process.env.PORT || 3000, '0.0.0.0', () => {
  console.log('kozuTV V5.0.0 listening on ' + (process.env.PORT || 3000));
});
