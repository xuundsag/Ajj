# Discord — do this

You only do this **once**. After that it just works, every time you watch.

---

## Step 1 — Connect your Discord account (30 seconds, done in the browser)

1. Go to **https://kozutv.bond** and sign in to Discord in that same browser
   first (if you are not signed in, Discord shows a login page instead of the
   permission screen — that is normal).
2. Open **Settings → Discord**.
3. Click the orange **Connect Discord** button.
4. Click **Authorise** on the Discord screen.
5. Come back to kozuTV. You will see your avatar and `@username`. ✅ Step 1 done.
6. Turn **on** the switch "Enable Discord Rich Presence".

After this, the grey line under the switch says *"Almost there…"*. That is
expected — continue to Step 2.

---

## Step 2 — Double-click one file (once, ever)

Presence has to be sent to Discord by something on **your own computer**. kozuTV
is a website, so it cannot do that itself. This one file sets that up and then
keeps it running by itself — **you never start it again.**

**Windows**

1. In the kozuTV folder, open the **`install`** folder.
2. Double-click **`START-RELAY-WINDOWS.bat`**.
3. Wait for *"Ready. The helper is running in the background."* Press Enter.

What it did: wrote the helper to `%LOCALAPPDATA%\kozuTV\relay.mjs`, registered it
to start **every time you sign in**, added a 5-minute keep-alive in case it ever
stops, started it right now, and checked that it answered.

**Mac / Linux**

```bash
bash install/START-RELAY-MAC-LINUX.sh
```

Installs a login item (LaunchAgent on macOS, a user service on Linux) that
restarts itself if it stops.

**To remove it later:** run the same file — `START-RELAY-WINDOWS.bat` in PowerShell
with `-Uninstall`, or `bash install/START-RELAY-MAC-LINUX.sh --uninstall`.

> Node.js is needed once. If the installer says so, install the **LTS** from
> <https://nodejs.org>, then double-click again. The installer opens that page
> for you.

## Step 3 — Watch something

Play any title, then open your Discord profile. It says:

```
Watching kozuTV
One Piece
Sanji's Shock! Mysterious Old Man and His Super Yummy Cooking!
S11E319
01:02 ────────────── 23:20   [ Watch on kozuTV ]
```

---

## Everyday use

| You want to… | Do this |
|---|---|
| Watch with presence on | Nothing. It starts itself at sign-in and stays running. |
| Stop showing presence for a while | Switch off the toggle in Settings |
| Stop it permanently | Run the installer again with `-Uninstall` |
| Watch on your phone | Presence appears if your PC is on and signed in — the card is published by the PC |
| Update kozuTV | Replace the web files on the server. Nothing to redo on your PC. |

---

## If it says "Almost there"

The helper is not running. Double-click `START-RELAY-WINDOWS.bat` and reload the
page. If it still says "Almost there", check that:

- The black window is still open (not closed, not crashed).
- **Discord desktop** is open and signed in on that same PC. The Discord
  website does not count — it must be the installed app.
- In Discord: **Settings → Activity Privacy → Share your detected activities**
  is switched **on**.

## If "Connect Discord" gives an error

- *Invalid OAuth2 redirect_uri* → in the Discord Developer Portal, under
  **OAuth2 → Redirects**, the entry must be exactly
  `https://kozutv.bond/api/discord/callback`.
- *Nothing happens / sends you to a login page* → sign in to Discord in that
  browser first, then click Connect again.

---

# Why a helper at all? (the short honest answer)

Discord has no internet endpoint where a website can say "this person is
watching X". The only door is inside the Discord app **on your computer**, and a
website is not allowed to knock on it. So something on your PC must do it — that
is the black window.

Every app that shows "Watching / Listening" does the same thing: LastWave on
Android talks to the Discord app on your phone; its desktop build opens a pipe
on your PC. The difference is that those are *installed apps*. A website needs a
helper. This one is 170 lines, needs no account password, never sees your
Discord login, and you can close it any time.

What we deliberately do **not** do: use your Discord account token to fake a
client. Discord bans accounts for that, and it would hand kozuTV your whole
Discord account.

---

## For whoever maintains the server

| File | What it does |
| --- | --- |
| `relay/kozutv-discord-relay.mjs` | Local helper: forwards presence frames to the Discord app |
| `install/START-RELAY-WINDOWS.bat` | Double-click installer: installs the helper, schedules it at login, starts it |
| `install/START-RELAY-MAC-LINUX.sh` | Same for macOS/Linux (user login item) |
| `public/discord-local.js` | Browser side of the connection |
| `discord-rpc.js` | OAuth login, token storage, and the desktop transport |
| `.env` | `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `DISCORD_REDIRECT_URI=https://kozutv.bond/api/discord/callback`, `KOZUTV_PUBLIC_URL=https://kozutv.bond` |

`npm test` covers both transports; `npm run relay` starts the helper from a
terminal.
