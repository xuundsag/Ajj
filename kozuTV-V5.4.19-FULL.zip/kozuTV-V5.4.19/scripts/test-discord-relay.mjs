// Verifies the relay + the browser module together, without Discord.
//
// 1. a fake Discord client listens on a unix socket and records frames
// 2. relay/kozutv-discord-relay.mjs bridges ws://127.0.0.1:6463 to it
// 3. public/discord-local.js (the real browser code) is driven by a real browser
//    when one is available, otherwise the framing functions are exercised
//    directly.
//
// This is the path used when kozuTV is hosted somewhere without Discord.
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kozutv-relay-'));
const sock = path.join(dir, 'discord-ipc-0');
const assert = (ok, label) => { if (!ok) throw Error('FAILED: ' + label); console.log('PASS', label); };

// ---------------------------------------------------------------- fake client
const frames = [];
const fake = net.createServer(s => {
  let buf = Buffer.alloc(0);
  s.on('data', chunk => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 8) {
      const op = buf.readUInt32LE(0);
      const len = buf.readUInt32LE(4);
      if (buf.length < 8 + len) break;
      const body = JSON.parse(buf.subarray(8, 8 + len).toString());
      buf = buf.subarray(8 + len);
      frames.push({op, body});
      if (op === 0) {
        const reply = Buffer.from(JSON.stringify({cmd: 'DISPATCH', evt: 'READY', data: {v: 1}}));
        const head = Buffer.alloc(8);
        head.writeUInt32LE(1, 0);
        head.writeUInt32LE(reply.length, 4);
        s.write(Buffer.concat([head, reply]));
      }
    }
  });
});
await new Promise(r => fake.listen(sock, r));

// --------------------------------------------------------------------- relay
const port = 6464 + (process.pid % 200);
const relay = spawn(process.execPath, [path.join(root, 'relay/kozutv-discord-relay.mjs')], {
  env: {...process.env, PORT: String(port), XDG_RUNTIME_DIR: dir},
  stdio: ['ignore', 'pipe', 'pipe']
});
const relayLog = [];
relay.stdout.on('data', d => relayLog.push(String(d)));
relay.stderr.on('data', d => relayLog.push(String(d)));
// wait for the listen banner (or a bind error) instead of guessing a delay
await new Promise((resolve, reject) => {
  const started = Date.now();
  const tick = setInterval(() => {
    const text = relayLog.join('');
    if (/listening on/.test(text)) { clearInterval(tick); resolve(); }
    else if (/EADDRINUSE|Error:/.test(text) || Date.now() - started > 5000) { clearInterval(tick); reject(Error('relay did not start: ' + text.slice(0, 200))); }
  }, 100);
});
assert(/listening on/.test(relayLog.join('')), 'relay starts and listens');

// ------------------------------------------------- a minimal ws client probe
// Speaks the same frames the browser module sends, so the relay contract is
// tested here; the browser-side encoding is covered by the unit assertions below.
function encode(op, payload) {
  const body = Buffer.from(JSON.stringify(payload));
  const head = Buffer.alloc(8);
  head.writeUInt32LE(op, 0);
  head.writeUInt32LE(body.length, 4);
  return Buffer.concat([head, body]);
}

function wsSend(socket, buffer, opcode = 0x2) {
  const mask = Buffer.from([1, 2, 3, 4]);
  const masked = Buffer.from(buffer);
  for (let i = 0; i < masked.length; i++) masked[i] ^= mask[i % 4];
  const head = buffer.length < 126
    ? Buffer.from([0x80 | opcode, 0x80 | buffer.length])
    : Buffer.from([0x80 | opcode, 0x80 | 126, buffer.length >> 8, buffer.length & 0xff]);
  socket.write(Buffer.concat([head, mask, masked]));
}

const probe = net.createConnection({host: '127.0.0.1', port});
await new Promise((resolve, reject) => { probe.once('connect', resolve); probe.once('error', reject); });
probe.write(
  'GET / HTTP/1.1\r\nHost: 127.0.0.1\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' +
  'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\n\r\n'
);
const handshake = await new Promise(r => probe.once('data', r));
assert(/101 Switching Protocols/.test(handshake.toString()), 'relay completes the websocket handshake');

wsSend(probe, encode(0, {v: 1, client_id: '1569992201914679329'}));
await new Promise(r => setTimeout(r, 400));
assert(frames.some(f => f.op === 0 && f.body.client_id === '1569992201914679329'), 'handshake reaches Discord with the app id');

wsSend(probe, encode(1, {cmd: 'SET_ACTIVITY', args: {pid: 0, activity: {type: 3, name: 'kozuTV', details: 'One Piece', state: 'S11E319'}}, nonce: 'n1'}));
await new Promise(r => setTimeout(r, 400));
const activity = frames.find(f => f.body.cmd === 'SET_ACTIVITY');
assert(activity && activity.body.args.activity.details === 'One Piece', 'SET_ACTIVITY is relayed unchanged');
assert(activity.body.args.activity.type === 3, 'activity type is Watching');
assert(frames.every(f => !JSON.stringify(f.body).includes('access_token')), 'no account token ever crosses the relay');

probe.destroy();
relay.kill();
fake.close();
fs.rmSync(dir, {recursive: true, force: true});
console.log('ALL RELAY TESTS PASSED');
