// Replaces the old MongoDB mirror test (the remote mirror was removed at the
// user's request). What must now hold: the store is local-only, a MongoDB URI
// in the environment changes nothing, and no remote client is ever created.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createTokenPersistence } from '../cache-token-persistence.js';

const dirs = [];
const temp = () => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'kozu-local-')); dirs.push(d); return d; };
const quiet = { warn() {} };
let clientCreated = false;

const dir = temp();
const store = createTokenPersistence({
  dataDir: dir,
  uri: 'mongodb://would-be-host/db',
  log: quiet,
  clientFactory: async () => { clientCreated = true; throw new Error('a remote client must never be created'); }
});
const state = await store.init();

assert.equal(state.backend, 'files', 'tokens are stored in local files');
assert.equal(state.mongo, 'disabled', 'remote mirror reports disabled, not retrying');
assert.equal(clientCreated, false, 'no remote client is constructed even with a URI set');

const created = store.create('visitor-1', {});
assert(/^[A-Za-z0-9]{6}$/.test(created.token), 'a six-character token is issued');
assert.equal(store.status('visitor-1').token, created.token, 'the token is bound to its visitor');
assert.equal(store.resolve(created.token).token, created.token, 'the token resolves locally');
assert.equal(store.patch('visitor-1', { 'kozutv-quality': '1080' }).preferences['kozutv-quality'], '1080', 'preferences persist');
assert(fs.existsSync(path.join(dir, 'cache-tokens.json')), 'document written to disk only');
await store.close();

console.log('PASS Cache Token is local-only: no MongoDB client, instant init, tokens and preferences persist on disk');

for (const d of dirs) fs.rmSync(d, { recursive: true, force: true });
