// Offline tests for the Discord Rich Presence module: OAuth URL, store,
// IPC framing/handshake, activity shape, and the failure paths that must
// stay silent (Discord closed, account not linked).
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kozutv-dc-'));
process.env.DISCORD_CLIENT_ID = '123456789012345678';
process.env.DISCORD_CLIENT_SECRET = 'test-secret';
process.env.DISCORD_REDIRECT_URI = 'http://localhost:3000/api/discord/callback';
process.env.KOZUTV_PUBLIC_URL = 'https://kozu.tv';
process.env.KOZUTV_DATA_DIR = dir;
process.env.XDG_RUNTIME_DIR = dir;

const mod = await import('../discord-rpc.js');
const assert = (ok, label) => { if (!ok) throw Error('FAILED: ' + label); console.log('PASS', label); };

// 1. Not configured without env
delete process.env.DISCORD_CLIENT_ID;
assert(mod.configured() === false, 'unconfigured server reports configured=false');
assert(mod.authorizeUrl('v', { headers: {} }) === null, 'no authorize URL without a client id');
process.env.DISCORD_CLIENT_ID = '123456789012345678';

// 2. Authorize URL
const url = new URL(mod.authorizeUrl('visitor', { headers: { host: 'localhost:3000' } }));
assert(url.origin + url.pathname === 'https://discord.com/oauth2/authorize', 'authorize URL host');
assert(url.searchParams.get('scope') === 'identify', 'identify scope');
assert(url.searchParams.get('response_type') === 'code', 'authorization code grant');
assert(/^[a-z0-9]+\.[A-Za-z0-9]+\.[A-Za-z0-9_-]{32}$/.test(url.searchParams.get('state')), 'state is signed and carries the visitor');
assert(url.searchParams.get('redirect_uri') === 'http://localhost:3000/api/discord/callback', 'redirect URI from config');

// 3. Store round-trip
mod.saveLink('visitor', { id: '42', username: 'tester', globalName: 'Tester', avatar: 'https://cdn/x.png', accessToken: 'a', refreshToken: 'r', expiresAt: Date.now() + 86400000 });
const link = mod.getLink('visitor');
assert(link.username === 'tester' && link.id === '42', 'link persists and reads back');
assert(fs.statSync(path.join(dir, 'discord-links.json')).mode & 0o077 ? false : true, 'store is not world readable');

// 4. IPC against a fake Discord client
const received = [];
const sock = path.join(dir, 'discord-ipc-0');
const clients = new Set();
const server = net.createServer(s => {
  clients.add(s); s.on('close', () => clients.delete(s));
  let buf = Buffer.alloc(0);
  s.on('data', chunk => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 8) {
      const op = buf.readUInt32LE(0), len = buf.readUInt32LE(4);
      if (buf.length < 8 + len) break;
      const body = JSON.parse(buf.subarray(8, 8 + len).toString());
      buf = buf.subarray(8 + len);
      received.push({ op, body });
      const reply = op === 0
        ? { cmd: 'DISPATCH', evt: 'READY', data: { v: 1 } }
        : { cmd: body.cmd, evt: null, nonce: body.nonce, data: {} };
      const payload = Buffer.from(JSON.stringify(reply));
      const head = Buffer.alloc(8); head.writeUInt32LE(1, 0); head.writeUInt32LE(payload.length, 4);
      s.write(Buffer.concat([head, payload]));
    }
  });
});
await new Promise(r => server.listen(sock, r));

mod.setState('visitor', { enabled: true, title: 'Breaking Bad', episodeText: 'S1 E3 : Cancer Man', linkUrl: '/watch/tv/1396', poster: 'https://img/x.jpg', startedAt: Date.now() });
const published = await mod.publish('visitor');
assert(published.ok === true, 'publish succeeds against a running Discord');
const handshake = received.find(f => f.op === 0);
assert(handshake && handshake.body.client_id === '123456789012345678' && handshake.body.v === 1, 'opcode 0 handshake carries the client id');
await new Promise(r => setTimeout(r, 150));
const frame = received.find(f => f.body.cmd === 'SET_ACTIVITY');
assert(Boolean(frame), 'SET_ACTIVITY frame reached Discord');
const activity = frame.body.args.activity;
assert(typeof frame.body.args.pid === 'number', 'SET_ACTIVITY includes pid');
assert(activity.type === 3, 'activity type is Watching');
assert(activity.name === 'kozuTV', 'activity names the app');
assert(activity.details === 'Breaking Bad' && activity.state === 'S1 E3 : Cancer Man', 'title and episode lines');
assert(activity.buttons?.[0]?.url === 'https://kozu.tv/watch/tv/1396', 'watch button points at the title');
assert(activity.assets.large_image === 'https://img/x.jpg', 'poster passed as a Discord external asset');

// 5. Toggle off clears the presence without dropping the link
mod.setState('visitor', { enabled: false });
const off = await mod.publish('visitor');
assert(off.ok === true && off.cleared === true, 'disabling clears the activity');
await new Promise(r => setTimeout(r, 150));
const cleared = received.filter(f => f.body.cmd === 'SET_ACTIVITY').pop();
assert(!cleared.body.args.activity, 'clear frame omits the activity');
assert(mod.getLink('visitor') !== null, 'link survives a clear');

// 6. Unlinked visitor never touches Discord
const before = received.length;
const unlinked = await mod.publish('nobody');
assert(unlinked.ok === false && unlinked.reason === 'not-connected', 'unlinked publish is a no-op');
assert(received.length === before, 'no frames sent for an unlinked visitor');

// 7. Discord closed -> publish reports failure instead of throwing
server.close();
for (const s of clients) s.destroy();
await new Promise(r => setTimeout(r, 250));
mod.setState('visitor', { enabled: true, title: 'One Piece', episodeText: 'Episode 3' });
const down = await mod.publish('visitor');
assert(down.ok === false && down.reason === 'ipc', 'closed Discord degrades to a quiet failure');
assert(/not running/i.test(down.message), 'failure explains that the desktop app is closed');


// 8. The signed state must verify after a restart (pending map is memory only)
{
  const urlA = new URL(mod.authorizeUrl('visitor', { headers: { host: 'localhost:3000' } }));
  const stateA = urlA.searchParams.get('state');
  assert(/^[a-z0-9]+\.[A-Za-z0-9]+\.[A-Za-z0-9_-]{32}$/.test(stateA), 'state carries issue time, visitor and signature');
  const mod2 = await import('../discord-rpc.js?restart=' + Date.now());
  assert(await mod2.completeOAuth(stateA, 'fake-code', { headers: { host: 'localhost:3000' } }).then(() => true, e => /fetch|token|JSON|ECONN|getaddrinfo|invalid_client/i.test(String(e))),
    'signed state is accepted by a fresh process (only the token exchange fails, as expected offline)');
  const tampered = stateA.replace(/.$/, c => (c === 'a' ? 'b' : 'a'));
  assert(await mod2.completeOAuth(tampered, 'fake-code', {}).then(() => false, e => /could not be verified|not valid/i.test(String(e))),
    'a tampered state is rejected');
  const stale = `${(Date.now() - 15 * 60 * 1000).toString(36)}.${'a'.repeat(32)}.${'x'.repeat(32)}`;
  assert(await mod2.completeOAuth(stale, 'fake-code', {}).then(() => false, e => /not valid|could not be verified|expired/i.test(String(e))),
    'an old or forged state is rejected');
}


// 9. Remote transport: a hosted box has no Discord client, so it must hand the
//    card to the browser instead of pretending to publish.
{
  assert(mod.transportAvailable() === true || mod.transportAvailable() === false, 'transport detection returns a boolean');
  const mod3 = await import('../discord-rpc.js?remote=' + Date.now());
  mod3.setState('visitor', {
    enabled: true, title: 'One Piece', episodeText: 'S11E319', linkUrl: '/watch/anime/21',
    poster: 'https://img/x.jpg', movie: false, startedAt: Date.now() - 62000
  });
  const card = mod3.activityFor('visitor');
  assert(card && card.type === 3 && card.details === 'One Piece' && card.state === 'S11E319', 'activityFor builds the same card the desktop transport sends');
  assert(card.assets.large_image === 'https://img/x.jpg', 'the browser card carries the poster URL');
  assert(mod3.activityFor('nobody') === null, 'no card is handed out for an unlinked visitor');
  mod3.setState('visitor', { enabled: false });
  assert(mod3.activityFor('visitor') === null, 'a disabled switch produces no card');
}

fs.rmSync(dir, { recursive: true, force: true });
console.log('ALL DISCORD TESTS PASSED');
