#!/usr/bin/env node
// kozuTV Discord relay - the small local helper that lets the *browser* publish
// Rich Presence to Discord's desktop client.
//
// Why a helper is needed: Discord has no cloud endpoint for presence. The
// desktop client exposes it on a local IPC endpoint (named pipe on Windows,
// $XDG_RUNTIME_DIR/discord-ipc-N unix socket elsewhere) and nothing else can
// reach it. A web page in any browser cannot open that endpoint, so the page
// talks to this relay over ws://127.0.0.1:6463 and the relay passes the frames
// straight through to the client.
//
// This is the same conclusion LastWave reached: presence must be delivered from
// the machine that runs Discord. LastWave can skip the relay because it is a
// native app living on that machine; a website cannot.
//
// What it does NOT do: it never sees a Discord account token, never asks for a
// password, and it cannot send anything Discord does not accept from an
// ordinary app. It only forwards the frames the page gives it.
//
// Usage:
//   node relay/kozutv-discord-relay.mjs            # listen on 127.0.0.1:6463
//   PORT=7000 node relay/...                       # different port
//   ALLOW_ORIGIN=https://kozutv.bond node relay/... # restrict which site may use it
//
// Run it on the machine where the Discord desktop app is running and signed in.

import net from 'node:net';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';

const PORT = Number(process.env.PORT || 6463);
const HOST = process.env.HOST || '127.0.0.1';
const ALLOW_ORIGIN = String(process.env.ALLOW_ORIGIN || '').trim();

function ipcCandidates() {
  const list = [];
  const add = base => { for (let i = 0; i < 10; i++) list.push(path.join(base, `discord-ipc-${i}`)); };
  if (process.platform === 'win32') {
    for (let i = 0; i < 10; i++) list.push(`\\\\?\\pipe\\discord-ipc-${i}`);
    return list;
  }
  for (const dir of [process.env.XDG_RUNTIME_DIR, process.env.TMPDIR, process.env.TMP, process.env.TEMP, '/tmp']) {
    if (dir) add(dir);
  }
  add(path.join(os.homedir(), '.flatpak/dev.discord.Discord/xdg-run'));
  add(path.join(os.homedir(), '.var/app/com.discordapp.Discord/xdg-run'));
  return [...new Set(list)];
}

function tryConnect(target) {
  return new Promise(resolve => {
    const socket = net.createConnection(target);
    const done = ok => {
      socket.removeAllListeners();
      if (ok) resolve(socket);
      else { try { socket.destroy(); } catch {} resolve(null); }
    };
    socket.once('connect', () => done(true));
    socket.once('error', () => done(false));
    setTimeout(() => done(false), 800);
  });
}

async function connectDiscord() {
  for (const candidate of ipcCandidates()) {
    const socket = await tryConnect(candidate);
    if (socket) return socket;
  }
  return null;
}

// ---------------------------------------------------------------- ws plumbing
function acceptKey(key) {
  return crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
}

function frame(opcode, payload) {
  const body = Buffer.from(payload);
  const head = body.length < 126
    ? Buffer.from([0x80 | opcode, body.length])
    : Buffer.from([0x80 | opcode, 126, body.length >> 8, body.length & 0xff]);
  return Buffer.concat([head, body]);
}

function readFrames(state) {
  const out = [];
  let buf = state.buffer;
  for (;;) {
    if (buf.length < 2) break;
    const opcode = buf[0] & 0x0f;
    const masked = (buf[1] & 0x80) !== 0;
    let length = buf[1] & 0x7f;
    let offset = 2;
    if (length === 126) {
      if (buf.length < 4) break;
      length = buf.readUInt16BE(2);
      offset = 4;
    } else if (length === 127) {
      if (buf.length < 10) break;
      length = Number(buf.readBigUInt64BE(2));
      offset = 10;
    }
    const maskBytes = masked ? 4 : 0;
    if (buf.length < offset + maskBytes + length) break;
    const mask = masked ? buf.subarray(offset, offset + 4) : null;
    const data = Buffer.from(buf.subarray(offset + maskBytes, offset + maskBytes + length));
    if (mask) for (let i = 0; i < data.length; i++) data[i] ^= mask[i % 4];
    out.push({ opcode, data });
    buf = buf.subarray(offset + maskBytes + length);
  }
  state.buffer = buf;
  return out;
}

const server = net.createServer(client => {
  let opened = false;
  const state = { buffer: Buffer.alloc(0) };
  let discord = null;

  const log = (...args) => console.log(new Date().toISOString().slice(11, 19), ...args);

  client.on('data', async chunk => {
    if (!opened) {
      const text = chunk.toString('latin1');
      const end = text.indexOf('\r\n\r\n');
      if (end === -1) return;
      const headers = Object.fromEntries(text.slice(0, end).split('\r\n').slice(1).map(line => {
        const i = line.indexOf(':');
        return [line.slice(0, i).toLowerCase().trim(), line.slice(i + 1).trim()];
      }));
      const origin = headers.origin || '';
      if (ALLOW_ORIGIN && origin && origin !== ALLOW_ORIGIN) {
        client.end('HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n');
        log('rejected origin', origin);
        return;
      }
      const key = headers['sec-websocket-key'];
      if (!key) { client.end('HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\n\r\n'); return; }
      client.write(
        'HTTP/1.1 101 Switching Protocols\r\n' +
        'Upgrade: websocket\r\nConnection: Upgrade\r\n' +
        `Sec-WebSocket-Accept: ${acceptKey(key)}\r\n\r\n`
      );
      opened = true;
      log('page connected', origin || '(no origin)');
      return;
    }

    state.buffer = Buffer.concat([state.buffer, chunk]);
    for (const incoming of readFrames(state)) {
      if (incoming.opcode === 0x8) { client.end(); return; }
      if (incoming.opcode !== 0x2 && incoming.opcode !== 0x1) continue;
      const body = Buffer.from(incoming.data);
      if (body.length < 8) continue;
      const op = body.readUInt32LE(0);
      const length = body.readUInt32LE(4);
      const json = body.subarray(8, 8 + length);

      if (op === 0) {
        // handshake: open a fresh Discord connection for this page
        discord = await connectDiscord();
        if (!discord) {
          log('no Discord desktop client found');
          client.write(frame(0x8, ''));
          return;
        }
        log('relaying to', 'discord-ipc');
        discord.on('data', data => {
          if (client.destroyed) return;
          client.write(frame(0x2, data));
        });
        discord.on('close', () => {
          log('Discord closed the connection');
          if (!client.destroyed) client.write(frame(0x8, ''));
        });
      }
      if (!discord) continue;
      try {
        discord.write(body);
      } catch (error) {
        log('write failed:', error.message);
      }
    }
  });

  const cleanup = () => {
    if (discord) { try { discord.destroy(); } catch {} discord = null; }
  };
  client.on('close', cleanup);
  client.on('error', cleanup);
});

server.listen(PORT, HOST, () => {
  console.log(`kozutv-discord-relay listening on ws://${HOST}:${PORT}`);
  console.log(ALLOW_ORIGIN ? `only accepting pages from ${ALLOW_ORIGIN}` : 'accepting pages from any origin (set ALLOW_ORIGIN to restrict)');
  console.log('the Discord desktop app must be running and signed in on this machine');
});
