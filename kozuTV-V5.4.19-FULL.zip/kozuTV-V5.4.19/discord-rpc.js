// Discord Rich Presence for kozuTV.
//
// Two halves:
//   1. OAuth2 (authorization code, scope "identify") so a visitor can link their
//      Discord account to this kozuTV visitor id and we can show their avatar.
//   2. Rich Presence, pushed from the browser through this module to the local
//      Discord desktop client over its IPC socket (named pipe on Windows,
//      unix socket elsewhere). The browser cannot open that socket, so the
//      server relays it.
//
// Nothing here runs until DISCORD_CLIENT_ID and DISCORD_CLIENT_SECRET exist in
// .env; every entry point returns { configured: false } until then, so an
// install without Discord configured behaves exactly as before.

import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

const API = 'https://discord.com/api/v10';
const OAUTH_URL = 'https://discord.com/oauth2/authorize';

const config = () => ({
  clientId: String(process.env.DISCORD_CLIENT_ID || '').trim(),
  clientSecret: String(process.env.DISCORD_CLIENT_SECRET || '').trim(),
  appName: String(process.env.DISCORD_APP_NAME || 'kozuTV').trim(),
  redirectUri: String(process.env.DISCORD_REDIRECT_URI || '').trim(),
  publicUrl: String(process.env.KOZUTV_PUBLIC_URL || '').trim().replace(/\/+$/, '')
});

const configured = () => Boolean(config().clientId && config().clientSecret);

// ---------------------------------------------------------------- persistence
// One small JSON file beside the watchlist/history store. Tokens are long-lived
// (Discord access tokens last 7 days, refresh tokens rotate), so they need a
// home that survives restarts.
function storePath() {
  const dir = process.env.KOZUTV_DATA_DIR || path.join(here, 'data');
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, 'discord-links.json');
}

function readStore() {
  try {
    const raw = JSON.parse(fs.readFileSync(storePath(), 'utf8'));
    return raw && typeof raw === 'object' && raw.links ? raw : { links: {}, states: {} };
  } catch {
    return { links: {}, states: {} };
  }
}

function writeStore(store) {
  const file = storePath();
  const temp = `${file}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  try {
    fs.writeFileSync(temp, JSON.stringify(store), { flag: 'wx', mode: 0o600 });
    fs.renameSync(temp, file);
  } finally {
    try { fs.unlinkSync(temp); } catch {}
  }
}

const cleanLink = link => link && typeof link === 'object' ? {
  id: String(link.id || ''),
  username: String(link.username || ''),
  globalName: String(link.globalName || ''),
  avatar: String(link.avatar || ''),
  discriminator: String(link.discriminator || '0'),
  accessToken: String(link.accessToken || ''),
  refreshToken: String(link.refreshToken || ''),
  expiresAt: Number(link.expiresAt) || 0,
  scope: String(link.scope || 'identify'),
  linkedAt: Number(link.linkedAt) || Date.now()
} : null;

function getLink(visitorId) {
  const store = readStore();
  return cleanLink(store.links[visitorId]);
}

function saveLink(visitorId, link) {
  const store = readStore();
  store.links[visitorId] = cleanLink(link);
  writeStore(store);
  return store.links[visitorId];
}

function removeLink(visitorId) {
  const store = readStore();
  delete store.links[visitorId];
  delete store.states[visitorId];
  writeStore(store);
  return { connected: false };
}

// Presence state per visitor: what they were last watching, and whether the
// browser has the toggle on. Kept server-side so the relay can retry when
// Discord starts *after* the browser did.
function setState(visitorId, patch) {
  const store = readStore();
  const prev = store.states[visitorId] || {};
  store.states[visitorId] = { ...prev, ...patch, updated: Date.now() };
  writeStore(store);
  return store.states[visitorId];
}

function getState(visitorId) {
  return readStore().states[visitorId] || null;
}

// ---------------------------------------------------------------- OAuth2
const pending = new Map(); // state -> { visitorId, createdAt }
const PENDING_TTL_MS = 10 * 60 * 1000; // Discord's authorization code lives 10 minutes.

function prunePending() {
  const cutoff = Date.now() - PENDING_TTL_MS;
  for (const [key, value] of pending) if (value.createdAt < cutoff) pending.delete(key);
}

function defaultRedirectUri(req) {
  const { redirectUri, publicUrl } = config();
  if (redirectUri) return redirectUri;
  if (publicUrl) return `${publicUrl}/api/discord/callback`;
  // Fall back to the host the visitor actually used, so a LAN install works
  // without extra configuration.
  const host = String(req?.headers?.host || 'localhost:3000');
  const proto = String(req?.headers?.['x-forwarded-proto'] || '').split(',')[0].trim() || (host.startsWith('localhost') || host.startsWith('127.') ? 'http' : 'https');
  return `${proto}://${host}/api/discord/callback`;
}

// The in-memory map only lives as long as the process, so a restart between
// "Connect" and Discord's redirect used to dead-end with "This link has
// expired". The state is signed with the client secret instead: it verifies
// after a restart, needs no disk, and cannot be forged without the secret.
function signState(visitorId, issued) {
  const secret = String(process.env.DISCORD_CLIENT_SECRET || '');
  return crypto.createHmac('sha256', secret).update(`${visitorId}.${issued}`).digest('base64url').slice(0, 32);
}

function authorizeUrl(visitorId, req) {
  const { clientId } = config();
  if (!clientId) return null;
  prunePending();
  const issued = Date.now();
  const state = `${issued.toString(36)}.${visitorId}.${signState(visitorId, issued)}`;
  pending.set(state, { visitorId, createdAt: issued });
  const params = new URLSearchParams({
    client_id: clientId,
    response_type: 'code',
    scope: 'identify',
    redirect_uri: defaultRedirectUri(req),
    state,
    prompt: 'consent'
  });
  return `${OAUTH_URL}?${params.toString()}`;
}

async function tokenRequest(body) {
  const { clientId, clientSecret } = config();
  const response = await fetch(`${API}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, ...body }),
    signal: AbortSignal.timeout(15000)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Error(data.error_description || data.error || `Discord token endpoint returned ${response.status}`);
  return data;
}

async function fetchIdentity(accessToken) {
  const response = await fetch(`${API}/users/@me`, {
    headers: { Authorization: `Bearer ${accessToken}` },
    signal: AbortSignal.timeout(12000)
  });
  if (!response.ok) throw Error(`Discord identity request returned ${response.status}`);
  return response.json();
}

function avatarUrl(user) {
  if (!user?.id) return '';
  if (!user.avatar) return `https://cdn.discordapp.com/embed/avatars/${Number(user.discriminator || 0) % 5}.png`;
  const ext = String(user.avatar).startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.${ext}?size=128`;
}

// Completes the redirect: exchange the code, read the profile, store the link.
async function completeOAuth(state, code, req) {
  prunePending();
  let entry = pending.get(state);
  if (!entry) {
    // Not in memory (server restarted, or the flow was started from a status
    // fetch on another host). Verify the signature and accept it while it is
    // still inside Discord's own authorization window.
    const [issuedPart, visitorPart, signature] = String(state || '').split('.');
    const issued = parseInt(issuedPart, 36);
    if (!visitorPart || !signature || !Number.isFinite(issued)) {
      throw Error('This Discord sign-in link is not valid. Start the connection again from Settings.');
    }
    if (signState(visitorPart, issued) !== signature) {
      throw Error('This Discord sign-in link could not be verified. Start the connection again from Settings.');
    }
    if (Date.now() - issued > PENDING_TTL_MS) {
      throw Error('This Discord sign-in link expired. Start the connection again from Settings.');
    }
    entry = { visitorId: visitorPart, createdAt: issued };
  }
  pending.delete(state);
  const tokens = await tokenRequest({
    grant_type: 'authorization_code',
    code,
    redirect_uri: defaultRedirectUri(req)
  });
  const user = await fetchIdentity(tokens.access_token);
  const link = saveLink(entry.visitorId, {
    id: user.id,
    username: user.username,
    globalName: user.global_name || '',
    discriminator: user.discriminator || '0',
    avatar: avatarUrl(user),
    accessToken: tokens.access_token,
    refreshToken: tokens.refresh_token || '',
    expiresAt: Date.now() + (Number(tokens.expires_in) || 604800) * 1000,
    scope: tokens.scope || 'identify',
    linkedAt: Date.now()
  });
  return { visitorId: entry.visitorId, link };
}

async function refreshIfNeeded(visitorId) {
  const link = getLink(visitorId);
  if (!link) return null;
  if (link.expiresAt - Date.now() > 10 * 60 * 1000 || !link.refreshToken) return link;
  try {
    const tokens = await tokenRequest({ grant_type: 'refresh_token', refresh_token: link.refreshToken });
    return saveLink(visitorId, {
      ...link,
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token || link.refreshToken,
      expiresAt: Date.now() + (Number(tokens.expires_in) || 604800) * 1000
    });
  } catch {
    // Refresh can fail if the user revoked access; drop the link so the UI
    // shows "Connect" again rather than pretending to be connected.
    if (getLink(visitorId)?.expiresAt < Date.now()) { removeLink(visitorId); return null; }
    return link;
  }
}

// ---------------------------------------------------------------- IPC relay
// Framing: uint32 LE opcode, uint32 LE length, UTF-8 JSON.
function ipcCandidates() {
  const list = [];
  const add = base => { for (let i = 0; i < 10; i++) list.push(path.join(base, `discord-ipc-${i}`)); };
  if (process.platform === 'win32') {
    for (let i = 0; i < 10; i++) list.push(String.raw`\\.\pipe\discord-ipc-` + i);
    return list;
  }
  for (const dir of [process.env.XDG_RUNTIME_DIR, process.env.TMPDIR, process.env.TMP, process.env.TEMP, '/tmp']) {
    if (dir) add(dir);
  }
  // Flatpak and Snap installs put the socket outside the host /tmp.
  add(path.join(os.homedir(), '.flatpak/dev.discord.Discord/xdg-run'));
  add(path.join(os.homedir(), '.var/app/com.discordapp.Discord/xdg-run'));
  return [...new Set(list)];
}

function tryConnect(pipePath) {
  return new Promise(resolve => {
    const socket = net.createConnection(pipePath);
    const fail = () => { socket.destroy(); resolve(null); };
    socket.once('error', fail);
    socket.setTimeout(1200, fail);
    socket.once('connect', () => {
      socket.setTimeout(0);
      socket.removeListener('error', fail);
      resolve(socket);
    });
  });
}

function frame(opcode, payload) {
  const body = Buffer.from(JSON.stringify(payload), 'utf8');
  const head = Buffer.alloc(8);
  head.writeUInt32LE(opcode, 0);
  head.writeUInt32LE(body.length, 4);
  return Buffer.concat([head, body]);
}

function readFrames(socket, onFrame) {
  let buffer = Buffer.alloc(0);
  socket.on('data', chunk => {
    buffer = Buffer.concat([buffer, chunk]);
    while (buffer.length >= 8) {
      const opcode = buffer.readUInt32LE(0);
      const length = buffer.readUInt32LE(4);
      if (buffer.length < 8 + length) break;
      const body = buffer.subarray(8, 8 + length).toString('utf8');
      buffer = buffer.subarray(8 + length);
      onFrame(opcode, body);
    }
  });
}

let connection = null;
let lastConnectedAt = 0; // { socket, ready, waiting: Map, clientId }

async function connect() {
  const { clientId } = config();
  if (!clientId) throw Error('Discord is not configured on this server.');
  if (connection && !connection.socket.destroyed && connection.ready) return connection;
  if (connection) { try { connection.socket.destroy(); } catch {} connection = null; }

  let socket = null;
  for (const candidate of ipcCandidates()) {
    socket = await tryConnect(candidate);
    if (socket) break;
  }
  if (!socket) {
    // Distinguish the three states, because the wording the user sees differs:
    //   a Discord app exists here     -> it is just not running, ask to open it
    //   a graphical machine, no app   -> desktop client missing
    //   a headless host (VPS/docker)  -> this machine can never publish, so the
    //                                    page (browser relay) or the APK must
    const desktop = transportAvailable();
    // Someone had a working Discord connection moments ago: this is a client
    // that has just quit, not a machine that never had one.
    const dropped = connection !== null || lastConnectedAt > 0 && Date.now() - lastConnectedAt < 60000;
    // A socket file on disk means a Discord client lives here too.
    const socketPresent = ipcCandidates().some(candidate => {
      try { return fs.statSync(candidate).isSocket(); } catch { return false; }
    });
    const graphical = hasGraphicalSession() || socketPresent || dropped;
    const error = Error(desktop || graphical
      ? 'The Discord desktop app is not running on this machine.'
      : 'This machine has no Discord desktop client, so it cannot publish presence itself. Use the Discord link in Settings to publish from your own device.');
    error.reason = 'ipc';
    error.transport = desktop || graphical ? 'desktop' : 'none';
    throw error;
  }

  const conn = { socket, ready: false, waiting: new Map(), clientId };
  connection = conn;
  lastConnectedAt = Date.now();
  readFrames(socket, (opcode, body) => {
    let payload = {};
    try { payload = JSON.parse(body); } catch {}
    if (payload.cmd === 'DISPATCH' && payload.evt === 'READY') {
      conn.ready = true;
      for (const [, resolve] of conn.waiting) resolve(true);
      conn.waiting.clear();
    }
    if (payload.nonce && conn.waiting.has(payload.nonce)) {
      const resolve = conn.waiting.get(payload.nonce);
      conn.waiting.delete(payload.nonce);
      resolve(payload.evt !== 'ERROR' ? payload : null);
    }
  });
  socket.on('close', () => { if (connection === conn) connection = null; });
  socket.on('error', () => { if (connection === conn) connection = null; });

  socket.write(frame(0, { v: 1, client_id: clientId }));
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(Error('Discord did not answer the handshake.')), 4000);
    conn.waiting.set('__ready__', () => { clearTimeout(timer); resolve(true); });
    // READY arrives as a dispatch, not a nonce reply; poll the flag.
    const check = setInterval(() => {
      if (conn.ready) { clearInterval(check); clearTimeout(timer); resolve(true); }
    }, 60);
    socket.once('close', () => { clearInterval(check); clearTimeout(timer); reject(Error('Discord closed the connection.')); });
  });
  conn.waiting.delete('__ready__');
  return conn;
}

// True when this machine could host a Discord desktop client at all.
// A Linux server / container / CI box has no DISPLAY and no socket, so the
// server can never publish presence there - the browser has to do it.
// Where Discord's IPC endpoint would be on this machine. Used only for wording
// and for the transport hint the Settings card shows; a real connection is
// always attempted before anything is claimed to work.
function transportAvailable() {
  return process.platform === 'win32' || process.platform === 'darwin';
}

// False on a headless server (VPS, container): such a box has no Discord client
// and never will, so the page must publish through the visitor's own device.
// This is what stops a hosted kozuTV from claiming "the desktop app is closed".
function hasGraphicalSession() {
  if (process.platform === 'win32' || process.platform === 'darwin') return true;
  return Boolean(process.env.DISPLAY || process.env.WAYLAND_DISPLAY);
}

// The exact SET_ACTIVITY payload the desktop relay would send. The web player
// re-uses it verbatim so both transports show an identical card.
function activityFor(visitorId) {
  const state = getState(visitorId);
  if (!state || state.enabled === false || !state.title) return null;
  return buildActivity(state);
}

async function setActivity(payload) {
  const conn = await connect();
  if (conn.socket.destroyed || !conn.socket.writable) throw Error('The Discord desktop app closed the connection.');
  const nonce = crypto.randomUUID();
  const args = { pid: process.pid, activity: payload };
  conn.socket.write(frame(1, { cmd: 'SET_ACTIVITY', args, nonce }));
  return true;
}

async function clearActivity() {
  if (!connection || connection.socket.destroyed) return false;
  const nonce = crypto.randomUUID();
  connection.socket.write(frame(1, { cmd: 'SET_ACTIVITY', args: { pid: process.pid }, nonce }));
  return true;
}

// ---------------------------------------------------------------- presence API
// Mirrors what Discord shows for a streaming service: a "Watching <app>" line,
// the title, the episode, an elapsed timer and one button.
function buildActivity(state) {
  const { appName } = config();
  const { publicUrl } = config();
  const title = String(state.title || '').slice(0, 128);
  const episodeText = String(state.episodeText || '').slice(0, 128);
  const activity = {
    type: 3, // Watching
    name: appName,
    details: title || `Browsing ${appName}`,
    state: title ? episodeText : 'Looking for something to watch',
    assets: { large_text: `${appName} · ${title || 'Home'}`.slice(0, 128) },
    timestamps: state.startedAt ? { start: Math.round(state.startedAt) } : undefined
  };
  if (state.poster) activity.assets.large_image = state.poster;
  if (state.movie) activity.assets.small_image = state.poster || activity.assets.large_image;
  if (publicUrl && title) {
    const link = state.linkUrl ? `${publicUrl}${state.linkUrl}` : publicUrl;
    activity.buttons = [{ label: 'Watch on kozuTV', url: link.slice(0, 512) }];
  }
  if (!activity.assets.large_image) delete activity.assets;
  return activity;
}

async function publish(visitorId) {
  const link = await refreshIfNeeded(visitorId);
  if (!link) return { ok: false, reason: 'not-connected' };
  const state = getState(visitorId);
  if (!state) return { ok: false, reason: 'no-activity' };
  if (state.enabled === false || !state.title) {
    await clearActivity().catch(() => {});
    return { ok: true, cleared: true };
  }
  try {
    await setActivity(buildActivity(state));
    return { ok: true };
  } catch (error) {
    return { ok: false, reason: 'ipc', message: error.message };
  }
}

export {
  transportAvailable,
  hasGraphicalSession,
  activityFor,
  config,
  configured,
  authorizeUrl,
  completeOAuth,
  getLink,
  saveLink,
  removeLink,
  refreshIfNeeded,
  setState,
  getState,
  publish,
  clearActivity,
  buildActivity,
  avatarUrl,
  ipcCandidates,
  defaultRedirectUri
};
export default {
  config, configured, authorizeUrl, completeOAuth, getLink, saveLink, removeLink,
  refreshIfNeeded, setState, getState, publish, clearActivity, buildActivity, avatarUrl
};
