// Discord Rich Presence, published by the BROWSER instead of the server.
//
// Why this exists: Rich Presence is not a cloud API. Discord's desktop client
// exposes presence on a local IPC endpoint (named pipe on Windows,
// $XDG_RUNTIME_DIR/discord-ipc-N unix socket elsewhere), and there is no
// server-to-Discord endpoint at all. A hosted kozuTV box has no Discord client,
// so it can never publish presence for you.
//
// Small Discord-aware programs solve this by letting the page talk to the
// local client through a tiny shim that must run on the user's own machine.
// That is the only shape a web app can take - LastWave can talk straight to
// the client because it *is* the native app on the device.
//
// This file is the browser half of that shim. It opens a WebSocket to a local
// relay and then speaks Discord's protocol inside it:
//
//   [4-byte LE opcode][4-byte LE length][JSON]
//
//   0 = HANDSHAKE  {"v":1,"client_id":"..."}
//   1 = FRAME      {"cmd":"SET_ACTIVITY","args":{...},"nonce":"..."}
//
// The relay side is relay/kozutv-discord-relay.mjs: it only forwards these
// frames to the Discord socket on the same machine. No account token is ever
// involved - Discord only ever sees the application id, exactly like a native
// app. kozuTV keeps the OAuth token on its own server and uses it only to read
// your username and avatar.
//
// State: this module is inert until something calls connect(). The player only
// calls it when the server reports { relay: 'browser' }.

const RELAY_CANDIDATES = ['ws://127.0.0.1:6463', 'ws://localhost:6463'];
const RECONNECT_DELAY = 15000;

let socket = null;
let ready = false;
let connecting = null;
let clientId = '';
let lastPayload = '';
let lastSentAt = 0;
let nonce = 0;

function encode(op, payload) {
  const body = new TextEncoder().encode(JSON.stringify(payload));
  const frame = new Uint8Array(8 + body.length);
  const view = new DataView(frame.buffer);
  view.setUint32(0, op, true);
  view.setUint32(4, body.length, true);
  frame.set(body, 8);
  return frame;
}

function decode(buffer) {
  const bytes = new Uint8Array(buffer);
  if (bytes.length < 8) return null;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const op = view.getUint32(0, true);
  const length = view.getUint32(4, true);
  let payload = null;
  try {
    payload = JSON.parse(new TextDecoder().decode(bytes.subarray(8, 8 + length)));
  } catch {
    payload = null;
  }
  return { op, payload };
}

function openRelay(url) {
  return new Promise(resolve => {
    let settled = false;
    let ws;
    try {
      ws = new WebSocket(url);
    } catch {
      resolve(null);
      return;
    }
    ws.binaryType = 'arraybuffer';
    const fail = () => {
      if (settled) return;
      settled = true;
      try { ws.close(); } catch {}
      resolve(null);
    };
    const timer = setTimeout(fail, 1200);
    ws.onopen = () => {
      clearTimeout(timer);
      if (settled) { try { ws.close(); } catch {} return; }
      settled = true;
      resolve(ws);
    };
    ws.onerror = fail;
    ws.onclose = () => {
      if (socket === ws) {
        ready = false;
        socket = null;
      }
      if (!settled) fail();
    };
    ws.onmessage = event => {
      const frame = decode(event.data);
      // opcode 1 DISPATCH with evt READY means Discord accepted the handshake
      if (frame && frame.op === 1 && frame.payload && frame.payload.evt === 'READY') ready = true;
    };
  });
}

// Resolves true when a local relay answers and Discord accepts the handshake.
export async function connect(id) {
  if (ready && socket) return true;
  if (connecting) return connecting;
  clientId = String(id || clientId || '');
  if (!clientId) return false;
  connecting = (async () => {
    for (const url of RELAY_CANDIDATES) {
      const ws = await openRelay(url);
      if (!ws) continue;
      socket = ws;
      ws.send(encode(0, { v: 1, client_id: clientId }));
      // Give Discord a moment to answer the handshake.
      await new Promise(r => setTimeout(r, 350));
      if (ready) return true;
      try { ws.close(); } catch {}
      socket = null;
      ready = false;
    }
    return false;
  })().finally(() => { connecting = null; });
  return connecting;
}

// Sends one activity (or clears it with null). Deduped and throttled: the
// player ticks position every second and none of those ticks need a frame.
export async function publish(activity) {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    const ok = await connect(clientId);
    if (!ok) return { ok: false, reason: 'relay' };
  }
  const payload = JSON.stringify(activity || null);
  const now = Date.now();
  // A clear must always go through - otherwise leaving the player right after
  // starting something leaves a stale card on your profile.
  const isClear = !activity;
  if (!isClear) {
    if (payload === lastPayload && now - lastSentAt < RECONNECT_DELAY) return { ok: true, deduped: true };
    if (now - lastSentAt < 1000) return { ok: true, throttled: true };
  }
  lastPayload = payload;
  lastSentAt = now;
  const args = activity ? { pid: 0, activity } : { pid: 0 };
  try {
    socket.send(encode(1, { cmd: 'SET_ACTIVITY', args, nonce: `${++nonce}-${now}` }));
    return { ok: true };
  } catch {
    ready = false;
    try { socket.close(); } catch {}
    socket = null;
    return { ok: false, reason: 'relay' };
  }
}

export function status() {
  return { connected: Boolean(socket && socket.readyState === WebSocket.OPEN), ready, clientId };
}

export function disconnect() {
  if (!socket) return;
  try { socket.close(); } catch {}
  socket = null;
  ready = false;
  lastPayload = '';
}
