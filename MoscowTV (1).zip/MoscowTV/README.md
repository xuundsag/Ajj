# MoscowTV

A combined anime, movie and web-series catalog at `/browse` with search, title details, episode lists, watchlist, genre-based suggestions and Continue Watching. Node 20+ recommended.

## Start

```sh
node start.js
```

Edit `PORT` at the top of `start.js` to change port 3000. The launcher installs dependencies if needed. The frontend is static; there is no build step. For a reliable OTT catalog, set your own `TMDB_API_KEY` environment variable; otherwise the server tries publicly shared keys from `freekeys`, which may fail or be rate-limited.

## Integrations

- Anime metadata: AniList. Anime playback: AnimeEmbed (`animeembed.com`) iframe, configured with orange accent, Sub/Dub, autoplay and `start`. An anime's linked sequel may appear as another season. Individual anime episode titles/images are not available from this metadata source.
- Movie/TV metadata and TV episode stills/titles: TMDB. Movie/TV embeds: VidCore (Stream 1) and Vidsrc (Stream 2).
- AnimeEmbed's documented versioned `postMessage` progress is validated by sender/origin and saved to `data/user.json`; time and duration appear in Continue Watching. VidCore accepts `startAt` when a saved position exists, but its public events do not establish reliable time reporting. Stream 2 OTT has no verified seek/progress integration. Opening a watch page creates history without fabricating progress.
- The app does not proxy streams or replace controls inside third-party iframes. The anime provider requires an unsandboxed iframe; this site cannot guarantee blocking its ads, redirects or popups. Playback availability varies by title and provider.

Watchlist and history are a single shared local profile, not per-user accounts. Do not expose a multi-user deployment without implementing authentication and private data storage. Verify content rights and provider terms before deploying.

## Attribution

The dark spotlight layout takes inspiration from Anipaca; its GPL-3.0 license is retained in `ANIPACA-LICENSE.txt`. MoscowTV's logo is a separate text wordmark.

## Latest mobile and episode-list changes

Manrope 400/700/800 is bundled locally, so mobile does not depend on a font CDN. Mobile navigation uses the MoscowTV wordmark and an icon-only watchlist shortcut; the player control bar is icon-only at mobile widths. Web-series episode rows use the desktop-style vertical list at all widths. AniList's ongoing `nextAiringEpisode` count is used when `episodes` is null, and anime lists are paginated in groups of 100 rather than truncated to 24/100. One Piece is a single continuous AniList title, not multiple separately cataloged seasons. TMDB season 0 (specials) is included when present. Movie/TV stream 1 is VidCore and stream 2 is CineSrc; CineSrc describes its free tier as having minimal ads, so neither source is guaranteed ad-free.

Latest improvements: mobile watch pages remove the small back/title line above the player and sit 11px below the header. Search is a locally rendered 32px SVG without a gray circle; the watchlist icon is similarly unframed. Spotlights rotate every 6.5 seconds with fading artwork and animated dot progress (paused when the page is hidden). Comedy, Horror and Romance shelves are loaded after the main catalog, and catalog queries are cached. Anime episode buttons now render every cataloged episode within a scrollable list (One Piece: 1,180 at time of verification), while AniList linked sequels are followed across several relations where known. Long-running shows such as One Piece are a single AniList entry, so there are no fabricated separate seasons.

## Verified episode lists and latest playback

On the current AniList response, One Piece has 1,180 indexed episodes, Naruto: Shippuden 500 and Bleach 366. All corresponding numbered episode buttons are rendered and the final numbers were checked in Chromium. Example requests to AnimeEmbed's final-episode iframe URLs returned HTTP 200, but this is not proof that all media files play. Money Heist's TMDB ID 71446 has Specials plus Seasons 1–3; Season 2 has 16 episode rows, tested in Chromium. Stream 2 for movies and shows now uses EmbedWave; the provider says its shell injects no ads, but third-party upstream behavior cannot be guaranteed.

The player control rail was redesigned with large icon targets and a restrained dark surface. Header search and watchlist SVGs are both 32px at mobile widths. The latest screenshot collection under `screenshots/current-*` covers browse, anime/movie/series details and watch pages, and watchlist at both desktop and mobile sizes.

Latest watch UI update: removed the Browse return link, adapted Anipaca's dark control-strip structure (Expand, Auto Play/Next/Skip, Light, Prev/Next and Add to List) in MoscowTV orange, and added episode-range dropdowns next to the season dropdown for anime with over 100 episodes. The provider iframe's own start/play button is cross-origin and cannot be hidden without provider support. The mobile spotlight uses the portrait poster as its backdrop, keeping subjects centered. Browse selects three random genres from Action, Adventure, Animation, Comedy, Drama, Fantasy, Horror, Romance and Thriller on each browse load, and spotlight rotation continues independently.

UI update: removed triangular play symbols from the site's Watch, Stream, and detail buttons (embedded provider controls remain provider-owned). Details-page mobile actions are text-only `Watch` and `+ Add`; desktop retains `Watch Now` and `+ Add to Watchlist`. Hero descriptions are shortened and details copy is clamped to three mobile lines. Mobile spotlight now uses the same backdrop image as desktop rather than swapping in portrait poster art.
