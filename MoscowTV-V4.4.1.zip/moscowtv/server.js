import freekeys from 'freekeys';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { cinesrcSubtitles, warmCineSrcBrowser } from './cinesrc-resolver.js';
import { resolveMegaPlayDirect } from './megaplay-resolver.js';
import { mediaUrl, dashUrl, handleMedia, handleDash } from './media-proxy.js';
import { OTT_SERVER_KEYS, resolveOttWithFallback } from './multilingual-resolvers.js';
const root=path.resolve('public'), db=path.resolve('data/user.json'), statesDb=path.resolve('data/states.json');
const initial={watchlist:[],history:[]};
if(!fs.existsSync(db))fs.writeFileSync(db,JSON.stringify(initial));
if(!fs.existsSync(statesDb))fs.writeFileSync(statesDb,JSON.stringify({visitors:{},meta:{}}));
const json=(res,data,status=200,req=null)=>{let body=JSON.stringify(data),accept=String(req?.headers?.['accept-encoding']||'');if(body.length>1024&&accept.includes('gzip')){let gz=zlib.gzipSync(body,{level:4});res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Encoding':'gzip','Vary':'Accept-Encoding','Cache-Control':'no-store'});return res.end(gz)}res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(body)};
const cache=new Map();
async function remote(url,options={}){
 let ttl=options.ttl??300000,c=cache.get(url);if(c&&Date.now()-c.time<(c.ttl||ttl))return c.data;
 let r=await fetch(url,{headers:{'User-Agent':'MoscowTV/4.4 (catalog app)',...(options.headers||{})},signal:AbortSignal.timeout(options.timeout||12000)}),text=await r.text();
 if(!r.ok)throw Error('Catalog unavailable ('+r.status+')');
 let data;try{data=JSON.parse(text)}catch{throw Error('A catalog service returned an invalid response.')}
 cache.set(url,{data,time:Date.now(),ttl});return data;
}
const genreNames={28:'Action',12:'Adventure',16:'Animation',35:'Comedy',80:'Crime',99:'Documentary',18:'Drama',10751:'Family',14:'Fantasy',36:'History',27:'Horror',10402:'Music',9648:'Mystery',10749:'Romance',878:'Science Fiction',10770:'TV Movie',53:'Thriller',10752:'War',37:'Western',10759:'Action & Adventure',10765:'Sci-Fi & Fantasy'};
const catalogGenres=['Action','Adventure','Animation','Comedy','Crime','Documentary','Drama','Family','Fantasy','Horror','Mecha','Music','Mystery','Psychological','Romance','Sci-Fi','Slice of Life','Sports','Supernatural','Thriller'];
const movieGenreIds={Action:28,Adventure:12,Animation:16,Comedy:35,Crime:80,Documentary:99,Drama:18,Family:10751,Fantasy:14,Horror:27,Music:10402,Mystery:9648,Romance:10749,'Sci-Fi':878,Thriller:53};
const tvGenreIds={Action:10759,Adventure:10759,Animation:16,Comedy:35,Crime:80,Documentary:99,Drama:18,Family:10751,Fantasy:10765,Mystery:9648,'Sci-Fi':10765};
const today=()=>new Date().toISOString().slice(0,10);
const releasedDate=value=>Boolean(value)&&String(value).slice(0,10)<=today();
const releasedOtt=x=>releasedDate(x.release_date||x.first_air_date);
const japaneseAnimation=x=>{let animated=x.genre_ids?.includes(16)||x.genres?.some(g=>g.id===16||g.name==='Animation');return animeAliasMatch(x.title||x.name)||Boolean(animated&&(x.original_language==='ja'||x.origin_country?.includes('JP')))};
const ott=x=>({id:String(x.id),type:x.media_type==='tv'||(!x.media_type&&x.first_air_date)?'tv':'movie',title:x.title||x.name||'',poster:x.poster_path?'https://image.tmdb.org/t/p/w500'+x.poster_path:null,backdrop:x.backdrop_path?'https://image.tmdb.org/t/p/original'+x.backdrop_path:null,description:x.overview||'',rating:x.vote_average?Number(x.vote_average.toFixed(1)):null,year:(x.release_date||x.first_air_date||'').slice(0,4),releaseDate:x.release_date||x.first_air_date||null,japaneseAnimation:japaneseAnimation(x),genres:x.genres?.map(g=>g.name)||x.genre_ids?.map(id=>genreNames[id]).filter(Boolean)||[],seasons:x.number_of_seasons});
const aniCache=new Map();async function anilist(query,variables={}){let key=JSON.stringify([query,variables]),cached=aniCache.get(key);if(cached&&Date.now()-cached.time<300000)return cached.data;let r=await fetch('https://graphql.anilist.co',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query,variables}),signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('Anime catalog unavailable');let text=await r.text(),d;try{d=JSON.parse(text)}catch{throw Error('Anime catalog returned an invalid response.')}if(d.errors)throw Error(d.errors[0].message);aniCache.set(key,{data:d.data,time:Date.now()});return d.data}
const fields='id idMal title{english romaji} coverImage{extraLarge large} bannerImage description(asHtml:false) averageScore format seasonYear startDate{year month day} episodes nextAiringEpisode{episode} genres status isAdult';
const positiveInt=value=>Number.isInteger(Number(value))&&Number(value)>0?Number(value):null;
function animeEpisodeCount(media){
 if(media.format==='MOVIE'||media.status==='NOT_YET_RELEASED')return null;
 let total=positiveInt(media.episodes);
 if(media.status==='RELEASING'){
  let released=positiveInt((media.nextAiringEpisode?.episode||1)-1);
  if(released)return total?Math.min(total,released):released;
 }
 return total;
}
const megaCatalogPath=path.resolve('data/megaplay-catalog.json');
let megaEntries=[],megaAliases=[];try{let d=JSON.parse(fs.readFileSync(megaCatalogPath));megaEntries=Array.isArray(d.entries)?d.entries:[];megaAliases=Array.isArray(d.aliases)?d.aliases:[]}catch{}
const megaByMal=new Map(),megaByAni=new Map(),megaAliasSet=new Set(megaAliases);
function animeAliasMatch(title){let key=normalizeTitle(title);if(!key)return false;if(megaAliasSet.has(key))return true;for(let alias of megaAliasSet)if(alias.length>3&&(key.startsWith(alias+' ')||key.endsWith(' '+alias)||key.includes(' '+alias+' ')))return true;return false}
for(let entry of megaEntries){if(entry.mal&&!megaByMal.has(String(entry.mal)))megaByMal.set(String(entry.mal),entry);if(entry.ani&&!megaByAni.has(String(entry.ani)))megaByAni.set(String(entry.ani),entry)}
function megaForMedia(media){return megaByAni.get(String(media?.id||''))||megaByMal.get(String(media?.idMal||''))||null}
function megaForIds(mal,ani){return megaByMal.get(String(mal||''))||megaByAni.get(String(ani||''))||null}
function releasedAnime(media){if(!['FINISHED','RELEASING'].includes(media?.status))return false;let d=media.startDate;if(!d?.year)return true;let date=`${d.year}-${String(d.month||1).padStart(2,'0')}-${String(d.day||1).padStart(2,'0')}`;return date<=today()}
function catalogAnime(list){return (list||[]).filter(x=>x.idMal&&releasedAnime(x)&&megaForMedia(x)).map(ani)}
async function anikotoSeries(providerId){
 let d=await remote(`https://anikotoapi.site/series/${encodeURIComponent(providerId)}`,{ttl:21600000,timeout:9000,headers:{Accept:'application/json'}});
 if(!d.ok||!d.data?.anime||!Array.isArray(d.data.episodes))throw Error('MegaPlay returned an invalid series response.');
 return d.data;
}
function anikotoItem(entry){
 let format=String(entry.format||'').toUpperCase(),isMovie=format.includes('MOVIE'),score=Number.parseFloat(entry.score),english=String(entry.english||'').split(';')[0].trim(),displayTitle=english.length>3?english:entry.title,status=/currently/i.test(entry.status)?'RELEASING':/not yet/i.test(entry.status)?'NOT_YET_RELEASED':'FINISHED';
 return {id:String(entry.mal),anilistId:entry.ani?String(entry.ani):null,type:'anime',title:displayTitle,poster:entry.poster||null,backdrop:entry.backdrop||null,description:entry.description||'',rating:Number.isFinite(score)&&score>0?score:null,year:entry.year||null,episodes:isMovie?null:entry.episodes,episodeCountKind:'available',genres:entry.genres||[],status,format,isMovie,playable:status!=='NOT_YET_RELEASED',providerId:entry.id,dub:Boolean(entry.dub),updated:entry.updated||''};
}
function validAnikotoEntry(entry){
 let year=Number(entry.year)||0;
 return Boolean(entry.mal&&entry.poster&&Number(entry.episodes)>0&&year<=new Date().getFullYear()&&!/not yet/i.test(entry.status||''));
}
const anikotoItems=megaEntries.filter(validAnikotoEntry).map(anikotoItem);
function anikotoSearch(term){let q=normalizeTitle(term);if(!q)return [];return megaEntries.filter(entry=>{if(!validAnikotoEntry(entry))return false;let titles=[entry.title,entry.english,entry.alternative,entry.native,...String(entry.titles||'').split(/[;,]/)];return titles.some(value=>{let key=normalizeTitle(value);return key===q||key.startsWith(q+' ')||key.endsWith(' '+q)||key.includes(' '+q+' ')})}).map(anikotoItem)}
function sortAnikoto(items,sort){let copy=[...items];if(sort==='rating')copy.sort((a,b)=>(b.rating||0)-(a.rating||0));else if(sort==='newest')copy.sort((a,b)=>(b.year||0)-(a.year||0)||String(b.updated).localeCompare(String(a.updated)));return copy}
const ani=x=>{
 let isMovie=x.format==='MOVIE',episodes=animeEpisodeCount(x),provider=megaForMedia(x);
 return {id:String(x.idMal),anilistId:String(x.id),type:'anime',title:x.title?.english||x.title?.romaji||'',poster:x.coverImage?.extraLarge||x.coverImage?.large,backdrop:x.bannerImage||provider?.backdrop||x.coverImage?.extraLarge,description:(x.description||'').replace(/<[^>]*>/g,''),rating:x.averageScore?Number((x.averageScore/10).toFixed(1)):null,year:x.seasonYear||x.startDate?.year,episodes,episodeCountKind:x.status==='RELEASING'?'released':'total',genres:x.genres||[],status:x.status,format:x.format||null,isMovie,playable:Boolean(provider)&&!/not yet/i.test(provider?.status||''),providerId:provider?.id||null,dub:Boolean(provider?.dub)};
}
function decodeEntities(value){return String(value||'').replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n))).replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16))).replace(/&(amp|quot|apos|lt|gt|hellip|mdash|ndash);/g,(_,name)=>({amp:'&',quot:'"',apos:"'",lt:'<',gt:'>',hellip:'…',mdash:'—',ndash:'–'})[name])}
function normalizeTitle(value){return String(value||'').toLowerCase().replace(/&/g,'and').replace(/[^a-z0-9]+/g,' ').trim()}
function dedupeCatalog(list){
 let output=[],positions=new Map();
 for(let item of list){
  let kind=item.type==='movie'||item.isMovie?'movie':'series',key=item.year?`${normalizeTitle(item.title)}|${item.year}|${kind}`:`${item.type}:${item.id}`;
  if(!positions.has(key)){positions.set(key,output.length);output.push(item);continue}
  let at=positions.get(key),old=output[at];
  if(old.type==='anime'&&item.type!=='anime')output[at]={...old,backdrop:item.backdrop||old.backdrop};
  else if(item.type==='anime'&&old.type!=='anime')output[at]={...item,backdrop:old.backdrop||item.backdrop};
 }
 return output.filter(x=>x.type==='anime'||!x.japaneseAnimation);
}
async function animeRecord(id,withRelations=false){
 let d=await anilist(`query($id:Int){Media(idMal:$id,type:ANIME){${fields}${withRelations?' relations{edges{relationType node{idMal type format}}}':''}}}`,{id:Number(id)});
 return d.Media;
}
function animeTitleKey(media){
 let title=(media.title?.english||media.title?.romaji||'').toLowerCase().split(':')[0];
 return title.replace(/\bfinal season\b.*$/,'').replace(/\b(?:season|part|cour)\s*\d+\b.*$/,'').replace(/\s+(?:ii|iii|iv|v|vi|vii|viii|ix|x)$/,'').replace(/[^a-z0-9]+/g,' ').trim();
}
function explicitAnimeSeason(media){return /\b(?:season|part|cour)\s*\d+\b|\bfinal season\b|\s(?:ii|iii|iv|v|vi|vii|viii|ix|x)$/i.test(media.title?.english||media.title?.romaji||'')}
function compatibleAnimeFormat(root,candidate){return ['TV','TV_SHORT'].includes(root)?['TV','TV_SHORT'].includes(candidate):root===candidate}
function animeSeasonEntry(media){let item=ani(media);return {id:String(media.idMal),anilistId:String(media.id),name:item.title,episodes:item.episodes,format:item.format}}
async function animeSeasonFamily(media){
 if(!media||media.format==='MOVIE'||!['TV','TV_SHORT','ONA'].includes(media.format))return [];
 let entries=new Map([[String(media.idMal),media]]),seen=new Set([String(media.idMal)]),queue=[media],key=animeTitleKey(media);
 while(queue.length&&seen.size<24){
  let current=queue.shift();
  for(let edge of current.relations?.edges||[]){
   let node=edge.node,id=String(node.idMal||'');
   if(!['PREQUEL','SEQUEL'].includes(edge.relationType)||node.type!=='ANIME'||!compatibleAnimeFormat(media.format,node.format)||!node.idMal||seen.has(id))continue;
   seen.add(id);
   try{let linked=await animeRecord(id,true);if(linked&&animeTitleKey(linked)===key){entries.set(id,linked);queue.push(linked)}}catch{}
  }
 }
 let all=[...entries.values()];
 if(all.length<2||!all.some(explicitAnimeSeason))return [];
 return all.sort((a,b)=>(a.startDate?.year||9999)-(b.startDate?.year||9999)||(a.startDate?.month||1)-(b.startDate?.month||1)||(a.startDate?.day||1)-(b.startDate?.day||1)||Number(a.id)-Number(b.id)).filter(media=>releasedAnime(media)&&megaForMedia(media)&&!/not yet/i.test(megaForMedia(media)?.status||'')).map(animeSeasonEntry);
}
let sharedKey=null;
async function tmdbKey(){if(process.env.TMDB_API_KEY)return process.env.TMDB_API_KEY;if(!sharedKey)sharedKey=(await freekeys()).tmdb_key;return sharedKey}
async function tmdb(route,params={}){let key=await tmdbKey();let q=new URLSearchParams({...params,api_key:key,language:'en-US'});try{return await remote('https://api.themoviedb.org/3/'+route+'?'+q)}catch(e){if(process.env.TMDB_API_KEY)throw e;sharedKey=(await freekeys()).tmdb_key;q.set('api_key',sharedKey);return remote('https://api.themoviedb.org/3/'+route+'?'+q)}}
async function getTmdbMetaForResolver(input){
 let d=await tmdb(`${input.type}/${input.id}`,{append_to_response:'external_ids'});
 return {
  title:d.title||d.name||d.original_title||d.original_name||'',
  year:String(d.release_date||d.first_air_date||'').slice(0,4),
  imdbId:d.imdb_id||d.external_ids?.imdb_id||''
 };
}
const readStates=()=>{try{let d=JSON.parse(fs.readFileSync(statesDb));return {visitors:d.visitors||{},meta:d.meta||{}}}catch{return {visitors:{},meta:{}}}};
const cleanState=state=>({watchlist:Array.isArray(state?.watchlist)?state.watchlist.slice(0,100):[],history:Array.isArray(state?.history)?state.history.slice(0,100):[]});
function readState(owner){let states=readStates(),existing=states.visitors[owner.id];if(!existing&&!states.meta.legacyMigrated){let legacy=null;try{legacy=JSON.parse(fs.readFileSync(db))}catch{}states.meta.legacyMigrated=true;if(legacy&&(legacy.watchlist?.length||legacy.history?.length))states.visitors[owner.id]=cleanState(legacy);fs.writeFileSync(statesDb,JSON.stringify(states));return cleanState(states.visitors[owner.id])}return cleanState(existing)}
function writeState(owner,state){let states=readStates();states.visitors[owner.id]=cleanState(state);fs.writeFileSync(statesDb,JSON.stringify(states));return states.visitors[owner.id]}
const parseCookies=req=>Object.fromEntries(String(req.headers.cookie||'').split(';').map(x=>x.trim().split('=').map(decodeURIComponent)).filter(x=>x.length===2));
function appendCookie(res,value){let old=res.getHeader('Set-Cookie'),all=old?(Array.isArray(old)?old:[old]):[];res.setHeader('Set-Cookie',[...all,value])}
function visitorId(req,res){let cookies=parseCookies(req),id=cookies.moscowtv_visitor;if(!/^[a-f0-9]{32}$/.test(id||'')){id=crypto.randomBytes(16).toString('hex');appendCookie(res,`moscowtv_visitor=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=315360000`)}return id}
function stateOwner(req,res){return {scope:'visitors',id:visitorId(req,res)}}
async function requestBody(req){let chunks=[];for await(let chunk of req){chunks.push(chunk);if(Buffer.concat(chunks).length>50000)throw Error('Payload too large')}return JSON.parse(Buffer.concat(chunks).toString()||'{}')}
function num(s){return /^\d{1,10}$/.test(s||'')?s:null}
async function api(req,res,url){let p=url.pathname, q=url.searchParams;try{
if(p==='/api/state'){return json(res,readState(stateOwner(req,res)))}
if((p==='/api/watchlist'&&req.method==='POST')||(p==='/api/history'&&req.method==='POST')){
 let item=await requestBody(req);if(!['anime','movie','tv'].includes(item.type)||!num(String(item.id)))return json(res,{error:'Invalid item'},400);
 let owner=stateOwner(req,res),state=readState(owner),field=p.endsWith('watchlist')?'watchlist':'history';
 let record={id:String(item.id),type:item.type,title:String(item.title||'').slice(0,200),poster:String(item.poster||'').slice(0,500),episode:Math.max(1,Number(item.episode)||1),season:Math.max(1,Number(item.season)||1),updated:Date.now()};
 record.genres=Array.isArray(item.genres)?item.genres.map(String).slice(0,10):[];record.format=typeof item.format==='string'?item.format.slice(0,20):null;record.isMovie=Boolean(item.isMovie);record.currentTime=Math.max(0,Number(item.currentTime)||0);record.duration=Math.max(0,Number(item.duration)||0);
 let found=state[field].findIndex(x=>x.id===record.id&&x.type===record.type),old=found>=0?state[field].splice(found,1)[0]:null;
 if(field==='history'&&old&&old.episode===record.episode&&old.season===record.season){record.currentTime=item.currentTime==null?old.currentTime||0:record.currentTime;record.duration=item.duration==null?old.duration||0:record.duration}if(!record.genres.length&&old)record.genres=old.genres||[];
 if(field==='history'||!item.remove)state[field].unshift(record);writeState(owner,state);return json(res,state)
}
if(p==='/api/browse'){
 let [o]=await Promise.allSettled([tmdb('trending/all/week')]),animeItems=anikotoItems.slice(0,30),ottItems=o.status==='fulfilled'?o.value.results.filter(x=>['tv','movie'].includes(x.media_type)&&releasedOtt(x)).map(ott):[];
 if(!animeItems.length&&!ottItems.length)throw Error('Catalogs are unavailable');
 let movies=ottItems.filter(x=>x.type==='movie'),shows=ottItems.filter(x=>x.type==='tv'),mixed=[];
 for(let i=0;i<Math.max(animeItems.length,movies.length,shows.length);i++){if(animeItems[i])mixed.push(animeItems[i]);if(movies[i])mixed.push(movies[i]);if(shows[i])mixed.push(shows[i])}
 mixed=dedupeCatalog(mixed);
 let history=readState(stateOwner(req,res)).history,watchedGenres=new Map();
 for(let [index,h] of history.entries())for(let g of h.genres||[])watchedGenres.set(g.toLowerCase(),(watchedGenres.get(g.toLowerCase())||0)+Math.max(1,8-index));
 let watched=new Set(history.map(h=>h.type+':'+h.id));
 let suggestions=mixed.filter(x=>!watched.has(x.type+':'+x.id)).map(x=>({...x,match:(x.genres||[]).reduce((n,g)=>n+(watchedGenres.get(g.toLowerCase())||0),0)})).filter(x=>x.match>0).sort((a,b)=>b.match-a.match).slice(0,12);
 return json(res,{items:mixed,suggestions,hasPreferences:watchedGenres.size>0});
}
if(p==='/api/search-all'){
 let term=(q.get('q')||'').trim().slice(0,100);if(!term)return json(res,{items:[]});
 let [o]=await Promise.allSettled([tmdb('search/multi',{query:term,include_adult:'false'})]),animeItems=anikotoSearch(term).slice(0,25),ottItems=o.status==='fulfilled'?o.value.results.filter(x=>['tv','movie'].includes(x.media_type)&&releasedOtt(x)).map(ott):[];
 return json(res,{items:dedupeCatalog([...animeItems,...ottItems])});
}
if(p==='/api/genre'){
 let g=q.get('name');if(!catalogGenres.includes(g))return json(res,{error:'Unknown genre'},400);
 let id=movieGenreIds[g];
 let [o]=await Promise.allSettled(id?[tmdb('discover/movie',{with_genres:String(id),sort_by:'popularity.desc',page:'1','primary_release_date.lte':today()})]:[]),animeItems=anikotoItems.filter(x=>x.genres.includes(g)).slice(0,16),movieItems=o?.status==='fulfilled'?o.value.results.filter(releasedOtt).slice(0,12).map(ott):[],mixed=[];
 for(let i=0;i<12;i++){if(animeItems[i])mixed.push(animeItems[i]);if(movieItems[i])mixed.push(movieItems[i])}
 return json(res,{items:dedupeCatalog(mixed).slice(0,16)});
}
if(p==='/api/random'){
 let [o]=await Promise.allSettled([tmdb('trending/all/week')]),ottItems=o.status==='fulfilled'?o.value.results.filter(x=>['movie','tv'].includes(x.media_type)&&releasedOtt(x)).map(ott):[],all=dedupeCatalog([...anikotoItems,...ottItems]);
 if(!all.length)throw Error('Catalogs are unavailable');return json(res,{item:all[crypto.randomInt(all.length)]});
}
if(p==='/api/schedule'){
 let now=Math.floor(Date.now()/1000),week=now+7*86400,d=await anilist(`query($now:Int,$week:Int){Page(page:1,perPage:50){airingSchedules(airingAt_greater:$now,airingAt_lesser:$week,sort:TIME){id airingAt episode media{${fields}}}}}`,{now,week});
 return json(res,{entries:d.Page.airingSchedules.filter(x=>x.media?.idMal&&!x.media.isAdult&&releasedAnime(x.media)&&megaForMedia(x.media)&&!/not yet/i.test(megaForMedia(x.media)?.status||'')).map(x=>({id:x.id,airingAt:x.airingAt,episode:x.episode,item:ani(x.media)}))});
}
if(p==='/api/upcoming'){
 let [a,o]=await Promise.allSettled([anilist(`query {Page(page:1,perPage:24){media(type:ANIME,status:NOT_YET_RELEASED,sort:POPULARITY_DESC,isAdult:false){${fields}}}}`),tmdb('movie/upcoming',{region:'IN'})]);
 let animeItems=a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal&&x.status==='NOT_YET_RELEASED').map(ani):[],movieItems=o?.status==='fulfilled'?o.value.results.filter(x=>x.release_date>today()).map(ott):[],all=dedupeCatalog([...animeItems,...movieItems]);return json(res,{anime:all.filter(x=>x.type==='anime'),movies:all.filter(x=>x.type==='movie')});
}
if(p==='/api/filter'){
 let type=['anime','movie','tv','all'].includes(q.get('type'))?q.get('type'):'all',genre=catalogGenres.includes(q.get('genre'))?q.get('genre'):'',year=/^\d{4}$/.test(q.get('year')||'')?q.get('year'):'',sort=['popularity','rating','newest'].includes(q.get('sort'))?q.get('sort'):'popularity',status=['releasing','finished'].includes(q.get('status'))?q.get('status'):'',tasks=[];
 if(type==='all'||type==='anime'){let animeItems=anikotoItems.filter(x=>(!genre||x.genres.includes(genre))&&(!year||String(x.year)===year)&&(!status||x.status===status.toUpperCase()));tasks.push(Promise.resolve(sortAnikoto(animeItems,sort).slice(0,40)))}
 let movieGenres=movieGenreIds,tvGenres=tvGenreIds;
 for(let mediaType of type==='all'?['movie','tv']:type==='anime'?[]:[type])tasks.push((async()=>{let genreMap=mediaType==='movie'?movieGenres:tvGenres;if(genre&&!genreMap[genre])return [];let params={sort_by:{popularity:'popularity.desc',rating:'vote_average.desc',newest:mediaType==='movie'?'primary_release_date.desc':'first_air_date.desc'}[sort],include_adult:'false','vote_count.gte':sort==='rating'?'20':'0'};if(genre)params.with_genres=String(genreMap[genre]);if(year)params[mediaType==='movie'?'primary_release_year':'first_air_date_year']=year;params[mediaType==='movie'?'primary_release_date.lte':'first_air_date.lte']=today();let d=await tmdb('discover/'+mediaType,params);return d.results.filter(releasedOtt).map(ott)})());
 let settled=await Promise.allSettled(tasks),groups=settled.filter(x=>x.status==='fulfilled').map(x=>x.value),items=[];for(let i=0;i<50;i++)for(let group of groups)if(group[i])items.push(group[i]);if(!items.length&&settled.every(x=>x.status==='rejected'))throw Error('Catalogs are unavailable');return json(res,{items:dedupeCatalog(items).slice(0,60)});
}
if(p==='/api/detail'){
 let id=num(q.get('id')),type=q.get('type');if(!id||!['anime','tv','movie'].includes(type))return json(res,{error:'Invalid title'},400);
 if(type==='anime'){
  let provider=megaByMal.get(id);
  if(provider&&!/not yet/i.test(provider.status||'')){
   let [providerData,media]=await Promise.all([anikotoSeries(provider.id).catch(()=>null),animeRecord(id,true).catch(()=>null)]),item=anikotoItem(provider);
   let count=providerData?.episodes?.length||0;
   if(count>0){
    if(!item.isMovie)item.episodes=count;
    item.playable=true;
    item.dub=providerData.episodes.some(x=>x.embed_url?.dub)||Boolean(provider.dub);
   }else{
    let directOk=await resolveMegaPlayDirect({malId:id,aniId:provider.ani||media?.id,episode:1,lang:'sub'}).then(()=>true).catch(()=>false);
    if(!directOk){
     item.upcoming=true;item.episodes=null;item.playable=false;
     return json(res,{item,episodes:[],seasons:[]});
    }
    item.playable=true;
   }
   if(media){let fallback=ani(media);item.poster=item.poster||fallback.poster;item.backdrop=item.backdrop||fallback.backdrop;item.description=item.description||fallback.description;if(!item.genres.length)item.genres=fallback.genres}
   item.upcoming=false;let seasons=media?await animeSeasonFamily(media):[];return json(res,{item,episodes:[],seasons});
  }
  let media=await animeRecord(id,true);if(!media)return json(res,{error:'Anime not found'},404);
  if(media.status!=='NOT_YET_RELEASED'){
   let directSub=await resolveMegaPlayDirect({malId:id,aniId:media.id,episode:1,lang:'sub'}).then(()=>true).catch(()=>false);
   if(directSub){
    let item=ani(media);item.playable=true;item.upcoming=false;
    let seasons=await animeSeasonFamily(media);
    return json(res,{item,episodes:[],seasons});
   }
   return json(res,{error:'This anime is not available for streaming yet.'},404);
  }
  let item=ani(media);item.upcoming=true;item.episodes=null;item.playable=false;return json(res,{item,episodes:[],seasons:[]});
 }
 let d=await tmdb(type+'/'+id),item=ott({...d,media_type:type});item.upcoming=!releasedOtt(d);if(item.japaneseAnimation&&!item.upcoming)return json(res,{error:'This anime is not listed by Anikoto.'},404);item.playable=!item.upcoming;
 return json(res,{item,seasons:item.upcoming?[]:d.seasons?.filter(x=>x.season_number>=0).map(x=>({number:x.season_number,name:x.name,episodes:x.episode_count}))||[]});
}
let jikanUnreachableUntil=0;
async function jikanAnimeEpisodeMeta(malId,sliceNums){
 if(Date.now()<jikanUnreachableUntil)return null;
 try{
  let jikanPage=Math.max(1,Math.ceil((sliceNums[0]||1)/100));
  let [epRes,vidRes]=await Promise.all([
   remote(`https://api.jikan.moe/v4/anime/${encodeURIComponent(malId)}/episodes?page=${jikanPage}`,{ttl:21600000,timeout:1800,headers:{Accept:'application/json'}}).catch(err=>{if(/timeout|abort|fetch/i.test(err.message))jikanUnreachableUntil=Date.now()+600000;return null}),
   remote(`https://api.jikan.moe/v4/anime/${encodeURIComponent(malId)}/videos/episodes?page=1`,{ttl:21600000,timeout:1800,headers:{Accept:'application/json'}}).catch(()=>null)
  ]);
  if(!epRes?.data&&!vidRes?.data)return null;
  let byNum=new Map();
  for(let row of epRes?.data||[]){let n=Number(row.mal_id);if(n>0)byNum.set(n,{title:row.title||row.title_romanji||'',still:null,description:''})}
  for(let row of vidRes?.data||[]){let n=Number(row.mal_id),img=row.images?.jpg?.image_url||null;if(n>0){let prev=byNum.get(n)||{title:'',still:null,description:''};byNum.set(n,{title:prev.title||row.title||'',still:img||prev.still,description:prev.description})}}
  return byNum;
 }catch{return null}
}
async function anizipEpisodeMeta(malId){
 try{
  let d=await remote(`https://api.ani.zip/mappings?mal_id=${encodeURIComponent(malId)}`,{ttl:21600000,timeout:4500,headers:{Accept:'application/json'}});
  let eps=d?.episodes||{};
  let byNum=new Map();
  for(let [k,ep] of Object.entries(eps)){
   if(!/^\d+$/.test(k))continue;
   let n=Number(k);if(!Number.isInteger(n)||n<=0)continue;
   let rawTitle=typeof ep.title==='string'?ep.title:(ep.title?.en||ep.title?.['x-jat']||ep.title?.ja||'');
   let rawDesc=String(ep.overview||ep.summary||'').replace(/\s*\(?\bSource:\s*[^)\n]+\)?\s*$/i,'').trim();
   let img=/^https:\/\//.test(ep.image||'')?ep.image:null;
   byNum.set(n,{title:rawTitle,still:img,description:rawDesc});
  }
  return byNum;
 }catch{return null}
}
if(p==='/api/anime-episodes'){
 let id=num(q.get('id')),page=Math.max(1,Math.min(10000,Math.floor(Number(q.get('page'))||1))),limit=20;
 if(!id)return json(res,{error:'Invalid anime'},400);
 let provider=megaByMal.get(id);
 let base=[];
 if(provider&&!/not yet/i.test(provider.status||'')){
  let data=await anikotoSeries(provider.id).catch(()=>null);
  base=(data?.episodes||[]).filter(x=>Number.isInteger(Number(x.number))&&Number(x.number)>0).sort((a,b)=>Number(a.number)-Number(b.number));
 }
 if(!base.length){
  let media=await animeRecord(id,false).catch(()=>null);
  let fallbackTotal=positiveInt(provider?.episodes)||animeEpisodeCount(media)||0;
  if(fallbackTotal>0&&(!provider||!/not yet/i.test(provider.status||''))){
   base=Array.from({length:fallbackTotal},(_,i)=>({number:i+1,title:`Episode ${i+1}`,episode_embed_id:'',embed_url:{sub:`https://megaplay.buzz/stream/mal/${id}/${i+1}/sub`,dub:provider?.dub?`https://megaplay.buzz/stream/mal/${id}/${i+1}/dub`:null}}));
  }else{
   return json(res,{error:'Episodes are not available for this title.'},404);
  }
 }
 let offset=(page-1)*limit,pageRows=base.slice(offset,offset+limit);
 let [jikanMap,anizipMap]=await Promise.all([jikanAnimeEpisodeMeta(id,pageRows.map(x=>Number(x.number))),anizipEpisodeMeta(id)]);
 let sources=['megaplay'];if(jikanMap?.size)sources.unshift('jikan');if(anizipMap?.size&&!sources.includes('jikan'))sources.unshift('jikan-mal');
 let episodes=pageRows.map(x=>{
  let n=Number(x.number),jk=jikanMap?.get(n),az=anizipMap?.get(n),fallbackTitle=decodeEntities(x.title);
  let cleanFallback=fallbackTitle&&!/^episode\s*\d+$/i.test(fallbackTitle.trim())?fallbackTitle:'';
  let title=(jk?.title||az?.title||cleanFallback||`Episode ${n}`).replace(/`/g,"'").trim();
  let description=(jk?.description||az?.description||'').trim();
  let still=jk?.still||az?.still||null;
  return {number:n,title,description,still,embedId:String(x.episode_embed_id||''),sub:Boolean(x.embed_url?.sub??true),dub:Boolean(x.embed_url?.dub)};
 });
 return json(res,{episodes,page,perPage:limit,total:base.length,hasNext:offset+limit<base.length,sources},200,req);
}
if(p==='/api/season'){let id=num(q.get('id')),season=q.get('season')==='0'?'0':num(q.get('season'));if(!id||season===null)return json(res,{error:'Invalid season'},400);let d=await tmdb(`tv/${id}/season/${season}`);return json(res,{episodes:(d.episodes||[]).map(e=>({number:e.episode_number,title:e.name,description:e.overview,still:e.still_path?'https://image.tmdb.org/t/p/w300'+e.still_path:null}))})}
if(p==='/api/play'){
 let id=num(q.get('id')),type=q.get('type'),ep=num(q.get('episode')||'1'),season=q.get('season')==='0'?'0':num(q.get('season')||'1'),lang=q.get('lang')==='dub'?'dub':'sub',requestedProvider=q.get('provider'),provider=OTT_SERVER_KEYS.has(requestedProvider)?requestedProvider:'default',aniId=num(q.get('anilistId'));
 if(!id||!ep||!season||!['anime','movie','tv'].includes(type))return json(res,{error:'Invalid playback request'},400);
 if(type==='anime'){
  let available=megaForIds(id,aniId),effectiveAni=aniId||available?.ani||null,fallbackEmbed=null;
  if(available?.id){
   let seriesData=await anikotoSeries(available.id).catch(()=>null),row=seriesData?.episodes?.find(x=>Number(x.number)===Number(ep));
   fallbackEmbed=row?.embed_url?.[lang]||null;
  }
  try{
   let resolved=await resolveMegaPlayDirect({malId:id,aniId:effectiveAni,episode:ep,lang,fallbackEmbed});
   let tracks=lang==='sub'?resolved.tracks.map(x=>({...x,src:mediaUrl(x.src,'megaplay')})):[];
   return json(res,{src:mediaUrl(resolved.url,'megaplay'),type:/\.mp4(?:\?|$)/i.test(resolved.url)?'video/mp4':'application/x-mpegURL',kind:'videojs',provider:'MegaPlay',server:lang==='dub'?'Dub':'Sub',tracks,intro:resolved.intro,outro:resolved.outro},200,req);
  }catch{
   let otherLang=lang==='dub'?'sub':'dub',otherFallback=null;
   if(available?.id){
    let seriesData=await anikotoSeries(available.id).catch(()=>null),row=seriesData?.episodes?.find(x=>Number(x.number)===Number(ep));
    otherFallback=row?.embed_url?.[otherLang]||null;
   }
   let hasOpposite=await resolveMegaPlayDirect({malId:id,aniId:effectiveAni,episode:ep,lang:otherLang,fallbackEmbed:otherFallback}).then(()=>true).catch(()=>false);
   if(hasOpposite){
    return json(res,{error:lang==='dub'?'Dub is not available for this episode.':'Sub is not available for this episode.',availableLang:otherLang},404,req);
   }
   return json(res,{error:'This episode is not available on MegaPlay right now.'},404,req);
  }
 }
 let input={type,id,season,episode:ep},subPromise=cinesrcSubtitles(input).catch(()=>[]);
 let resolved=await resolveOttWithFallback(input,provider,getTmdbMetaForResolver);
 let cineTracks=resolved.tracks?.length?[]:await Promise.race([subPromise,new Promise(r=>setTimeout(()=>r([]),1200))]);
 let proxyProvider=resolved.proxyProvider||(['vidlink','vidsrc'].includes(resolved.sourceKey)?resolved.sourceKey:'cinesrc');
 let src=resolved.kind==='dash'?dashUrl(resolved.url,proxyProvider,resolved.headers):mediaUrl(resolved.url,proxyProvider,resolved.headers);
 let providerTracks=(resolved.tracks||[]).map(x=>{try{return {...x,src:mediaUrl(x.src,proxyProvider,resolved.headers)}}catch{return null}}).filter(Boolean);
 let tracks=providerTracks.length?providerTracks:cineTracks.map(x=>{try{return {...x,src:mediaUrl(x.src,'cinesrc')}}catch{return null}}).filter(Boolean);
 let audioStreams=(resolved.audioStreams||[]).map(a=>{
  try{return {language:a.language,label:a.label,src:mediaUrl(a.url,a.proxyProvider||proxyProvider,a.headers||resolved.headers)}}catch{return null}
 }).filter(Boolean);
 return json(res,{src,type:resolved.kind==='mp4'?'video/mp4':'application/x-mpegURL',kind:'videojs',provider:resolved.provider,sourceKey:resolved.sourceKey,server:resolved.server,tracks,audioStreams},200,req);
}
return json(res,{error:'Not found'},404)
}catch(e){return json(res,{error:e.message||'Request failed'},e.message?.includes('configured')?503:502)}}
const staticCache=new Map();
const mimeTypes={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.ttf':'font/ttf','.woff':'font/woff','.woff2':'font/woff2'};
const CSP="default-src 'self' https: data: blob:; frame-src 'none'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' https: data:; connect-src 'self' https: data: blob:; media-src 'self' https: data: blob:; worker-src 'self' blob:";
http.createServer((req,res)=>{
 let u=new URL(req.url,'http://localhost');
 if(/^\/(anime|ott)(\/|$)/.test(u.pathname)){let dest=u.pathname.replace(/^\/(anime|ott)/,'/browse');res.writeHead(302,{Location:dest+u.search});return res.end()}
 if(u.pathname.startsWith('/api/dash/'))return handleDash(req,res,u);
 if(u.pathname==='/api/media')return handleMedia(req,res,u);
 if(u.pathname.startsWith('/api/'))return api(req,res,u);
 let pathname=u.pathname==='/'?'/index.html':u.pathname,target=path.resolve(root,'.'+pathname);
 if(!target.startsWith(root+path.sep)||!fs.existsSync(target)||!fs.statSync(target).isFile())target=path.join(root,'index.html');
 let ext=path.extname(target),stat=fs.statSync(target),cached=staticCache.get(target);
 if(!cached||cached.mtime!==stat.mtimeMs){
  let raw=fs.readFileSync(target),compressible=/^\.(?:html|js|css|svg)$/.test(ext);
  cached={mtime:stat.mtimeMs,raw,gz:compressible?zlib.gzipSync(raw,{level:6}):null};
  staticCache.set(target,cached);
 }
 let immutable=u.pathname.startsWith('/vendor/')||u.pathname.startsWith('/fonts/')||u.pathname.startsWith('/images/')||u.searchParams.has('v');
 let headers={'Content-Type':mimeTypes[ext]||'application/octet-stream','Cache-Control':ext==='.html'?'no-cache':(immutable?'public, max-age=86400':'public, max-age=300'),'Content-Security-Policy':CSP};
 if(cached.gz&&String(req.headers['accept-encoding']||'').includes('gzip')){headers['Content-Encoding']='gzip';headers['Vary']='Accept-Encoding';res.writeHead(200,headers);return res.end(cached.gz)}
 res.writeHead(200,headers);res.end(cached.raw);
}).listen(process.env.PORT||3000,'0.0.0.0',()=>{console.log('MoscowTV listening on '+(process.env.PORT||3000))});
