import crypto from 'node:crypto';
import { resolveCineSrc } from './cinesrc-resolver.js';
import { resolveVidlink, resolveVidsrc } from './fallback-resolvers.js';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const CACHE_TTL = 12 * 60_000;
const streamCache = new Map();
const inflight = new Map();

export const OTT_SERVERS = [
  ['default', 'Primary'],
  ['vidzee_multi', 'VidZee Multi'],
  ['vidzee_v6', 'Turbo V6'],
  ['vaplayer', 'VaPlayer'],
  ['vidfast_rapid', 'vRapid 4K'],
  ['vidfast_blaze', 'vBlaze 4K'],
  ['wing_secret', 'CineJoy 4K'],
  ['wing_nebula', 'Nebula Direct'],
  ['hexa', 'Hexa Multi'],
  ['vidzee_peak', 'Peak Stream'],
  ['onetouch', 'OneTouch'],
  ['vidlink', 'VidLink'],
  ['cinesrc', 'CineSrc'],
  ['vidsrc', 'VidSrc']
];

export const OTT_SERVER_KEYS = new Set(OTT_SERVERS.map(([k]) => k));

const LANG_CODE_MAP = {
  hindi: 'hi', hi: 'hi', hin: 'hi',
  tamil: 'ta', ta: 'ta', tam: 'ta',
  telugu: 'te', te: 'te', tel: 'te',
  malayalam: 'ml', ml: 'ml', mal: 'ml',
  kannada: 'kn', kn: 'kn', kan: 'kn',
  bengali: 'bn', bn: 'bn', ben: 'bn',
  marathi: 'mr', mr: 'mr',
  punjabi: 'pa', pa: 'pa',
  english: 'en', en: 'en', eng: 'en',
  korean: 'ko', ko: 'ko', kor: 'ko',
  japanese: 'ja', ja: 'ja', jpn: 'ja',
  spanish: 'es', es: 'es', spa: 'es',
  french: 'fr', fr: 'fr', fra: 'fr',
  german: 'de', de: 'de', deu: 'de'
};

function normLangCode(raw = '') {
  const clean = String(raw || '').trim().toLowerCase();
  return LANG_CODE_MAP[clean] || clean.slice(0, 3) || 'und';
}

function langSortRank(label = '') {
  const l = String(label || '').toLowerCase();
  if (l.includes('english')) return 0;
  if (l.includes('hindi')) return 1;
  if (l.includes('tamil')) return 2;
  if (l.includes('telugu')) return 3;
  if (l.includes('malayalam')) return 4;
  if (l.includes('kannada')) return 5;
  if (l.includes('bengali')) return 6;
  return 10;
}

// Validates that an HLS playlist is reachable, non-empty, H.264 compatible, and full-length (rejects short trailers/promos).
async function verifyPlayableHls(url, headers = {}, minDurationSec = 900) {
  const reqHeaders = { 'User-Agent': UA, ...headers };
  const r = await fetch(url, { headers: reqHeaders, signal: AbortSignal.timeout(8500), redirect: 'follow' });
  if (!r.ok) throw Error(`Playlist HTTP ${r.status}`);
  const text = await r.text();
  if (!text.trimStart().startsWith('#EXTM3U')) throw Error('Invalid M3U8 manifest');

  const codecs = [...text.matchAll(/CODECS="([^"]+)"/gi)].flatMap(m => m[1].split(','));
  if (codecs.length && !codecs.some(c => /^(?:avc1|avc3|mp4a)/i.test(c.trim())) && codecs.every(c => /^(?:hvc1|hev1)/i.test(c.trim()))) {
    throw Error('HEVC-only manifest');
  }

  let mediaUrl = r.url || url;
  let mediaText = text;
  if (/#EXT-X-STREAM-INF/i.test(text)) {
    const variant = text.split(/\r?\n/).map(l => l.trim()).find(l => l && !l.startsWith('#'));
    if (!variant) throw Error('Master playlist has no variants');
    const subUrl = new URL(variant, mediaUrl).href;
    const sr = await fetch(subUrl, { headers: reqHeaders, signal: AbortSignal.timeout(8500), redirect: 'follow' });
    if (!sr.ok) throw Error(`Variant HTTP ${sr.status}`);
    mediaText = await sr.text();
    mediaUrl = sr.url || subUrl;
    if (!mediaText.trimStart().startsWith('#EXTM3U')) throw Error('Invalid variant M3U8');
  }

  const durs = [...mediaText.matchAll(/#EXTINF:(\d+(?:\.\d+)?)/g)].map(m => Number(m[1]));
  const totalSec = durs.reduce((a, b) => a + b, 0);
  if (durs.length > 0 && totalSec < minDurationSec) {
    throw Error(`Preview/short clip rejected (${Math.round(totalSec)}s)`);
  }
  return { finalUrl: url, totalSec };
}

// ---------------------------------------------------------------------------
// 1. Primary: VidZee Multi-Language (v4:Hindi/Tamil/Telugu/Bengali/English + v6 fallback)
// ---------------------------------------------------------------------------
const VIDZEE_BASE = 'https://core.vidzee.wtf';
const VIDZEE_HEADERS = {
  Referer: 'https://player.vidzee.wtf/',
  Origin: 'https://player.vidzee.wtf'
};

async function fetchVidZeeOne(input, serverParam) {
  const path = input.type === 'tv'
    ? `/streams/tv/${encodeURIComponent(input.id)}/${encodeURIComponent(input.season)}/${encodeURIComponent(input.episode)}`
    : `/streams/movie/${encodeURIComponent(input.id)}`;
  const r = await fetch(`${VIDZEE_BASE}${path}?s=${encodeURIComponent(serverParam)}&e=0`, {
    headers: { ...VIDZEE_HEADERS, 'User-Agent': UA },
    signal: AbortSignal.timeout(6500)
  });
  if (!r.ok) return null;
  const d = await r.json().catch(() => null);
  if (!d?.url || !/^https:\/\//i.test(d.url)) return null;
  return {
    url: d.url.trim(),
    language: d.language || serverParam.replace(/^v\d+:/i, ''),
    headers: { ...VIDZEE_HEADERS, ...(d.headers && typeof d.headers === 'object' ? d.headers : {}) }
  };
}

async function resolveVidZeePrimary(input) {
  const minDur = input.type === 'tv' ? 780 : 1200;
  const langPath = input.type === 'tv'
    ? `/streams/languages/tv/${encodeURIComponent(input.id)}/${encodeURIComponent(input.season)}/${encodeURIComponent(input.episode)}`
    : `/streams/languages/movie/${encodeURIComponent(input.id)}`;

  let langs = [];
  try {
    const lr = await fetch(VIDZEE_BASE + langPath, {
      headers: { ...VIDZEE_HEADERS, 'User-Agent': UA },
      signal: AbortSignal.timeout(5500)
    });
    if (lr.ok) {
      const ld = await lr.json().catch(() => ({}));
      if (Array.isArray(ld?.languages)) langs = ld.languages.filter(Boolean);
    }
  } catch {}

  if (langs.length) {
    const settled = await Promise.all(langs.map(l => fetchVidZeeOne(input, `v4:${l}`).catch(() => null)));
    const candidates = settled.filter(Boolean).sort((a, b) => langSortRank(a.language) - langSortRank(b.language));
    for (let i = 0; i < candidates.length; i++) {
      try {
        await verifyPlayableHls(candidates[i].url, candidates[i].headers, minDur);
        const ordered = [candidates[i], ...candidates.filter((_, idx) => idx !== i)];
        return {
          url: ordered[0].url,
          kind: 'hls',
          proxyProvider: 'vidzee',
          headers: ordered[0].headers,
          provider: 'VidZee Multi',
          sourceKey: 'vidzee_multi',
          server: 'VidZee Multi',
          tracks: [],
          audioStreams: ordered.map(v => ({
            language: normLangCode(v.language),
            label: String(v.language || 'Default'),
            url: v.url,
            headers: v.headers,
            proxyProvider: 'vidzee'
          }))
        };
      } catch {}
    }
  }
  // Fallback to Turbo V6 if v4 language list wasn't available
  const v6 = await resolveVidZeeV6(input);
  return { ...v6, provider: 'VidZee Multi', sourceKey: 'vidzee_multi', server: 'VidZee Multi' };
}

// ---------------------------------------------------------------------------
// 2. Turbo V6 (VidZee v6:English + v6:Hindi ultra-high-throughput CDN)
// ---------------------------------------------------------------------------
async function resolveVidZeeV6(input) {
  const minDur = input.type === 'tv' ? 780 : 1200;
  const settled = await Promise.all(['v6:English', 'v6:Hindi'].map(s => fetchVidZeeOne(input, s).catch(() => null)));
  const candidates = settled.filter(Boolean);
  const verified = [];
  await Promise.all(candidates.map(async item => {
    try {
      await verifyPlayableHls(item.url, item.headers, minDur);
      verified.push(item);
    } catch {}
  }));
  if (!verified.length) throw Error('Turbo V6 stream unavailable.');
  verified.sort((a, b) => langSortRank(a.language) - langSortRank(b.language));
  const first = verified[0];
  return {
    url: first.url,
    kind: 'hls',
    proxyProvider: 'vidzee',
    headers: first.headers,
    provider: 'Turbo V6',
    sourceKey: 'vidzee_v6',
    server: 'Turbo V6',
    tracks: [],
    audioStreams: verified.map(v => ({
      language: normLangCode(v.language),
      label: String(v.language || 'Default'),
      url: v.url,
      headers: v.headers,
      proxyProvider: 'vidzee'
    }))
  };
}

// ---------------------------------------------------------------------------
// 3. Peak Stream (VidZee peak CDN)
// ---------------------------------------------------------------------------
async function resolveVidZeePeak(input) {
  const minDur = input.type === 'tv' ? 780 : 1200;
  const hit = await fetchVidZeeOne(input, 'peak');
  if (!hit) throw Error('Peak Stream unavailable.');
  await verifyPlayableHls(hit.url, hit.headers, minDur);
  return {
    url: hit.url,
    kind: 'hls',
    proxyProvider: 'vidzee',
    headers: hit.headers,
    provider: 'Peak Stream',
    sourceKey: 'vidzee_peak',
    server: 'Peak Stream',
    tracks: [],
    audioStreams: []
  };
}

// ---------------------------------------------------------------------------
// 4. Castle India (api.hlowb.com AES-128 — Hindi, Tamil, Telugu, Malayalam, Kannada, English)
// ---------------------------------------------------------------------------
const CASTLE_BASE = 'https://api.hlowb.com';
const CASTLE_API_HEADERS = {
  'User-Agent': 'okhttp/4.9.3',
  Accept: 'application/json',
  'Accept-Language': 'en-US,en;q=0.9',
  Referer: CASTLE_BASE
};
let castleKeyCache = { key: '', time: 0 };

function castleSafeParse(text) {
  return JSON.parse(text.replace(/([:{[,]\s*)(\d{16,})/g, '$1"$2"'));
}
function castleDecrypt(rawText, securityKey) {
  let cipher = String(rawText || '').trim();
  try {
    const parsed = JSON.parse(cipher);
    if (typeof parsed?.data === 'string') cipher = parsed.data.trim();
  } catch {}
  const combined = Buffer.concat([Buffer.from(securityKey, 'base64'), Buffer.from('T!BgJB', 'utf8')]);
  const key = combined.length < 16 ? Buffer.concat([combined, Buffer.alloc(16 - combined.length, 0)]) : combined.subarray(0, 16);
  const decipher = crypto.createDecipheriv('aes-128-cbc', key, key);
  return Buffer.concat([decipher.update(Buffer.from(cipher, 'base64')), decipher.final()]).toString('utf8');
}
async function getCastleKey() {
  if (castleKeyCache.key && Date.now() - castleKeyCache.time < 20 * 60_000) return castleKeyCache.key;
  const r = await fetch(`${CASTLE_BASE}/v0.1/system/getSecurityKey/1?channel=IndiaA&clientType=1&lang=en-US`, {
    headers: CASTLE_API_HEADERS,
    signal: AbortSignal.timeout(7000)
  });
  const j = await r.json();
  if (!j?.data) throw Error('Castle security key unavailable');
  castleKeyCache = { key: j.data, time: Date.now() };
  return j.data;
}

async function resolveCastleTV(input, getMeta) {
  const meta = await getMeta(input);
  if (!meta?.title) throw Error('Title metadata unavailable');
  const minDur = input.type === 'tv' ? 780 : 1200;
  const secKey = await getCastleKey();

  const searchOnce = async kw => {
    const q = new URLSearchParams({
      channel: 'IndiaA', clientType: '1', keyword: kw, lang: 'en-US',
      mode: '1', packageName: 'com.external.castle', page: '1', size: '20'
    });
    const r = await fetch(`${CASTLE_BASE}/film-api/v1.1.0/movie/searchByKeyword?${q}`, {
      headers: CASTLE_API_HEADERS, signal: AbortSignal.timeout(7500)
    });
    if (!r.ok) return [];
    const dec = castleSafeParse(castleDecrypt(await r.text(), secKey));
    return dec?.data?.rows || dec?.rows || [];
  };

  let rows = await searchOnce(`${meta.title} ${meta.year || ''}`.trim());
  if (!rows.length) rows = await searchOnce(meta.title);
  if (!rows.length) throw Error('Castle India: title not found');

  const norm = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  const targetNorm = norm(meta.title);
  const scoredRows = rows.map(row => {
    const rTitle = norm(row.title || row.name || '');
    let score = 0;
    if (rTitle === targetNorm) score += 50;
    else if (rTitle.startsWith(targetNorm) || targetNorm.startsWith(rTitle)) score += 30;
    else if (rTitle.includes(targetNorm)) score += 15;
    if (/trailer|teaser|making|behind|clip|short/i.test(row.title || '')) score -= 60;
    const rowYear = String(row.publishTime || row.year || '').slice(0, 4);
    if (meta.year && rowYear === String(meta.year)) score += 25;
    return { row, score };
  }).sort((a, b) => b.score - a.score);

  for (const { row } of scoredRows.slice(0, 3)) {
    let activeId = String(row.id || row.redirectId || row.redirectIdStr || '');
    if (!/^\d+$/.test(activeId)) continue;
    try {
      const fetchDetail = async mid => {
        const dr = await fetch(`${CASTLE_BASE}/film-api/v1.9.9/movie?channel=IndiaA&clientType=1&lang=en-US&movieId=${mid}&packageName=com.external.castle`, {
          headers: CASTLE_API_HEADERS, signal: AbortSignal.timeout(7500)
        });
        const dj = castleSafeParse(castleDecrypt(await dr.text(), secKey));
        return dj?.data || dj || {};
      };
      let det = await fetchDetail(activeId);
      if (input.type === 'tv' && Array.isArray(det.seasons) && det.seasons.length) {
        const sMatch = det.seasons.find(s => Number(s.number) === Number(input.season));
        if (sMatch?.movieId && String(sMatch.movieId) !== activeId) {
          activeId = String(sMatch.movieId);
          det = await fetchDetail(activeId);
        }
      }
      const eps = Array.isArray(det.episodes) ? det.episodes : [];
      const epObj = input.type === 'tv'
        ? eps.find(e => Number(e.number) === Number(input.episode))
        : eps[0];
      if (!epObj?.id || !/^\d+$/.test(String(epObj.id))) continue;

      const tracks = Array.isArray(epObj.tracks) ? epObj.tracks : [];
      const fetchCastleVideo = async (langId, resNum) => {
        const langPart = langId ? `"languageId":${Number(langId)},` : '';
        const rawBody = `{"mode":"1","appMarket":"GuanWang","clientType":"1","woolUser":"false","apkSignKey":"ED0955EB04E67A1D9F3305B95454FED485261475","androidVersion":"13","movieId":${activeId},"episodeId":${epObj.id},${langPart}"isNewUser":"true","resolution":"${resNum}","packageName":"com.external.castle"}`;
        const vr = await fetch(`${CASTLE_BASE}/film-api/v2.0.1/movie/getVideo2?clientType=1&packageName=com.external.castle&channel=IndiaA&lang=en-US`, {
          method: 'POST',
          headers: { ...CASTLE_API_HEADERS, 'Content-Type': 'application/json' },
          body: rawBody,
          signal: AbortSignal.timeout(7500)
        });
        if (!vr.ok) return null;
        const vd = castleSafeParse(castleDecrypt(await vr.text(), secKey))?.data || {};
        if (vd.isPreview) return null;
        const u = vd.videos?.[0]?.url || vd.videoUrl;
        if (!u || !/^https:\/\//i.test(u)) return null;
        return { url: u, subtitles: vd.subtitles || [] };
      };

      const audioStreams = [];
      let collectedSubs = [];
      if (tracks.length) {
        const perLang = await Promise.all(tracks.slice(0, 8).map(async trk => {
          for (const resNum of [2, 3]) {
            const v = await fetchCastleVideo(trk.existIndividualVideo ? trk.languageId : null, resNum).catch(() => null);
            if (v?.url) {
              return {
                language: normLangCode(trk.abbreviate || trk.languageName),
                label: trk.languageName || trk.abbreviate || 'Default',
                url: v.url,
                headers: {},
                proxyProvider: 'castletv',
                subtitles: v.subtitles
              };
            }
          }
          return null;
        }));
        const seen = new Set();
        for (const item of perLang.filter(Boolean)) {
          if (!collectedSubs.length && item.subtitles?.length) collectedSubs = item.subtitles;
          const key = item.label.toLowerCase();
          if (!seen.has(key)) {
            seen.add(key);
            audioStreams.push(item);
          }
        }
        if (audioStreams.length) {
          audioStreams.sort((a, b) => langSortRank(a.label) - langSortRank(b.label));
          let validPrimaryIdx = -1;
          for (let i = 0; i < audioStreams.length; i++) {
            try {
              await verifyPlayableHls(audioStreams[i].url, {}, minDur);
              validPrimaryIdx = i;
              break;
            } catch {}
          }
          if (validPrimaryIdx < 0) audioStreams.length = 0;
          else if (validPrimaryIdx > 0) {
            const [picked] = audioStreams.splice(validPrimaryIdx, 1);
            audioStreams.unshift(picked);
          }
        }
      }
      if (!audioStreams.length) {
        for (const resNum of [3, 2, 1]) {
          const v = await fetchCastleVideo(null, resNum).catch(() => null);
          if (v?.url) {
            try {
              await verifyPlayableHls(v.url, {}, minDur);
              collectedSubs = v.subtitles || [];
              audioStreams.push({ language: 'und', label: 'Default Audio', url: v.url, headers: {}, proxyProvider: 'castletv' });
              break;
            } catch {}
          }
        }
      }
      if (audioStreams.length) {
        audioStreams.sort((a, b) => langSortRank(a.label) - langSortRank(b.label));
        const subTracks = collectedSubs
          .filter(s => /^https:\/\//i.test(s?.url || ''))
          .slice(0, 20)
          .map(s => ({
            src: s.url.replace(/ /g, '%20'),
            label: String(s.title || s.abbreviate || 'Subtitle').slice(0, 50),
            language: normLangCode(s.abbreviate || s.title),
            kind: 'subtitles',
            default: false
          }));
        return {
          url: audioStreams[0].url,
          kind: 'hls',
          proxyProvider: 'castletv',
          headers: {},
          provider: 'Primary',
          sourceKey: 'default',
          server: 'Primary',
          tracks: subTracks,
          audioStreams: audioStreams.map(({ subtitles, ...rest }) => rest)
        };
      }
    } catch {}
  }
  throw Error('Primary stream unavailable.');
}

// ---------------------------------------------------------------------------
// 5. VaPlayer (streamdata.vaplayer.ru — ~240ms HLS for Indian + Global titles)
// ---------------------------------------------------------------------------
async function resolveVaPlayer(input, getMeta) {
  const meta = await getMeta(input);
  if (!meta?.imdbId) throw Error('VaPlayer requires IMDb ID');
  const minDur = input.type === 'tv' ? 780 : 1200;
  const q = new URLSearchParams({ imdb: meta.imdbId, type: input.type });
  if (input.type === 'tv') {
    q.set('season', String(input.season));
    q.set('episode', String(input.episode));
  }
  const referer = input.type === 'tv'
    ? `https://nextgencloudfabric.com/embed/tv/${meta.imdbId}/${input.season}/${input.episode}`
    : `https://nextgencloudfabric.com/embed/movie/${meta.imdbId}`;
  const headers = { Referer: referer, Origin: 'https://nextgencloudfabric.com' };
  const r = await fetch(`https://streamdata.vaplayer.ru/api.php?${q}`, {
    headers: { ...headers, 'User-Agent': UA },
    signal: AbortSignal.timeout(7500)
  });
  if (!r.ok) throw Error(`VaPlayer HTTP ${r.status}`);
  const d = await r.json();
  const rawList = d?.data?.stream_urls || [];
  for (const entry of rawList) {
    const u = typeof entry === 'string' ? entry : entry?.url;
    if (!u || !/^https:\/\//i.test(u)) continue;
    try {
      await verifyPlayableHls(u, headers, minDur);
      return {
        url: u,
        kind: 'hls',
        proxyProvider: 'vaplayer',
        headers,
        provider: 'VaPlayer',
        sourceKey: 'vaplayer',
        server: 'VaPlayer',
        tracks: [],
        audioStreams: []
      };
    } catch {}
  }
  throw Error('VaPlayer stream unavailable.');
}

// ---------------------------------------------------------------------------
// 6 & 7. VidFast 4K (vRapid & vBlaze via vidfast.vc + enc-dec.app)
// ---------------------------------------------------------------------------
const vidfastStageCache = new Map();
async function getVidFastStage(input) {
  const key = `${input.type}:${input.id}:${input.season}:${input.episode}`;
  const hit = vidfastStageCache.get(key);
  if (hit && Date.now() - hit.time < 5 * 60_000) return hit.value;
  const pagePath = input.type === 'tv' ? `tv/${input.id}/${input.season}/${input.episode}/` : `movie/${input.id}/`;
  const html = await (await fetch(`https://vidfast.vc/${pagePath}`, {
    headers: { 'User-Agent': UA, Referer: 'https://vidfast.vc/' },
    signal: AbortSignal.timeout(8000)
  })).text();
  const m = html.match(/\\"(?:en|token)\\":\\"(.*?)\\"/) || html.match(/"(?:en|token)":"([^"]+)"/);
  if (!m?.[1]) throw Error('VidFast token not found');
  const p1 = (await (await fetch(`https://enc-dec.app/api/enc-vidfast?text=${encodeURIComponent(m[1])}&stage=1`, { signal: AbortSignal.timeout(6500) })).json()).result;
  const t1 = await (await fetch(p1.stage1, {
    method: 'POST',
    headers: { 'User-Agent': UA, Referer: 'https://vidfast.vc/', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': p1.token },
    signal: AbortSignal.timeout(6500)
  })).text();
  const p2 = (await (await fetch(`https://enc-dec.app/api/enc-vidfast?text=${encodeURIComponent(t1)}&stage=2`, { signal: AbortSignal.timeout(6500) })).json()).result;
  const sEnc = await (await fetch(p2.servers, {
    method: 'POST',
    headers: { 'User-Agent': UA, Referer: 'https://vidfast.vc/', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': p2.token },
    signal: AbortSignal.timeout(6500)
  })).text();
  const servers = (await (await fetch('https://enc-dec.app/api/dec-vidfast', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: sEnc }),
    signal: AbortSignal.timeout(6500)
  })).json()).result;
  if (!Array.isArray(servers) || !servers.length) throw Error('VidFast returned no servers');
  const value = { streamBase: p2.stream, token: p2.token, servers };
  vidfastStageCache.set(key, { value, time: Date.now() });
  return value;
}

async function resolveVidFast(input, targetName, sourceKey, displayLabel) {
  const minDur = input.type === 'tv' ? 780 : 1200;
  const stage = await getVidFastStage(input);
  const preferred = stage.servers.filter(s => s?.name?.toLowerCase() === targetName.toLowerCase());
  const ordered = preferred.length ? preferred : stage.servers.slice(0, 2);
  for (const srv of ordered) {
    if (!srv?.data) continue;
    try {
      const stEnc = await (await fetch(`${stage.streamBase}/${srv.data}`, {
        method: 'POST',
        headers: { 'User-Agent': UA, Referer: 'https://vidfast.vc/', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': stage.token },
        signal: AbortSignal.timeout(7000)
      })).text();
      const stDec = (await (await fetch('https://enc-dec.app/api/dec-vidfast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: stEnc }),
        signal: AbortSignal.timeout(6500)
      })).json()).result;
      if (!stDec?.url || !/^https:\/\//i.test(stDec.url)) continue;
      const headers = stDec.noReferrer ? {} : { Referer: 'https://vidfast.vc/', Origin: 'https://vidfast.vc' };
      await verifyPlayableHls(stDec.url, headers, minDur);
      const tracks = (stDec.tracks || [])
        .filter(t => /^https:\/\//i.test(t?.file || ''))
        .slice(0, 25)
        .map(t => ({
          src: t.file,
          label: String(t.label || 'Subtitle').slice(0, 50),
          language: normLangCode(t.label),
          kind: 'subtitles',
          default: false
        }));
      return {
        url: stDec.url,
        kind: 'hls',
        proxyProvider: 'vidfast',
        headers,
        provider: displayLabel,
        sourceKey,
        server: displayLabel,
        tracks,
        audioStreams: []
      };
    } catch {}
  }
  throw Error(`${displayLabel} stream unavailable.`);
}

// ---------------------------------------------------------------------------
// 8 & 9. CineJoy 4K ('secret') & Nebula Direct ('Nebula') via api.wing.st
// ---------------------------------------------------------------------------
async function resolveWing(input, getMeta, wingServer, sourceKey, displayLabel) {
  const meta = await getMeta(input);
  if (!meta?.title) throw Error('Wing requires metadata');
  const minDur = input.type === 'tv' ? 780 : 1200;
  const type = input.type === 'tv' ? 'series' : 'movie';
  let url = `https://api.wing.st/?title=${encodeURIComponent(meta.title)}&type=${type}&year=${meta.year || ''}&imdb=${meta.imdbId || ''}&tmdb=${input.id}&server=${encodeURIComponent(wingServer)}`;
  if (input.type === 'tv') url += `&season=${input.season}&episode=${input.episode}`;

  const ej = await (await fetch(`https://enc-dec.app/api/enc-cinejoy?url=${encodeURIComponent(url)}`, { signal: AbortSignal.timeout(6500) })).json();
  if (ej.status !== 200 || !ej.result?.data) throw Error(`${displayLabel} token failed`);
  const gr = await fetch('https://api.wing.st/g', {
    method: 'POST',
    headers: { Accept: '*/*', Origin: 'https://cinejoy.pk', Referer: 'https://cinejoy.pk/', 'User-Agent': UA },
    body: Buffer.from(ej.result.data, 'base64url'),
    signal: AbortSignal.timeout(8000)
  });
  const gbuf = Buffer.from(await gr.arrayBuffer());
  const dj = await (await fetch('https://enc-dec.app/api/dec-cinejoy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: gbuf.toString('base64url'), state: ej.result.state }),
    signal: AbortSignal.timeout(6500)
  })).json();
  if (dj.status !== 200) throw Error(`${displayLabel} decrypt failed`);
  const streamObj = dj.result?.data?.stream?.[0];
  const playlist = streamObj?.playlist;
  if (!playlist || !/^https:\/\//i.test(playlist)) throw Error(`${displayLabel} returned no playlist`);
  const headers = streamObj?.headers && typeof streamObj.headers === 'object'
    ? streamObj.headers
    : { Referer: 'https://cinejoy.pk/', Origin: 'https://cinejoy.pk' };
  await verifyPlayableHls(playlist, headers, minDur);
  const tracks = (streamObj.captions || [])
    .filter(c => /^https:\/\//i.test(c?.url || ''))
    .slice(0, 25)
    .map(c => ({
      src: c.url,
      label: String(c.language || c.id || 'Subtitle').toUpperCase(),
      language: normLangCode(c.language || c.id),
      kind: 'subtitles',
      default: false
    }));
  return {
    url: playlist,
    kind: 'hls',
    proxyProvider: 'wing',
    headers,
    provider: displayLabel,
    sourceKey,
    server: displayLabel,
    tracks,
    audioStreams: []
  };
}

// ---------------------------------------------------------------------------
// 10. Hexa Multi (theemoviedb.hexa.su — alpha / echo / delta / charlie)
// ---------------------------------------------------------------------------
let hexaTokenState = { token: '', uses: 0, time: 0 };
async function getHexaCapToken() {
  if (hexaTokenState.token && hexaTokenState.uses < 16 && Date.now() - hexaTokenState.time < 10 * 60_000) {
    hexaTokenState.uses++;
    return hexaTokenState.token;
  }
  const ch = await (await fetch('https://cap.hexa.su/15d2cf0395/challenge', {
    method: 'POST',
    headers: { Origin: 'https://hexa.su', Referer: 'https://hexa.su/', 'User-Agent': UA },
    signal: AbortSignal.timeout(6500)
  })).json();
  const solved = await (await fetch('https://enc-dec.app/api/enc-hexa', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ challenge_data: ch }),
    signal: AbortSignal.timeout(8000)
  })).json();
  if (solved.status !== 200) throw Error('Hexa challenge failed');
  const red = await (await fetch('https://cap.hexa.su/15d2cf0395/redeem', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: 'https://hexa.su', Referer: 'https://hexa.su/', 'User-Agent': UA },
    body: JSON.stringify(solved.result),
    signal: AbortSignal.timeout(6500)
  })).json();
  if (!red?.token) throw Error('Hexa redeem failed');
  hexaTokenState = { token: red.token, uses: 1, time: Date.now() };
  return red.token;
}

async function resolveHexa(input) {
  const minDur = input.type === 'tv' ? 780 : 1200;
  const capToken = await getHexaCapToken();
  const key = crypto.randomBytes(32).toString('hex');
  const endpoint = input.type === 'tv'
    ? `https://theemoviedb.hexa.su/api/tmdb/tv/${input.id}/season/${input.season}/episode/${input.episode}/images`
    : `https://theemoviedb.hexa.su/api/tmdb/movie/${input.id}/images`;
  const enc = await (await fetch(endpoint, {
    headers: {
      'User-Agent': UA,
      Referer: 'https://hexa.su/',
      Origin: 'https://hexa.su',
      Accept: 'text/plain',
      'X-Fingerprint-Lite': 'e9136c41504646444',
      'X-Cap-Token': capToken,
      'X-Api-Key': key
    },
    signal: AbortSignal.timeout(8000)
  })).text();
  const dj = await (await fetch('https://enc-dec.app/api/dec-hexa', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: enc, key }),
    signal: AbortSignal.timeout(6500)
  })).json();
  if (dj.status !== 200) throw Error('Hexa decrypt failed');
  const res = typeof dj.result === 'string' ? JSON.parse(dj.result) : dj.result;
  const sources = (res?.sources || []).filter(s => /^https:\/\//i.test(s?.url || ''));
  const headers = { Referer: 'https://hexa.su/', Origin: 'https://hexa.su' };
  for (const s of sources) {
    try {
      await verifyPlayableHls(s.url, headers, minDur);
      return {
        url: s.url,
        kind: 'hls',
        proxyProvider: 'hexa',
        headers,
        provider: 'Hexa Multi',
        sourceKey: 'hexa',
        server: 'Hexa Multi',
        tracks: [],
        audioStreams: []
      };
    } catch {}
  }
  throw Error('Hexa Multi stream unavailable.');
}

// ---------------------------------------------------------------------------
// 11. OneTouch (api3.devcorp.me AES-256 — Indian, Korean & Asian VOD)
// ---------------------------------------------------------------------------
const ONETOUCH_MAIN = 'https://api3.devcorp.me';
const ONETOUCH_KEY = Buffer.from('im72charPasswordofdInitVectorStm', 'utf8');
const ONETOUCH_IV = Buffer.from('im72charPassword', 'utf8');

function decryptOneTouch(encoded) {
  let s = String(encoded || '').replace(/-_\./g, '/').replace(/@/g, '+').replace(/\s+/g, '');
  if (s.length % 4) s += '='.repeat(4 - (s.length % 4));
  const dec = crypto.createDecipheriv('aes-256-cbc', ONETOUCH_KEY, ONETOUCH_IV);
  const plain = Buffer.concat([dec.update(Buffer.from(s, 'base64')), dec.final()]).toString('utf8');
  return JSON.parse(plain).result;
}
async function fetchOneTouch(path) {
  const r = await fetch(ONETOUCH_MAIN + path, {
    headers: { 'User-Agent': UA, Referer: 'https://onetouchtv.xyz/' },
    signal: AbortSignal.timeout(7500)
  });
  if (!r.ok) throw Error(`OneTouch HTTP ${r.status}`);
  return decryptOneTouch(await r.text());
}

async function resolveOneTouch(input, getMeta) {
  const meta = await getMeta(input);
  if (!meta?.title) throw Error('OneTouch requires title');
  const minDur = input.type === 'tv' ? 780 : 1200;
  const keywords = input.type === 'tv' && Number(input.season) > 1
    ? [`${meta.title} Season ${input.season}`, meta.title]
    : [meta.title];
  let matched = null;
  const targetLc = meta.title.toLowerCase();
  for (const kw of keywords) {
    const results = await fetchOneTouch(`/vod/search?keyword=${encodeURIComponent(kw)}`).catch(() => []);
    if (!Array.isArray(results) || !results.length) continue;
    const filtered = results.filter(r => input.type === 'movie' ? String(r.type || '').toLowerCase() === 'movie' : String(r.type || '').toLowerCase() !== 'movie');
    matched = filtered.find(r => String(r.title || '').toLowerCase() === targetLc)
      || filtered.find(r => String(r.title || '').toLowerCase().includes(targetLc))
      || filtered[0];
    if (matched?.id) break;
  }
  if (!matched?.id) throw Error('OneTouch: title not found');
  const det = await fetchOneTouch(`/vod/${matched.id}/detail`);
  const eps = det?.episodes || [];
  const ep = input.type === 'movie' ? eps[0] : eps.find(e => Number(e.episode) === Number(input.episode));
  if (!ep?.playId) throw Error('OneTouch: episode not found');
  const sd = await fetchOneTouch(`/vod/${matched.id}/episode/${ep.playId}`);
  const sources = (sd?.sources || []).filter(s => /^https:\/\//i.test(s?.url || ''));
  const tracks = (sd?.track || [])
    .filter(t => /^https:\/\//i.test(t?.file || ''))
    .slice(0, 20)
    .map(t => ({
      src: t.file,
      label: String(t.name || 'Subtitle').slice(0, 50),
      language: normLangCode(t.name),
      kind: 'subtitles',
      default: false
    }));
  for (const src of sources) {
    for (const headers of [{ Referer: `${ONETOUCH_MAIN}/` }, { Referer: 'https://onetouchtv.xyz/', Origin: 'https://onetouchtv.xyz' }]) {
      try {
        await verifyPlayableHls(src.url, headers, minDur);
        return {
          url: src.url,
          kind: 'hls',
          proxyProvider: 'onetouch',
          headers,
          provider: 'OneTouch',
          sourceKey: 'onetouch',
          server: 'OneTouch',
          tracks,
          audioStreams: []
        };
      } catch {}
    }
  }
  throw Error('OneTouch stream unavailable.');
}

// ---------------------------------------------------------------------------
// 12, 13, 14. Existing VidLink, CineSrc, VidSrc Wrappers
// ---------------------------------------------------------------------------
async function resolveCineSrcWrapped(input) {
  const resolved = await resolveCineSrc(input, 'second').catch(() => resolveCineSrc(input, 'default'));
  return {
    url: resolved.url,
    kind: 'hls',
    proxyProvider: 'cinesrc',
    headers: {},
    provider: 'CineSrc',
    sourceKey: 'cinesrc',
    server: 'CineSrc',
    tracks: [],
    audioStreams: []
  };
}
async function resolveVidLinkWrapped(input) {
  try {
    const enc = (await (await fetch(`https://enc-dec.app/api/enc-vidlink?text=${encodeURIComponent(input.id)}`, { signal: AbortSignal.timeout(6000) })).json()).result;
    const apiPath = input.type === 'tv' ? `tv/${enc}/${input.season}/${input.episode}` : `movie/${enc}`;
    const d = await (await fetch(`https://vidlink.pro/api/b/${apiPath}?multiLang=0`, {
      headers: { 'User-Agent': UA, Referer: 'https://vidlink.pro/', Origin: 'https://vidlink.pro', 'x-playback-environment': 'standard' },
      signal: AbortSignal.timeout(8000)
    })).json();
    const source = d?.stream;
    if (source) {
      const tracks = (source.captions || []).filter(t => /^https:\/\//i.test(t?.url || '')).slice(0, 25).map(t => ({
        src: t.url,
        label: String(t.language || 'Subtitle').slice(0, 50),
        language: normLangCode(t.language),
        kind: 'subtitles',
        default: false
      }));
      const qualities = Object.entries(source.qualities || {})
        .filter(([, v]) => /^https:\/\//i.test(v?.url || '') && !/hevc|h265|x265/i.test(v?.codecName || ''))
        .sort((a, b) => Number(b[0]) - Number(a[0]));
      if (qualities.length) {
        const [, q] = qualities[0];
        return { url: q.url, kind: q.type === 'hls' ? 'hls' : 'mp4', proxyProvider: 'vidlink', headers: q.headers || {}, provider: 'VidLink', sourceKey: 'vidlink', server: 'VidLink', tracks, audioStreams: [] };
      }
      if (/^https:\/\//i.test(source.playlist || '')) {
        const kind = source.type === 'dash' || /\.mpd(?:\?|$)/i.test(source.playlist) ? 'dash' : 'hls';
        return { url: source.playlist, kind, proxyProvider: 'vidlink', headers: source.playlistHeaders || {}, provider: 'VidLink', sourceKey: 'vidlink', server: 'VidLink', tracks, audioStreams: [] };
      }
    }
  } catch {}
  const resolved = await resolveVidlink(input);
  return {
    ...resolved,
    proxyProvider: 'vidlink',
    sourceKey: 'vidlink',
    server: 'VidLink',
    audioStreams: []
  };
}
async function resolveVidSrcWrapped(input) {
  const resolved = await resolveVidsrc(input);
  return {
    ...resolved,
    proxyProvider: 'vidsrc',
    sourceKey: 'vidsrc',
    server: 'VidSrc',
    audioStreams: []
  };
}

// ---------------------------------------------------------------------------
// Unified Cached Dispatcher + Smart Failover
// ---------------------------------------------------------------------------
function runSingleServer(providerKey, input, getMeta) {
  switch (providerKey) {
    case 'default': return resolveCastleTV(input, getMeta).catch(async () => {
      const v6 = await resolveVidZeeV6(input);
      return { ...v6, provider: 'Primary', sourceKey: 'default', server: 'Primary' };
    });
    case 'vidzee_multi': return resolveVidZeePrimary(input);
    case 'vidzee_v6': return resolveVidZeeV6(input);
    case 'vaplayer': return resolveVaPlayer(input, getMeta);
    case 'vidfast_rapid': return resolveVidFast(input, 'vRapid', 'vidfast_rapid', 'vRapid 4K');
    case 'vidfast_blaze': return resolveVidFast(input, 'vBlaze', 'vidfast_blaze', 'vBlaze 4K');
    case 'wing_secret': return resolveWing(input, getMeta, 'secret', 'wing_secret', 'CineJoy 4K');
    case 'wing_nebula': return resolveWing(input, getMeta, 'Nebula', 'wing_nebula', 'Nebula Direct');
    case 'hexa': return resolveHexa(input);
    case 'vidzee_peak': return resolveVidZeePeak(input);
    case 'onetouch': return resolveOneTouch(input, getMeta);
    case 'vidlink': return resolveVidLinkWrapped(input);
    case 'cinesrc': return resolveCineSrcWrapped(input);
    case 'vidsrc': return resolveVidSrcWrapped(input);
    default: return resolveCastleTV(input, getMeta);
  }
}

export function resolveOttServer(input, providerKey, getMeta) {
  const normalized = OTT_SERVER_KEYS.has(providerKey) ? providerKey : 'default';
  const cacheKey = `${normalized}:${input.type}:${input.id}:${input.season}:${input.episode}`;
  const hit = streamCache.get(cacheKey);
  if (hit && Date.now() - hit.time < CACHE_TTL) return Promise.resolve(hit.value);
  if (inflight.has(cacheKey)) return inflight.get(cacheKey);

  const p = runSingleServer(normalized, input, getMeta)
    .then(val => {
      streamCache.set(cacheKey, { value: val, time: Date.now() });
      if (streamCache.size > 400) streamCache.delete(streamCache.keys().next().value);
      return val;
    })
    .finally(() => inflight.delete(cacheKey));
  inflight.set(cacheKey, p);
  return p;
}

function withTimeout(promise, ms) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, rej) => { timer = setTimeout(() => rej(Error('Server timed out')), ms); })
  ]).finally(() => clearTimeout(timer));
}

export async function resolveOttWithFallback(input, requestedProvider, getMeta) {
  const key = OTT_SERVER_KEYS.has(requestedProvider) ? requestedProvider : 'default';
  try {
    return await withTimeout(resolveOttServer(input, key, getMeta), key === 'vidsrc' ? 22_000 : 12_500);
  } catch {
    // Fast parallel wave 1 (pure HTTP multilingual resolvers < 2s), then wave 2 if needed
    const wave1 = ['default', 'vidzee_v6', 'vaplayer', 'vidzee_multi', 'wing_nebula', 'vidfast_rapid', 'hexa']
      .filter(k => k !== key);
    try {
      return await Promise.any(wave1.map(k => withTimeout(resolveOttServer(input, k, getMeta), 11_000)));
    } catch {}
    const wave2 = ['wing_secret', 'vidfast_blaze', 'vidzee_peak', 'onetouch', 'vidlink', 'cinesrc']
      .filter(k => k !== key);
    try {
      return await Promise.any(wave2.map(k => withTimeout(resolveOttServer(input, k, getMeta), 14_000)));
    } catch {
      throw Error('None of the available playback servers could load this title.');
    }
  }
}
