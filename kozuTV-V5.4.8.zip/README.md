# kozuTV V5.4.8

kozuTV is a responsive anime, movie and series browser with a custom Video.js player and a same-origin media proxy.

## Quick start

Requires Node.js 20 or newer.

```bash
npm install
npm start
```

Open `http://localhost:3000`. To use another port, run `PORT=8080 npm start`. Some optional provider fallbacks use Playwright; if prompted, install Chromium with `npx playwright install chromium`.

## V5.4.8

- Episode navigation keeps the player container mounted, including across seasons, so supported browsers stay in fullscreen. Browser Back and Forward also update the current episode in place.
- Explore and Genres match the Home menu heading, and genre entries have distinct icons.
- Regional audio selection prioritizes tested, browser-compatible sources. Runtime checks reject a known ad-spliced fallback and a confirmed incorrect Naruto source. H.264 MP4 sources are detected correctly and inspected with bounded range reads.
- Available captions are retained when changing audio, with conservative PAL/NTSC timing adjustment and HLS audio-based synchronization where possible. Subtitle timing can also be adjusted in the player settings.
- Movies and series show the identified audio language from the stream or title metadata instead of a generic default label. Where the language cannot be determined, the player says “Original audio” rather than guessing.
- The default OTT resolver can start after a verified source is found rather than waiting indefinitely for a slower alternate provider.

The app offers VidCore, EmbedWave, CineSrc, VidLink and VidSrc for movies and series. Anime playback uses MegaPlay with regional alternatives where available. The player includes subtitle controls, playback speed, picture-in-picture, seek previews and quality choices when the source provides them.

**Source limitations:** Streaming providers and subtitle catalogs are external and change over time. A language, clean copy, matching captions, or a particular resolution is not available for every title or episode. Automatic subtitle alignment is best-effort; use the sync control if a release differs. Watermarks and embedded advertising cannot always be removed.

The app keeps per-visitor watchlist and history data in `data/states.json`. The delivery archive starts with an empty state. Font and third-party license notices are included with the project.
