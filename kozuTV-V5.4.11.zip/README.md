# kozuTV V5.4.11

kozuTV is a responsive anime, movie and series browser with a custom Video.js player and same-origin media proxy.

## Quick start

Requires Node.js 20 or newer.

```bash
npm install
npm start
```

Open `http://localhost:3000`. The included `Screenshot.html` is an offline visual guide to the pages and states. To use another port, run `PORT=8080 npm start`. Some optional provider fallbacks use Playwright; if prompted, install Chromium with `npx playwright install chromium`.

Run `npm run test:token` for isolated token-store checks. `npm run test:viewer` runs the browser regression checks with Playwright Chromium (install it with `npx playwright install chromium` if needed). Both use temporary data and do not touch your saved data.

## What's new in V5.4.11

- New in 2026 and the Hindi, Tamil and Telugu Dubbed collections appear as shuffled Browse rows, not in Explore or the genre dropdown. The dubbed collections and Language & sources use a headphones icon; Playback has its own screen-and-play icon.
- Dub-detection notices are no longer shown. The episode-order confirmation still appears when a language change would switch between incompatible regional and Japanese/English catalogs.
- Viewer settings now include **Seek interval** (5, 10, 15 or 30 seconds for the arrow/J/L keys and player double taps), **Resume playback**, **Save watch history**, **Spotlight autoplay** and **Reduce motion**. Defaults preserve the previous behavior. Turning off history stops new progress writes from that browser without deleting previous history or the watchlist; other open browsers apply a synced change when they refresh, regain focus, or poll. Turning off resume starts the selected episode at the beginning. Manual spotlight dots remain usable when autoplay is off. Reduce motion minimizes page and player animations.
- The new preferences are saved locally, synchronized using Cache Token, and included when resetting preferences. Existing history, watchlist and the token are not deleted by reset.

## Previously in V5.4.10

- The Settings gear is fixed, and the individual setting descriptions have been removed.
- Cache Token links a browser to its existing kozuTV watchlist, viewing history, and app-owned playback, audio, subtitle, quality and other preferences. See the restore and privacy notes below.
- Hindi Dubbed, Tamil Dubbed and Telugu Dubbed were moved into randomized Browse rows alongside the other categories.

## Cache Token

1. In Settings, choose **Generate Token**, then copy and save the six-character code. The copy icon is available in the current page session; after reloading, the visible token is locked and the two buttons are disabled.
2. On another browser using **the same kozuTV server**, enter that code and choose **Set Token**. The token's saved watchlist, history and app-owned preferences replace this browser's current kozuTV data. Changes are saved to the shared profile; preferences are restored on load and refreshed when the page regains focus.
3. To use a different token on a browser, manually clear this site's data, including **both cookies and local storage**, and reload. Reset preferences does not remove or change the token.

The token identifies data stored on this kozuTV server; six characters cannot contain the data itself. Preserve and back up `data/states.json`, `data/cache-tokens.json` and `data/cache-token.key` together when upgrading or moving the server. The release archive omits runtime user and token files; the server creates fresh ones on first run, so extracting an update does not overwrite existing runtime data. If these files are lost, the token cannot restore that server's data. This feature covers kozuTV's stored history, watchlist and app-owned browser preferences, not the browser's entire cache, passwords, downloads, or data belonging to other sites.

**Privacy:** A six-character token has limited strength. Anyone who knows or guesses it can access the associated history, watchlist and preferences. Keep it private and do not use it for sensitive information. Online attempts are rate-limited, but this is not a substitute for a secure account.

## Previously in V5.4.9

- Pokémon has a region/series selector from Kanto through Horizons, provider-aware episode titles and artwork, and chronological next/previous navigation. The normal Journeys path moves to *To Be a Pokémon Master* after episode 136 rather than repeating the overlapping episodes. Direct links to the overlapping Journeys episodes still work. The provider currently skips Sun & Moon episode 6; navigation skips that gap.
- Doraemon's Indian-broadcast first season has 52 episode titles and corresponding stills. Perman and Shin-chan have additional episode metadata; episode stills are used where matched, and unknown titles or images fall back rather than borrowing an unrelated episode. Shin-chan's regional provider does not consistently follow broadcast numbering, so only checked matches are named.
- Language and direct-quality changes are committed only after the new source loads. Where possible, playback position, play/pause state, fullscreen, and a matching caption selection are retained. A failed switch attempts to restore the previous source and reports the outcome. An unavailable language is not silently relabeled as another.
- Shin-chan and Doraemon's regional broadcasts and Japanese/English catalogs use different episode orders. Switching between them asks for confirmation and opens episode 1 of the other catalog; it does not pretend to find an equivalent episode.
- The Browse page automatically loads shuffled genre and collection rows as you scroll, and recycles off-screen cards while preserving scroll position. Explore and Genres are collapsible.
- A Settings page saves playback, language, quality, speed and source preferences on this device. Reset clears those preferences and player caption/audio settings, not the watchlist or history. Artwork falls back to show art or a neutral placeholder when an episode image fails.
- Search and navigation ignore stale requests, and changing sources refreshes the available quality and subtitle lists.

**Availability and accuracy:** Providers and subtitle catalogs are external and may change or fail. Dubs, captions, image matches, and particular resolutions are not guaranteed for every title or episode. Dub collections are curated from observed tracks, not a guarantee of availability for an entire series. Some sources use different cuts or contain embedded watermarks or advertising. Unknown episode names are deliberately left generic. Automatic subtitle alignment is best-effort; use the player's sync control if a release differs. Pokémon's first episode has a sampled Hindi source; that does not imply all Pokémon episodes have Hindi audio.

The app offers VidCore, EmbedWave, CineSrc, VidLink and VidSrc for movies and series. Anime uses MegaPlay with regional alternatives where available. Player features include subtitle controls, playback speed, picture-in-picture, seek previews and quality choices when provided by the source.

Watchlist and history are stored per visitor in `data/states.json`; a fresh installation starts with an empty state. Device preferences are stored in the browser and are synchronized to the shared profile after a Cache Token is set. See [data/ATTRIBUTION.md](data/ATTRIBUTION.md) for episode-data and artwork sources, and the included license files for third-party software and fonts.
