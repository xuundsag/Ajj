import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {createCacheTokenStore,CacheTokenError} from '../cache-tokens.js';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'kozu-token-unit-'));try{
 let store=createCacheTokenStore(dir),generated=new Set(), first;
 for(let i=0;i<120;i++){
  const visitor=i.toString(16).padStart(32,'0'), row=store.create(visitor,{'moscowtv-autoplay':'false','kozutv-caption-style-ott':'{"size":"120"}'});
  assert.match(row.token,/^[A-Z0-9]{6}$/);assert.match(row.token,/[A-Z]/);assert.match(row.token,/[0-9]/);assert(!generated.has(row.token));generated.add(row.token);
  assert.equal(store.status(visitor).token,row.token);assert.equal(store.resolve(row.token).visitorId,visitor);first ||= {visitor,...row};
 }
 let db=JSON.parse(fs.readFileSync(path.join(dir,'cache-tokens.json'),'utf8'));for(const [hash,record] of Object.entries(db.tokens)){assert.match(hash,/^[a-f0-9]{64}$/);assert(!generated.has(record.sealed),'raw token must not be stored as the display value')}
 assert.throws(()=>store.create(first.visitor,{}),e=>e instanceof CacheTokenError&&e.code==='BOUND');
 assert.equal(store.resolve('ZZZZZZ'),null);assert.equal(store.resolve('../'),null);
 assert.throws(()=>store.patch('f'.repeat(32),{'moscowtv-speed':'2'}),e=>e.code==='UNBOUND');
 assert.throws(()=>store.patch(first.visitor,{'other-app-secret':'oops'}),e=>e.code==='INVALID_PREFS');
 assert.throws(()=>store.patch(first.visitor,{'kozutv-cache-token':'unsafe'}),e=>e.code==='INVALID_PREFS');
 assert.throws(()=>store.patch(first.visitor,{'moscowtv-big':'X'.repeat(8193)}),e=>e.code==='INVALID_PREFS');
 let updated=store.patch(first.visitor,{'moscowtv-autoplay':null,'moscowtv-speed':'1.5'});
 assert.equal(updated.preferences['moscowtv-autoplay'],undefined);assert.equal(updated.preferences['moscowtv-speed'],'1.5');assert.equal(updated.revision,2);
 store=createCacheTokenStore(dir);assert.equal(store.status(first.visitor).token,first.token);assert.equal(store.status(first.visitor).preferences['moscowtv-speed'],'1.5');
 fs.renameSync(path.join(dir,'cache-token.key'),path.join(dir,'backup.key'));assert.throws(()=>createCacheTokenStore(dir),/key is missing/);fs.renameSync(path.join(dir,'backup.key'),path.join(dir,'cache-token.key'));
 const dbBackup=fs.readFileSync(path.join(dir,'cache-tokens.json'));fs.writeFileSync(path.join(dir,'cache-tokens.json'),'broken');store=createCacheTokenStore(dir);assert.throws(()=>store.status(first.visitor));assert.equal(fs.readFileSync(path.join(dir,'cache-tokens.json'),'utf8'),'broken');fs.writeFileSync(path.join(dir,'cache-tokens.json'),dbBackup);
 console.log('PASS: 120 unique mixed 6-char tokens; encrypted-at-rest; persistence; binding; strict prefs; deletion; corruption/key loss protections.');
}finally{fs.rmSync(dir,{recursive:true,force:true})}
