// Browser regression checks run an isolated server with mocked catalog data.
// The small silent WebM fixture exercises the real Video.js player offline.
import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const work=fs.mkdtempSync(path.join(os.tmpdir(),'kozutv-viewer-test-'));
const excluded=new Set(['states.json','user.json','cache-token.key','cache-tokens.json']);
fs.cpSync(path.join(root,'public'),path.join(work,'public'),{recursive:true});
fs.cpSync(path.join(root,'data'),path.join(work,'data'),{recursive:true,filter:src=>!excluded.has(path.basename(src))&&!src.endsWith('.tmp')});
const allocator=net.createServer();
await new Promise((resolve,reject)=>{allocator.once('error',reject);allocator.listen(0,'127.0.0.1',resolve)});
const port=allocator.address().port;await new Promise(resolve=>allocator.close(resolve));
const BASE=`http://127.0.0.1:${port}`;
let child=null,browser=null,log='';
try {
 child=spawn(process.execPath,[path.join(root,'server.js')],{cwd:work,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
 child.stdout.on('data',d=>{log+=d.toString()});child.stderr.on('data',d=>{log+=d.toString()});
 await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>reject(new Error('Test server did not start: '+log)),20000);
  child.once('error',e=>{clearTimeout(timer);reject(e)});
  child.once('exit',code=>{clearTimeout(timer);reject(new Error('Test server exited '+code+': '+log))});
  child.stdout.on('data',()=>{if(log.includes('listening on')){clearTimeout(timer);resolve()}});
 });
 browser=await chromium.launch({headless:true,args:['--no-sandbox','--autoplay-policy=no-user-gesture-required']});
const testImage='/images/spotlight/anime-21.jpg';
const item={id:'424242',type:'anime',title:'Test Anime',description:'Test description',poster:testImage,backdrop:testImage,genres:['Action'],episodes:3,sub:true,dub:true,differentDubOrder:true};
const items=Array.from({length:4},(_,i)=>({...item,id:String(424242+i),title:`Test Anime ${i+1}`}));
const mediaPath=path.join(root,'scripts','fixtures','seek-test.webm');
function json(route,body){return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)})}
async function mockApi(context){
 await context.route('**/api/**',async route=>{
  const u=new URL(route.request().url());
  if(u.pathname==='/api/browse')return json(route,{items,spotlight:items.slice(0,3),suggestions:[]});
  if(u.pathname==='/api/genre'||u.pathname==='/api/collection')return json(route,{items,hasMore:false,totalResults:items.length,note:'Live Hindi dub was detected: legacy unwanted notice.'});
  if(u.pathname==='/api/detail')return json(route,{item:{...item,audioNote:'Regional dub was detected: legacy unwanted notice.'},seasons:[{id:item.id,name:'Season 1',episodes:3}],episodes:[]});
  if(u.pathname==='/api/anime-episodes')return json(route,{episodes:[1,2,3].map(number=>({number,title:`Episode ${number}`})),hasNext:false});
  if(u.pathname==='/api/anime-audio')return json(route,{streams:[]});
  if(u.pathname==='/api/play')return json(route,{src:'/__qa_test.webm',type:'video/webm',provider:'megaplay',activeLang:u.searchParams.get('lang')||'sub',allowSub:true,allowDub:true,regionalStreams:[],tracks:[]});
  return route.continue();
 });
 await context.route('**/__qa_test.webm',route=>route.fulfill({status:200,path:mediaPath,contentType:'video/webm',headers:{'Accept-Ranges':'bytes'}}));
}
async function ready(p,path='/settings'){
 await p.goto(BASE+path,{waitUntil:'domcontentloaded',timeout:15000});
 await p.waitForSelector(path==='/settings'?'.settings-page':'#app > :not(.loading)',{timeout:15000});
}
async function toggle(p,key,value){
 const x=p.locator(`[data-site-pref="${key}"]`);assert.equal(await x.count(),1,key);
 if(await x.isChecked()!==value)await p.locator(`[data-site-pref="${key}"] + span`).click();
 assert.equal(await x.isChecked(),value,key);
}
async function waitBound(p){await p.waitForFunction(()=>window.KozuCacheToken?.state().bound&&window.KozuCacheToken.state().ready,{timeout:10000})}
async function loadVideo(p){
 await p.waitForFunction(()=>{const p=window.videojs?.getPlayer('moscowtv-video');return p&&p.duration()>=170&&p.readyState()>=2&&p.megaUI},{timeout:15000});
 await p.waitForTimeout(350);
}
async function seekTo(p,v){
 await p.evaluate(v=>{const pl=window.videojs.getPlayer('moscowtv-video');pl.pause();pl.currentTime(v)},v);
 await p.waitForFunction(v=>Math.abs(window.videojs.getPlayer('moscowtv-video').currentTime()-v)<1.1,v,{timeout:5000});
}
async function expectTime(p,v){await p.waitForFunction(v=>Math.abs(window.videojs.getPlayer('moscowtv-video').currentTime()-v)<1.1,v,{timeout:5000})}
const errors=[];
function watchErrors(p,label){p.on('pageerror',e=>errors.push(label+': '+String(e)))}
// Compact settings and menu on both desktop and narrow mobile.
 for(const width of [1440,390,320]){
  const c=await browser.newContext({viewport:{width,height:900}});await mockApi(c);const p=await c.newPage();watchErrors(p,'layout '+width);await ready(p);
  assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth),width,'no overflow at '+width);
  assert.equal(await p.locator('.setting-row small,.setting-row p').count(),0,'no descriptions');
  const flags=['moscowtv-resume-playback','moscowtv-save-history','moscowtv-spotlight-autoplay'];for(const f of flags)assert.equal(await p.locator(`[data-site-pref="${f}"]`).isChecked(),true,f);
  assert.equal(await p.locator('[data-site-pref="moscowtv-reduce-motion"]').isChecked(),false);
  assert.equal(await p.locator('[data-site-pref="moscowtv-seek-step"]').inputValue(),'10');
  const headerPaths=await p.locator('.settings-card-heading').evaluateAll(els=>els.map(el=>({text:el.innerText,svg:el.querySelector('svg').innerHTML})));
  assert(headerPaths.find(x=>x.text==='Playback').svg.includes('rect'));
  assert(headerPaths.find(x=>x.text==='Language & sources').svg.includes('M3 14v-3a9'));
  await p.locator('.menu-toggle').click();
  assert.equal(await p.locator('.menu-explore').getByText('New in 2026').count(),0);
  for(const name of ['New in 2026','Hindi Dubbed','Tamil Dubbed','Telugu Dubbed'])assert.equal(await p.locator('#genre-menu').getByText(name).count(),0);
  await c.close();
 }
 console.log('PASS layout, defaults, distinct playback/headphone icons, menus at 1440/390/320');

 // Cache Token snapshots and bidirectional preference synchronization.
 const a=await browser.newContext({viewport:{width:1200,height:800}}),pa=await a.newPage();watchErrors(pa,'token A');await ready(pa);
 await toggle(pa,'moscowtv-resume-playback',false);await toggle(pa,'moscowtv-save-history',false);await toggle(pa,'moscowtv-spotlight-autoplay',false);await toggle(pa,'moscowtv-reduce-motion',true);await pa.locator('[data-site-pref="moscowtv-seek-step"]').selectOption('15');
 assert(await pa.evaluate(()=>document.documentElement.classList.contains('reduce-motion')&&document.documentElement.classList.contains('spotlight-paused')));
 await pa.evaluate(async item=>{for(const [endpoint,body] of [['/api/history',{...item,episode:2,season:1,currentTime:60,duration:180}],['/api/watchlist',item]])await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})},item);
 await pa.locator('[data-token-generate]').click();await waitBound(pa);
 const token=await pa.locator('#cache-token-input').inputValue();assert.match(token,/^[A-Z0-9]{6}$/);assert.equal(await pa.locator('[data-token-copy]').count(),1);assert.equal(await pa.locator('[data-token-generate]').isDisabled(),true);
 const b=await browser.newContext({viewport:{width:390,height:844}}),pb=await b.newPage();watchErrors(pb,'token B');await ready(pb);await pb.locator('#cache-token-input').fill(token);pb.on('dialog',d=>d.accept());await pb.locator('[data-token-set]').click();await waitBound(pb);
 for(const [k,v] of Object.entries({'moscowtv-resume-playback':'false','moscowtv-save-history':'false','moscowtv-spotlight-autoplay':'false','moscowtv-reduce-motion':'true','moscowtv-seek-step':'15'}))assert.equal(await pb.evaluate(k=>localStorage.getItem(k),k),v,'restore '+k);
 const restored=await pb.evaluate(()=>fetch('/api/state').then(r=>r.json()));assert.equal(restored.history[0].currentTime,60);assert.equal(restored.watchlist.length,1);
 assert(await pb.evaluate(()=>document.documentElement.classList.contains('reduce-motion')&&document.documentElement.classList.contains('spotlight-paused')));
 await pb.reload();await waitBound(pb);assert.equal(await pb.locator('[data-token-copy]').count(),0);assert.equal(await pb.locator('#cache-token-input').getAttribute('aria-readonly'),'true');assert.equal(await pb.locator('[data-token-set]').isDisabled(),true);
 await toggle(pb,'moscowtv-resume-playback',true);await toggle(pb,'moscowtv-save-history',true);await toggle(pb,'moscowtv-spotlight-autoplay',true);await toggle(pb,'moscowtv-reduce-motion',false);await pb.locator('[data-site-pref="moscowtv-seek-step"]').selectOption('30');await pb.evaluate(()=>window.KozuCacheToken.flush());
 await pa.bringToFront();await pa.evaluate(()=>window.KozuCacheToken.pull());
 await pa.waitForFunction(()=>localStorage.getItem('moscowtv-seek-step')==='30');
 for(const [k,v] of Object.entries({'moscowtv-resume-playback':'true','moscowtv-save-history':'true','moscowtv-spotlight-autoplay':'true','moscowtv-reduce-motion':'false','moscowtv-seek-step':'30'}))assert.equal(await pa.evaluate(k=>localStorage.getItem(k),k),v,'pull '+k);
 assert.equal(await pa.locator('[data-site-pref="moscowtv-seek-step"]').inputValue(),'30');assert.equal(await pa.locator('[data-site-pref="moscowtv-reduce-motion"]').isChecked(),false);assert.equal(await pa.evaluate(()=>document.documentElement.classList.contains('reduce-motion')),false);
 await pb.bringToFront();await pb.locator('[data-reset-settings]').click();await pb.evaluate(()=>window.KozuCacheToken.flush());
 const persisted=await pb.evaluate(()=>Promise.all([fetch('/api/state').then(r=>r.json()),fetch('/api/cache-token/status').then(r=>r.json())]));assert.equal(persisted[0].history.length,1);assert.equal(persisted[0].watchlist.length,1);assert.equal(persisted[1].bound,true);
 for(const k of ['moscowtv-resume-playback','moscowtv-save-history','moscowtv-spotlight-autoplay','moscowtv-reduce-motion','moscowtv-seek-step'])assert.equal(await pb.evaluate(k=>localStorage.getItem(k),k),null,'reset '+k);
 await pa.bringToFront();await pa.evaluate(()=>window.KozuCacheToken.pull());await pa.waitForFunction(()=>localStorage.getItem('moscowtv-seek-step')===null);assert.equal(await pa.locator('[data-site-pref="moscowtv-seek-step"]').inputValue(),'10');
 await a.close();await b.close();console.log('PASS token generate, restore, reload-lock, two-way sync and reset of all new settings');

 // Randomized Browse rows and both menu/dropdown exclusions.
 const cat=await browser.newContext({viewport:{width:1200,height:900}});await mockApi(cat);
 await cat.addInitScript(()=>{const f=window.setInterval;window.setInterval=function(cb,ms,...args){if(ms===6500)window.__testCarousel=cb;return f(cb,ms,...args)}});
 const pc=await cat.newPage();watchErrors(pc,'browse');await ready(pc,'/browse');await pc.waitForSelector('.hero');
 const firstTitle=await pc.locator('.hero h1').innerText();await pc.evaluate(()=>window.__testCarousel());assert.notEqual(await pc.locator('.hero h1').innerText(),firstTitle,'carousel advances');
 await pc.evaluate(()=>{localStorage.setItem('moscowtv-spotlight-autoplay','false');window.dispatchEvent(new CustomEvent('kozutv-preferences-restored'))});
 const pausedTitle=await pc.locator('.hero h1').innerText();await pc.evaluate(()=>window.__testCarousel());assert.equal(await pc.locator('.hero h1').innerText(),pausedTitle,'carousel paused');
 assert(await pc.evaluate(()=>document.documentElement.classList.contains('spotlight-paused')));await pc.locator('.dots [data-slide="0"]').click();assert.equal(await pc.locator('.hero h1').innerText(),firstTitle,'manual spotlight selection');
 for(let i=0;i<20;i++){
  const count=await pc.locator('#browse-categories > .category-row').count();if(count>=24)break;
  await pc.locator('#browse-sentinel').scrollIntoViewIfNeeded();await pc.waitForFunction(count=>document.querySelectorAll('#browse-categories > .category-row').length>count,count,{timeout:6000});
 }
 const rows=await pc.locator('#browse-categories > .category-row').evaluateAll(els=>els.slice(0,24).map(e=>({name:e.dataset.name,kind:e.dataset.kind})));
 assert.equal(rows.length,24);assert.equal(new Set(rows.map(x=>x.name)).size,24);
 for(const name of ['Hindi Dubbed','Tamil Dubbed','Telugu Dubbed','New in 2026']){
  assert(rows.some(r=>r.name===name&&r.kind==='collection'),name+' randomized row');
  const direct=pc.locator(`.category-row[data-name="${name}"]`);await direct.scrollIntoViewIfNeeded();await direct.locator('.category-heading').waitFor({timeout:5000});
  const href=await direct.locator('.category-see-all').getAttribute('href');assert.equal(new URL(href,BASE).searchParams.get('collection'),name);
  if(name.endsWith('Dubbed'))assert((await direct.locator('h2 svg').innerHTML()).includes('M3 14v-3a9'));
 }
 await pc.goto(BASE+'/browse?collection=Hindi%20Dubbed',{waitUntil:'domcontentloaded'});await pc.waitForSelector('h1.section-title');assert.equal(await pc.locator('h1.section-title').innerText(),'Hindi Dubbed');assert.equal(await pc.getByText(/legacy unwanted notice/i).count(),0);
 await pc.goto(BASE+'/browse/anime/424242',{waitUntil:'domcontentloaded'});await pc.waitForSelector('.detail');assert.equal(await pc.locator('.catalog-note').count(),0);assert.equal(await pc.getByText(/legacy unwanted notice/i).count(),0);
 await cat.close();console.log('PASS all 24 shuffled first-cycle rows, collection navigation/icons, no legacy notices, carousel and manual selection');

 // Different deterministic random streams must yield different first rows.
 async function seededRows(seed){
  const context=await browser.newContext({viewport:{width:1200,height:900}});await mockApi(context);
  await context.addInitScript(initial=>{let n=initial;Math.random=()=>((n=(1664525*n+1013904223)>>>0)/4294967296)},seed);
  const page=await context.newPage();await ready(page,'/browse');await page.waitForSelector('.category-row');
  const names=await page.locator('.category-row').evaluateAll(els=>els.slice(0,2).map(el=>el.dataset.name));await context.close();return names;
 }
 assert.notDeepEqual(await seededRows(23),await seededRows(1234),'Browse order changes with random input');
 // Empty categories eventually stop instead of repeatedly appending forever.
 const empty=await browser.newContext({viewport:{width:1200,height:900}});let emptyRequests=0;
 await empty.route('**/api/**',route=>{
  const u=new URL(route.request().url());
  if(u.pathname==='/api/browse')return json(route,{items,spotlight:items.slice(0,3)});
  if(['/api/genre','/api/collection'].includes(u.pathname)){emptyRequests++;return json(route,{items:[]})}
  return route.continue();
 });
 const pe=await empty.newPage();await ready(pe,'/browse');await pe.waitForSelector('#browse-sentinel');
 for(let i=0;i<10;i++){if(await pe.locator('#browse-sentinel').textContent()==='You are all caught up.')break;await pe.locator('#browse-sentinel').scrollIntoViewIfNeeded();await pe.waitForTimeout(250)}
 await pe.waitForFunction(()=>document.querySelector('#browse-sentinel').textContent==='You are all caught up.',{timeout:6000});
 const stoppedAt=emptyRequests;await pe.waitForTimeout(500);assert.equal(emptyRequests,stoppedAt);assert(stoppedAt>=8&&stoppedAt<=24);await empty.close();
 console.log('PASS seeded shuffle and bounded empty-category exhaustion');

 // A real Video.js player with a local 180-second WebM exercises resume, keyboard,
 // pointer double-taps, history posts, episode changes and catalog warning.
 const c=await browser.newContext({viewport:{width:1200,height:900}});await mockApi(c);const p=await c.newPage();watchErrors(p,'player');let posts=0;
 p.on('request',r=>{if(r.url().includes('/api/history')&&r.method()==='POST')posts++});await ready(p);
 await toggle(p,'moscowtv-autoplay',false);await toggle(p,'moscowtv-save-history',false);await toggle(p,'moscowtv-resume-playback',false);await toggle(p,'moscowtv-reduce-motion',true);await p.locator('[data-site-pref="moscowtv-seek-step"]').selectOption('15');
 await p.evaluate(async item=>fetch('/api/history',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...item,episode:1,season:1,currentTime:60,duration:180})}),item);posts=0;
 await ready(p,'/watch/anime/424242?episode=1&lang=sub');await loadVideo(p);assert.equal(await p.locator('.catalog-note').count(),0);assert.equal(await p.getByText(/legacy unwanted notice/i).count(),0);
 let time=await p.evaluate(()=>window.videojs.getPlayer('moscowtv-video').currentTime());assert(time<2,'resume off should begin at zero, got '+time);
 await seekTo(p,50);await p.locator('#watch-title').click();await p.keyboard.press('ArrowRight');
 const seekInfo=await p.evaluate(()=>{const e=document.querySelector('.mp-tap-seek[data-side="right"]');return {text:e.textContent.trim(),opacity:getComputedStyle(e).opacity,animations:e.getAnimations().length, el:e.outerHTML,html:document.documentElement.className,animation:getComputedStyle(e).animationName}});assert.equal(seekInfo.text,'15s');assert.equal(seekInfo.opacity,'1');assert.equal(seekInfo.animations,0,'WAAPI seek animation disabled');await expectTime(p,65);
 await p.waitForTimeout(750);await seekTo(p,50);await p.keyboard.press('j');await expectTime(p,35);
 // Validate the other interval and fallback values with the actual player.
 await p.evaluate(()=>localStorage.setItem('moscowtv-seek-step','5'));await p.waitForTimeout(750);await seekTo(p,50);await p.keyboard.press('l');await expectTime(p,55);
 await p.evaluate(()=>localStorage.setItem('moscowtv-seek-step','bogus'));await p.waitForTimeout(750);await seekTo(p,50);await p.keyboard.press('l');await expectTime(p,60);
 await p.evaluate(()=>localStorage.setItem('moscowtv-seek-step','15'));
 await p.waitForTimeout(750);await seekTo(p,50);const rect=await p.locator('#player .video-js').boundingBox();await p.mouse.click(rect.x+rect.width*.8,rect.y+rect.height*.5,{clickCount:2,delay:45});await expectTime(p,65);
 await p.evaluate(()=>{localStorage.setItem('moscowtv-autonext','false');const pl=videojs.getPlayer('moscowtv-video');pl.trigger('playing');pl.trigger('timeupdate');pl.trigger('ended')});await p.waitForTimeout(350);assert.equal(posts,0,'history disabled for player events');
 // This also exercises the old-episode snapshot path, which must not post.
 await p.evaluate(()=>videojs.getPlayer('moscowtv-video').megaUI.showControls());await p.locator('.mp-next-ep').click({force:true});await p.waitForURL(/episode=2/);await loadVideo(p);await p.waitForTimeout(350);assert.equal(posts,0,'history disabled while switching episodes');
 let st=await p.evaluate(()=>fetch('/api/state').then(r=>r.json()));assert.equal(st.history[0].currentTime,60);assert.equal(st.history[0].episode,1);
 let confirmation='';p.on('dialog',async d=>{confirmation=d.message();await d.dismiss()});await p.evaluate(()=>videojs.getPlayer('moscowtv-video').megaUI.openSettings('audio'));await p.locator('[data-audio-choice="dub"]').click();await p.waitForFunction(()=>!document.querySelector('.mp-settings')||document.querySelector('.mp-settings').hidden);await p.waitForTimeout(250);assert.match(confirmation,/different episode orders/i,'catalog confirmation retained');assert.match(p.url(),/episode=2/);
 // Switch resume/history back on through the viewer settings, retaining the old 60-second position.
 await ready(p);await toggle(p,'moscowtv-save-history',true);await toggle(p,'moscowtv-resume-playback',true);
 await ready(p,'/watch/anime/424242?episode=1&lang=sub');await loadVideo(p);await p.waitForFunction(()=>videojs.getPlayer('moscowtv-video').currentTime()>59,{timeout:5000});
 await p.evaluate(()=>videojs.getPlayer('moscowtv-video').trigger('playing'));await p.waitForFunction(()=>true);await p.waitForTimeout(400);assert(posts>0,'history resumes writing when enabled');
 await c.close();console.log('PASS real player resume off/on, 15-second keyboard & double-click seeks, reduced-motion feedback, history gating & catalog confirmation');

 // Mobile touch double-tap uses the selected interval, not the desktop default.
 const m=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await mockApi(m);const pm=await m.newPage();watchErrors(pm,'mobile player');await ready(pm);await toggle(pm,'moscowtv-autoplay',false);await pm.locator('[data-site-pref="moscowtv-seek-step"]').selectOption('30');await ready(pm,'/watch/anime/424242?episode=1&lang=sub');await loadVideo(pm);await seekTo(pm,50);
 const mr=await pm.locator('#player .video-js').boundingBox();await pm.touchscreen.tap(mr.x+mr.width*.8,mr.y+mr.height*.5);await pm.touchscreen.tap(mr.x+mr.width*.8,mr.y+mr.height*.5);await expectTime(pm,80);assert.equal((await pm.locator('.mp-tap-seek[data-side="right"] span').innerText()).trim(),'30s');await m.close();
 console.log('PASS mobile 30-second double-tap');
 assert.deepEqual(errors,[],'no uncaught page errors');console.log('ALL V5.4.11 QA PASSED');
}finally{
 if(browser)await browser.close();
 if(child&&child.exitCode===null){const ended=once(child,'exit').catch(()=>{});child.kill('SIGTERM');await Promise.race([ended,new Promise(resolve=>setTimeout(resolve,2000))]);if(child.exitCode===null)child.kill('SIGKILL')}
 fs.rmSync(work,{recursive:true,force:true});
}
