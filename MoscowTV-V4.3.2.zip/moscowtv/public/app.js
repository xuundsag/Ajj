const app=document.querySelector('#app'),search=document.querySelector('#search');let items=[],suggestions=[],genreRows={},activeGenres=[],genreQueue=[],continueItems=[],slide=0,detail=null,season=1,episode=1,provider='default',searchTimer,lastProgressSent=0,savedKeys=new Set(),animeEpisodeLists={detail:null,watch:null},videoPlayer=null,playGeneration=0,lang='sub';
const siteFooter=document.querySelector('footer');
function syncFooter(){let loading=app.firstElementChild?.classList.contains('loading');document.body.classList.toggle('route-ready',app.childElementCount>0&&!loading)}
new MutationObserver(syncFooter).observe(app,{childList:true});syncFooter();
let playerAssetsPromise=null,detailWarmTimer=0;const jikanClientCache=new Map();
function loadPlayerAssets(){if(window.videojs&&window.MegaPlayUI)return Promise.resolve();if(!playerAssetsPromise)playerAssetsPromise=(async()=>{for(let src of ['/vendor/video.min.js','/megaplay-controls.js?v=4.3.4'])await new Promise((resolve,reject)=>{let script=document.createElement('script');script.src=src;script.async=true;script.onload=resolve;script.onerror=()=>{script.remove();reject(Error('The player assets could not be loaded.'))};document.head.append(script)})})().catch(error=>{playerAssetsPromise=null;throw error});return playerAssetsPromise}
const isFeature=x=>x?.type==='movie'||x?.isMovie||x?.format==='MOVIE';const short=(s,n)=>{let t=String(s||'').replace(/\s+/g,' ').trim();return t.length>n?t.slice(0,n).replace(/\s+\S*$/,'')+'…':t};const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const url=(type,id)=>`/browse/${type}/${id}`;const responseJSON=async r=>{let text=await r.text(),d;try{d=JSON.parse(text)}catch{throw Error(r.ok?'The service returned an invalid response.':`Request failed (${r.status}).`)}if(!r.ok)throw Error(d.error||'Request failed');return d};const get=async p=>responseJSON(await fetch(p));const post=async(p,body)=>responseJSON(await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}));const params=()=>new URLSearchParams(location.search);const safeImage=s=>/^https:\/\//.test(s||'')?esc(s):'';
const catalogGenres=['Action','Adventure','Animation','Comedy','Crime','Documentary','Drama','Family','Fantasy','Horror','Mecha','Music','Mystery','Psychological','Romance','Sci-Fi','Slice of Life','Sports','Supernatural','Thriller'];
const spotlightPortraits={'anime:21':'/images/spotlight/anime-21.jpg','movie:1263337':'/images/spotlight/movie-1263337.jpg','anime:61607':'/images/spotlight/anime-61607.jpg','movie:1423191':'/images/spotlight/movie-1423191.jpg','tv:289517':'/images/spotlight/tv-289517.jpg','movie:1294189':'/images/spotlight/movie-1294189.jpg'};
function disposeVideo(){clearTimeout(detailWarmTimer);playGeneration++;if(videoPlayer){try{videoPlayer.dispose()}catch{}videoPlayer=null}}


function nav(path){disposeVideo();history.pushState({},'',path);search.value='';document.querySelector('.searchbox')?.classList.remove('open');render();window.scrollTo(0,0)}
function card(x){return `<article class="card" data-open="${esc(url(x.type,x.id))}"><div class="poster">${x.poster?`<img loading="lazy" src="${safeImage(x.poster)}" alt="${esc(x.title)}">`:''}<span class="badge">${x.type==='anime'?(x.isMovie?'ANIME MOVIE':'ANIME'):x.type==='tv'?'WEB SERIES':'MOVIE'}</span>${x.rating?`<span class="rating">${ico('star')}${esc(x.rating)}</span>`:''}</div><h3 title="${esc(x.title)}">${esc(x.title)}</h3><p>${esc(x.year||'New')} &nbsp;·&nbsp; ${x.type==='anime'?(x.isMovie?'Anime Movie':'Anime Series'):x.type==='tv'?'TV Series':'Movie'}</p></article>`}
function grid(data){return data.length?`<div class="grid">${data.map(card).join('')}</div>`:'<div class="empty">No titles found.</div>'}
function hero(data){
 let x=data[slide%data.length];if(!x)return '';let feature=isFeature(x),key=x.type+':'+x.id,saved=savedKeys.has(key),watch=`/browse/watch/${x.type}/${x.id}?season=1&episode=1`,art=safeImage(x.backdrop||x.poster),mobileArt=spotlightPortraits[key]||safeImage(x.poster||x.backdrop);
 return `<section class="hero" data-hero-details="${url(x.type,x.id)}" role="link" tabindex="0" aria-label="View ${esc(x.title)} details"><div class="hero-image" style="background-image:url('${art}')"></div><img class="hero-image-mobile" src="${mobileArt}" alt="" fetchpriority="high" decoding="async"><div class="container hero-content"><div class="hero-copy"><h1>${esc(x.title)}</h1><div class="meta hero-meta"><span>${ico(x.type==='anime'?(feature?'film':'tv'):x.type==='tv'?'tv':'film')}${x.type==='anime'?(feature?'Anime Movie':'Anime'):x.type==='tv'?'Web Series':'Movie'}</span><span>${ico('calendar')}${esc(x.year||'')}</span><span class="quality">HD</span>${x.rating?`<span>${ico('star')}${esc(x.rating)}</span>`:''}</div><p class="description">${esc(short(x.description||'',220))}</p><div class="hero-actions"><button class="btn hero-watch" data-open="${watch}">${ico('play')}<span>Start Watching${feature?'':' E1'}</span></button><button class="hero-save ${saved?'saved':''}" data-hero-save="${key}" aria-label="${saved?'Remove from':'Add to'} Watchlist" title="Watchlist">${ico('bookmark')}</button></div></div><div class="dots">${data.slice(0,6).map((_,i)=>`<button data-slide="${i}" class="${i===slide?'active':''}" aria-label="Spotlight ${i+1}"></button>`).join('')}</div></div></section>`;
}
async function catalog(isSearch=false){
 let term=search.value.trim(),genre=isSearch?null:params().get('genre');app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let endpoint=isSearch?`/api/search-all?q=${encodeURIComponent(term)}`:genre?`/api/genre?name=${encodeURIComponent(genre)}`:'/api/browse',[d,state]=await Promise.all([get(endpoint),get('/api/state')]);
  items=d.items||[];suggestions=isSearch||genre?[]:d.suggestions||[];savedKeys=new Set((state.watchlist||[]).map(x=>x.type+':'+x.id));continueItems=isSearch||genre?[]:(state.history||[]).slice(0,8);genreRows={};genreQueue=[...catalogGenres].sort(()=>Math.random()-.5);activeGenres=genreQueue.splice(0,3);slide=0;
  let filtered=isSearch||Boolean(genre);drawCatalog(filtered,genre?genre:term);if(!filtered)loadGenreRows();
 }catch(e){app.innerHTML=`<div class="container content"><div class="empty"><h2>Catalog unavailable</h2><p class="error">${esc(e.message)}</p><button class="btn" data-retry>Try again</button></div></div>`}
}
const genreIcons={Action:'swords',Adventure:'compass',Animation:'sparkles',Comedy:'laugh',Crime:'shield',Documentary:'film',Drama:'theater',Family:'users',Fantasy:'wand',Horror:'ghost',Mecha:'cpu',Music:'music',Mystery:'search',Psychological:'brain',Romance:'heart','Sci-Fi':'rocket','Slice of Life':'coffee',Sports:'trophy',Supernatural:'sparkles',Thriller:'zap'};
function sectionTitle(title,icon='sparkles',tag='h2'){return `<${tag} class="section-title"><span class="section-icon">${ico(icon)}</span><span>${esc(title)}</span></${tag}>`}
async function loadGenreRows(names=activeGenres){names=[...names];await Promise.all(names.map(async name=>{try{let d=await get('/api/genre?name='+encodeURIComponent(name));if(location.pathname!=='/browse'||params().has('genre')||search.value.trim())return;genreRows[name]=d.items||[];let slot=document.querySelector('[data-genre="'+name+'"]');if(slot)slot.innerHTML=genreRows[name].length?sectionTitle(name,genreIcons[name])+grid(genreRows[name]):''}catch{}}))}
const carousel=setInterval(()=>{if(location.pathname!=='/browse'||params().has('genre')||search.value.trim()||document.hidden||!items.length)return;let data=items.filter(x=>x.poster&&x.title&&x.backdrop).slice(0,6);if(!data.length)return;slide=(slide+1)%data.length;let current=document.querySelector('.hero');if(current)current.outerHTML=hero(data)},6500);
function drawCatalog(isSearch=false,term=''){
 let data=items.filter(x=>x.poster&&x.title);
 let continueSection=!isSearch&&continueItems.length?`<section class="continue-section home-continue">${sectionTitle('Continue Watching','history')}${continueGrid(continueItems)}</section>`:'',moreCategories=!isSearch&&genreQueue.length?`<div class="category-more"><button class="category-more-button" data-more-categories aria-label="Show more categories">${ico('plus')}<span>Show more</span></button></div>`:'';
 app.innerHTML=`${!isSearch&&data.length?hero(data.filter(x=>x.backdrop).slice(0,6)):''}<div class="container content">${continueSection}${sectionTitle(isSearch?`Results for “${term}”`:'Trending Now',isSearch?'search':'flame')}${grid(data)}${!isSearch&&suggestions.length?`<section class="suggestions">${sectionTitle('Suggested for you','sparkles')}${grid(suggestions)}</section>`:''}${!isSearch?activeGenres.map(name=>`<section class="genre-section" data-genre="${name}"></section>`).join(''):''}${moreCategories}</div>`;
}
const icons={
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
 bookmark:'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
 autoplay:'<path d="M21 12a9 9 0 1 1-2.64-6.36L21 8"/><path d="M21 3v5h-5"/>',
 autonext:'<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
 autoskip:'<path d="m3 5 8 7-8 7z"/><path d="m13 5 8 7-8 7z"/>',
 light:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.66 6.34l1.41-1.41"/>',
 prev:'<path d="M19 20 9 12l10-8z"/><path d="M5 19V5"/>',
 next:'<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
 expand:'<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 check:'<path d="m5 12 4 4L19 6"/>',
 'bookmark-plus':'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/><path d="M12 7v6M9 10h6"/>',
 'bookmark-check':'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/><path d="m9 10 2 2 4-4"/>',
 star:'<path d="m12 2 3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01z"/>',
 calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
 tv:'<rect x="2" y="7" width="20" height="13" rx="2"/><path d="m17 2-5 5-5-5"/>',
 film:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4"/>',
 play:'<path d="m8 5 11 7-11 7z"/>',
 flame:'<path d="M12 22c4.4 0 8-3.2 8-7.5 0-2.2-1.1-4.2-3-6.5.1 2-1 3.5-2.2 4.2.3-3.8-1.7-7.2-5.3-10.2.2 3.5-1.8 5.7-3.3 7.6C5.1 11.1 4 12.8 4 14.5 4 18.8 7.6 22 12 22Z"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>',
 compass:'<circle cx="12" cy="12" r="9"/><path d="m16 8-2.5 5.5L8 16l2.5-5.5Z"/>',
 sparkles:'<path d="m12 3 1.3 3.7L17 8l-3.7 1.3L12 13l-1.3-3.7L7 8l3.7-1.3ZM5 14l.9 2.1L8 17l-2.1.9L5 20l-.9-2.1L2 17l2.1-.9ZM18 14l.9 2.1L21 17l-2.1.9L18 20l-.9-2.1L15 17l2.1-.9Z"/>',
 laugh:'<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 3 4 3 4-3 4-3ZM9 9h.01M15 9h.01"/>',
 theater:'<path d="M4 4h16v6a8 8 0 0 1-16 0ZM8 9h.01M16 9h.01M8 13c2 1.5 6 1.5 8 0M12 18v3M8 21h8"/>',
 wand:'<path d="m15 4 5 5L8 21H3v-5ZM14 6l4 4M6 3v3M4.5 4.5h3M20 15v4M18 17h4"/>',
 ghost:'<path d="M5 21V10a7 7 0 0 1 14 0v11l-2.5-2-2.3 2-2.2-2-2.2 2-2.3-2ZM9 10h.01M15 10h.01"/>',
 zap:'<path d="M13 2 4 14h7l-1 8 9-12h-7Z"/>',
 swords:'<path d="m14.5 4.5 5-1-1 5L8 19l-3 1 1-3ZM14 9l3 3M4 4l16 16M4 9l-1-5 5 1 11 11"/>',
 shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
 users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
 cpu:'<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
 music:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
 brain:'<path d="M12 5a3 3 0 1 0-6 .1 4 4 0 0 0-2.5 5.8 4 4 0 0 0 .5 6.6A4 4 0 1 0 12 18ZM12 5a3 3 0 1 1 6 .1 4 4 0 0 1 2.5 5.8 4 4 0 0 1-.5 6.6A4 4 0 1 1 12 18ZM12 5v13"/>',
 rocket:'<path d="M14 4c3-3 7-2 7-2s1 4-2 7l-7 7-5-5Z"/><path d="m7 11-4 1 3 3M12 16l-1 4 3-3"/><circle cx="16" cy="8" r="1"/><path d="M7 17c-2 1-3 3-3 5 2 0 4-1 5-3"/>',
 coffee:'<path d="M17 8h1a4 4 0 1 1 0 8h-1M3 8h14v7a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4ZM6 2v2M10 2v2M14 2v2"/>',
 trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0ZM7 6H4v2a4 4 0 0 0 4 4M17 6h3v2a4 4 0 0 1-4 4"/>',
 history:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l3 2"/>',
 sliders:'<path d="M4 6h10M18 6h2M4 12h3M11 12h9M4 18h8M16 18h4"/><circle cx="16" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="14" cy="18" r="2"/>',
 shuffle:'<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 episodes:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 9h8M8 13h5"/>',
 home:'<path d="m3 11 9-8 9 8v9a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>'
};
function ico(n,extra=''){return `<svg class="ui-icon ${extra}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${icons[n]||''}</svg>`}
const playerIcons={report:'<path d="M10.3 3.7 2.5 18a2 2 0 0 0 1.8 3h15.4a2 2 0 0 0 1.8-3L13.7 3.7a2 2 0 0 0-3.4 0z"/><path d="M12 9v4m0 4h.01"/>',bookmark:'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>','bookmark-filled':'<path fill="currentColor" d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',bulb:'<path d="M9 18h6M10 22h4M8.5 14.5A6 6 0 1 1 15.5 14.5C14.5 15.2 14 16 14 18h-4c0-2-.5-2.8-1.5-3.5z"/>',autoplay:'<path d="M5 4v5h5M5 9a8 8 0 1 1-1 5"/><path d="m10 9 5 3-5 3z"/>',autonext:'<path d="M4 6v12l9-6zM17 6v12"/>',light:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',prev:'<path d="M18 5 8 12l10 7zM5 5v14"/>',next:'<path d="m6 5 10 7-10 7zM19 5v14"/>'};
function playerIco(n){return `<svg class="control-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${playerIcons[n]||''}</svg>`}
function animeSeasonSelect(d,x,mode){if(!d.seasons||d.seasons.length<2)return '';let id=mode==='detail'?'detail-anime-season':'anime-season';return `<select class="season-select" id="${id}" aria-label="Anime season">${d.seasons.map(s=>`<option value="${s.id}" ${s.id===x.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`}
function animeEpisodeRow(x,id,active){
 let art=x.still||detail?.item.backdrop||detail?.item.poster;
 return `<button class="episode-row ${x.number===active?'selected':''}" data-open="/browse/watch/anime/${id}?episode=${x.number}&lang=${lang}&provider=${provider}">${art?`<img loading="lazy" referrerpolicy="no-referrer" src="${safeImage(art)}" alt="">`:''}<span><strong>${x.number}. ${esc(x.title||`Episode ${x.number}`)}</strong>${x.description?`<small>${esc(short(x.description,190))}</small>`:''}</span></button>`;
}
async function jikanFetchJSON(url,timeout=3200){
 let ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeout);
 try{let r=await fetch(url,{signal:ctrl.signal});if(!r.ok)return null;return await r.json()}catch{return null}finally{clearTimeout(timer)}
}
async function enrichEpisodesFromJikan(id,page,state,mode){
 let pageData=state.pages.get(page);if(!pageData?.episodes?.length)return;
 let jikanPage=Math.max(1,Math.floor(((page-1)*20)/100)+1),cacheKey=`${id}:${jikanPage}`;
 let entry=jikanClientCache.get(cacheKey);
 if(!entry){
  entry=(async()=>{
   let [epRes,vidRes]=await Promise.all([
    jikanFetchJSON(`https://api.jikan.moe/v4/anime/${id}/episodes?page=${jikanPage}`),
    jikanFetchJSON(`https://api.jikan.moe/v4/anime/${id}/videos/episodes?page=1`)
   ]);
   let byNum=new Map();
   for(let e of epRes?.data||[]){
    let n=Number(e.mal_id);if(!Number.isFinite(n)||n<=0)continue;
    byNum.set(n,{title:e.title||e.title_romanji||e.title_japanese||'',description:e.synopsis||'',still:''});
   }
   for(let v of vidRes?.data||[]){
    let n=Number(v.mal_id);if(!Number.isFinite(n)||n<=0)continue;
    let cur=byNum.get(n)||{title:'',description:'',still:''},img=v.images?.jpg?.large_image_url||v.images?.jpg?.image_url||'';
    byNum.set(n,{title:cur.title||v.title||'',description:cur.description||'',still:img||cur.still});
   }
   return byNum;
  })();
  jikanClientCache.set(cacheKey,entry);
 }
 let byNum=await entry;if(!byNum?.size||animeEpisodeLists[mode]!==state)return;
 let changed=false,missingDesc=[];
 for(let ep of pageData.episodes){
  let j=byNum.get(Number(ep.number));if(!j)continue;
  if(j.title&&(!ep.title||/^Episode\s+\d+$/i.test(ep.title))){ep.title=j.title;changed=true}
  if(j.still&&(!ep.still||ep.still===detail?.item?.backdrop||ep.still===detail?.item?.poster)){ep.still=j.still;changed=true}
  if(j.description&&!ep.description){ep.description=j.description;changed=true}
  if(!ep.description)missingDesc.push(ep);
 }
 if(changed&&animeEpisodeLists[mode]===state)renderAnimeEpisodes(mode);
 for(let ep of missingDesc.slice(0,3)){
  if(animeEpisodeLists[mode]!==state)break;
  let full=await jikanFetchJSON(`https://api.jikan.moe/v4/anime/${id}/episodes/${ep.number}`,2600);
  let syn=String(full?.data?.synopsis||'').replace(/\s*\[Written by MAL Rewrite\]\s*$/i,'').trim();
  if(syn&&!ep.description){ep.description=syn;if(animeEpisodeLists[mode]===state)renderAnimeEpisodes(mode)}
 }
}
function renderAnimeEpisodes(mode){
 let state=animeEpisodeLists[mode],container=document.querySelector(`#${mode}-anime-episodes`);if(!state||!container)return;
 let pages=[...state.pages.keys()].sort((a,b)=>a-b),episodes=new Map();
 for(let page of pages)for(let x of state.pages.get(page).episodes||[])if(!state.startFrom||x.number>=state.startFrom)episodes.set(x.number,x);
 let last=pages.at(-1)||1,more=state.pages.get(last)?.hasNext,button=(page,label)=>`<div class="anime-pagination"><button class="btn secondary" data-anime-page="${page}" data-anime-mode="${mode}">${label}</button></div>`;
 container.innerHTML=state.error?'<div class="empty">Episodes are unavailable right now.</div>':`<div class="episode-detail-list anime-episode-list">${[...episodes.values()].sort((a,b)=>a.number-b.number).map(x=>animeEpisodeRow(x,state.id,state.active)).join('')||'<div class="empty">No episodes listed.</div>'}</div>${more?button(last+1,'Show more'):''}`;
}
async function loadAnimeEpisodes(id,mode,page=1,active=0,reset=false,startFrom=0){
 let container=document.querySelector(`#${mode}-anime-episodes`);if(!container)return;let state=animeEpisodeLists[mode];
 if(reset||!state||state.id!==id){state={id,pages:new Map(),active,error:'',loading:false,startFrom};animeEpisodeLists[mode]=state;container.innerHTML='<div class="loading">Loading episodes…</div>'}
 if(state.loading)return;state.loading=true;state.error='';let clicked=container.querySelector(`[data-anime-page="${page}"]`);if(clicked){clicked.disabled=true;clicked.innerHTML='<span class="button-loader" aria-label="Loading"></span>';clicked.classList.add('is-loading')}
 try{let d=await get(`/api/anime-episodes?id=${id}&page=${page}`);if(animeEpisodeLists[mode]!==state)return;state.pages.set(page,d);state.active=active||state.active;enrichEpisodesFromJikan(id,page,state,mode).catch(()=>{})}
 catch(e){state.error=e.message;if(reset)state.pages.clear()}
 finally{state.loading=false;if(animeEpisodeLists[mode]===state)renderAnimeEpisodes(mode)}
}
function watchlistButton(){return `<button class="btn secondary" data-save>${ico('plus')}<span class="desktop-action">Add to Watchlist</span><span class="mobile-action">Add</span></button>`}
function settingControl(key,label){return `<button data-setting="${key}" aria-label="${label}"><b class="setting-check">✓</b><span>${label}</span><b class="toggle-result"></b></button>`}
function episodeTargets(){
 if(!detail||isFeature(detail.item))return {prev:null,next:null};let x=detail.item;
 if(x.type==='anime'){
  let seasons=Array.isArray(detail.seasons)?detail.seasons:[],index=seasons.findIndex(s=>String(s.id)===String(x.id)),count=Math.max(1,Number(x.episodes)||1),own=n=>({type:'anime',id:x.id,season:1,episode:n});
  return {prev:episode>1?own(episode-1):index>0?{type:'anime',id:seasons[index-1].id,season:1,episode:Math.max(1,Number(seasons[index-1].episodes)||1)}:null,next:episode<count?own(episode+1):index>=0&&seasons[index+1]?{type:'anime',id:seasons[index+1].id,season:1,episode:1}:null};
 }
 let seasons=(detail.seasons||[]).filter(s=>Number(s.episodes)>0).sort((a,b)=>a.number-b.number),index=seasons.findIndex(s=>Number(s.number)===Number(season)),current=seasons[index],count=Math.max(1,Number(current?.episodes)||1),own=n=>({type:'tv',id:x.id,season,episode:n});
 return {prev:episode>1?own(episode-1):index>0?{type:'tv',id:x.id,season:seasons[index-1].number,episode:Number(seasons[index-1].episodes)}:null,next:episode<count?own(episode+1):index>=0&&seasons[index+1]?{type:'tv',id:x.id,season:seasons[index+1].number,episode:1}:null};
}
function timeAgo(timestamp){let seconds=Math.round((Number(timestamp)-Date.now())/1000),abs=Math.abs(seconds),unit=abs>=86400?'day':abs>=3600?'hour':abs>=60?'minute':'second',value=Math.round(seconds/(unit==='day'?86400:unit==='hour'?3600:unit==='minute'?60:1)),r=new Intl.RelativeTimeFormat('en',{numeric:'auto'});return r.format(value,unit)}
async function details(type,id){
 app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let d=await get(`/api/detail?type=${type}&id=${id}`);detail=d;let x=d.item,resumeEpisode=0,state=await get('/api/state');savedKeys=new Set((state.watchlist||[]).map(i=>i.type+':'+i.id));
  if(type==='anime'&&!x.upcoming){let seen=state.history.find(h=>h.type==='anime'&&h.id===x.id);if(seen){resumeEpisode=Math.max(1,Number(seen.episode)||1);if(x.episodes)resumeEpisode=Math.min(resumeEpisode,x.episodes)}}
  document.title=`${x.title} — MoscowTV`;let watch=`/browse/watch/${type}/${id}${resumeEpisode?`?episode=${resumeEpisode}`:''}`,watchLabel=resumeEpisode?'Continue':'Watch Now';
  let showEpisodes=!x.upcoming&&!isFeature(x),actions=`<div class="actions">${!x.upcoming?`<button class="btn" data-open="${watch}">${ico('play')}<span>${watchLabel}</span></button>`:''}${watchlistButton()}</div>`;
  app.innerHTML=`<div class="container content detail"><div class="detail-layout"><img class="detail-poster" src="${safeImage(x.poster)}" alt="${esc(x.title)}"><div class="detail-heading"><h1>${esc(x.title)}</h1><div class="meta"><span>${ico('star')}${esc(x.rating||'N/A')}</span><span class="quality">HD</span>${x.upcoming?'<span class="upcoming-badge">Upcoming</span>':showEpisodes&&x.episodes?`<span>${x.episodes} episodes</span>`:''}</div></div><div class="detail-body"><div class="description detail-description" data-description-toggle role="button" tabindex="0" aria-expanded="false">${esc(x.description||'No description available.')}</div><div class="chips">${(x.genres||[]).map(g=>`<span class="chip">${esc(g)}</span>`).join('')}</div>${actions}</div></div>${type==='anime'&&showEpisodes?`<section class="season-section">${sectionTitle(d.seasons.length>1?'Seasons & Episodes':'Episodes','episodes')}${animeSeasonSelect(d,x,'detail')}<div id="detail-anime-episodes" class="anime-episodes"><div class="loading">Loading…</div></div></section>`:''}${type==='tv'&&!x.upcoming?`<section class="season-section">${sectionTitle('Seasons & Episodes','episodes')}<select class="season-select" id="detail-tv-season">${d.seasons.map(s=>`<option value="${s.number}">${esc(s.name)}</option>`).join('')}</select><div id="detail-episodes" class="episode-detail-list">Loading…</div></section>`:''}</div>`;
  updateSave(state);if(type==='tv'&&!x.upcoming&&d.seasons?.length)loadDetailEpisodes(id,d.seasons[0].number);if(type==='anime'&&showEpisodes)loadAnimeEpisodes(id,'detail',resumeEpisode?Math.floor((resumeEpisode-1)/20)+1:1,resumeEpisode,true,resumeEpisode);
  if(!x.upcoming&&!navigator.connection?.saveData){
   let savedAnimeLang='sub';try{if(localStorage.getItem('moscowtv-anime-lang')==='dub')savedAnimeLang='dub'}catch{}
   clearTimeout(detailWarmTimer);let warmEp=resumeEpisode||1,warmSeason=type==='tv'?(d.seasons?.[0]?.number??1):1,warmProv=type==='anime'?(savedAnimeLang==='dub'?'second':'default'):'default';
   detailWarmTimer=setTimeout(()=>{loadPlayerAssets().catch(()=>{});fetch(`/api/play?type=${type}&id=${id}&episode=${warmEp}&season=${warmSeason}&lang=${savedAnimeLang}&provider=${warmProv}&anilistId=${x.anilistId||''}`).catch(()=>{})},180);
  }
 }catch(e){failure(e)}
}
async function loadDetailEpisodes(id,num){let box=document.querySelector('#detail-episodes');if(!box)return;box.innerHTML='<div class="loading">Loading episodes…</div>';try{let d=await get(`/api/season?id=${id}&season=${num}`);box.innerHTML=d.episodes.map(e=>`<button class="episode-row" data-open="/browse/watch/tv/${id}?season=${num}&episode=${e.number}">${e.still?`<img loading="lazy" referrerpolicy="no-referrer" src="${safeImage(e.still)}" alt="">`:''}<span><strong>${e.number}. ${esc(e.title)}</strong><small>${esc((e.description||'').slice(0,160))}</small></span></button>`).join('')||'No episode information available.'}catch{box.textContent='Episodes unavailable right now.'}}
async function loadWatchEpisodes(id,number,active){let box=document.querySelector('#watch-episodes');if(!box)return;try{let d=await get(`/api/season?id=${id}&season=${number}`);box.innerHTML=d.episodes.map(e=>`<button class="episode-row ${e.number===active?'selected':''}" data-open="/browse/watch/tv/${id}?season=${number}&episode=${e.number}">${e.still?`<img loading="lazy" referrerpolicy="no-referrer" src="${safeImage(e.still)}" alt="">`:''}<span><strong>${e.number}. ${esc(e.title)}</strong><small>${esc((e.description||'').slice(0,160))}</small></span></button>`).join('')||'No episodes available.'}catch{box.textContent='Episodes unavailable right now.'}}
async function updateSave(state=null){
 if(!detail)return;let d=state||await get('/api/state'),saved=d.watchlist.some(i=>i.id===detail.item.id&&i.type===detail.item.type),button=document.querySelector('.detail [data-save]');
 if(button)button.innerHTML=saved?`${ico('check')}<span class="desktop-action">In Watchlist</span><span class="mobile-action">Added</span>`:`${ico('plus')}<span class="desktop-action">Add to Watchlist</span><span class="mobile-action">Add</span>`;
 }
function watchUrl(){let x=detail?.item;return `/browse/watch/${x.type}/${x.id}?season=${season}&episode=${episode}&lang=${lang}&provider=${provider}`}
function changeEpisode(step){let target=episodeTargets()[step>0?'next':'prev'];if(!target)return;if(String(target.id)!==String(detail.item.id)){nav(`/browse/watch/${target.type}/${target.id}?season=${target.season}&episode=${target.episode}&lang=${lang}&provider=${provider}`);return}season=target.season;episode=target.episode;nav(watchUrl())}
async function watch(type,id){
 let cachedTitle=[detail?.item,...items,...suggestions,...continueItems,...Object.values(genreRows).flat()].find(i=>i?.type===type&&String(i.id)===String(id))?.title||'';
 app.innerHTML=`<div class="container content"><div class="player-wrap"><h1 class="watch-title" id="watch-title"${cachedTitle?'':' hidden'}>${esc(cachedTitle)}</h1><div class="player" id="player"><div class="loading">Loading player…</div></div><div id="watch-meta"></div></div></div>`;
 try{
  let p=params(),reqSeason=p.has('season')?Math.max(0,Number(p.get('season'))||0):1,reqEpisode=Math.max(1,Number(p.get('episode'))||1);
  let savedAnimeLang='sub',savedServer='default';try{if(localStorage.getItem('moscowtv-anime-lang')==='dub')savedAnimeLang='dub';let sp=localStorage.getItem('moscowtv-server-pref');if(['default','second','vidlink','vidsrc'].includes(sp))savedServer=sp}catch{}
  let reqLang=p.has('lang')?(p.get('lang')==='dub'?'dub':'sub'):savedAnimeLang,requestedProvider=p.get('provider'),reqProvider=type==='anime'?(requestedProvider==='second'||reqLang==='dub'?'second':'default'):(['default','second','vidlink','vidsrc'].includes(requestedProvider)?requestedProvider:savedServer);
  let earlyPlay=get(`/api/play?type=${type}&id=${id}&episode=${reqEpisode}&season=${reqSeason}&lang=${reqLang}&provider=${reqProvider}`);earlyPlay.catch(()=>{});
  let [,d,state]=await Promise.all([loadPlayerAssets(),get(`/api/detail?type=${type}&id=${id}`),get('/api/state')]);
  detail=d;let x=d.item;if(x.upcoming)throw Error('This title has not been released yet.');season=reqSeason;episode=reqEpisode;if(type==='anime'){if(x.isMovie)episode=1;else if(x.episodes)episode=Math.min(episode,x.episodes)}else if(type==='tv'){let current=d.seasons.find(s=>Number(s.number)===Number(season));if(current?.episodes)episode=Math.min(episode,Number(current.episodes))}lang=reqLang;provider=reqProvider;document.title=`Watch ${x.title} — MoscowTV`;
  let titleEl=document.querySelector('#watch-title');if(titleEl){titleEl.textContent=x.title;titleEl.hidden=false}
  let metaBox=document.querySelector('#watch-meta');
  if(metaBox)metaBox.innerHTML=!isFeature(x)?`${sectionTitle('Episodes','episodes')}${type==='tv'?`<select class="season-select" id="season">${d.seasons.map(s=>`<option value="${s.number}" ${s.number===season?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:''}${type==='anime'?animeSeasonSelect(d,x,'watch'):''}${type==='tv'?`<div id="watch-episodes" class="episode-detail-list"><div class="loading">Loading episodes…</div></div>`:`<div id="watch-anime-episodes" class="anime-episodes"><div class="loading">Loading episodes…</div></div>`}`:'';
  await updateSave(state);if(type==='tv')loadWatchEpisodes(id,season,episode);else if(type==='anime'&&!x.isMovie)loadAnimeEpisodes(id,'watch',Math.floor((episode-1)/20)+1,episode,true);
  let canUseEarly=season===reqSeason&&episode===reqEpisode&&lang===reqLang&&provider===reqProvider;
  await play(x,state,[],canUseEarly?{prefetchedMedia:earlyPlay}:{});
 }catch(e){failure(e)}
}
function syncHistoryRecord(state,x,current,duration){if(!state||!Array.isArray(state.history))return;let idx=state.history.findIndex(h=>h.type===x.type&&String(h.id)===String(x.id)),old=idx>=0?state.history.splice(idx,1)[0]:{};state.history.unshift({...old,...x,episode,season,currentTime:Math.max(0,Number(current)||0),duration:Math.max(0,Number(duration)||0),updated:Date.now()})}
function showPlayerError(error){let container=document.querySelector('#player');if(!container)return failure(error);container.innerHTML=`<div class="empty player-error"><strong>Playback unavailable</strong><span>${esc(error.message||'The stream could not be loaded.')}</span><button class="btn" data-retry>Try again</button></div>`}
async function play(x,state=null,tried=[],options={}){
 disposeVideo();let generation=playGeneration,container=document.querySelector('#player');
 if(container&&options.isSwitch){container.dataset.server='';container.innerHTML='<div class="loading">Loading player…</div>'}
 try{
  let statePromise=state?Promise.resolve(state):get('/api/state'),mediaPromise=options.prefetchedMedia||get(`/api/play?type=${x.type}&id=${x.id}&episode=${episode}&season=${season}&lang=${lang}&provider=${provider}&anilistId=${x.anilistId||''}`),[,resolvedState,d]=await Promise.all([loadPlayerAssets(),statePromise,mediaPromise]);state=resolvedState;if(generation!==playGeneration)return;
  let isSwitch=Boolean(options.isSwitch),saved=state.history.find(h=>h.type===x.type&&String(h.id)===String(x.id)&&Number(h.episode)===Number(episode)&&Number(h.season)===Number(season)),resumeAt=isSwitch?Math.max(0,Number(options.resumeTime)||0):(saved?.currentTime>15&&saved?.duration-saved?.currentTime>20?Math.max(0,Number(saved.currentTime)+.25):0),saveData=Boolean(navigator.connection?.saveData),autoplay=isSwitch?!options.wasPaused:(!saveData&&localStorage.getItem('moscowtv-autoplay')!=='false');
  container=document.querySelector('#player');if(!container)return;
  container.dataset.provider=d.provider;container.dataset.server=d.server||'';container.innerHTML='<video id="moscowtv-video" class="video-js vjs-default-skin vjs-big-play-centered" playsinline webkit-playsinline disableremoteplayback></video>';
  let player=videojs('moscowtv-video',{controls:false,preload:saveData?'none':'auto',playbackRates:[.25,.5,.75,1,1.25,1.5,1.75,2],html5:{vhs:{overrideNative:true,useBandwidthFromLocalStorage:true,useNetworkInformationApi:true,limitRenditionByPlayerDimensions:true,useDevicePixelRatio:true,smoothQualityChange:true,handlePartialData:true,bandwidth:saveData?500000:2800000,enableLowInitialPlaylist:false,goalBufferLength:30,maxGoalBufferLength:60,backBufferLength:20},nativeAudioTracks:false,nativeTextTracks:false}});videoPlayer=player;player.tech({}).el().setAttribute('disableremoteplayback','');
  player.src({src:d.src,type:d.type||'application/x-mpegURL'});
  let save=(current=0,duration=0)=>{syncHistoryRecord(state,x,current,duration);return post('/api/history',{...x,episode,season,currentTime:current,duration}).catch(()=>{})};
  MegaPlayUI.create(player,{item:x,data:d,lang,server:d.sourceKey||provider,autoplay,onAudioChange:value=>{if(value===lang)return;let exactTime=Number(player.currentTime())||0,dur=Number(player.duration())||0,wasPaused=player.paused();lang=value;provider=value==='dub'?'second':'default';try{localStorage.setItem('moscowtv-anime-lang',value)}catch{}save(exactTime,dur);history.pushState({},'',watchUrl());if(x.type==='anime'&&animeEpisodeLists.watch)renderAnimeEpisodes('watch');play(x,state,[],{resumeTime:exactTime,wasPaused,isSwitch:true})},onServerChange:value=>{if(value===(d.sourceKey||provider))return;let exactTime=Number(player.currentTime())||0,dur=Number(player.duration())||0,wasPaused=player.paused();provider=value;try{localStorage.setItem('moscowtv-server-pref',value)}catch{}save(exactTime,dur);history.pushState({},'',watchUrl());play(x,state,[],{resumeTime:exactTime,wasPaused,isSwitch:true})}});
  let attempted=new Set([...tried,provider,d.sourceKey].filter(Boolean)),bypassedRanges=new Set();
  const markContainingRanges=time=>{for(let [idx,range] of [d.intro,d.outro].entries()){let start=Number(range?.start),end=Number(range?.end);if(Number.isFinite(start)&&Number.isFinite(end)&&end>start&&time>=start&&time<end)bypassedRanges.add(idx)}};
  if(resumeAt>0)markContainingRanges(resumeAt);
  player.on('seeking',()=>markContainingRanges(player.currentTime()));
  player.one('canplay',()=>{let dur=Number(player.duration());if(resumeAt>0&&Number.isFinite(dur)&&(isSwitch?dur>resumeAt+.5:dur>resumeAt+10))player.currentTime(resumeAt)});
  player.one('playing',()=>{if(isSwitch&&resumeAt>0){let dur=Number(player.duration());if(Number.isFinite(dur)&&dur>resumeAt+.5&&Math.abs(player.currentTime()-resumeAt)>1.2)player.currentTime(resumeAt)}save(player.currentTime(),player.duration())});
  player.on('timeupdate',()=>{
   let current=player.currentTime(),duration=player.duration();
   for(let [idx,range] of [d.intro,d.outro].entries()){
    let start=Number(range?.start),end=Number(range?.end);if(!(Number.isFinite(start)&&Number.isFinite(end)&&end>start))continue;
    if(current<start-1||current>=end)bypassedRanges.delete(idx);
    else if(!bypassedRanges.has(idx)&&localStorage.getItem('moscowtv-autoskip')==='true'&&current>=start&&current<end){bypassedRanges.add(idx);player.currentTime(end);break}
   }
   if(Number.isFinite(duration)&&duration>0&&Date.now()-lastProgressSent>5000){lastProgressSent=Date.now();save(current,duration)}
  });
  player.on('ended',()=>{save(player.duration(),player.duration());if(localStorage.getItem('moscowtv-autonext')!=='false')changeEpisode(1)});
  player.on('error',()=>{if(generation!==playGeneration)return;let error=player.error(),next=x.type!=='anime'?['default','vidlink','vidsrc','second'].find(value=>!attempted.has(value)):null;if(next){provider=next;play(x,state,[...attempted],isSwitch?{resumeTime:resumeAt,wasPaused:options.wasPaused,isSwitch:true}:{});return}disposeVideo();showPlayerError(Error(error?.message||'The stream could not be loaded.'))});
  if(autoplay)player.play().catch(()=>player.megaUI?.onAutoplayBlocked?.());
 }catch(e){if(generation===playGeneration){disposeVideo();showPlayerError(e)}}
}

function failure(e){app.innerHTML=`<div class="container content"><div class="empty"><h2>Something went wrong</h2><p class="error">${esc(e.message)}</p><button class="btn" data-retry>Try again</button></div></div>`}
function clock(v){let n=Math.max(0,Math.floor(Number(v)||0));return `${Math.floor(n/3600)?String(Math.floor(n/3600))+':':''}${String(Math.floor(n/60)%60).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`}
function continueGrid(data){return `<div class="continue-grid">${data.map(x=>`<article class="continue-card" data-open="/browse/watch/${x.type}/${x.id}?episode=${x.episode}&season=${x.season}"><div class="continue-image">${x.poster?`<img loading="lazy" src="${safeImage(x.poster)}" alt="${esc(x.title)}">`:''}<span class="continue-label">${x.type==='anime'?(x.isMovie?'ANIME MOVIE':'ANIME'):x.type==='tv'?'WEB SERIES':'MOVIE'}</span></div><div class="continue-foot"><div class="continue-progress" style="width:${x.duration?Math.min(100,100*x.currentTime/x.duration):0}%"></div><span>${isFeature(x)?'MOVIE':x.type==='tv'?`S${x.season} E${x.episode}`:`EP ${x.episode}`}</span><span>${x.duration?clock(x.currentTime):'00:00'}</span></div><h3>${esc(x.title)}</h3></article>`).join('')}</div>`}
async function watchlist(){
 app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let d=await get('/api/state'),convert=x=>({...x,year:'Saved',rating:null});savedKeys=new Set((d.watchlist||[]).map(x=>x.type+':'+x.id));document.title='Watchlist — MoscowTV';
  app.innerHTML=`<div class="container content watchlist-page">${sectionTitle('Watchlist','bookmark','h1')}${grid(d.watchlist.map(convert))}<div class="continue-section">${sectionTitle('Continue Watching','history')}${d.history.length?continueGrid(d.history):grid([])}</div></div>`;
 }catch(e){failure(e)}
}
async function schedulePage(){
 app.innerHTML='<div class="loading">Loading…</div>';document.title='Anime Schedule — MoscowTV';
 try{let d=await get('/api/schedule'),groups=new Map();for(let entry of d.entries){let date=new Date(entry.airingAt*1000),key=date.toLocaleDateString('en',{weekday:'long',month:'long',day:'numeric'});if(!groups.has(key))groups.set(key,[]);groups.get(key).push(entry)}app.innerHTML=`<div class="container content">${sectionTitle('Anime Schedule','clock','h1')}${groups.size?[...groups].map(([day,entries])=>`<section class="schedule-day"><h2>${day}</h2>${entries.map(({item,episode,airingAt})=>`<article class="schedule-row" data-open="${url(item.type,item.id)}"><img src="${safeImage(item.poster)}" alt=""><div><strong>${esc(item.title)}</strong><span>Episode ${episode} · ${new Date(airingAt*1000).toLocaleTimeString('en',{hour:'numeric',minute:'2-digit'})}</span></div><b>${timeAgo(airingAt*1000)}</b></article>`).join('')}</section>`).join(''):'<div class="empty">No scheduled episodes.</div>'}</div>`}catch(e){failure(e)}
}
async function upcomingPage(){app.innerHTML='<div class="loading">Loading…</div>';document.title='Upcoming — MoscowTV';try{let d=await get('/api/upcoming');app.innerHTML=`<div class="container content">${sectionTitle('Upcoming','calendar','h1')}${sectionTitle('Anime','sparkles')}${grid(d.anime)}${sectionTitle('Movies','film')}${grid(d.movies)}</div>`}catch(e){failure(e)}}
const option=(value,label,current)=>`<option value="${value}" ${value===current?'selected':''}>${label}</option>`;
async function filtersPage(){
 app.innerHTML='<div class="loading">Loading advanced filters…</div>';document.title='Advanced Filters — MoscowTV';let p=params(),values={type:p.get('type')||'all',genre:p.get('genre')||'',year:p.get('year')||'',sort:p.get('sort')||'popularity',status:p.get('status')||''};
 try{let d=await get('/api/filter'+location.search);app.innerHTML=`<div class="container content">${sectionTitle('Advanced Filters','sliders','h1')}<form class="filters-form" data-filters><label>Type<select name="type">${option('all','Everything',values.type)}${option('anime','Anime',values.type)}${option('movie','Movies',values.type)}${option('tv','Web series',values.type)}</select></label><label>Genre<select name="genre">${option('','All genres',values.genre)}${catalogGenres.map(g=>option(g,g,values.genre)).join('')}</select></label><label>Year<input name="year" inputmode="numeric" pattern="[0-9]{4}" minlength="4" maxlength="4" value="${esc(values.year)}" placeholder="Any year"></label><label>Sort<select name="sort">${option('popularity','Popularity',values.sort)}${option('rating','Rating',values.sort)}${option('newest','Newest',values.sort)}</select></label><label>Anime status<select name="status">${option('','Any status',values.status)}${option('releasing','Ongoing',values.status)}${option('finished','Finished',values.status)}</select></label><button class="btn" type="submit">Apply filters</button></form><div class="filter-results-heading">${sectionTitle('Results','sliders')}<span>${d.items.length} titles</span></div>${grid(d.items)}</div>`}catch(e){failure(e)}
}
async function randomPage(){app.innerHTML='<div class="loading">Choosing a random title…</div>';try{let d=await get('/api/random');history.replaceState({},'',url(d.item.type,d.item.id));render()}catch(e){failure(e)}}
function render(){
 disposeVideo();closeMenu();let p=location.pathname;
 if(['/account','/login','/create-account','/profile','/community'].includes(p)){history.replaceState({},'','/browse');p='/browse'}
 if(p==='/schedule')return schedulePage();if(p==='/upcoming')return upcomingPage();if(p==='/filters')return filtersPage();if(p==='/random')return randomPage();
 search.placeholder='Search anime, movies & series...';if(p==='/watchlist')return watchlist();let m=p.match(/^\/browse\/(watch\/)?(anime|movie|tv)\/(\d+)$/);if(m)return m[1]?watch(m[2],m[3]):details(m[2],m[3]);return catalog();
}

document.addEventListener('click',async e=>{
 try{
  let description=e.target.closest('[data-description-toggle]');if(description){let expanded=description.classList.toggle('expanded');description.setAttribute('aria-expanded',String(expanded));return}
  let heroSave=e.target.closest('[data-hero-save]');if(heroSave){let [type,id]=heroSave.dataset.heroSave.split(':'),x=[...items,...suggestions,...Object.values(genreRows).flat()].find(i=>i.type===type&&String(i.id)===id);if(!x)return;let state=await get('/api/state'),saved=state.watchlist.some(i=>i.id===id&&i.type===type),next=await post('/api/watchlist',{...x,remove:saved});savedKeys=new Set(next.watchlist.map(i=>i.type+':'+i.id));document.querySelectorAll(`[data-hero-save="${type}:${id}"]`).forEach(b=>{b.classList.toggle('saved',!saved);b.setAttribute('aria-label',(!saved?'Remove from':'Add to')+' Watchlist')});return}
  let categoryButton=e.target.closest('[data-more-categories]');if(categoryButton){if(categoryButton.disabled)return;categoryButton.disabled=true;categoryButton.textContent='Loading…';let next=genreQueue.splice(0,3),anchor=categoryButton.closest('.category-more');activeGenres.push(...next);for(let name of next)anchor.insertAdjacentHTML('beforebegin',`<section class="genre-section" data-genre="${name}"></section>`);await loadGenreRows(next);if(!anchor.isConnected)return;if(genreQueue.length){categoryButton.disabled=false;categoryButton.innerHTML=`${ico('plus')}<span>Show more</span>`}else anchor.remove();return}
  let genre=e.target.closest('[data-genre-filter]');if(genre){nav('/browse?genre='+encodeURIComponent(genre.dataset.genreFilter));return}
  let more=e.target.closest('[data-anime-page]');if(more&&detail){let mode=more.dataset.animeMode;await loadAnimeEpisodes(detail.item.id,mode,Number(more.dataset.animePage),mode==='watch'?episode:0,false);return}
  let dot=e.target.closest('[data-slide]');if(dot){slide=+dot.dataset.slide;let data=items.filter(x=>x.poster&&x.title&&x.backdrop).slice(0,6),current=document.querySelector('.hero');if(current)current.outerHTML=hero(data);return}
  let open=e.target.closest('[data-open]');if(open){nav(open.dataset.open);return}
  let link=e.target.closest('a[href^="/"]');if(link){e.preventDefault();nav(link.getAttribute('href'));return}
  let heroDetails=e.target.closest('[data-hero-details]');if(heroDetails){nav(heroDetails.dataset.heroDetails);return}
  if(e.target.closest('[data-retry]')){render();return}
  if(e.target.closest('[data-save]')&&detail){let x=detail.item,d=await get('/api/state'),saved=d.watchlist.some(i=>i.id===x.id&&i.type===x.type);let next=await post('/api/watchlist',{...x,remove:saved});savedKeys=new Set(next.watchlist.map(i=>i.type+':'+i.id));await updateSave();return}
  let ep=e.target.closest('[data-episode]');if(ep&&detail){episode=+ep.dataset.episode;nav(`/browse/watch/${detail.item.type}/${detail.item.id}?season=${season}&episode=${episode}&lang=${lang}&provider=${provider}`);return}
  let l=e.target.closest('[data-lang]');if(l&&detail){lang=l.dataset.lang;nav(`/browse/watch/anime/${detail.item.id}?episode=${episode}&lang=${lang}&provider=${provider}`);return}
 }catch(error){console.error(error);alert(error.message)}
});
document.addEventListener('change',e=>{if(e.target.id==='season'&&detail){season=+e.target.value;episode=1;nav(`/browse/watch/tv/${detail.item.id}?season=${season}&episode=1`)}if(e.target.id==='detail-tv-season'&&detail)loadDetailEpisodes(detail.item.id,e.target.value);if(['detail-anime-season','anime-season'].includes(e.target.id)&&detail){let id=e.target.value;nav(e.target.id==='anime-season'?`/browse/watch/anime/${id}?episode=1&lang=${lang}&provider=${provider}`:`/browse/anime/${id}`)}});const menuToggle=document.querySelector('.menu-toggle'),mainMenu=document.querySelector('#main-menu');
function closeMenu(){if(!menuToggle||!mainMenu)return;menuToggle.setAttribute('aria-expanded','false');menuToggle.setAttribute('aria-label','Open menu');mainMenu.hidden=true}
menuToggle?.addEventListener('click',()=>{let open=menuToggle.getAttribute('aria-expanded')!=='true';menuToggle.setAttribute('aria-expanded',String(open));menuToggle.setAttribute('aria-label',open?'Close menu':'Open menu');mainMenu.hidden=!open});
document.addEventListener('click',e=>{if(!e.target.closest('#main-menu,.menu-toggle'))closeMenu()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
document.addEventListener('submit',async e=>{
 let filters=e.target.closest('[data-filters]');if(filters){e.preventDefault();let data=new FormData(filters),q=new URLSearchParams();for(let [key,value] of data)if(String(value).trim())q.set(key,String(value).trim());nav('/filters'+(q.toString()?'?'+q:''));return}
});
const searchbox=document.querySelector('.searchbox');searchbox.addEventListener('click',()=>{searchbox.classList.add('open');search.focus()});search.addEventListener('blur',()=>{if(!search.value.trim())searchbox.classList.remove('open')});search.addEventListener('input',()=>{clearTimeout(searchTimer);if(!['/browse','/'].includes(location.pathname)||params().has('genre')){history.pushState({},'','/browse');document.querySelectorAll('[data-nav]').forEach(a=>a.classList.toggle('active',a.dataset.nav==='browse'))}searchTimer=setTimeout(()=>search.value.trim()?catalog(true):catalog(),450)});document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-hero-details]')){e.preventDefault();nav(e.target.dataset.heroDetails);return}if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-description-toggle]')){e.preventDefault();e.target.click();return}if(e.key==='/'&&document.activeElement!==search){e.preventDefault();search.focus()}});const genreMenu=document.querySelector('#genre-menu');if(genreMenu)genreMenu.innerHTML=catalogGenres.map(name=>`<button type="button" data-genre-filter="${esc(name)}">${esc(name)}</button>`).join('');const exploreIcons={'/browse':'home','/schedule':'clock','/upcoming':'calendar','/random':'shuffle','/filters':'sliders'};document.querySelectorAll('.main-menu a[href]').forEach(a=>{let icon=exploreIcons[a.getAttribute('href')];if(icon)a.innerHTML=`${ico(icon)}<span>${esc(a.textContent)}</span>`});document.querySelectorAll('[data-genre-filter]').forEach(b=>{b.innerHTML=`${ico(genreIcons[b.dataset.genreFilter])}<span>${esc(b.textContent)}</span>`});window.addEventListener('popstate',render);if(location.pathname==='/')history.replaceState({},'','/browse');render();if(!navigator.connection?.saveData)setTimeout(()=>loadPlayerAssets().catch(()=>{}),700);
