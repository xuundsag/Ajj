import crypto from 'node:crypto';
import { Readable } from 'node:stream';
import net from 'node:net';

const secret = crypto.createHash('sha256').update(process.env.MEDIA_PROXY_SECRET || crypto.randomBytes(32)).digest();
const providers = {
  megaplay: { referer: 'https://megaplay.buzz/' },
  cinesrc: { referer: 'https://cinesrc.st/' },
  vidlink: { referer: '', ua: 'MoscowTV/4.2 (media proxy)' },
  vidsrc: { referer: 'https://vidsrc.pm/' }
};
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const privateHost = host => /^(localhost|0\.0\.0\.0|::1)$/i.test(host) || (net.isIP(host) && /^(10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|fc|fd|fe80:)/i.test(host));

function cleanHeaders(headers = {}) {
  const clean = {};
  for (const key of ['Cookie', 'Referer', 'Origin']) if (typeof headers[key] === 'string' && headers[key].length < 8192) clean[key] = headers[key];
  return clean;
}
function decodeHeaders(value) {
  if (!value) return {};
  try { return cleanHeaders(JSON.parse(Buffer.from(value, 'base64url').toString('utf8'))); }
  catch { throw Error('Invalid media headers.'); }
}
const signature = (url, provider, headers = {}) => crypto.createHmac('sha256', secret).update(provider + '\n' + url + '\n' + JSON.stringify(cleanHeaders(headers))).digest('hex').slice(0, 40);

export function mediaUrl(url, provider, headers = {}) {
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:' || !providers[provider] || privateHost(parsed.hostname)) throw Error('Unsupported media URL.');
  const clean = cleanHeaders(headers);
  const params = new URLSearchParams({ provider, url: parsed.href, sig: signature(parsed.href, provider, clean) });
  if (Object.keys(clean).length) params.set('h', Buffer.from(JSON.stringify(clean)).toString('base64url'));
  return '/api/media?' + params;
}
function validSignature(value, url, provider, headers) {
  if (!/^[a-f0-9]{40}$/.test(value || '')) return false;
  const expected = Buffer.from(signature(url, provider, headers));
  const actual = Buffer.from(value);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}
function safeRemote(value) {
  const parsed = new URL(value);
  if (parsed.protocol !== 'https:' || privateHost(parsed.hostname)) throw Error('Unsafe media URL.');
  return parsed;
}
function rewritePlaylist(text, base, provider, headers) {
  return text.split(/(\r?\n)/).map(part => {
    if (/^\r?\n$/.test(part)) return part;
    const value = part.trim();
    if (!value) return part;
    if (value.startsWith('#')) return part.replace(/URI=(["'])(.*?)\1/g, (match, quote, uri) => `URI=${quote}${mediaUrl(new URL(uri, base).href, provider, headers)}${quote}`);
    return mediaUrl(new URL(value, base).href, provider, headers);
  }).join('');
}
function upstreamHeaders(provider, headers, range) {
  const config = providers[provider];
  return { ...(config.referer ? { Referer: config.referer } : {}), ...cleanHeaders(headers), 'User-Agent': config.ua || UA, ...(range ? { Range: range } : {}) };
}
function pipeUpstream(upstream, res, cacheHeader = null) {
  const headers = {
    'Content-Type': upstream.headers.get('content-type') || 'application/octet-stream',
    'Cache-Control': cacheHeader || upstream.headers.get('cache-control') || 'private, max-age=600',
    'Access-Control-Allow-Origin': '*'
  };
  for (const key of ['content-length', 'content-range', 'accept-ranges', 'etag', 'last-modified']) {
    const value = upstream.headers.get(key);
    if (value) headers[key.replace(/(^|-)(\w)/g, (_, a, b) => a + b.toUpperCase())] = value;
  }
  res.writeHead(upstream.status, headers);
  if (!upstream.body) return res.end();
  const stream = Readable.fromWeb(upstream.body);
  res.once('close', () => { if (!res.writableEnded) stream.destroy(); });
  stream.on('error', () => { if (!res.destroyed) res.destroy(); }).pipe(res);
}
const playlistCache = new Map();
const initSegmentCache = new Map();
const RETRYABLE_STATUS = new Set([408, 429, 500, 502, 503, 504, 520, 521, 522, 523, 524]);

async function fetchWithRetry(parsed, reqHeaders, clientState, maxAttempts = 3) {
  let lastError = null;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (clientState.closed) throw Error('Client closed connection.');
    const controller = new AbortController();
    const onClose = () => controller.abort();
    clientState.onAbort = onClose;
    const timer = setTimeout(() => controller.abort(), 16_000);
    try {
      const upstream = await fetch(parsed, { headers: reqHeaders, signal: controller.signal, redirect: 'follow' });
      clearTimeout(timer);
      if (RETRYABLE_STATUS.has(upstream.status) && attempt + 1 < maxAttempts && !clientState.closed) {
        upstream.body?.cancel().catch(() => {});
        await new Promise(r => setTimeout(r, 140 * (attempt + 1)));
        continue;
      }
      return upstream;
    } catch (err) {
      clearTimeout(timer);
      lastError = err;
      if (clientState.closed || attempt + 1 >= maxAttempts) throw err;
      await new Promise(r => setTimeout(r, 140 * (attempt + 1)));
    }
  }
  throw lastError || Error('Upstream fetch failed.');
}

async function fetchMedia(req, res, target, provider, headers) {
  let upstream;
  const clientState = { closed: false, onAbort: null };
  res.once('close', () => {
    if (!res.writableEnded) {
      clientState.closed = true;
      clientState.onAbort?.();
    }
  });
  try {
    const parsed = safeRemote(target);
    const cacheKey = provider + ':' + parsed.href;
    const hit = playlistCache.get(cacheKey);
    if (hit && Date.now() - hit.time < 90_000) {
      res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegurl; charset=utf-8', 'Cache-Control': 'private, max-age=30', 'Access-Control-Allow-Origin': '*' });
      return res.end(hit.body);
    }
    const isInitMap = !req.headers.range && /\/init\.mp4(?:\?|$)/i.test(parsed.pathname + parsed.search);
    if (isInitMap) {
      const initHit = initSegmentCache.get(cacheKey);
      if (initHit && Date.now() - initHit.time < 30 * 60_000) {
        res.writeHead(200, {
          'Content-Type': initHit.type || 'video/mp4',
          'Content-Length': String(initHit.buf.byteLength),
          'Cache-Control': 'private, max-age=1800',
          'Access-Control-Allow-Origin': '*'
        });
        return res.end(initHit.buf);
      }
    }
    upstream = await fetchWithRetry(parsed, upstreamHeaders(provider, headers, req.headers.range), clientState, 3);
    const final = safeRemote(upstream.url || parsed);
    const type = String(upstream.headers.get('content-type') || '').toLowerCase();
    const playlist = /\.m3u8(?:\?|$)/i.test(final.pathname + final.search) || type.includes('mpegurl');
    if (playlist && upstream.ok) {
      const text = await upstream.text();
      if (!text.trimStart().startsWith('#EXTM3U')) throw Error('The provider returned an invalid playlist.');
      const body = rewritePlaylist(text, final.href, provider, headers);
      if (/#EXT-X-(?:STREAM-INF|ENDLIST)/.test(text)) {
        playlistCache.set(cacheKey, { body, time: Date.now() });
        if (playlistCache.size > 150) playlistCache.delete(playlistCache.keys().next().value);
      }
      res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegurl; charset=utf-8', 'Cache-Control': 'private, max-age=15', 'Access-Control-Allow-Origin': '*' });
      return res.end(body);
    }
    const isSubtitle = /[?&]format=srt(?:&|$)/i.test(final.search) || /\.srt(?:$|\?)/i.test(final.href);
    const isVtt = /\.vtt(?:$|\?)/i.test(final.href) || type.includes('text/vtt');
    if ((isSubtitle || isVtt) && upstream.ok) {
      const buffer = Buffer.from(await upstream.arrayBuffer());
      if (buffer.length > 8 * 1024 * 1024) throw Error('Subtitle file too large');
      let encoding = final.searchParams.get('encoding') || 'utf-8';
      encoding = encoding.replace(/^cp(\d+)$/i, 'windows-$1');
      let text;
      try { text = new TextDecoder(encoding).decode(buffer); } catch { text = new TextDecoder().decode(buffer); }
      let vtt = text.replace(/^\uFEFF/, '').replace(/\r/g, '');
      if (!/^WEBVTT/i.test(vtt)) vtt = 'WEBVTT\n\n' + vtt.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
      res.writeHead(200, { 'Content-Type': 'text/vtt; charset=utf-8', 'Cache-Control': 'private, max-age=3600', 'Access-Control-Allow-Origin': '*' });
      return res.end(vtt);
    }
    if (!upstream.ok) {
      upstream.body?.cancel().catch(() => {});
      res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Upstream media unavailable (' + upstream.status + ').');
    }
    if (isInitMap) {
      const buf = Buffer.from(await upstream.arrayBuffer());
      if (buf.byteLength > 0 && buf.byteLength <= 262_144) {
        initSegmentCache.set(cacheKey, { buf, type: upstream.headers.get('content-type') || 'video/mp4', time: Date.now() });
        if (initSegmentCache.size > 80) initSegmentCache.delete(initSegmentCache.keys().next().value);
      }
      res.writeHead(200, {
        'Content-Type': upstream.headers.get('content-type') || 'video/mp4',
        'Content-Length': String(buf.byteLength),
        'Cache-Control': 'private, max-age=1800',
        'Access-Control-Allow-Origin': '*'
      });
      return res.end(buf);
    }
    return pipeUpstream(upstream, res, req.headers.range ? 'no-store' : 'private, max-age=600');
  } catch (error) {
    upstream?.body?.cancel().catch(() => {});
    if (clientState.closed || res.headersSent) return res.destroy();
    res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end('Media request failed: ' + error.message);
  }
}

export function handleMedia(req, res, url) {
  const target = url.searchParams.get('url') || '';
  const provider = url.searchParams.get('provider') || '';
  const sig = url.searchParams.get('sig') || '';
  try {
    const parsed = safeRemote(target);
    const headers = decodeHeaders(url.searchParams.get('h'));
    if (!providers[provider] || !validSignature(sig, parsed.href, provider, headers)) throw Error('Invalid media signature.');
  } catch (error) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end(error.message);
  }
  return fetchMedia(req, res, target, provider, decodeHeaders(url.searchParams.get('h')));
}

// Vidlink currently delivers static fMP4 DASH. These short-lived, unguessable
// sessions let VHS read the same segments as HLS without transcoding them.
const dashSessions = new Map();
const dashManifests = new Map();
export function dashUrl(url, provider, headers = {}) {
  const parsed = safeRemote(url);
  if (!providers[provider]) throw Error('Unsupported DASH provider.');
  const id = crypto.randomBytes(18).toString('base64url');
  dashSessions.set(id, { url: parsed.href, provider, headers: cleanHeaders(headers), expires: Date.now() + 50 * 60_000 });
  if (dashSessions.size > 100) for (const [key, session] of dashSessions) if (session.expires < Date.now() || dashSessions.size > 100) { dashSessions.delete(key); dashManifests.delete(key); }
  return `/api/dash/${provider}/${id}/master.m3u8`;
}
function xmlAttrs(source = '') {
  const attrs = {};
  for (const match of source.matchAll(/([\w:-]+)="([^"]*)"/g)) attrs[match[1]] = match[2].replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  return attrs;
}
function isoDuration(value = '') {
  const match = value.match(/^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$/);
  if (!match) return 0;
  return (Number(match[1] || 0) * 86400) + (Number(match[2] || 0) * 3600) + (Number(match[3] || 0) * 60) + Number(match[4] || 0);
}
function parseDashManifest(text) {
  const mpd = xmlAttrs(text.match(/<MPD\b([^>]*)>/i)?.[1]);
  const duration = isoDuration(mpd.mediaPresentationDuration);
  const videos = [], audios = [];
  for (const set of text.matchAll(/<AdaptationSet\b([^>]*)>([\s\S]*?)<\/AdaptationSet>/gi)) {
    const setAttrs = xmlAttrs(set[1]), body = set[2];
    const setTemplate = body.match(/<SegmentTemplate\b([^>]*)>/i)?.[1] || '';
    const setBase = body.match(/<BaseURL>([\s\S]*?)<\/BaseURL>/i)?.[1]?.trim() || '';
    for (const representation of body.matchAll(/<Representation\b([^>]*)>([\s\S]*?)<\/Representation>/gi)) {
      const attrs = xmlAttrs(representation[1]), repBody = representation[2];
      const template = xmlAttrs(repBody.match(/<SegmentTemplate\b([^>]*)>/i)?.[1] || setTemplate);
      const timescale = Number(template.timescale || 1), segmentDuration = Number(template.duration) / timescale;
      if (!template.media || !template.initialization || !Number.isFinite(segmentDuration) || segmentDuration <= 0 || !duration) continue;
      const base = repBody.match(/<BaseURL>([\s\S]*?)<\/BaseURL>/i)?.[1]?.trim() || setBase;
      const kind = (setAttrs.contentType || attrs.mimeType || '').startsWith('audio') ? 'audio' : 'video';
      const item = {
        id: String(attrs.id || (kind === 'video' ? videos.length : audios.length)),
        kind,
        width: Number(attrs.width || setAttrs.maxWidth || 0),
        height: Number(attrs.height || setAttrs.maxHeight || 0),
        bandwidth: Number(attrs.bandwidth || 0),
        codecs: attrs.codecs || setAttrs.codecs || '',
        language: setAttrs.lang || 'und',
        segmentDuration,
        startNumber: Number(template.startNumber || 1),
        media: base + template.media,
        initialization: base + template.initialization
      };
      (kind === 'audio' ? audios : videos).push(item);
    }
  }
  if (!videos.length || !duration) throw Error('This DASH manifest cannot be repackaged as HLS.');
  return { duration, videos, audios };
}
function segmentName(template, representation, number) {
  return template.replace(/\$RepresentationID\$/g, representation.id).replace(/\$Number(?:%0(\d+)d)?\$/g, (match, width) => String(number).padStart(Number(width || 1), '0'));
}
function dashMediaPlaylist(manifest, representation) {
  const count = Math.ceil(manifest.duration / representation.segmentDuration);
  if (count > 20000) throw Error('DASH playlist is too large.');
  const lines = ['#EXTM3U', '#EXT-X-VERSION:7', `#EXT-X-TARGETDURATION:${Math.ceil(representation.segmentDuration)}`, '#EXT-X-PLAYLIST-TYPE:VOD', '#EXT-X-INDEPENDENT-SEGMENTS', `#EXT-X-MAP:URI="${segmentName(representation.initialization, representation, representation.startNumber)}"`];
  for (let index = 0; index < count; index++) {
    const remaining = manifest.duration - index * representation.segmentDuration;
    lines.push(`#EXTINF:${Math.min(representation.segmentDuration, remaining).toFixed(6)},`, segmentName(representation.media, representation, representation.startNumber + index));
  }
  lines.push('#EXT-X-ENDLIST', '');
  return lines.join('\n');
}
function dashMasterPlaylist(manifest) {
  const lines = ['#EXTM3U', '#EXT-X-VERSION:7', '#EXT-X-INDEPENDENT-SEGMENTS'];
  const audioBandwidth = manifest.audios[0]?.bandwidth || 0;
  for (const [index, audio] of manifest.audios.entries()) lines.push(`#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="mp-audio",NAME="Audio ${index + 1}",LANGUAGE="${audio.language}",DEFAULT=${index ? 'NO' : 'YES'},AUTOSELECT=YES,URI="audio-${audio.id}.m3u8"`);
  for (const video of [...manifest.videos].sort((a, b) => b.height - a.height)) {
    const codecs = [video.codecs, manifest.audios[0]?.codecs].filter(Boolean).join(',');
    lines.push(`#EXT-X-STREAM-INF:BANDWIDTH=${video.bandwidth + audioBandwidth}${video.width && video.height ? `,RESOLUTION=${video.width}x${video.height}` : ''}${codecs ? `,CODECS="${codecs}"` : ''}${manifest.audios.length ? ',AUDIO="mp-audio"' : ''}`, `video-${video.id}.m3u8`);
  }
  return lines.join('\n') + '\n';
}
async function dashManifest(id, session) {
  const cached = dashManifests.get(id);
  if (cached && Date.now() - cached.time < 5 * 60_000) return cached.value;
  const response = await fetch(session.url, { headers: upstreamHeaders(session.provider, session.headers), signal: AbortSignal.timeout(15_000) });
  if (!response.ok) throw Error('DASH manifest unavailable (' + response.status + ').');
  const text = await response.text();
  const final = safeRemote(response.url || session.url);
  session.url = final.href;
  const value = parseDashManifest(text);
  dashManifests.set(id, { value, time: Date.now() });
  return value;
}
export async function handleDash(req, res, url) {
  try {
    const match = url.pathname.match(/^\/api\/dash\/([a-z]+)\/([A-Za-z0-9_-]+)\/(.+)$/);
    if (!match) throw Error('Invalid DASH proxy path.');
    const [, provider, id, relative] = match;
    const session = dashSessions.get(id);
    if (!session || session.expires < Date.now() || session.provider !== provider) throw Error('DASH session expired.');
    if (relative === 'master.m3u8' || /^(?:video|audio)-[^/]+\.m3u8$/.test(relative)) {
      const manifest = await dashManifest(id, session);
      let body;
      if (relative === 'master.m3u8') body = dashMasterPlaylist(manifest);
      else {
        const [kind, representationId] = relative.replace(/\.m3u8$/, '').split('-');
        const representation = (kind === 'video' ? manifest.videos : manifest.audios).find(item => item.id === representationId);
        if (!representation) throw Error('Unknown DASH rendition.');
        body = dashMediaPlaylist(manifest, representation);
      }
      res.writeHead(200, { 'Content-Type': 'application/vnd.apple.mpegurl; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
      return res.end(body);
    }
    const base = new URL(session.url);
    const target = new URL(relative, base);
    const directory = base.pathname.slice(0, base.pathname.lastIndexOf('/') + 1);
    if (target.origin !== base.origin || !target.pathname.startsWith(directory)) throw Error('Unsafe DASH segment path.');
    return await fetchMedia(req, res, target.href, provider, session.headers);
  } catch (error) {
    if (res.headersSent) return res.destroy();
    res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end('DASH proxy failed: ' + error.message);
  }
}
