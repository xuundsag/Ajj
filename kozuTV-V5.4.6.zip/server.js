import freekeys from 'freekeys';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { resolveMegaPlayDirect, enrichAnimeQualityStreams, measureMegaHlsDurationSec } from './megaplay-resolver.js';
import { mediaUrl, dashUrl, handleMedia, handleDash } from './media-proxy.js';
import {
  OTT_SERVER_KEYS, DEFAULT_OTT_SERVER,
  resolveOttWithFallback, resolveAnimeRegionalAudio, resolveSpecialRegionalAnime,
  fetchVidsparkSubtitles, fetchEmbedWaveSubtitles
} from './ott-resolvers.js';

const root = path.resolve('public');
const db = path.resolve('data/user.json');
const statesDb = path.resolve('data/states.json');
const initial = { watchlist: [], history: [] };
if (!fs.existsSync(db)) fs.writeFileSync(db, JSON.stringify(initial));
if (!fs.existsSync(statesDb)) fs.writeFileSync(statesDb, JSON.stringify({ visitors: {}, meta: {} }));

const json = (res, data, status = 200, req = null) => {
  let body = JSON.stringify(data), accept = String(req?.headers?.['accept-encoding'] || '');
  if (body.length > 1024 && accept.includes('gzip')) {
    let gz = zlib.gzipSync(body, { level: 4 });
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Encoding': 'gzip', 'Vary': 'Accept-Encoding', 'Cache-Control': 'no-store' });
    return res.end(gz);
  }
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
};

const cache = new Map();
async function remote(url, options = {}) {
  let ttl = options.ttl ?? 300000, c = cache.get(url);
  if (c && Date.now() - c.time < (c.ttl || ttl)) return c.data;
  let r = await fetch(url, {
    headers: { 'User-Agent': 'kozuTV/5.0 (catalog app)', ...(options.headers || {}) },
    signal: AbortSignal.timeout(options.timeout || 12000)
  });
  let text = await r.text();
  if (!r.ok) throw Error('Catalog unavailable (' + r.status + ')');
  let data;
  try { data = JSON.parse(text); } catch { throw Error('A catalog service returned an invalid response.'); }
  cache.set(url, { data, time: Date.now(), ttl });
  return data;
}

const genreNames = { 28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy', 80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family', 14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music', 9648: 'Mystery', 10749: 'Romance', 878: 'Sci-Fi', 10770: 'TV Movie', 53: 'Thriller', 10752: 'War', 37: 'Western', 10759: 'Action & Adventure', 10762: 'Kids', 10764: 'Reality', 10765: 'Sci-Fi & Fantasy', 10766: 'Soap', 10768: 'War' };
const catalogGenres = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Horror', 'Mecha', 'Music', 'Mystery', 'Psychological', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller'];
const movieGenreIds = { Action: 28, Adventure: 12, Animation: 16, Comedy: 35, Crime: 80, Documentary: 99, Drama: 18, Family: 10751, Fantasy: 14, History: 36, Horror: 27, Music: 10402, Mystery: 9648, Romance: 10749, 'Sci-Fi': 878, Thriller: 53, War: 10752, Western: 37 };
const movieKeywordIds = { Mecha: 10040, Psychological: 272553, 'Slice of Life': 258533, Sports: 6075, Supernatural: 6152 };
const tvGenreIds = { Action: 10759, Adventure: 10759, Animation: 16, Comedy: 35, Crime: 80, Documentary: 99, Drama: 18, Family: 10751, Fantasy: 10765, Mystery: 9648, 'Sci-Fi': 10765, War: 10768, Western: 37 };
const tvKeywordIds = { History: 282633, Horror: 315058, Mecha: 10040, Music: 283297, Psychological: 272553, Romance: 9840, 'Slice of Life': 258533, Sports: 6075, Supernatural: 6152, Thriller: 316362 };
const catalogLanguages = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'Hindi' },
  { code: 'ko', name: 'Korean' },
  { code: 'ja', name: 'Japanese' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'ta', name: 'Tamil' },
  { code: 'te', name: 'Telugu' },
  { code: 'ml', name: 'Malayalam' },
  { code: 'kn', name: 'Kannada' },
  { code: 'bn', name: 'Bengali' },
  { code: 'zh', name: 'Chinese' },
  { code: 'de', name: 'German' },
  { code: 'tr', name: 'Turkish' },
  { code: 'th', name: 'Thai' },
  { code: 'it', name: 'Italian' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ru', name: 'Russian' }
];
const validLangCodes = new Set(catalogLanguages.map(l => l.code));

const today = () => new Date().toISOString().slice(0, 10);
const releasedDate = value => Boolean(value) && /^\d{4}-\d{2}-\d{2}$/.test(String(value).slice(0, 10)) && String(value).slice(0, 10) <= today();

function decodeEntities(value) {
  return String(value || '')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&(amp|quot|apos|lt|gt|hellip|mdash|ndash);/g, (_, name) => ({ amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', hellip: '…', mdash: '—', ndash: '–' })[name]);
}
function normalizeTitle(value) {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/['’‘`]/g, '')
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
function parseAiredStartDate(aired, year) {
  const s = String(aired || '').split(/\s+to\s+/i)[0].trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  if (/^\d{4}-\d{2}$/.test(s)) return `${s}-01`;
  const m1 = s.match(/^([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})$/);
  if (m1) {
    const mo = MONTHS[m1[1].slice(0, 3).toLowerCase()];
    if (mo) return `${m1[3]}-${String(mo).padStart(2, '0')}-${String(m1[2]).padStart(2, '0')}`;
  }
  const m2 = s.match(/^([A-Za-z]{3,9})\s+(\d{4})$/);
  if (m2) {
    const mo = MONTHS[m2[1].slice(0, 3).toLowerCase()];
    if (mo) return `${m2[2]}-${String(mo).padStart(2, '0')}-01`;
  }
  if (/^\d{4}$/.test(s) && Number(s) > new Date().getFullYear()) return `${s}-01-01`;
  if (year && Number(year) > new Date().getFullYear()) return `${year}-01-01`;
  return '';
}

const megaCatalogPath = path.resolve('data/megaplay-catalog.json');
const animeOverridesPath = path.resolve('data/anime-episode-overrides.json');
let megaEntries = [], megaAliases = [], animeEpisodeOverrides = {};
try {
  let d = JSON.parse(fs.readFileSync(megaCatalogPath));
  megaEntries = Array.isArray(d.entries) ? d.entries : [];
  megaAliases = Array.isArray(d.aliases) ? d.aliases : [];
} catch {}
try {
  animeEpisodeOverrides = JSON.parse(fs.readFileSync(animeOverridesPath, 'utf8')) || {};
} catch {}

// Block legacy duplicate MAL entries that MegaPlay mis-maps (e.g. 501 Doraemon 1973 -> 8687 Doraemon 2005)
const MEGA_BLOCKED_MAL_IDS = new Set(['501', '2471']);
const MEGA_REDIRECT_MAL_MAP = new Map([['501', '8687'], ['2471', '8687']]);

const ANIME_REGIONAL_LANG_SET = new Set(['hi', 'ta', 'te', 'ml', 'kn', 'bn']);
const ANIME_VALID_LANG_SET = new Set(['sub', 'dub', 'hi', 'ta', 'te', 'ml', 'kn', 'bn']);
const SHINCHAN_REGIONAL_EPS = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18,19,20,22,23,24,27,28,29,30,31,32,34,35,37,39,44,46,47,50,51,52,53,54,55,56,57,63,64,65,68,69,71,78,79,80,81,85,86,88,96,98,100,101,103,105,106,107,108,109,111,112,115,116,117,122,124,126,127,130,132,142,143,145,146,147,148,150,153,154,155,170,176,183,195,196,198,199,201,203,205,208,209,210,211,215,217,218,219,220,221,222,223,224,225,226,229,237,240,241,242,243,245,248,251,253,256,262,263,264,265,266,267,271,272,274,283,284,287,289,290,291,293,297,298,300,302,303,304,305,306,312,315,316,318,319,323,328,331,332,334,336,347,348,349,350,351,353,354,355,356,357,358,360,361,362,365,366,367,371,372,375,380,381,382];
const SHINCHAN_REGIONAL_TOTAL = SHINCHAN_REGIONAL_EPS.length;
function mapShinchanRegionalEp(epNum) {
  const idx = Math.max(0, Math.min(SHINCHAN_REGIONAL_TOTAL - 1, (Math.floor(Number(epNum)) || 1) - 1));
  return SHINCHAN_REGIONAL_EPS[idx];
}
const DORAEMON_REGIONAL_RAW = [
  { season: 1, count: 52 },
  { season: 2, count: 51 },
  { season: 3, count: 52 },
  { season: 4, count: 52 },
  { season: 5, count: 52 },
  { season: 6, count: 52 },
  { season: 7, count: 52 },
  { season: 8, count: 51 },
  { season: 14, count: 52 },
  { season: 15, count: 52 },
  { season: 16, count: 50 },
  { season: 17, count: 47 },
  { season: 18, count: 51 },
  { season: 19, count: 51 },
  { season: 20, count: 45 }
];
let _doraCursor = 1;
const DORAEMON_REGIONAL_LIST = DORAEMON_REGIONAL_RAW.map(row => {
  const startEp = _doraCursor;
  const endEp = _doraCursor + row.count - 1;
  _doraCursor = endEp + 1;
  return {
    season: row.season,
    count: row.count,
    startEp,
    endEp,
    name: `Season ${row.season} (Ep ${startEp}–${endEp})`
  };
});
const DORAEMON_REGIONAL_TOTAL = _doraCursor - 1;

function mapDoraemonRegionalEp(globalEp) {
  const n = Math.max(1, Math.min(DORAEMON_REGIONAL_TOTAL, Number(globalEp) || 1));
  const found = DORAEMON_REGIONAL_LIST.find(r => n >= r.startEp && n <= r.endEp) || DORAEMON_REGIONAL_LIST[0];
  return {
    season: found.season,
    episode: n - found.startEp + 1,
    startEp: found.startEp,
    endEp: found.endEp
  };
}

// Pre-seed verified Shin Chan (966, 382 regional eps + 78-ep English Dub) and Doraemon (8687, 762 regional eps + 156-ep Japanese & 52-ep English Dub)
const CURATED_MEGA_SEEDS = [
  {
    id: 'mp-966',
    mal: '966',
    ani: '966',
    title: 'Shin Chan',
    english: 'Shin Chan',
    alternative: 'Crayon Shin-chan',
    titles: 'Shin Chan; Shinchan; Crayon Shin-chan; Shin-chan',
    native: 'クレヨンしんちゃん',
    poster: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/medium/b966-QUCdKAk4ls9J.jpg',
    backdrop: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/966-J5CwLLTBs4OO.jpg',
    description: 'Follow the outrageous everyday misadventures of five-year-old Shinnosuke "Shin-chan" Nohara, his parents Hiroshi and Misae, baby sister Himawari, dog Shiro, and classmates at Futaba Kindergarten.',
    year: 1992,
    status: 'Currently Airing',
    score: '7.78',
    popularity: 25000,
    genres: ['Comedy', 'Slice of Life'],
    format: 'TV',
    aired: '1992-04-13',
    episodes: SHINCHAN_REGIONAL_TOTAL,
    sub: false,
    dub: true,
    subCount: 0,
    dubCount: 78,
    regionalCount: SHINCHAN_REGIONAL_TOTAL,
    updated: '2024-01-01 00:00:00'
  },
  {
    id: 'mp-8687',
    mal: '8687',
    ani: '8687',
    title: 'Doraemon (2005)',
    english: 'Doraemon (2005)',
    alternative: 'Doraemon: Gadget Cat from the Future',
    titles: 'Doraemon; Doraemon (2005); Doraemon: Gadget Cat from the Future',
    native: 'ドラえもん (2005)',
    poster: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/medium/b8687-bBnJMGnih4PT.jpg',
    backdrop: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/8687-aa3QbJjGfy3B.jpg',
    description: 'Sent back in time from the 22nd century, robotic cat Doraemon uses futuristic gadgets from his fourth-dimensional pocket to help clumsy schoolboy Nobita Nobi navigate everyday mishaps and extraordinary adventures.',
    year: 2005,
    status: 'Currently Airing',
    score: '7.72',
    popularity: 22000,
    genres: ['Adventure', 'Comedy', 'Family', 'Sci-Fi'],
    format: 'TV',
    aired: '2005-04-15',
    episodes: DORAEMON_REGIONAL_TOTAL,
    sub: true,
    dub: true,
    subCount: 156,
    dubCount: 52,
    regionalCount: DORAEMON_REGIONAL_TOTAL,
    updated: '2024-01-01 00:00:00'
  }
];
for (const seed of CURATED_MEGA_SEEDS) {
  if (!megaEntries.some(e => String(e.mal) === seed.mal)) megaEntries.push(seed);
}

// Build alias set across ALL anime entries (including unreleased) so unreleased/unavailable anime on TMDB never leaks into Movies/TV
const megaAliasSet = new Set(megaAliases.map(normalizeTitle).filter(Boolean));
for (let entry of megaEntries) {
  for (let raw of [entry.title, entry.english, entry.alternative, ...String(entry.titles || '').split(/[;,]/)]) {
    let norm = normalizeTitle(raw);
    if (norm && norm.length >= 3) megaAliasSet.add(norm);
  }
}

function animeAliasMatch(title) {
  let key = normalizeTitle(title);
  if (!key) return false;
  if (megaAliasSet.has(key)) return true;
  for (let alias of megaAliasSet) {
    if (alias.length > 4 && (key === alias || key.startsWith(alias + ' ') || key.endsWith(' ' + alias))) return true;
  }
  return false;
}

function validAnikotoEntry(entry) {
  let year = Number(entry?.year) || 0;
  if (!entry?.mal || !entry?.id || !entry?.poster) return false;
  if (!(Number(entry.episodes) > 0)) return false;
  if (year > new Date().getFullYear()) return false;
  if (/not yet|upcoming|unreleased/i.test(entry.status || '')) return false;
  let start = parseAiredStartDate(entry.aired, entry.year);
  if (start && start > today()) return false;
  return true;
}

// Strict MegaPlay playable maps ONLY contain released, streamable MegaPlay entries!
const megaByMal = new Map(), megaByAni = new Map();
const playableMegaEntries = megaEntries.filter(validAnikotoEntry);
for (let entry of playableMegaEntries) {
  if (entry.mal && !megaByMal.has(String(entry.mal))) megaByMal.set(String(entry.mal), entry);
  if (entry.ani && !megaByAni.has(String(entry.ani))) megaByAni.set(String(entry.ani), entry);
}
function megaForMedia(media) { return megaByAni.get(String(media?.id || '')) || megaByMal.get(String(media?.idMal || '')) || null; }
function megaForIds(mal, ani) { return megaByMal.get(String(mal || '')) || megaByAni.get(String(ani || '')) || null; }

const japaneseAnimation = x => {
  let animated = Boolean(x.genre_ids?.includes(16) || x.genres?.some(g => g.id === 16 || g.name === 'Animation'));
  if (!animated) return false;
  let origLang = String(x.original_language || '').toLowerCase();
  let countries = Array.isArray(x.origin_country) ? x.origin_country : [];
  return origLang === 'ja' || countries.includes('JP');
};

function makeFallbackPosterDataUri(title, year, type) {
  const safeTitle = String(title || 'Untitled').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).slice(0, 42);
  const badge = type === 'tv' ? 'SERIES' : 'MOVIE';
  const yr = String(year || '').replace(/[^0-9]/g, '').slice(0, 4);
  const sub = yr ? `${badge} • ${yr}` : badge;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1e222d"/><stop offset="100%" stop-color="#12141b"/></linearGradient></defs><rect width="400" height="600" fill="url(#g)"/><circle cx="320" cy="90" r="140" fill="#ff731c" fill-opacity="0.08"/><rect x="32" y="42" width="44" height="4" rx="2" fill="#ff731c"/><text x="32" y="500" fill="#ff731c" font-family="sans-serif" font-size="15" font-weight="700" letter-spacing="2">${sub}</text><text x="32" y="538" fill="#f3f4f8" font-family="sans-serif" font-size="24" font-weight="800">${safeTitle}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

const UNRELEASED_OTT_STATUSES = new Set(['rumored', 'planned', 'in production', 'post production', 'pilot', 'canceled']);
function releasedOtt(x, minVotes = 0, requirePoster = true) {
  if (!x || x.adult) return false;
  if (requirePoster && !x.poster_path && !x.backdrop_path) return false;
  if (!(x.title || x.name)) return false;
  if (!releasedDate(x.release_date || x.first_air_date)) return false;
  if (x.status && UNRELEASED_OTT_STATUSES.has(String(x.status).toLowerCase())) {
    if (!(String(x.status).toLowerCase() === 'canceled' && Number(x.number_of_episodes) > 0)) return false;
  }
  if ((x.media_type === 'tv' || (!x.media_type && x.first_air_date)) && x.number_of_episodes !== undefined && Number(x.number_of_episodes) <= 0) {
    return false;
  }
  let votes = Number(x.vote_count) || 0, pop = Number(x.popularity) || 0;
  if (minVotes > 0 && votes < minVotes && pop < 5) return false;
  if (japaneseAnimation(x)) return false;
  return true;
}

const ott = x => {
  const mediaType = x.media_type === 'tv' || (!x.media_type && x.first_air_date) ? 'tv' : 'movie';
  const title = x.title || x.name || '';
  const year = (x.release_date || x.first_air_date || '').slice(0, 4);
  const poster = x.poster_path
    ? 'https://image.tmdb.org/t/p/w500' + x.poster_path
    : (x.backdrop_path ? 'https://image.tmdb.org/t/p/w500' + x.backdrop_path : makeFallbackPosterDataUri(title, year, mediaType));
  return {
    id: String(x.id),
    type: mediaType,
    title,
    originalTitle: x.original_title || x.original_name || '',
    poster,
    backdrop: x.backdrop_path ? 'https://image.tmdb.org/t/p/original' + x.backdrop_path : null,
    description: x.overview || '',
    rating: x.vote_average ? Number(x.vote_average.toFixed(1)) : null,
    popularity: Number(x.popularity) || 0,
    voteCount: Number(x.vote_count) || 0,
    year,
    releaseDate: x.release_date || x.first_air_date || null,
    originalLanguage: String(x.original_language || '').toLowerCase(),
    japaneseAnimation: japaneseAnimation(x),
    genres: x.genres?.map(g => g.name) || x.genre_ids?.map(id => genreNames[id]).filter(Boolean) || [],
    seasons: x.number_of_seasons
  };
};

const aniCache = new Map();
async function anilist(query, variables = {}, timeout = 10000) {
  let key = JSON.stringify([query, variables]), cached = aniCache.get(key);
  if (cached && Date.now() - cached.time < 300000) return cached.data;
  let r = await fetch('https://graphql.anilist.co', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
    signal: AbortSignal.timeout(timeout)
  });
  if (!r.ok) throw Error('Anime catalog unavailable');
  let text = await r.text(), d;
  try { d = JSON.parse(text); } catch { throw Error('Anime catalog returned an invalid response.'); }
  if (d.errors) throw Error(d.errors[0].message);
  aniCache.set(key, { data: d.data, time: Date.now() });
  return d.data;
}

const fields = 'id idMal title{english romaji native} synonyms popularity coverImage{extraLarge large} bannerImage description(asHtml:false) averageScore format seasonYear startDate{year month day} episodes nextAiringEpisode{episode} genres status isAdult';
const positiveInt = value => Number.isInteger(Number(value)) && Number(value) > 0 ? Number(value) : null;
function animeEpisodeCount(media) {
  if (media.format === 'MOVIE' || media.status === 'NOT_YET_RELEASED') return null;
  let total = positiveInt(media.episodes);
  if (media.status === 'RELEASING') {
    let released = positiveInt((media.nextAiringEpisode?.episode || 1) - 1);
    if (released) return total ? Math.min(total, released) : released;
  }
  return total;
}

const spotlightCatalogPath = path.resolve('data/spotlight.json');
let spotlightCatalog = [];
try {
  let d = JSON.parse(fs.readFileSync(spotlightCatalogPath, 'utf8'));
  if (Array.isArray(d)) {
    spotlightCatalog = d.filter(x => x?.id && x?.type && x?.title && x?.backdrop && x?.spotlightBanner && (x.type !== 'anime' || megaByMal.has(String(x.id))));
  }
} catch {}

function cryptoShuffle(list) {
  let a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    let j = crypto.randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function buildRandomizedSpotlight() {
  if (!spotlightCatalog.length) return [];
  let isRomance = x => (x.genres || []).some(g => /romance/i.test(g));
  let romance = cryptoShuffle(spotlightCatalog.filter(isRomance));
  let others = cryptoShuffle(spotlightCatalog.filter(x => !isRomance(x)));
  let romCount = Math.min(romance.length, crypto.randomInt(2, 4));
  let lead = cryptoShuffle([...romance.slice(0, romCount), ...others.slice(0, Math.max(0, 6 - romCount))]);
  let tail = cryptoShuffle([...romance.slice(romCount), ...others.slice(Math.max(0, 6 - romCount))]);
  return [...lead, ...tail];
}

function releasedAnime(media) {
  if (!['FINISHED', 'RELEASING'].includes(media?.status)) return false;
  let d = media.startDate;
  if (!d?.year) return false;
  let date = `${d.year}-${String(d.month || 1).padStart(2, '0')}-${String(d.day || 1).padStart(2, '0')}`;
  if (date > today()) return false;
  if (media.status === 'RELEASING' && media.nextAiringEpisode?.episode === 1) return false;
  return true;
}

async function anikotoSeries(providerId) {
  if (!providerId || !/^\d+$/.test(String(providerId))) return null;
  let d = await remote(`https://anikotoapi.site/series/${encodeURIComponent(providerId)}`, { ttl: 21600000, timeout: 9000, headers: { Accept: 'application/json' } });
  if (!d.ok || !d.data?.anime || !Array.isArray(d.data.episodes)) throw Error('MegaPlay returned an invalid series response.');
  return d.data;
}

function cleanAnimeDisplayTitle(entry) {
  let primary = decodeEntities(entry.title || '').replace(/\s*\(TV\)\s*$/i, '').trim();
  let cjkIdx = primary.search(/[\u3040-\u30ff\u3400-\u9fff]/);
  if (cjkIdx > 6) primary = primary.slice(0, cjkIdx).trim();
  let engFirst = decodeEntities(String(entry.english || '').split(';')[0]).replace(/\s*\(TV\)\s*$/i, '').trim();
  if (primary && !/[\u3040-\u30ff\u3400-\u9fff]/.test(primary)) {
    if (
      engFirst.length > 4 &&
      !/^(Sorcery Fight|Blade of Demon Destruction|Na Honjaman|Naruto Hurricane|AoT$)/i.test(engFirst) &&
      /\b(Link Click|Bungo Stray Dogs|Kaguya-sama|My Dress-Up Darling|Frieren|Chainsaw Man|Spy x Family|My Hero Academia|Demon Slayer|Attack on Titan|Fullmetal Alchemist|Hunter x Hunter|Mob Psycho|Steins;Gate|Re:Zero|Konosuba|Mushoku Tensei|That Time I Got Reincarnated|Apothecary Diaries|Blue Box|Dandadan|Oshi no Ko|Haikyu|Vinland Saga| Rascal Does Not Dream|Fruits Basket|Violet Evergarden|Code Geass|Your Lie in April|Assassination Classroom|promised Neverland|Tokyo Ghoul|Black Clover|Fire Force|Dr\. Stone|Overlord|Classroom of the Elite|Horimiya|Toradora)\b/i.test(engFirst)
    ) {
      return engFirst;
    }
    return primary;
  }
  return engFirst.length > 2 ? engFirst : primary;
}

function anikotoItem(entry) {
  let format = String(entry.format || '').toUpperCase(), isMovie = format.includes('MOVIE');
  let score = Number.parseFloat(entry.score);
  let displayTitle = cleanAnimeDisplayTitle(entry);
  let status = /currently/i.test(entry.status) ? 'RELEASING' : 'FINISHED';
  let cleanDesc = decodeEntities(entry.description || '').replace(/\s*\[Written by MAL Rewrite\]\s*$/i, '').trim();
  return {
    id: String(entry.mal),
    anilistId: entry.ani ? String(entry.ani) : null,
    type: 'anime',
    title: displayTitle,
    poster: entry.poster || null,
    backdrop: entry.backdrop || null,
    description: cleanDesc,
    rating: Number.isFinite(score) && score > 0 ? score : null,
    popularity: Number(entry.popularity) || 0,
    year: entry.year || null,
    episodes: isMovie ? null : entry.episodes,
    episodeCountKind: 'available',
    genres: entry.genres || [],
    status,
    format,
    isMovie,
    playable: true,
    providerId: entry.id,
    sub: entry.sub !== false,
    dub: Boolean(entry.dub),
    subCount: Number.isInteger(entry.subCount) ? entry.subCount : null,
    dubCount: Number.isInteger(entry.dubCount) ? entry.dubCount : null,
    differentDubOrder: Boolean(animeEpisodeOverrides[String(entry.mal)]?.differentDubOrder),
    updated: entry.updated || ''
  };
}

const anikotoItems = playableMegaEntries.map(anikotoItem);

const ani = x => {
  let isMovie = x.format === 'MOVIE', provider = megaForMedia(x);
  let episodes = animeEpisodeCount(x) || (isMovie ? null : positiveInt(provider?.episodes));
  return {
    id: String(x.idMal),
    anilistId: String(x.id),
    type: 'anime',
    title: x.title?.english || x.title?.romaji || provider?.english || provider?.title || '',
    poster: x.coverImage?.extraLarge || x.coverImage?.large || provider?.poster,
    backdrop: x.bannerImage || provider?.backdrop || x.coverImage?.extraLarge,
    description: (x.description || '').replace(/<[^>]*>/g, '') || provider?.description || '',
    rating: x.averageScore ? Number((x.averageScore / 10).toFixed(1)) : (provider?.score ? Number.parseFloat(provider.score) : null),
    popularity: Number(x.popularity) || 0,
    year: x.seasonYear || x.startDate?.year || provider?.year,
    episodes,
    episodeCountKind: x.status === 'RELEASING' ? 'released' : 'total',
    genres: x.genres?.length ? x.genres : (provider?.genres || []),
    status: x.status,
    format: x.format || provider?.format || null,
    isMovie,
    playable: Boolean(provider),
    providerId: provider?.id || null,
    dub: Boolean(provider?.dub)
  };
};

// ============================================================================
// V5.2.0 High-Precision Popularity-Driven Search Index & Ranking Engine
// ============================================================================
const STOP_WORDS = new Set(['the', 'a', 'an', 'of', 'in', 'on', 'at', 'to', 'for', 'and', 'no', 'ni', 'wa', 'ga', 'wo']);

// Curated real-world abbreviations & franchise aliases (prevents noisy random 3-letter acronyms like "end" -> "Egao no Daika")
const CURATED_OTT_ALIASES = new Map([
  ['tv:1399', ['got', 'song of ice and fire']],
  ['tv:94997', ['hotd']],
  ['tv:1396', ['brba']],
  ['tv:60059', ['bcs']],
  ['tv:2316', ['the office us']],
  ['movie:299534', ['endgame', 'end game', 'avengers 4', 'mcu']],
  ['movie:299536', ['infinity war', 'avengers 3', 'mcu']],
  ['movie:24428', ['avengers 1', 'mcu']],
  ['movie:99861', ['age of ultron', 'avengers 2', 'mcu']],
  ['movie:155', ['batman', 'batman dark knight', 'tdk']],
  ['movie:49026', ['batman', 'batman dark knight rises', 'tdkr']],
  ['movie:120', ['lotr', 'fellowship of the ring']],
  ['movie:121', ['lotr', 'two towers']],
  ['movie:122', ['lotr', 'return of the king', 'rotk']],
  ['movie:634649', ['nwh', 'spiderman no way home', 'spiderman 3']],
  ['movie:569094', ['atsv', 'spiderverse', 'spider verse']],
  ['movie:324857', ['itsv', 'spiderverse', 'spider verse']],
  ['movie:671', ['hp', 'philosophers stone', 'sorcerers stone']]
]);

const CURATED_ANIME_ACRONYMS = new Map([
  ['16498', ['aot']],
  ['40748', ['jjk']],
  ['31964', ['mha', 'bnha']],
  ['5114', ['fmab', 'fma brotherhood']],
  ['11061', ['hxh']],
  ['11757', ['sao']],
  ['30276', ['opm']],
  ['44511', ['csm']],
  ['1535', ['dn']],
  ['21', ['op']],
  ['38000', ['kny', 'ds']],
  ['52991', ['frieren', 'beyond journeys end']],
  ['52299', ['sl', 'ore dake level up na ken']],
  ['32281', ['kimi no na wa']]
]);

function extractSubtitleParts(rawTitle) {
  const s = String(rawTitle || '').trim();
  if (!s) return [];
  const parts = [];
  for (const piece of s.split(/\s*[:–—]\s*|\s+-\s+/)) {
    const n = normalizeTitle(piece);
    if (n && n.length >= 3) parts.push(n);
  }
  return parts;
}

// Unified 0..1000 Backend Popularity Meter across Movies, Web Series & Anime
function computePopularityMeter(item) {
  if (!item) return 20;
  if (item.type === 'anime') {
    const aniPop = Math.max(0, Number(item.popularity) || 250);
    const curve = 1000 * (1 - Math.exp(-aniPop / 210000)) * 0.72;
    const logPart = Math.min(280, Math.log10(1 + aniPop / 25) * 62);
    return Math.max(10, Math.min(1000, curve + logPart));
  }
  const votes = Math.max(0, Number(item.voteCount) || 0);
  const pop = Math.max(0, Number(item.popularity) || 0);
  const effectiveVotes = item.type === 'tv' ? votes * 1.75 : votes;
  const voteMeter = 1000 * (1 - Math.exp(-effectiveVotes / 8500)) * 0.72 + Math.min(280, Math.log10(1 + effectiveVotes) * 62);
  const trendMeter = votes >= 80 ? Math.min(860, Math.log10(1 + pop) * 305) : Math.min(220, Math.log10(1 + pop) * 95);
  return Math.max(8, Math.min(1000, Math.max(voteMeter, voteMeter * 0.65 + trendMeter * 0.45)));
}

function buildIndexedAnimeRecord(entry, item) {
  const primaryNorm = normalizeTitle(item.title);
  const rawNames = [
    item.title,
    entry.title,
    entry.english,
    entry.alternative,
    entry.native,
    ...String(entry.titles || '').split(/[;,]/),
  ];
  const candSet = new Set();
  const subtitleSet = new Set();
  for (const r of rawNames) {
    const n = normalizeTitle(r);
    if (n) candSet.add(n);
    for (const sub of extractSubtitleParts(r)) {
      if (sub !== n) subtitleSet.add(sub);
    }
  }
  for (const ac of CURATED_ANIME_ACRONYMS.get(String(entry.mal)) || []) {
    candSet.add(ac);
  }
  // Only add >=4-char acronyms for genuinely popular anime (prevents obscure 3-letter collisions like "end" or "bat")
  if ((Number(entry.popularity) || 0) >= 120000) {
    for (const n of [...candSet]) {
      const words = n.split(' ').filter(w => w.length > 0 && !/^\d+$/.test(w));
      if (words.length >= 4 && words.length <= 7) {
        const ac = words.map(w => w[0]).join('');
        if (ac.length >= 4) subtitleSet.add(ac);
      }
    }
  }
  const candidates = [...candSet];
  const subtitles = [...subtitleSet];
  const compacts = candidates.map(c => c.replace(/\s+/g, '')).filter(Boolean);
  const subCompacts = subtitles.map(c => c.replace(/\s+/g, '')).filter(Boolean);
  const wordSet = new Set();
  for (const c of [...candidates, ...subtitles]) {
    for (const w of c.split(' ')) if (w) wordSet.add(w);
  }
  const popMeter = computePopularityMeter(item);
  return {
    entry,
    item,
    primaryNorm,
    primaryCompact: primaryNorm.replace(/\s+/g, ''),
    candidates,
    compacts,
    subtitles,
    subCompacts,
    words: [...wordSet],
    popMeter
  };
}

const indexedAnime = playableMegaEntries.map((entry, rankIdx) => buildIndexedAnimeRecord(entry, anikotoItems[rankIdx]));

// Load Top ~2,630 Popular TMDB Movies & Web Series Index for instant 0ms blockbuster recall (e.g. "end" -> "Avengers: Endgame")
const popularOttCatalogPath = path.resolve('data/ott-popular-catalog.json');
const indexedPopularOtt = [];
try {
  const rawPop = JSON.parse(fs.readFileSync(popularOttCatalogPath, 'utf8'));
  for (const row of rawPop?.entries || []) {
    if (!row?.id || !row?.title) continue;
    const item = {
      id: String(row.id),
      type: row.type === 'tv' ? 'tv' : 'movie',
      title: row.title,
      originalTitle: row.originalTitle || '',
      poster: row.poster || null,
      backdrop: row.backdrop || null,
      description: row.description || '',
      rating: row.rating ?? null,
      popularity: Number(row.popularity) || 0,
      voteCount: Number(row.voteCount) || 0,
      year: row.year || '',
      releaseDate: row.releaseDate || null,
      japaneseAnimation: false,
      genres: (row.genreIds || []).map(id => genreNames[id]).filter(Boolean)
    };
    const primaryNorm = normalizeTitle(item.title);
    const oNorm = normalizeTitle(item.originalTitle);
    const candSet = new Set([primaryNorm, oNorm].filter(Boolean));
    const subSet = new Set();
    for (const rawName of [item.title, item.originalTitle]) {
      for (const sub of extractSubtitleParts(rawName)) {
        if (!candSet.has(sub)) subSet.add(sub);
      }
    }
    for (const alias of CURATED_OTT_ALIASES.get(`${item.type}:${item.id}`) || []) {
      const n = normalizeTitle(alias);
      if (n) subSet.add(n);
    }
    const candidates = [...candSet];
    const subtitles = [...subSet];
    const compacts = candidates.map(c => c.replace(/\s+/g, '')).filter(Boolean);
    const subCompacts = subtitles.map(c => c.replace(/\s+/g, '')).filter(Boolean);
    const wordSet = new Set();
    for (const c of [...candidates, ...subtitles]) {
      for (const w of c.split(' ')) if (w) wordSet.add(w);
    }
    indexedPopularOtt.push({
      key: `${item.type}:${item.id}`,
      item,
      primaryNorm,
      primaryCompact: primaryNorm.replace(/\s+/g, ''),
      candidates,
      compacts,
      subtitles,
      subCompacts,
      words: [...wordSet],
      popMeter: computePopularityMeter(item)
    });
  }
} catch {}

const megaMissCache = new Map();
async function probeMegaPlayEmbedUrl(url) {
  try {
    let r = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        Referer: 'https://megaplay.buzz/'
      },
      signal: AbortSignal.timeout(4200)
    });
    if (!r.ok) return false;
    let html = await r.text();
    return Boolean(html.match(/data-id=["']?(\d+)/)?.[1] || html.match(/File\s+(\d+)\s+-/)?.[1]);
  } catch {
    return false;
  }
}

async function ensureDynamicMegaEntry(malId, mediaOpt = null) {
  const malStr = String(malId || '');
  if (!/^\d+$/.test(malStr) || MEGA_BLOCKED_MAL_IDS.has(malStr)) return null;
  if (megaByMal.has(malStr)) return megaByMal.get(malStr);
  const missTs = megaMissCache.get(malStr);
  if (missTs && Date.now() - missTs < 900_000) return null;

  const media = mediaOpt || await animeRecord(malStr, false).catch(() => null);
  if (!media || media.isAdult || !releasedAnime(media)) {
    megaMissCache.set(malStr, Date.now());
    return null;
  }
  const aniStr = String(media.id || '');
  const [subMal, dubMal] = await Promise.all([
    probeMegaPlayEmbedUrl(`https://megaplay.buzz/stream/mal/${malStr}/1/sub`),
    probeMegaPlayEmbedUrl(`https://megaplay.buzz/stream/mal/${malStr}/1/dub`)
  ]);
  let subOk = subMal, dubOk = dubMal;
  if (!subOk && !dubOk && aniStr && aniStr === malStr) {
    const [subAni, dubAni] = await Promise.all([
      probeMegaPlayEmbedUrl(`https://megaplay.buzz/stream/ani/${aniStr}/1/sub`),
      probeMegaPlayEmbedUrl(`https://megaplay.buzz/stream/ani/${aniStr}/1/dub`)
    ]);
    subOk = subAni;
    dubOk = dubAni;
  }
  if (!subOk && !dubOk) {
    megaMissCache.set(malStr, Date.now());
    return null;
  }

  const isMovie = media.format === 'MOVIE';
  const fmtMap = { MOVIE: 'Movie', TV: 'TV', TV_SHORT: 'TV_SHORT', ONA: 'ONA', OVA: 'OVA', SPECIAL: 'Special' };
  const eng = String(media.title?.english || '').trim();
  const rom = String(media.title?.romaji || '').trim();
  const nat = String(media.title?.native || '').trim();
  const syns = Array.isArray(media.synonyms) ? media.synonyms.filter(Boolean) : [];
  const allTitles = [...new Set([eng, rom, nat, ...syns].filter(Boolean))].join('; ');
  const sd = media.startDate || {};
  const entry = {
    id: `mp-${malStr}`,
    mal: malStr,
    ani: aniStr,
    title: eng || rom || nat,
    english: eng || rom,
    alternative: rom || eng,
    titles: allTitles,
    native: nat,
    poster: media.coverImage?.extraLarge || media.coverImage?.large || '',
    backdrop: media.bannerImage || media.coverImage?.extraLarge || '',
    description: String(media.description || '').replace(/<[^>]*>/g, '').trim(),
    year: sd.year || media.seasonYear || null,
    status: media.status === 'RELEASING' ? 'Currently Airing' : 'Finished Airing',
    score: media.averageScore ? (media.averageScore / 10).toFixed(2) : '',
    popularity: Number(media.popularity) || 0,
    genres: Array.isArray(media.genres) ? media.genres : [],
    format: fmtMap[media.format] || 'TV',
    aired: sd.year ? `${sd.year}-${String(sd.month || 1).padStart(2, '0')}-${String(sd.day || 1).padStart(2, '0')}` : '',
    episodes: isMovie ? 1 : (animeEpisodeCount(media) || 1),
    sub: Boolean(subOk),
    dub: Boolean(dubOk),
    updated: `${sd.year || media.seasonYear || 2024}-01-01 00:00:00`
  };
  if (!megaByMal.has(malStr)) {
    megaByMal.set(malStr, entry);
    if (aniStr && !megaByAni.has(aniStr)) megaByAni.set(aniStr, entry);
    const item = anikotoItem(entry);
    anikotoItems.push(item);
    indexedAnime.push(buildIndexedAnimeRecord(entry, item));
    for (const raw of [entry.title, entry.english, entry.alternative, ...syns]) {
      const n = normalizeTitle(raw);
      if (n && n.length >= 3) megaAliasSet.add(n);
    }
  }
  return megaByMal.get(malStr);
}

function editDistanceAtMost(a, b, maxDist) {
  const la = a.length, lb = b.length;
  if (Math.abs(la - lb) > maxDist) return maxDist + 1;
  if (a === b) return 0;
  let prev = new Uint16Array(lb + 1);
  let curr = new Uint16Array(lb + 1);
  for (let j = 0; j <= lb; j++) prev[j] = j;
  for (let i = 1; i <= la; i++) {
    curr[0] = i;
    let rowMin = curr[0];
    const ca = a.charCodeAt(i - 1);
    for (let j = 1; j <= lb; j++) {
      const cost = ca === b.charCodeAt(j - 1) ? 0 : 1;
      const v = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
      curr[j] = v;
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > maxDist) return maxDist + 1;
    [prev, curr] = [curr, prev];
  }
  return prev[lb];
}

function scoreCandidateMatch(qNorm, qCompact, qWords, primaryNorm, primaryCompact, candidates, compacts, allWords, subtitles = [], subCompacts = []) {
  if (!qNorm) return 0;
  let best = 0;

  // 1. Primary & full-alias matching
  if (primaryNorm === qNorm || (qCompact.length >= 2 && primaryCompact === qCompact)) {
    best = Math.max(best, 1620);
  }
  for (let i = 0; i < candidates.length; i++) {
    const c = candidates[i], cc = compacts[i];
    const noArt = c.replace(/^(?:the|a|an)\s+/, '');
    if (c === qNorm || (qCompact.length >= 3 && cc === qCompact)) {
      best = Math.max(best, 1580);
    } else if (noArt && noArt !== c && noArt === qNorm) {
      best = Math.max(best, c === primaryNorm ? 1560 : 1510);
    } else if (c.startsWith(qNorm + ' ') || c.startsWith(qNorm)) {
      const penalty = Math.min(180, Math.max(0, c.length - qNorm.length) * 2.5);
      best = Math.max(best, (c === primaryNorm ? 1360 : 1240) - penalty);
    } else if (noArt && (noArt.startsWith(qNorm + ' ') || noArt.startsWith(qNorm))) {
      const penalty = Math.min(180, Math.max(0, noArt.length - qNorm.length) * 2.5);
      best = Math.max(best, (c === primaryNorm ? 1330 : 1210) - penalty);
    } else if (qCompact.length >= 3 && cc.startsWith(qCompact)) {
      const penalty = Math.min(180, Math.max(0, cc.length - qCompact.length) * 2.5);
      best = Math.max(best, 1220 - penalty);
    } else if ((' ' + c + ' ').includes(' ' + qNorm + ' ')) {
      best = Math.max(best, c === primaryNorm ? 1140 : 1040);
    } else if (qCompact.length >= 4 && cc.includes(qCompact)) {
      best = Math.max(best, 940);
    }
  }

  // 2. Subtitle / post-colon & curated franchise alias matching (e.g. "Avengers: Endgame" -> "endgame" matches "end" & "end game"!)
  for (let i = 0; i < subtitles.length; i++) {
    const sub = subtitles[i], sc = subCompacts[i] || sub.replace(/\s+/g, '');
    const noArt = sub.replace(/^(?:the|a|an)\s+/, '');
    if (sub === qNorm || (qCompact.length >= 2 && sc === qCompact) || (noArt && noArt === qNorm)) {
      best = Math.max(best, 1520);
    } else if (sub.startsWith(qNorm + ' ') || sub.startsWith(qNorm) || (noArt && noArt.startsWith(qNorm))) {
      const penalty = Math.min(150, Math.max(0, sub.length - qNorm.length) * 2.5);
      best = Math.max(best, 1260 - penalty);
    } else if (qCompact.length >= 3 && sc.startsWith(qCompact)) {
      const penalty = Math.min(150, Math.max(0, sc.length - qCompact.length) * 2.5);
      best = Math.max(best, 1200 - penalty);
    } else if ((' ' + sub + ' ').includes(' ' + qNorm + ' ')) {
      best = Math.max(best, 1080);
    }
  }

  if (best >= 1200) return best;

  // 3. Multi-word / prefix token match within a single candidate or subtitle
  if (qWords.length >= 1) {
    for (const c of [...candidates, ...subtitles]) {
      const cWords = c.split(' ');
      if (qWords.every(qw => cWords.some(cw => cw.startsWith(qw)))) {
        const lenDiff = Math.min(160, Math.max(0, cWords.length - qWords.length) * 18);
        best = Math.max(best, (c === primaryNorm ? 1120 : 1020) - lenDiff);
      }
    }
  }
  if (best >= 980) return best;

  // 4. Cross-alias prefix + fuzzy typo tolerance (handles "frieran", "interstelar", "jujtsu", "spider verse", etc.)
  const sigWords = qWords.filter(w => !STOP_WORDS.has(w));
  const checkWords = sigWords.length ? sigWords : qWords;
  let exactOrPrefixHits = 0;
  let fuzzyHits = 0;
  for (const qw of checkWords) {
    if (allWords.some(cw => cw === qw || (qw.length >= 3 && cw.startsWith(qw)))) {
      exactOrPrefixHits++;
      continue;
    }
    if (qw.length >= 4) {
      const maxEd = qw.length >= 7 ? 2 : 1;
      if (allWords.some(cw => cw.length >= 3 && editDistanceAtMost(qw, cw.slice(0, Math.max(cw.length, qw.length)), maxEd) <= maxEd)) {
        fuzzyHits++;
      }
    }
  }
  const totalMatched = exactOrPrefixHits + fuzzyHits;
  if (totalMatched === checkWords.length && checkWords.length > 0) {
    best = Math.max(best, fuzzyHits === 0 ? 860 : 640 - fuzzyHits * 35);
  } else if (checkWords.length >= 2 && totalMatched / checkWords.length >= 0.66 && exactOrPrefixHits >= 1) {
    best = Math.max(best, Math.round(420 * (totalMatched / checkWords.length)));
  }

  return best;
}

// Combines text relevance with the 0..1000 Backend Popularity Meter so popular titles always rise to the top
function finalizeSearchScore(baseMatchScore, item, qNorm, popMeterOpt = null) {
  if (baseMatchScore <= 0) return 0;
  const popMeter = popMeterOpt !== null ? popMeterOpt : computePopularityMeter(item);

  // Dampen exact-name monopoly of obscure micro-titles (< 220 popMeter) so global hits aren't buried under 3-vote films
  const credibility = Math.min(1, 0.36 + popMeter / 280);
  let score = baseMatchScore * credibility;

  // Strong backend popularity meter weight (0 .. 1900 pts) + subtle rating tie-breaker
  score += popMeter * 1.9;
  score += (Number(item.rating) || 0) * 9;

  // Subtle boost to root/main series over specials/recaps unless user explicitly searched for season/movie/ova/special
  const lowerTitle = String(item.title || '').toLowerCase();
  const wantsSubEntry = /\b(season|part|cour|ova|special|movie|film|recap)\b|\b[2-9]\b/.test(qNorm);
  if (!wantsSubEntry) {
    if (item.type === 'anime') {
      const fmt = String(item.format || '').toUpperCase();
      if (fmt === 'TV') score += 35;
      else if (fmt === 'MOVIE') score += 20;
      else if (fmt === 'SPECIAL' || fmt === 'OVA') score -= 55;
      if (/\b(season\s*[2-9]|2nd\s*season|3rd\s*season|4th\s*season|part\s*[2-9]|ova|special)\b/i.test(lowerTitle)) {
        score -= 40;
      }
    } else {
      score += 20;
    }
  }
  return score;
}

function searchLocalMegaPlay(term, extraAniMap = null) {
  const qNorm = normalizeTitle(term);
  if (!qNorm) return [];
  const qCompact = qNorm.replace(/\s+/g, '');
  const qWords = qNorm.split(' ').filter(Boolean);
  const results = [];

  for (const rec of indexedAnime) {
    let extraBoost = 0;
    const aniExtra = extraAniMap?.get(rec.item.id);
    let candidates = rec.candidates, compacts = rec.compacts, words = rec.words;
    if (aniExtra) {
      extraBoost = 80;
      if (aniExtra.extraCands.length) {
        const merged = new Set([...rec.candidates, ...aniExtra.extraCands]);
        candidates = [...merged];
        compacts = candidates.map(c => c.replace(/\s+/g, ''));
        const ws = new Set(rec.words);
        for (const c of aniExtra.extraCands) for (const w of c.split(' ')) if (w) ws.add(w);
        words = [...ws];
      }
    }
    let mScore = scoreCandidateMatch(qNorm, qCompact, qWords, rec.primaryNorm, rec.primaryCompact, candidates, compacts, words, rec.subtitles, rec.subCompacts);
    if (mScore <= 0 && aniExtra) mScore = 760;
    if (mScore <= 0) continue;
    const enrichedItem = aniExtra?.mediaItem ? {
      ...rec.item,
      popularity: Math.max(Number(rec.item.popularity) || 0, Number(aniExtra.popularity) || 0),
      backdrop: rec.item.backdrop || aniExtra.mediaItem.backdrop,
      rating: rec.item.rating || aniExtra.mediaItem.rating
    } : rec.item;
    const popMeter = aniExtra?.popularity ? computePopularityMeter(enrichedItem) : rec.popMeter;
    const total = finalizeSearchScore(mScore + extraBoost, enrichedItem, qNorm, popMeter);
    results.push({ item: enrichedItem, score: total, popMeter });
  }
  results.sort((a, b) => b.score - a.score);
  return results.slice(0, 240);
}

function scoreOttSearchItem(rawTmdb, qNorm, qCompact, qWords, allowTranslatedFallback = true) {
  const item = ott(rawTmdb);
  const pNorm = normalizeTitle(item.title);
  const oNorm = normalizeTitle(item.originalTitle);
  const candidates = [pNorm, oNorm].filter(Boolean);
  const compacts = candidates.map(c => c.replace(/\s+/g, ''));
  const subSet = new Set();
  for (const r of [item.title, item.originalTitle]) {
    for (const sub of extractSubtitleParts(r)) {
      if (!candidates.includes(sub)) subSet.add(sub);
    }
  }
  for (const al of CURATED_OTT_ALIASES.get(`${item.type}:${item.id}`) || []) {
    const n = normalizeTitle(al);
    if (n) subSet.add(n);
  }
  const subtitles = [...subSet];
  const subCompacts = subtitles.map(c => c.replace(/\s+/g, ''));
  const wordSet = new Set();
  for (const c of [...candidates, ...subtitles]) for (const w of c.split(' ')) if (w) wordSet.add(w);
  let mScore = scoreCandidateMatch(qNorm, qCompact, qWords, pNorm, pNorm.replace(/\s+/g, ''), candidates, compacts, [...wordSet], subtitles, subCompacts);
  if (mScore <= 0) {
    if (allowTranslatedFallback) mScore = 480;
    else if ((item.voteCount >= 120 || item.popularity >= 25) && qNorm.length >= 3) mScore = 500;
    else return null;
  }
  const popMeter = computePopularityMeter(item);
  return { item, score: finalizeSearchScore(mScore, item, qNorm || pNorm || 'q', popMeter), popMeter };
}

function animePopRank(item) {
  const aniPop = Number(item.popularity) || 0;
  if (aniPop > 0) return aniPop + (item.rating || 7) * 4000;
  return ((item.rating || 6) ** 4) * (item.dub ? 1.35 : 1) * ((Number(item.year) || 0) >= 2015 ? 1.2 : 1);
}

function sortAnikoto(items, sort) {
  let copy = [...items];
  if (sort === 'rating') copy.sort((a, b) => (b.rating || 0) - (a.rating || 0) || animePopRank(b) - animePopRank(a));
  else if (sort === 'newest') copy.sort((a, b) => (b.year || 0) - (a.year || 0) || String(b.updated).localeCompare(String(a.updated)));
  else if (sort === 'title') copy.sort((a, b) => String(a.title || '').localeCompare(String(b.title || '')));
  else copy.sort((a, b) => animePopRank(b) - animePopRank(a));
  return copy;
}

const EPISODIC_ANIME_FORMATS = new Set(['TV', 'TV_SHORT', 'ONA']);
const EXPLICIT_SEASON_SUFFIX_RE = /(?:\s*[:\-–—]\s*|\s+)(?:season\s*\d+|\d+(?:st|nd|rd|th)\s+season|part\s*\d+|cour\s*\d+|the\s+final\s+season.*|final\s+season.*|(?:ii|iii|iv|v|vi))(?:\s+part\s*\d+)?\s*$/i;

function isEpisodicCatalogAnime(item) {
  if (!item || item.type !== 'anime' || item.isMovie) return false;
  const fmt = String(item.format || '').toUpperCase();
  if (/MOVIE|OVA|SPECIAL|MUSIC/.test(fmt)) return false;
  return true;
}

function stripAnimeSeasonSuffix(rawTitle) {
  let clean = String(rawTitle || '').replace(/\s*\(TV\)\s*$/i, '').trim();
  let prev = '';
  while (clean && clean !== prev) {
    prev = clean;
    clean = clean.replace(EXPLICIT_SEASON_SUFFIX_RE, '').trim();
  }
  return clean;
}

const localSeasonFamilyByMal = new Map();
const localRootItemByMal = new Map();
(() => {
  const byRootKey = new Map();
  const baseExactKeys = new Set();
  for (const it of anikotoItems) {
    if (!isEpisodicCatalogAnime(it)) continue;
    const exactKey = normalizeTitle(it.title);
    if (exactKey && stripAnimeSeasonSuffix(it.title) === it.title.replace(/\s*\(TV\)\s*$/i, '').trim()) {
      baseExactKeys.add(exactKey);
    }
  }
  for (const it of anikotoItems) {
    if (!isEpisodicCatalogAnime(it)) continue;
    const exactKey = normalizeTitle(it.title);
    const stripped = normalizeTitle(stripAnimeSeasonSuffix(it.title));
    if (!stripped || stripped.length < 3) continue;
    if (stripped !== exactKey && !baseExactKeys.has(stripped)) {
      // Also allow grouping multiple explicit seasons even when S1 had "Season 1" in title
      const list = byRootKey.get(stripped) || [];
      list.push(it);
      byRootKey.set(stripped, list);
      continue;
    }
    const list = byRootKey.get(stripped) || [];
    list.push(it);
    byRootKey.set(stripped, list);
  }
  for (const [, group] of byRootKey) {
    if (group.length < 2) continue;
    const sorted = [...group].sort((a, b) => {
      const aBase = stripAnimeSeasonSuffix(a.title) === a.title.replace(/\s*\(TV\)\s*$/i, '').trim() ? 0 : 1;
      const bBase = stripAnimeSeasonSuffix(b.title) === b.title.replace(/\s*\(TV\)\s*$/i, '').trim() ? 0 : 1;
      return (Number(a.year) || 9999) - (Number(b.year) || 9999) || aBase - bBase || Number(a.id) - Number(b.id);
    });
    const root = sorted[0];
    const entries = sorted.map(s => ({
      id: String(s.id),
      anilistId: s.anilistId ? String(s.anilistId) : '',
      name: s.title,
      episodes: s.episodes,
      format: s.format || 'TV',
      year: Number(s.year) || 9999
    }));
    for (const s of sorted) {
      localSeasonFamilyByMal.set(String(s.id), entries);
      if (String(s.id) !== String(root.id)) localRootItemByMal.set(String(s.id), root);
    }
  }
})();

function dedupeCatalog(list, preserveSequels = false) {
  let output = [], positions = new Map();
  for (let rawItem of list) {
    if (!rawItem?.id || !rawItem?.title || !rawItem?.poster) continue;
    let item = rawItem;
    if (item.type === 'anime' && !preserveSequels && localRootItemByMal.has(String(item.id))) {
      item = localRootItemByMal.get(String(item.id));
    }
    if (item.type === 'anime' && !megaByMal.has(String(item.id))) continue;
    if (item.type !== 'anime' && item.japaneseAnimation) continue;
    let kind = item.type === 'movie' || item.isMovie ? 'movie' : 'series';
    let key = item.year ? `${normalizeTitle(item.title)}|${item.year}|${kind}` : `${item.type}:${item.id}`;
    let idKey = `${item.type}:${item.id}`;
    if (positions.has(idKey)) continue;
    if (!positions.has(key)) {
      positions.set(key, output.length);
      positions.set(idKey, output.length);
      output.push(item);
      continue;
    }
    let at = positions.get(key), old = output[at];
    if (old.type === 'anime' && item.type !== 'anime') {
      output[at] = { ...old, backdrop: item.backdrop || old.backdrop };
    } else if (item.type === 'anime' && old.type !== 'anime') {
      output[at] = { ...item, backdrop: old.backdrop || item.backdrop };
      positions.set(idKey, at);
    } else if (old.type !== 'anime' && item.type !== 'anime') {
      // Never drop a distinct TMDB movie/series just because another movie/series shares its title & year!
      positions.set(idKey, output.length);
      output.push(item);
    }
  }
  return output;
}

async function animeRecord(id, withRelations = false) {
  let d = await anilist(`query($id:Int){Media(idMal:$id,type:ANIME){${fields}${withRelations ? ' relations{edges{relationType node{idMal type format}}}' : ''}}}`, { id: Number(id) });
  return d.Media;
}
async function animeRecordsBatch(malIds) {
  const nums = [...new Set(malIds.map(Number).filter(n => Number.isInteger(n) && n > 0))].slice(0, 25);
  if (!nums.length) return [];
  const d = await anilist(
    `query($ids:[Int]){Page(page:1,perPage:25){media(idMal_in:$ids,type:ANIME){${fields} relations{edges{relationType node{idMal type format}}}}}}`,
    { ids: nums }
  );
  return d?.Page?.media || [];
}
function animeSeasonEntry(media) {
  const malStr = String(media.idMal);
  const provider = megaByMal.get(malStr);
  const item = ani(media);
  const catalogName = provider ? cleanAnimeDisplayTitle(provider) : '';
  return {
    id: malStr,
    anilistId: String(media.id),
    name: catalogName || item.title,
    episodes: positiveInt(provider?.episodes) || item.episodes,
    format: item.format
  };
}

const seasonFamilyCache = new Map();

async function animeSeasonFamily(media, fallbackMalId = '') {
  const rootMal = String(media?.idMal || fallbackMalId || '');
  if (!rootMal) return [];
  const cached = seasonFamilyCache.get(rootMal);
  if (cached && Date.now() - cached.time < 1800_000) return cached.seasons;

  const localFallback = (localSeasonFamilyByMal.get(rootMal) || []).map(({ year, ...rest }) => rest);
  if (!media || media.format === 'MOVIE' || !EPISODIC_ANIME_FORMATS.has(media.format)) {
    return localFallback.length >= 2 ? localFallback : [];
  }

  const entries = new Map([[rootMal, media]]);
  const seen = new Set([rootMal]);
  let frontier = [media];

  // Traverse PREQUEL/SEQUEL graph across all episodic anime formats (TV, TV_SHORT, ONA) in batched GraphQL hops
  for (let depth = 0; depth < 6 && frontier.length && seen.size < 24; depth++) {
    const nextIds = [];
    for (const cur of frontier) {
      for (const edge of cur.relations?.edges || []) {
        const node = edge.node;
        const nId = String(node?.idMal || '');
        if (
          !['PREQUEL', 'SEQUEL'].includes(edge.relationType) ||
          node?.type !== 'ANIME' ||
          !EPISODIC_ANIME_FORMATS.has(node?.format) ||
          !nId ||
          seen.has(nId)
        ) continue;
        seen.add(nId);
        nextIds.push(nId);
      }
    }
    if (!nextIds.length) break;
    try {
      const fetched = await animeRecordsBatch(nextIds);
      frontier = [];
      for (const linked of fetched) {
        if (linked?.idMal && EPISODIC_ANIME_FORMATS.has(linked.format)) {
          entries.set(String(linked.idMal), linked);
          frontier.push(linked);
        }
      }
    } catch {
      break;
    }
  }

  const aniListSeasons = [...entries.values()]
    .filter(m => releasedAnime(m) && megaForMedia(m))
    .sort((a, b) =>
      (a.startDate?.year || 9999) - (b.startDate?.year || 9999) ||
      (a.startDate?.month || 1) - (b.startDate?.month || 1) ||
      (a.startDate?.day || 1) - (b.startDate?.day || 1) ||
      Number(a.id) - Number(b.id)
    )
    .map(animeSeasonEntry);

  // Merge any local catalog seasons not yet linked on AniList
  const mergedById = new Map();
  for (const s of aniListSeasons) mergedById.set(s.id, s);
  for (const s of localFallback) {
    if (!mergedById.has(s.id)) mergedById.set(s.id, s);
  }
  const finalSeasons = mergedById.size >= 2 ? [...mergedById.values()] : [];

  if (finalSeasons.length >= 2) {
    const now = Date.now();
    for (const s of finalSeasons) {
      seasonFamilyCache.set(s.id, { seasons: finalSeasons, time: now });
    }
  }
  return finalSeasons;
}

let sharedKey = null;
async function tmdbKey() {
  if (process.env.TMDB_API_KEY) return process.env.TMDB_API_KEY;
  if (!sharedKey) sharedKey = (await freekeys()).tmdb_key;
  return sharedKey;
}
async function tmdb(route, params = {}, timeout = 10000) {
  let key = await tmdbKey();
  let q = new URLSearchParams({ ...params, api_key: key, language: 'en-US' });
  try {
    return await remote('https://api.themoviedb.org/3/' + route + '?' + q, { timeout });
  } catch (e) {
    if (process.env.TMDB_API_KEY) throw e;
    sharedKey = (await freekeys()).tmdb_key;
    q.set('api_key', sharedKey);
    return remote('https://api.themoviedb.org/3/' + route + '?' + q, { timeout });
  }
}

async function getTmdbMetaForResolver(input) {
  let [d, seasonData] = await Promise.all([
    tmdb(`${input.type}/${input.id}`, { append_to_response: 'external_ids' }),
    input.type === 'tv' ? tmdb(`tv/${input.id}/season/${input.season}`).catch(() => null) : Promise.resolve(null)
  ]);
  let epObj = input.type === 'tv' && Array.isArray(seasonData?.episodes)
    ? seasonData.episodes.find(e => Number(e.episode_number) === Number(input.episode))
    : null;
  let epRun = Number(epObj?.runtime) || (Array.isArray(d.episode_run_time) ? Number(d.episode_run_time[0]) : 0) || 0;
  return {
    title: d.title || d.name || d.original_title || d.original_name || '',
    year: String(d.release_date || d.first_air_date || '').slice(0, 4),
    imdbId: d.imdb_id || d.external_ids?.imdb_id || '',
    originalLanguage: String(d.original_language || '').toLowerCase(),
    episodeRuntimeMinutes: epRun,
    movieRuntimeMinutes: Number(d.runtime) || 0
  };
}

const readStates = () => {
  try { let d = JSON.parse(fs.readFileSync(statesDb)); return { visitors: d.visitors || {}, meta: d.meta || {} }; }
  catch { return { visitors: {}, meta: {} }; }
};
const cleanState = state => ({
  watchlist: Array.isArray(state?.watchlist) ? state.watchlist.slice(0, 100) : [],
  history: Array.isArray(state?.history) ? state.history.slice(0, 100) : []
});
function readState(owner) {
  let states = readStates(), existing = states.visitors[owner.id];
  if (!existing && !states.meta.legacyMigrated) {
    let legacy = null;
    try { legacy = JSON.parse(fs.readFileSync(db)); } catch {}
    states.meta.legacyMigrated = true;
    if (legacy && (legacy.watchlist?.length || legacy.history?.length)) states.visitors[owner.id] = cleanState(legacy);
    fs.writeFileSync(statesDb, JSON.stringify(states));
    existing = states.visitors[owner.id];
  }
  return cleanState(existing);
}
function writeState(owner, state) {
  let states = readStates();
  let next = cleanState(state);
  states.visitors[owner.id] = next;
  fs.writeFileSync(statesDb, JSON.stringify(states));
  return next;
}
const parseCookies = req => Object.fromEntries(String(req.headers.cookie || '').split(';').map(x => x.trim().split('=').map(decodeURIComponent)).filter(x => x.length === 2));
function appendCookie(res, value) {
  if (!res || res.headersSent) return;
  let old = res.getHeader('Set-Cookie'), all = old ? (Array.isArray(old) ? old : [old]) : [];
  res.setHeader('Set-Cookie', [...all, value]);
}
function visitorId(req, res) {
  const cookies = parseCookies(req);
  const cookieId = cookies.kozutv_visitor || cookies.moscowtv_visitor;
  let id = /^[a-f0-9]{32}$/.test(cookieId || '') ? cookieId : crypto.randomBytes(16).toString('hex');
  if (cookies.kozutv_visitor !== id) {
    appendCookie(res, `kozutv_visitor=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=315360000`);
  }
  return id;
}
function stateOwner(req, res) { return { scope: 'visitors', id: visitorId(req, res) }; }
async function requestBody(req) {
  let chunks = [];
  for await (let chunk of req) {
    chunks.push(chunk);
    if (Buffer.concat(chunks).length > 50000) throw Error('Payload too large');
  }
  return JSON.parse(Buffer.concat(chunks).toString() || '{}');
}
function num(s) { return /^\d{1,10}$/.test(s || '') ? s : null; }

const CATALOG_ERA_SHARDS = [
  ['2024-01-01', null],
  ['2021-01-01', '2023-12-31'],
  ['2018-01-01', '2020-12-31'],
  ['2014-01-01', '2017-12-31'],
  ['2008-01-01', '2013-12-31'],
  ['1998-01-01', '2007-12-31'],
  ['1980-01-01', '1997-12-31'],
  ['1900-01-01', '1979-12-31']
];

let cachedCatalogTotals = null;
let cachedCatalogTotalsAt = 0;
async function getCatalogTotals() {
  if (cachedCatalogTotals && Date.now() - cachedCatalogTotalsAt < 3600_000) return cachedCatalogTotals;
  try {
    const td = today();
    const [mShards, tShards] = await Promise.all([
      Promise.all(CATALOG_ERA_SHARDS.map(([gte, lte]) => tmdb('discover/movie', {
        include_adult: 'false',
        'primary_release_date.gte': gte,
        'primary_release_date.lte': lte || td,
        page: '1'
      }, 6000).catch(() => ({ total_results: 0 })))),
      Promise.all(CATALOG_ERA_SHARDS.map(([gte, lte]) => tmdb('discover/tv', {
        include_adult: 'false',
        'first_air_date.gte': gte,
        'first_air_date.lte': lte || td,
        page: '1'
      }, 6000).catch(() => ({ total_results: 0 }))))
    ]);
    const movies = mShards.reduce((s, r) => s + (Number(r?.total_results) || 0), 0) || 160000;
    const tv = tShards.reduce((s, r) => s + (Number(r?.total_results) || 0), 0) || 146000;
    const anime = anikotoItems.length;
    cachedCatalogTotals = { movies, tv, anime, all: movies + tv + anime };
    cachedCatalogTotalsAt = Date.now();
    return cachedCatalogTotals;
  } catch {
    return { movies: 160000, tv: 146000, anime: anikotoItems.length, all: 306000 + anikotoItems.length };
  }
}

function applyGenreToTmdbParams(params, mediaType, genre) {
  if (!genre) return true;
  if (mediaType === 'movie') {
    if (movieGenreIds[genre]) { params.with_genres = String(movieGenreIds[genre]); return true; }
    if (movieKeywordIds[genre]) { params.with_keywords = String(movieKeywordIds[genre]); return true; }
    return false;
  }
  if (tvGenreIds[genre]) { params.with_genres = String(tvGenreIds[genre]); return true; }
  if (tvKeywordIds[genre]) { params.with_keywords = String(tvKeywordIds[genre]); return true; }
  return false;
}

function applyYearFilterToTmdbParams(params, mediaType, yearVal) {
  const gteKey = mediaType === 'movie' ? 'primary_release_date.gte' : 'first_air_date.gte';
  const lteKey = mediaType === 'movie' ? 'primary_release_date.lte' : 'first_air_date.lte';
  const td = today();
  params[lteKey] = td;
  if (!yearVal) return;
  if (/^\d{4}$/.test(yearVal)) {
    params[mediaType === 'movie' ? 'primary_release_year' : 'first_air_date_year'] = yearVal;
    return;
  }
  const eraRanges = {
    '2020s': ['2020-01-01', td],
    '2010s': ['2010-01-01', '2019-12-31'],
    '2000s': ['2000-01-01', '2009-12-31'],
    '1990s': ['1990-01-01', '1999-12-31'],
    '1980s': ['1980-01-01', '1989-12-31'],
    classic: ['1900-01-01', '1979-12-31']
  };
  if (eraRanges[yearVal]) {
    params[gteKey] = eraRanges[yearVal][0];
    params[lteKey] = eraRanges[yearVal][1];
  }
}

function filterAnimeByYearEra(itemYear, yearVal) {
  if (!yearVal) return true;
  const y = Number(itemYear) || 0;
  if (/^\d{4}$/.test(yearVal)) return String(itemYear) === yearVal;
  if (yearVal === '2020s') return y >= 2020;
  if (yearVal === '2010s') return y >= 2010 && y <= 2019;
  if (yearVal === '2000s') return y >= 2000 && y <= 2009;
  if (yearVal === '1990s') return y >= 1990 && y <= 1999;
  if (yearVal === '1980s') return y >= 1980 && y <= 1989;
  if (yearVal === 'classic') return y > 0 && y <= 1979;
  return true;
}

async function discoverTmdbBatch(mediaType, { genre = '', year = '', lang = '', sort = 'popularity', uiPage = 1, pagesPerBatch = 2, requirePoster = false } = {}) {
  const params = { include_adult: 'false' };
  if (!applyGenreToTmdbParams(params, mediaType, genre)) {
    return { items: [], totalResults: 0, hasMore: false };
  }
  applyYearFilterToTmdbParams(params, mediaType, year);
  if (lang && validLangCodes.has(lang)) {
    params.with_original_language = lang;
  }
  const sortMap = {
    popularity: 'popularity.desc',
    trending: 'popularity.desc',
    rating: 'vote_average.desc',
    newest: mediaType === 'movie' ? 'primary_release_date.desc' : 'first_air_date.desc',
    title: mediaType === 'movie' ? 'title.asc' : 'name.asc'
  };
  params.sort_by = sortMap[sort] || 'popularity.desc';
  if (sort === 'rating') {
    params['vote_count.gte'] = lang && lang !== 'en' ? '10' : '25';
  }

  // Trending without genre/year/lang filter uses TMDB's live weekly trending feed for pages 1..250
  const useTrendingFeed = sort === 'trending' && !genre && !year && !lang && (uiPage - 1) * pagesPerBatch + 1 <= 500;
  const rawStart = (uiPage - 1) * pagesPerBatch + 1;

  const pageRequests = [];
  for (let offset = 0; offset < pagesPerBatch; offset++) {
    const absPage = rawStart + offset;
    if (useTrendingFeed) {
      if (absPage <= 500) pageRequests.push(tmdb(`trending/${mediaType}/week`, { page: String(absPage) }));
      continue;
    }
    if (absPage <= 500) {
      pageRequests.push(tmdb(`discover/${mediaType}`, { ...params, page: String(absPage) }));
    } else if (!year) {
      const shardIdx = Math.floor((absPage - 1) / 500);
      const shardPage = ((absPage - 1) % 500) + 1;
      const shard = CATALOG_ERA_SHARDS[shardIdx];
      if (shard) {
        const gteKey = mediaType === 'movie' ? 'primary_release_date.gte' : 'first_air_date.gte';
        const lteKey = mediaType === 'movie' ? 'primary_release_date.lte' : 'first_air_date.lte';
        pageRequests.push(tmdb(`discover/${mediaType}`, {
          ...params,
          [gteKey]: shard[0],
          [lteKey]: shard[1] || today(),
          page: String(shardPage)
        }));
      }
    }
  }

  if (!pageRequests.length) return { items: [], totalResults: 0, hasMore: false };
  const settled = await Promise.allSettled(pageRequests);
  let items = [];
  let totalResults = 0;
  let maxTotalPages = 0;
  let lastQueriedPage = rawStart;

  settled.forEach((res, idx) => {
    if (res.status !== 'fulfilled' || !res.value) return;
    const d = res.value;
    totalResults = Math.max(totalResults, Number(d.total_results) || 0);
    maxTotalPages = Math.max(maxTotalPages, Number(d.total_pages) || 0);
    lastQueriedPage = rawStart + idx;
    for (const raw of d.results || []) {
      const enriched = { ...raw, media_type: mediaType };
      if (releasedOtt(enriched, 0, requirePoster)) {
        items.push(ott(enriched));
      }
    }
  });

  // If unfiltered by genre/year/lang, reflect full sharded library size instead of TMDB's 20,001 single-query cap
  let hasMore = false;
  if (!genre && !year && !lang) {
    const totals = await getCatalogTotals();
    totalResults = Math.max(totalResults, mediaType === 'movie' ? totals.movies : totals.tv);
    hasMore = items.length > 0 && rawStart + pagesPerBatch <= CATALOG_ERA_SHARDS.length * 500;
  } else {
    hasMore = (lastQueriedPage < Math.min(500, maxTotalPages)) || (!year && maxTotalPages >= 500 && rawStart + pagesPerBatch <= CATALOG_ERA_SHARDS.length * 500);
  }
  return { items: dedupeCatalog(items), totalResults, hasMore };
}

// Same-origin fast LRU-cached image proxy (/api/img?u=...) to eliminate ISP CDN blocks & hotlink failures
const ALLOWED_IMG_HOSTS = new Set([
  'image.tmdb.org',
  'media.themoviedb.org',
  'cdn.anipixcdn.co',
  's4.anilist.co',
  'img.anili.st',
  'artworks.thetvdb.com',
  'thetvdb.com',
  'www.thetvdb.com',
  'cdn.myanimelist.net',
  'myanimelist.net',
  'media.kitsu.app',
  'media.kitsu.io',
  'static.tvmaze.com'
]);
const imgMemCache = new Map();
let imgMemBytes = 0;
const IMG_CACHE_MAX_BYTES = 52 * 1024 * 1024;
const imgInflight = new Map();
const FALLBACK_STILL_SVG = Buffer.from(
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#22252e"/><stop offset="100%" stop-color="#14161c"/></linearGradient></defs><rect width="320" height="180" fill="url(#bg)"/><circle cx="160" cy="90" r="26" fill="#ff731c" fill-opacity="0.16"/><path d="M153 78l20 12-20 12z" fill="#ff731c"/></svg>',
  'utf8'
);

async function handleImageProxy(req, res, url) {
  const raw = String(url.searchParams.get('u') || '').trim();
  let parsed = null;
  try { parsed = new URL(raw); } catch {}
  const host = String(parsed?.hostname || '').toLowerCase();
  const allowed = parsed && parsed.protocol === 'https:' && (
    ALLOWED_IMG_HOSTS.has(host)
    || host.endsWith('.tmdb.org')
    || host.endsWith('.anilist.co')
    || host.endsWith('.anipixcdn.co')
    || host.endsWith('.thetvdb.com')
    || host.endsWith('.myanimelist.net')
  );
  if (!allowed) {
    res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end('Invalid image URL');
  }

  const key = parsed.href;
  const hit = imgMemCache.get(key);
  if (hit && Date.now() - hit.time < 6 * 3600_000) {
    imgMemCache.delete(key);
    imgMemCache.set(key, hit);
    res.writeHead(200, {
      'Content-Type': hit.type,
      'Content-Length': String(hit.buf.byteLength),
      'Cache-Control': 'public, max-age=604800, immutable'
    });
    return res.end(hit.buf);
  }

  let task = imgInflight.get(key);
  if (!task) {
    task = (async () => {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const r = await fetch(key, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
              Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
            },
            redirect: 'follow',
            signal: AbortSignal.timeout(7500)
          });
          if (!r.ok) {
            if (r.status >= 500 && attempt === 0) {
              await new Promise(ok => setTimeout(ok, 220));
              continue;
            }
            return null;
          }
          const ct = String(r.headers.get('content-type') || 'image/jpeg').split(';')[0].trim().toLowerCase();
          if (!ct.startsWith('image/')) return null;
          const buf = Buffer.from(await r.arrayBuffer());
          if (!buf.byteLength || buf.byteLength > 8 * 1024 * 1024) return null;
          return { buf, type: ct, time: Date.now() };
        } catch {
          if (attempt === 0) await new Promise(ok => setTimeout(ok, 220));
        }
      }
      return null;
    })();
    imgInflight.set(key, task);
  }

  let result = null;
  try {
    result = await task;
  } finally {
    imgInflight.delete(key);
  }

  if (result) {
    if (result.buf.byteLength <= 1.5 * 1024 * 1024) {
      while (imgMemCache.size > 0 && (imgMemBytes + result.buf.byteLength > IMG_CACHE_MAX_BYTES || imgMemCache.size >= 480)) {
        const oldestKey = imgMemCache.keys().next().value;
        const oldest = imgMemCache.get(oldestKey);
        imgMemCache.delete(oldestKey);
        if (oldest) imgMemBytes = Math.max(0, imgMemBytes - oldest.buf.byteLength);
      }
      imgMemCache.set(key, result);
      imgMemBytes += result.buf.byteLength;
    }
    res.writeHead(200, {
      'Content-Type': result.type,
      'Content-Length': String(result.buf.byteLength),
      'Cache-Control': 'public, max-age=604800, immutable'
    });
    return res.end(result.buf);
  }

  res.writeHead(200, {
    'Content-Type': 'image/svg+xml; charset=utf-8',
    'Content-Length': String(FALLBACK_STILL_SVG.byteLength),
    'Cache-Control': 'public, max-age=180'
  });
  return res.end(FALLBACK_STILL_SVG);
}

async function resolveAnimeTmdbMapping(malId, available, ep = 1) {
  const isAnimeMovie = String(available?.format || '').toUpperCase().includes('MOVIE');
  const az = await remote(`https://api.ani.zip/mappings?mal_id=${encodeURIComponent(malId)}`, {
    ttl: 21600000,
    timeout: 2400,
    headers: { Accept: 'application/json' }
  }).catch(() => null);
  let tmdbId = az?.mappings?.themoviedb_id ? String(az.mappings.themoviedb_id) : '';
  let mediaType = isAnimeMovie || az?.mappings?.type === 'MOVIE' ? 'movie' : 'tv';
  let azEp = az?.episodes?.[String(ep)] || null;
  let seasonNum = Number(azEp?.seasonNumber) || 1;
  let episodeNum = Number(azEp?.episodeNumber) || Number(ep) || 1;

  // Verify/resolve movie TMDB ID via IMDb ID when ani.zip has a mismatched TV ID on a movie (e.g. Stand By Me Doraemon)
  if (mediaType === 'movie' && /^tt\d{5,10}$/i.test(az?.mappings?.imdb_id || '')) {
    const found = await tmdb(`find/${az.mappings.imdb_id}`, { external_source: 'imdb_id' }).catch(() => null);
    const mv = found?.movie_results?.[0];
    if (mv?.id) tmdbId = String(mv.id);
  }

  if (!tmdbId && available) {
    const cleanQ = stripAnimeSeasonSuffix(cleanAnimeDisplayTitle(available));
    if (cleanQ) {
      const sRes = await tmdb(`search/${mediaType}`, { query: cleanQ, page: 1 }).catch(() => null);
      const hit = (sRes?.results || []).find(r => japaneseAnimation(r))
        || (sRes?.results || []).find(r => Array.isArray(r?.genre_ids) && r.genre_ids.includes(16));
      if (hit?.id) tmdbId = String(hit.id);
    }
  }
  if (!tmdbId) return { az, tmdbMapping: null };
  return {
    az,
    tmdbMapping: {
      tmdbId,
      type: mediaType,
      season: mediaType === 'movie' ? 1 : seasonNum,
      episode: mediaType === 'movie' ? 1 : episodeNum
    }
  };
}

async function api(req, res, url) {
  let p = url.pathname, q = url.searchParams;
  try {
    if (p === '/api/img') return await handleImageProxy(req, res, url);
    if (p === '/api/state') return json(res, readState(stateOwner(req, res)), 200, req);

    if ((p === '/api/watchlist' && req.method === 'POST') || (p === '/api/history' && req.method === 'POST')) {
      let item = await requestBody(req);
      if (!['anime', 'movie', 'tv'].includes(item.type) || !num(String(item.id))) return json(res, { error: 'Invalid item' }, 400);
      let owner = stateOwner(req, res), state = readState(owner), field = p.endsWith('watchlist') ? 'watchlist' : 'history';
      let record = {
        id: String(item.id),
        type: item.type,
        title: String(item.title || '').slice(0, 200),
        poster: String(item.poster || '').slice(0, 500),
        episode: Math.max(1, Number(item.episode) || 1),
        season: Math.max(1, Number(item.season) || 1),
        updated: Date.now(),
        genres: Array.isArray(item.genres) ? item.genres.map(String).slice(0, 10) : [],
        format: typeof item.format === 'string' ? item.format.slice(0, 20) : null,
        isMovie: Boolean(item.isMovie),
        currentTime: Math.max(0, Number(item.currentTime) || 0),
        duration: Math.max(0, Number(item.duration) || 0)
      };
      let found = state[field].findIndex(x => x.id === record.id && x.type === record.type);
      let old = found >= 0 ? state[field].splice(found, 1)[0] : null;
      if (field === 'history' && old && old.episode === record.episode && old.season === record.season) {
        record.currentTime = item.currentTime == null ? old.currentTime || 0 : record.currentTime;
        record.duration = item.duration == null ? old.duration || 0 : record.duration;
      }
      if (!record.genres.length && old) record.genres = old.genres || [];
      if (field === 'history' || !item.remove) state[field].unshift(record);
      return json(res, writeState(owner, state), 200, req);
    }

    if (p === '/api/browse') {
      let [o] = await Promise.allSettled([tmdb('trending/all/week')]);
      let freshAnime = anikotoItems.filter(x => !x.isMovie).slice(0, 12);
      let popularAnimeSeries = sortAnikoto(anikotoItems.filter(x => !x.isMovie), 'popularity').slice(0, 10);
      let popularAnimeMovies = sortAnikoto(anikotoItems.filter(x => x.isMovie), 'popularity').slice(0, 10);
      let animeItems = [];
      for (let i = 0; i < 12; i++) {
        if (freshAnime[i]) animeItems.push(freshAnime[i]);
        if (popularAnimeMovies[i]) animeItems.push(popularAnimeMovies[i]);
        if (popularAnimeSeries[i]) animeItems.push(popularAnimeSeries[i]);
      }
      let ottItems = o.status === 'fulfilled'
        ? o.value.results.filter(x => ['tv', 'movie'].includes(x.media_type) && releasedOtt(x, 0, true)).map(ott)
        : [];
      if (!animeItems.length && !ottItems.length) throw Error('Catalogs are unavailable');
      let movies = ottItems.filter(x => x.type === 'movie'), shows = ottItems.filter(x => x.type === 'tv'), mixed = [];
      for (let i = 0; i < Math.max(animeItems.length, movies.length, shows.length); i++) {
        if (animeItems[i]) mixed.push(animeItems[i]);
        if (movies[i]) mixed.push(movies[i]);
        if (shows[i]) mixed.push(shows[i]);
      }
      mixed = dedupeCatalog(mixed);
      let history = readState(stateOwner(req, res)).history, watchedGenres = new Map();
      for (let [index, h] of history.entries()) {
        for (let g of h.genres || []) watchedGenres.set(g.toLowerCase(), (watchedGenres.get(g.toLowerCase()) || 0) + Math.max(1, 8 - index));
      }
      let watched = new Set(history.map(h => h.type + ':' + h.id));
      let suggestions = mixed
        .filter(x => !watched.has(x.type + ':' + x.id))
        .map(x => ({ ...x, match: (x.genres || []).reduce((n, g) => n + (watchedGenres.get(g.toLowerCase()) || 0), 0) }))
        .filter(x => x.match > 0)
        .sort((a, b) => b.match - a.match)
        .slice(0, 12);
      return json(res, {
        items: mixed,
        spotlight: buildRandomizedSpotlight(),
        suggestions,
        hasPreferences: watchedGenres.size > 0
      }, 200, req);
    }

    if (p === '/api/category-page') {
      const section = String(q.get('section') || '');
      const uiPage = Math.max(1, Math.min(2000, Math.floor(Number(q.get('page')) || 1)));
      const perPage = 24;
      if (section === 'trendingMovies') {
        const r = await discoverTmdbBatch('movie', { sort: 'trending', uiPage, pagesPerBatch: 2, requirePoster: true });
        return json(res, { items: r.items, page: uiPage, hasMore: r.hasMore }, 200, req);
      }
      if (section === 'popularMovies') {
        const r = await discoverTmdbBatch('movie', { sort: 'popularity', uiPage, pagesPerBatch: 2, requirePoster: true });
        return json(res, { items: r.items, page: uiPage, hasMore: r.hasMore }, 200, req);
      }
      if (section === 'topRatedMovies') {
        const r = await discoverTmdbBatch('movie', { sort: 'rating', uiPage, pagesPerBatch: 2, requirePoster: true });
        return json(res, { items: r.items, page: uiPage, hasMore: r.hasMore }, 200, req);
      }
      if (section === 'trendingTv') {
        const r = await discoverTmdbBatch('tv', { sort: 'trending', uiPage, pagesPerBatch: 2, requirePoster: true });
        return json(res, { items: r.items, page: uiPage, hasMore: r.hasMore }, 200, req);
      }
      if (section === 'popularTv') {
        const r = await discoverTmdbBatch('tv', { sort: 'popularity', uiPage, pagesPerBatch: 2, requirePoster: true });
        return json(res, { items: r.items, page: uiPage, hasMore: r.hasMore }, 200, req);
      }
      if (section === 'topRatedTv') {
        const r = await discoverTmdbBatch('tv', { sort: 'rating', uiPage, pagesPerBatch: 2, requirePoster: true });
        return json(res, { items: r.items, page: uiPage, hasMore: r.hasMore }, 200, req);
      }
      let animePool = [];
      if (section === 'latestAnime') animePool = dedupeCatalog(anikotoItems.filter(x => !x.isMovie));
      else if (section === 'airingAnime') animePool = dedupeCatalog(sortAnikoto(anikotoItems.filter(x => x.status === 'RELEASING' && !x.isMovie), 'popularity'));
      else if (section === 'popularAnime') animePool = dedupeCatalog(sortAnikoto(anikotoItems, 'popularity'));
      const offset = (uiPage - 1) * perPage;
      return json(res, {
        items: animePool.slice(offset, offset + perPage),
        page: uiPage,
        hasMore: offset + perPage < animePool.length
      }, 200, req);
    }

    if (p === '/api/search-all') {
      let term = (q.get('q') || '').trim().slice(0, 100);
      let filterType = ['all', 'movie', 'tv', 'anime'].includes(q.get('type')) ? q.get('type') : 'all';
      let uiPage = Math.max(1, Math.min(250, Math.floor(Number(q.get('page')) || 1)));
      if (!term) return json(res, { items: [], page: 1, hasMore: false, totalResults: 0 }, 200, req);
      let qNorm = normalizeTitle(term), qCompact = qNorm.replace(/\s+/g, ''), qWords = qNorm.split(' ').filter(Boolean);

      const tmdbStartPage = (uiPage - 1) * 2 + 1;
      const wantAnime = filterType === 'all' || filterType === 'anime';
      const wantMovie = filterType === 'all' || filterType === 'movie';
      const wantTv = filterType === 'all' || filterType === 'tv';

      const [aniRes, multiP1, movieP1, movieP2, tvP1, tvP2] = await Promise.allSettled([
        wantAnime && uiPage <= 10 ? anilist(
          `query($q:String,$p:Int){Page(page:$p,perPage:24){pageInfo{hasNextPage total}media(search:$q,type:ANIME,isAdult:false,status_in:[FINISHED,RELEASING],sort:[SEARCH_MATCH,POPULARITY_DESC]){${fields}}}}`,
          { q: term, p: uiPage },
          2800
        ) : Promise.resolve(null),
        (wantMovie || wantTv) && uiPage === 1 ? tmdb('search/multi', { query: term, include_adult: 'false', page: '1' }, 3400) : Promise.resolve(null),
        wantMovie && tmdbStartPage <= 500 ? tmdb('search/movie', { query: term, include_adult: 'false', page: String(tmdbStartPage) }, 3400) : Promise.resolve(null),
        wantMovie && tmdbStartPage + 1 <= 500 ? tmdb('search/movie', { query: term, include_adult: 'false', page: String(tmdbStartPage + 1) }, 3400) : Promise.resolve(null),
        wantTv && tmdbStartPage <= 500 ? tmdb('search/tv', { query: term, include_adult: 'false', page: String(tmdbStartPage) }, 3400) : Promise.resolve(null),
        wantTv && tmdbStartPage + 1 <= 500 ? tmdb('search/tv', { query: term, include_adult: 'false', page: String(tmdbStartPage + 1) }, 3400) : Promise.resolve(null)
      ]);

      // Map AniList search hits to released MegaPlay-available anime (probing MegaPlay live for unindexed titles!)
      const extraAniMap = new Map();
      if (aniRes.status === 'fulfilled' && aniRes.value) {
        const aniMediaList = (aniRes.value?.Page?.media || []).filter(m => m?.idMal && releasedAnime(m));
        const unindexed = uiPage === 1 ? aniMediaList.filter(m => !megaForMedia(m)).slice(0, 6) : [];
        if (unindexed.length) {
          await Promise.allSettled(unindexed.map(m => ensureDynamicMegaEntry(m.idMal, m)));
        }
        for (const m of aniMediaList) {
          if (!megaForMedia(m)) continue;
          const extraCands = [
            m.title?.english,
            m.title?.romaji,
            m.title?.native,
            ...(Array.isArray(m.synonyms) ? m.synonyms : [])
          ].map(normalizeTitle).filter(Boolean);
          extraAniMap.set(String(m.idMal), {
            popularity: Number(m.popularity) || 0,
            extraCands,
            mediaItem: ani(m)
          });
        }
      }

      const allLocalAnime = wantAnime ? searchLocalMegaPlay(term, extraAniMap) : [];
      const animePageSlice = wantAnime ? allLocalAnime.slice((uiPage - 1) * 36, uiPage * 36) : [];

      // Merge & score ALL released TMDB movies & web series (minVotes=0, requirePoster=false so zero released titles are hidden!)
      const rawOttMap = new Map();
      let movieTotalResults = 0, tvTotalResults = 0, movieTotalPages = 0, tvTotalPages = 0;
      for (const [srcRes, forcedType] of [
        [multiP1, null],
        [movieP1, 'movie'],
        [movieP2, 'movie'],
        [tvP1, 'tv'],
        [tvP2, 'tv']
      ]) {
        if (srcRes.status !== 'fulfilled' || !srcRes.value) continue;
        if (forcedType === 'movie') {
          movieTotalResults = Math.max(movieTotalResults, Number(srcRes.value.total_results) || 0);
          movieTotalPages = Math.max(movieTotalPages, Number(srcRes.value.total_pages) || 0);
        } else if (forcedType === 'tv') {
          tvTotalResults = Math.max(tvTotalResults, Number(srcRes.value.total_results) || 0);
          tvTotalPages = Math.max(tvTotalPages, Number(srcRes.value.total_pages) || 0);
        }
        for (const raw of srcRes.value?.results || []) {
          const mediaType = forcedType || raw.media_type;
          if (!['movie', 'tv'].includes(mediaType)) continue;
          if (mediaType === 'movie' && !wantMovie) continue;
          if (mediaType === 'tv' && !wantTv) continue;
          const enriched = { ...raw, media_type: mediaType };
          if (!releasedOtt(enriched, 0, false)) continue;
          const k = `${mediaType}:${raw.id}`;
          if (!rawOttMap.has(k)) rawOttMap.set(k, enriched);
        }
      }

      const scoredOttMap = new Map();
      for (const raw of rawOttMap.values()) {
        const scored = scoreOttSearchItem(raw, qNorm, qCompact, qWords, true);
        if (scored) scoredOttMap.set(`${scored.item.type}:${scored.item.id}`, scored);
      }

      if (uiPage === 1 && (wantMovie || wantTv)) {
        // Scan the in-memory Popular Blockbusters Index (2,630 top Movies & TV Series) so short/prefix/compound queries
        // like "end" -> "Avengers: Endgame" or "bat" -> "The Batman" ALWAYS surface the world's most popular hits first!
        for (const rec of indexedPopularOtt) {
          if (rec.item.type === 'movie' && !wantMovie) continue;
          if (rec.item.type === 'tv' && !wantTv) continue;
          const mScore = scoreCandidateMatch(qNorm, qCompact, qWords, rec.primaryNorm, rec.primaryCompact, rec.candidates, rec.compacts, rec.words, rec.subtitles, rec.subCompacts);
          if (mScore <= 0) continue;
          const total = finalizeSearchScore(mScore, rec.item, qNorm, rec.popMeter);
          const prev = scoredOttMap.get(rec.key);
          if (!prev || total > prev.score) {
            scoredOttMap.set(rec.key, { item: prev?.item || rec.item, score: total, popMeter: rec.popMeter });
          }
        }

        // Also fuzzy-match curated OTT Spotlight titles
        for (const sp of spotlightCatalog) {
          const k = `${sp.type}:${sp.id}`;
          if (sp.type === 'anime' || scoredOttMap.has(k)) continue;
          if (sp.type === 'movie' && !wantMovie) continue;
          if (sp.type === 'tv' && !wantTv) continue;
          const pNorm = normalizeTitle(sp.title);
          const pComp = pNorm.replace(/\s+/g, '');
          const subs = extractSubtitleParts(sp.title).filter(s => s !== pNorm);
          const subComps = subs.map(s => s.replace(/\s+/g, ''));
          const pWords = [...new Set([pNorm, ...subs].flatMap(s => s.split(' ')).filter(Boolean))];
          const mScore = scoreCandidateMatch(qNorm, qCompact, qWords, pNorm, pComp, [pNorm], [pComp], pWords, subs, subComps);
          if (mScore > 0) {
            scoredOttMap.set(k, { item: sp, score: finalizeSearchScore(mScore, sp, qNorm, 780), popMeter: 780 });
          }
        }

        // If TMDB missed due to a space-split compound word (e.g. "end game" vs "endgame") or mid-word typo, run a fallback query
        if (scoredOttMap.size < 3 && ((qWords.length >= 2 && qCompact.length >= 5) || (qWords.length === 1 && qWords[0].length >= 6))) {
          const altQuery = qWords.length >= 2 ? qCompact : qWords[0].slice(0, 5);
          const stemRes = await tmdb('search/multi', { query: altQuery, include_adult: 'false', page: '1' }, 2200).catch(() => null);
          for (const raw of stemRes?.results || []) {
            if (!['movie', 'tv'].includes(raw.media_type)) continue;
            if (raw.media_type === 'movie' && !wantMovie) continue;
            if (raw.media_type === 'tv' && !wantTv) continue;
            if (!releasedOtt(raw, 0, false)) continue;
            const k = `${raw.media_type}:${raw.id}`;
            if (scoredOttMap.has(k)) continue;
            const scored = scoreOttSearchItem(raw, qNorm, qCompact, qWords, false);
            if (scored) scoredOttMap.set(k, scored);
          }
        }
      }

      const scoredOtt = [...scoredOttMap.values()];
      const combinedRanked = [...animePageSlice, ...scoredOtt]
        .sort((a, b) => b.score - a.score)
        .map(x => x.item);

      const queryMentionsSeason = /\b(?:season|part|cour|s\d+)\b/i.test(term);
      const deduped = dedupeCatalog(combinedRanked, queryMentionsSeason);
      const hasMoreMovie = wantMovie && tmdbStartPage + 1 < Math.min(500, movieTotalPages);
      const hasMoreTv = wantTv && tmdbStartPage + 1 < Math.min(500, tvTotalPages);
      const hasMoreAnime = wantAnime && uiPage * 36 < allLocalAnime.length;
      const totalResults = (wantMovie ? movieTotalResults : 0) + (wantTv ? tvTotalResults : 0) + (wantAnime ? allLocalAnime.length : 0);

      return json(res, {
        items: deduped,
        page: uiPage,
        hasMore: Boolean(hasMoreMovie || hasMoreTv || hasMoreAnime),
        totalResults: Math.max(totalResults, deduped.length)
      }, 200, req);
    }

    if (p === '/api/genre') {
      let g = q.get('name');
      if (!catalogGenres.includes(g)) return json(res, { error: 'Unknown genre' }, 400);
      let type = ['all', 'movie', 'tv', 'anime'].includes(q.get('type')) ? q.get('type') : 'all';
      let sort = ['popularity', 'trending', 'rating', 'newest', 'title'].includes(q.get('sort')) ? q.get('sort') : 'popularity';
      let uiPage = Math.max(1, Math.min(2000, Math.floor(Number(q.get('page')) || 1)));

      const wantAnime = type === 'all' || type === 'anime';
      const wantMovie = type === 'all' || type === 'movie';
      const wantTv = type === 'all' || type === 'tv';

      const [mBatch, tBatch] = await Promise.all([
        wantMovie ? discoverTmdbBatch('movie', { genre: g, sort, uiPage, pagesPerBatch: type === 'movie' ? 2 : 1, requirePoster: false }) : Promise.resolve({ items: [], totalResults: 0, hasMore: false }),
        wantTv ? discoverTmdbBatch('tv', { genre: g, sort, uiPage, pagesPerBatch: type === 'tv' ? 2 : 1, requirePoster: false }) : Promise.resolve({ items: [], totalResults: 0, hasMore: false })
      ]);

      let animeFiltered = wantAnime ? dedupeCatalog(sortAnikoto(anikotoItems.filter(x => x.genres.includes(g)), sort)) : [];
      const animePerPage = type === 'anime' ? 36 : 16;
      const animeSlice = wantAnime ? animeFiltered.slice((uiPage - 1) * animePerPage, uiPage * animePerPage) : [];
      const hasMoreAnime = wantAnime && uiPage * animePerPage < animeFiltered.length;

      let mixed = [];
      const maxLen = Math.max(animeSlice.length, mBatch.items.length, tBatch.items.length);
      for (let i = 0; i < maxLen; i++) {
        if (mBatch.items[i]) mixed.push(mBatch.items[i]);
        if (tBatch.items[i]) mixed.push(tBatch.items[i]);
        if (animeSlice[i]) mixed.push(animeSlice[i]);
      }
      const deduped = dedupeCatalog(mixed);
      const totalResults = (wantMovie ? mBatch.totalResults : 0) + (wantTv ? tBatch.totalResults : 0) + (wantAnime ? animeFiltered.length : 0);
      if (q.get('home') === '1') {
        return json(res, { items: deduped.slice(0, 24) }, 200, req);
      }

      return json(res, {
        items: deduped,
        page: uiPage,
        hasMore: Boolean(mBatch.hasMore || tBatch.hasMore || hasMoreAnime),
        totalResults: Math.max(totalResults, deduped.length)
      }, 200, req);
    }

    if (p === '/api/random') {
      let [o] = await Promise.allSettled([tmdb('trending/all/week')]);
      let ottItems = o.status === 'fulfilled' ? o.value.results.filter(x => ['movie', 'tv'].includes(x.media_type) && releasedOtt(x, 0, true)).map(ott) : [];
      let topAnime = sortAnikoto(anikotoItems, 'popularity').slice(0, 250);
      let all = dedupeCatalog([...spotlightCatalog, ...topAnime, ...anikotoItems.slice(0, 150), ...ottItems]);
      if (!all.length) throw Error('Catalogs are unavailable');
      return json(res, { item: all[crypto.randomInt(all.length)] }, 200, req);
    }

    if (p === '/api/schedule') {
      let now = Math.floor(Date.now() / 1000), start = now - 24 * 3600, week = now + 8 * 86400;
      let pageBlock = n => `p${n}:Page(page:${n},perPage:50){airingSchedules(airingAt_greater:$start,airingAt_lesser:$week,sort:TIME){id airingAt episode media{${fields}}}}`;
      let d = await anilist(
        `query($start:Int,$week:Int){${[1, 2, 3, 4, 5, 6].map(pageBlock).join(' ')}}`,
        { start, week },
        14000
      );
      let rawSchedules = [1, 2, 3, 4, 5, 6].flatMap(n => d?.[`p${n}`]?.airingSchedules || []);
      let seenSlot = new Set();
      let entries = [];
      for (let x of rawSchedules) {
        if (!x?.media?.idMal || x.media.isAdult || !megaForMedia(x.media)) continue;
        let slotKey = `${x.media.idMal}:${x.episode}`;
        if (seenSlot.has(slotKey)) continue;
        seenSlot.add(slotKey);
        let item = ani(x.media);
        let provider = megaByMal.get(String(x.media.idMal));
        if (provider) item.title = cleanAnimeDisplayTitle(provider) || item.title;
        entries.push({ id: x.id, airingAt: x.airingAt, episode: x.episode, item });
      }
      return json(res, { entries }, 200, req);
    }

    if (p === '/api/filter') {
      let type = ['anime', 'movie', 'tv', 'all'].includes(q.get('type')) ? q.get('type') : 'all';
      let genre = catalogGenres.includes(q.get('genre')) ? q.get('genre') : '';
      let rawYear = String(q.get('year') || '').trim();
      let validEras = new Set(['2020s', '2010s', '2000s', '1990s', '1980s', 'classic']);
      let year = '';
      if (/^\d{4}$/.test(rawYear)) {
        if (Number(rawYear) > new Date().getFullYear()) return json(res, { items: [], page: 1, hasMore: false, totalResults: 0 }, 200, req);
        year = rawYear;
      } else if (validEras.has(rawYear)) {
        year = rawYear;
      }
      let lang = validLangCodes.has(q.get('lang') || '') ? q.get('lang') : '';
      let sort = ['popularity', 'trending', 'rating', 'newest', 'title'].includes(q.get('sort')) ? q.get('sort') : 'popularity';
      let status = ['releasing', 'finished'].includes(q.get('status')) ? q.get('status') : '';
      let dubOnly = q.get('dub') === '1' || q.get('dub') === 'true';
      let uiPage = Math.max(1, Math.min(4000, Math.floor(Number(q.get('page')) || 1)));

      const wantAnime = (type === 'all' || type === 'anime') && (!lang || lang === 'ja');
      const wantMovie = type === 'all' || type === 'movie';
      const wantTv = type === 'all' || type === 'tv';

      const [mBatch, tBatch, totals] = await Promise.all([
        wantMovie ? discoverTmdbBatch('movie', { genre, year, lang, sort, uiPage, pagesPerBatch: type === 'movie' ? 2 : 1, requirePoster: false }) : Promise.resolve({ items: [], totalResults: 0, hasMore: false }),
        wantTv ? discoverTmdbBatch('tv', { genre, year, lang, sort, uiPage, pagesPerBatch: type === 'tv' ? 2 : 1, requirePoster: false }) : Promise.resolve({ items: [], totalResults: 0, hasMore: false }),
        getCatalogTotals()
      ]);

      let animePool = [];
      if (wantAnime) {
        animePool = dedupeCatalog(sortAnikoto(
          anikotoItems.filter(x =>
            (!genre || x.genres.includes(genre)) &&
            filterAnimeByYearEra(x.year, year) &&
            (!status || x.status === status.toUpperCase()) &&
            (!dubOnly || Boolean(x.dub))
          ),
          sort
        ));
      }
      const animePerPage = type === 'anime' ? 36 : 16;
      const animeSlice = wantAnime ? animePool.slice((uiPage - 1) * animePerPage, uiPage * animePerPage) : [];
      const hasMoreAnime = wantAnime && uiPage * animePerPage < animePool.length;

      let combined = [];
      if (type === 'movie') combined = mBatch.items;
      else if (type === 'tv') combined = tBatch.items;
      else if (type === 'anime') combined = animeSlice;
      else {
        const maxLen = Math.max(mBatch.items.length, tBatch.items.length, animeSlice.length);
        for (let i = 0; i < maxLen; i++) {
          if (mBatch.items[i]) combined.push(mBatch.items[i]);
          if (tBatch.items[i]) combined.push(tBatch.items[i]);
          if (animeSlice[i]) combined.push(animeSlice[i]);
        }
      }

      if (!combined.length && uiPage === 1 && !genre && !year && !lang && !status && !dubOnly) {
        throw Error('Catalogs are unavailable');
      }

      const deduped = dedupeCatalog(combined);
      const totalResults = (wantMovie ? mBatch.totalResults : 0) + (wantTv ? tBatch.totalResults : 0) + (wantAnime ? animePool.length : 0);

      return json(res, {
        items: deduped,
        page: uiPage,
        hasMore: Boolean(mBatch.hasMore || tBatch.hasMore || hasMoreAnime),
        totalResults: Math.max(totalResults, deduped.length),
        totals,
        genres: catalogGenres,
        languages: catalogLanguages
      }, 200, req);
    }

    if (p === '/api/detail') {
      let id = num(q.get('id')), type = q.get('type');
      if (!id || !['anime', 'tv', 'movie'].includes(type)) return json(res, { error: 'Invalid title' }, 400);

      if (type === 'anime') {
        if (MEGA_REDIRECT_MAL_MAP.has(id)) id = MEGA_REDIRECT_MAL_MAP.get(id);
        let provider = megaByMal.get(id) || await ensureDynamicMegaEntry(id);
        if (!provider) {
          return json(res, { error: 'This anime is not available on MegaPlay.' }, 404, req);
        }
        const ovr = animeEpisodeOverrides[id] || null;
        let [providerData, media] = await Promise.all([
          ovr ? Promise.resolve(null) : anikotoSeries(provider.id).catch(() => null),
          animeRecord(id, true).catch(() => null)
        ]);
        let item = anikotoItem(provider);
        let count = providerData?.episodes?.length || 0;
        if (ovr) {
          const regTotal = id === '966' ? SHINCHAN_REGIONAL_TOTAL : (id === '8687' ? DORAEMON_REGIONAL_TOTAL : 0);
          item.playable = true;
          item.sub = ovr.subCount > 0;
          item.dub = ovr.dubCount > 0;
          item.subCount = ovr.subCount;
          item.dubCount = ovr.dubCount;
          item.differentDubOrder = Boolean(ovr.differentDubOrder);
          if (regTotal > 0) {
            item.regionalCount = regTotal;
            item.regionalDefault = 'hi';
            item.episodes = regTotal;
            if (id === '8687') item.regionalSeasons = DORAEMON_REGIONAL_LIST;
          } else {
            item.episodes = ovr.subCount > 0 ? ovr.subCount : ovr.dubCount;
          }
        } else if (count > 0) {
          if (!item.isMovie) item.episodes = count;
          item.playable = true;
          item.sub = providerData.episodes.some(x => x.embed_url?.sub) || provider.sub !== false;
          item.dub = providerData.episodes.some(x => x.embed_url?.dub) || Boolean(provider.dub);
        } else {
          let [subDirect, dubDirect] = await Promise.all([
            resolveMegaPlayDirect({ malId: id, aniId: provider.ani || media?.id, episode: 1, lang: 'sub' }).then(() => true).catch(() => false),
            resolveMegaPlayDirect({ malId: id, aniId: provider.ani || media?.id, episode: 1, lang: 'dub' }).then(() => true).catch(() => false)
          ]);
          if (!subDirect && !dubDirect) {
            return json(res, { error: 'This anime has no released episodes available yet.' }, 404, req);
          }
          item.playable = true;
          item.sub = subDirect;
          item.dub = dubDirect || Boolean(provider.dub);
        }
        if (media) {
          let fallback = ani(media);
          item.poster = item.poster || fallback.poster;
          item.backdrop = item.backdrop || fallback.backdrop;
          item.description = item.description || fallback.description;
          if (!item.genres.length) item.genres = fallback.genres;
        }
        item.upcoming = false;
        let seasons = await animeSeasonFamily(media, id);
        return json(res, {
          item,
          episodes: [],
          seasons,
          ...(id === '8687' ? { regionalSeasons: DORAEMON_REGIONAL_LIST } : {})
        }, 200, req);
      }

      let d = await tmdb(type + '/' + id);
      if (!releasedOtt({ ...d, media_type: type }, 0, false)) {
        return json(res, { error: 'This title is unreleased or unavailable for streaming.' }, 404, req);
      }
      let item = ott({ ...d, media_type: type });
      item.upcoming = false;
      item.playable = true;
      let seasons = type === 'tv'
        ? (d.seasons || [])
            .filter(x => x.season_number >= 1 && Number(x.episode_count) > 0 && (!x.air_date || String(x.air_date).slice(0, 10) <= today()))
            .map(x => ({ number: x.season_number, name: x.name, episodes: x.episode_count }))
        : [];
      return json(res, { item, seasons }, 200, req);
    }

    if (p === '/api/anime-episodes') {
      let id = num(q.get('id')), page = Math.max(1, Math.min(10000, Math.floor(Number(q.get('page')) || 1))), limit = 20;
      let rawReqLang = String(q.get('lang') || '').toLowerCase();
      let reqLang = ANIME_VALID_LANG_SET.has(rawReqLang) ? rawReqLang : 'sub';
      if (!id) return json(res, { error: 'Invalid anime' }, 400);
      if (MEGA_REDIRECT_MAL_MAP.has(id)) id = MEGA_REDIRECT_MAL_MAP.get(id);
      let provider = megaByMal.get(id) || await ensureDynamicMegaEntry(id);
      if (!provider) return json(res, { error: 'Episodes are not available for this title.' }, 404);

      const ovr = animeEpisodeOverrides[id] || null;
      if (ovr) {
        const isRegionalMode = (id === '966' || id === '8687') && ANIME_REGIONAL_LANG_SET.has(reqLang);
        if (isRegionalMode && id === '966') {
          const total = SHINCHAN_REGIONAL_TOTAL;
          const offset = (page - 1) * limit;
          const tmdbS1 = await tmdb('tv/30623/season/1').catch(() => null);
          const epMap = new Map((tmdbS1?.episodes || []).map(e => [Number(e.episode_number), e]));
          const episodes = [];
          for (let n = offset + 1; n <= Math.min(total, offset + limit); n++) {
            const tmdbEpNum = mapShinchanRegionalEp(n);
            const te = epMap.get(tmdbEpNum);
            const rawName = (te?.name || '').trim();
            episodes.push({
              number: n,
              title: rawName && !/^episode\s*\d+$/i.test(rawName) ? rawName : `Episode ${n}`,
              description: (te?.overview || '').trim(),
              still: te?.still_path ? `https://image.tmdb.org/t/p/w300${te.still_path}` : (provider.backdrop || provider.poster || null),
              embedId: '',
              sub: false,
              dub: n <= 78
            });
          }
          return json(res, { episodes, page, perPage: limit, total, hasNext: offset + limit < total, sources: ['embedwave'] }, 200, req);
        }

        if (isRegionalMode && id === '8687') {
          const total = DORAEMON_REGIONAL_TOTAL;
          const offset = (page - 1) * limit;
          const nums = [];
          for (let n = offset + 1; n <= Math.min(total, offset + limit); n++) nums.push(n);
          const neededSeasons = [...new Set(nums.map(n => mapDoraemonRegionalEp(n).season))];
          const seasonMaps = new Map();
          await Promise.all(neededSeasons.map(async sNum => {
            const sd = await tmdb(`tv/57911/season/${sNum}`).catch(() => null);
            seasonMaps.set(sNum, new Map((sd?.episodes || []).map(e => [Number(e.episode_number), e])));
          }));
          const episodes = nums.map(n => {
            const mapped = mapDoraemonRegionalEp(n);
            const te = seasonMaps.get(mapped.season)?.get(mapped.episode) || null;
            const rawName = te?.name && !/^episode\s*\d+$/i.test(te.name.trim()) ? te.name.trim() : '';
            const title = rawName
              ? `S${mapped.season} E${mapped.episode} · ${rawName}`
              : `Season ${mapped.season} · Episode ${mapped.episode}`;
            return {
              number: n,
              title,
              description: (te?.overview || '').trim(),
              still: te?.still_path ? `https://image.tmdb.org/t/p/w300${te.still_path}` : (provider.backdrop || provider.poster || null),
              embedId: '',
              sub: n <= 156,
              dub: n <= 52
            };
          });
          return json(res, { episodes, page, perPage: limit, total, hasNext: offset + limit < total, sources: ['embedwave'] }, 200, req);
        }

        const effectiveLang = (ovr.subCount === 0 && ovr.dubCount > 0)
          ? 'dub'
          : (reqLang === 'dub' && ovr.dubCount > 0 ? 'dub' : 'sub');
        const total = effectiveLang === 'dub' ? ovr.dubCount : ovr.subCount;
        const offset = (page - 1) * limit;
        const nums = [];
        for (let n = offset + 1; n <= Math.min(total, offset + limit); n++) nums.push(n);
        const anizipMap = await anizipEpisodeMeta(id);
        const episodes = nums.map(n => {
          if (effectiveLang === 'dub' && ovr.dub?.[String(n)]) {
            const dRow = ovr.dub[String(n)];
            const jpMeta = dRow.jpEp ? anizipMap?.get(Number(dRow.jpEp)) : null;
            return {
              number: n,
              title: dRow.title || `Episode ${n}`,
              description: dRow.description || jpMeta?.description || '',
              still: jpMeta?.still || provider.backdrop || provider.poster || null,
              embedId: '',
              sub: ovr.subCount >= n,
              dub: ovr.dubCount >= n
            };
          }
          const sRow = ovr.sub?.[String(n)] || null;
          const azIdx = n + (Number(ovr.subAnizipOffset) || 0);
          const az = azIdx > 0 ? anizipMap?.get(azIdx) : null;
          return {
            number: n,
            title: (sRow?.title || az?.title || `Episode ${n}`).replace(/`/g, "'").trim(),
            description: (sRow?.description || az?.description || '').trim(),
            still: az?.still || provider.backdrop || provider.poster || null,
            embedId: '',
            sub: ovr.subCount >= n,
            dub: ovr.dubCount >= n
          };
        });
        return json(res, { episodes, page, perPage: limit, total, hasNext: offset + limit < total, sources: ['megaplay'] }, 200, req);
      }

      let base = [];
      let data = await anikotoSeries(provider.id).catch(() => null);
      base = (data?.episodes || []).filter(x => Number.isInteger(Number(x.number)) && Number(x.number) > 0).sort((a, b) => Number(a.number) - Number(b.number));
      if (!base.length) {
        let media = await animeRecord(id, false).catch(() => null);
        let fallbackTotal = positiveInt(provider.episodes) || animeEpisodeCount(media) || 0;
        if (fallbackTotal > 0) {
          base = Array.from({ length: fallbackTotal }, (_, i) => ({
            number: i + 1,
            title: `Episode ${i + 1}`,
            episode_embed_id: '',
            embed_url: {
              sub: provider.sub === false ? null : `https://megaplay.buzz/stream/mal/${id}/${i + 1}/sub`,
              dub: provider.dub ? `https://megaplay.buzz/stream/mal/${id}/${i + 1}/dub` : null
            }
          }));
        } else {
          return json(res, { error: 'Episodes are not available for this title.' }, 404);
        }
      }
      let offset = (page - 1) * limit, pageRows = base.slice(offset, offset + limit);
      let [jikanMap, anizipMap] = await Promise.all([jikanAnimeEpisodeMeta(id, pageRows.map(x => Number(x.number))), anizipEpisodeMeta(id)]);
      let sources = ['megaplay'];
      if (jikanMap?.size) sources.unshift('jikan');
      if (anizipMap?.size && !sources.includes('jikan')) sources.unshift('jikan-mal');
      let episodes = pageRows.map(x => {
        let n = Number(x.number), jk = jikanMap?.get(n), az = anizipMap?.get(n), fallbackTitle = decodeEntities(x.title);
        let cleanFallback = fallbackTitle && !/^episode\s*\d+$/i.test(fallbackTitle.trim()) ? fallbackTitle : '';
        let title = (jk?.title || az?.title || cleanFallback || `Episode ${n}`).replace(/`/g, "'").trim();
        let description = (jk?.description || az?.description || '').trim();
        let still = jk?.still || az?.still || null;
        return { number: n, title, description, still, embedId: String(x.episode_embed_id || ''), sub: Boolean(x.embed_url?.sub ?? true), dub: Boolean(x.embed_url?.dub) };
      });
      return json(res, { episodes, page, perPage: limit, total: base.length, hasNext: offset + limit < base.length, sources }, 200, req);
    }

    if (p === '/api/season') {
      let id = num(q.get('id')), season = q.get('season') === '0' ? '0' : num(q.get('season'));
      if (!id || season === null) return json(res, { error: 'Invalid season' }, 400);
      let [d, showInfo] = await Promise.all([
        tmdb(`tv/${id}/season/${season}`),
        tmdb(`tv/${id}`).catch(() => null)
      ]);
      let fallbackStill = showInfo?.backdrop_path
        ? 'https://image.tmdb.org/t/p/w500' + showInfo.backdrop_path
        : (showInfo?.poster_path ? 'https://image.tmdb.org/t/p/w342' + showInfo.poster_path : null);
      let rawEps = Array.isArray(d.episodes) ? d.episodes : [];
      let hasAnyDated = rawEps.some(e => Boolean(e.air_date));
      let airedEps = rawEps.filter(e => {
        if (!e.episode_number || e.episode_number <= 0) return false;
        if (e.air_date) return String(e.air_date).slice(0, 10) <= today();
        return !hasAnyDated;
      });
      return json(res, {
        episodes: airedEps.map(e => ({
          number: e.episode_number,
          title: e.name || `Episode ${e.episode_number}`,
          description: e.overview || '',
          still: e.still_path ? 'https://image.tmdb.org/t/p/w300' + e.still_path : fallbackStill
        }))
      }, 200, req);
    }

    if (p === '/api/anime-audio') {
      let id = num(q.get('id')), ep = num(q.get('episode') || '1'), aniId = num(q.get('anilistId'));
      if (!id || !ep) return json(res, { streams: [] }, 200, req);
      if (MEGA_REDIRECT_MAL_MAP.has(id)) id = MEGA_REDIRECT_MAL_MAP.get(id);

      if (id === '966' || id === '8687') {
        const specialInput = id === '966'
          ? { type: 'tv', id: '30623', season: '1', episode: String(mapShinchanRegionalEp(ep)) }
          : (() => {
              const m = mapDoraemonRegionalEp(ep);
              return { type: 'tv', id: '57911', season: String(m.season), episode: String(m.episode) };
            })();
        const rawSpecial = await resolveSpecialRegionalAnime(specialInput).catch(() => []);
        const streams = rawSpecial
          .filter(a => ANIME_REGIONAL_LANG_SET.has(a.key))
          .map(a => {
            try {
              const opts = a.audioLang ? { audioLang: a.audioLang } : {};
              return {
                key: a.key,
                language: a.language,
                label: a.label,
                type: a.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL',
                codec: a.codec || 'h264',
                src: mediaUrl(a.url, a.proxyProvider || 'embedwave', a.headers || {}, opts)
              };
            } catch { return null; }
          }).filter(Boolean);
        return json(res, { streams }, 200, req);
      }

      let available = megaForIds(id, aniId) || await ensureDynamicMegaEntry(id);
      if (!available) return json(res, { streams: [] }, 200, req);
      const { tmdbMapping } = await resolveAnimeTmdbMapping(id, available, ep);
      if (!tmdbMapping) return json(res, { streams: [] }, 200, req);
      const tmdbInput = {
        type: tmdbMapping.type,
        id: String(tmdbMapping.tmdbId),
        season: String(tmdbMapping.season || 1),
        episode: String(tmdbMapping.episode || 1)
      };
      const meta = await getTmdbMetaForResolver(tmdbInput).catch(() => ({ title: cleanAnimeDisplayTitle(available), originalLanguage: 'ja' }));
      const rawStreams = await resolveAnimeRegionalAudio(tmdbInput, meta).catch(() => []);
      const streams = rawStreams.map(a => {
        try {
          const opts = a.audioLang ? { audioLang: a.audioLang } : {};
          return {
            key: a.key,
            language: a.language,
            label: a.label,
            type: a.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL',
            codec: a.codec || 'h264',
            src: mediaUrl(a.url, a.proxyProvider || 'embedwave', a.headers || {}, opts)
          };
        } catch { return null; }
      }).filter(Boolean);
      return json(res, { streams }, 200, req);
    }

    if (p === '/api/play') {
      let id = num(q.get('id')), type = q.get('type'), ep = num(q.get('episode') || '1'), season = q.get('season') === '0' ? '0' : num(q.get('season') || '1');
      let rawLang = String(q.get('lang') || 'sub').toLowerCase();
      let lang = ANIME_VALID_LANG_SET.has(rawLang) ? rawLang : 'sub';
      let requestedProvider = q.get('provider');
      let provider = OTT_SERVER_KEYS.has(requestedProvider) ? requestedProvider : DEFAULT_OTT_SERVER;
      let aniId = num(q.get('anilistId'));
      if (!id || !ep || !season || !['anime', 'movie', 'tv'].includes(type)) return json(res, { error: 'Invalid playback request' }, 400);

      if (type === 'anime') {
        if (MEGA_REDIRECT_MAL_MAP.has(id)) id = MEGA_REDIRECT_MAL_MAP.get(id);
        let available = megaForIds(id, aniId) || await ensureDynamicMegaEntry(id), effectiveAni = aniId || available?.ani || null, fallbackEmbed = null, subFallbackEmbed = null;
        if (!available) return json(res, { error: 'This anime is not available right now.' }, 404, req);
        const ovr = animeEpisodeOverrides[id] || null;
        const isRegionalReq = ANIME_REGIONAL_LANG_SET.has(lang);

        // Direct regional playback for Shin Chan (1..181 verified) & Doraemon (1..762 verified)
        if ((id === '966' || id === '8687') && (isRegionalReq || Number(ep) > (id === '966' ? 78 : 156))) {
          const specialInput = id === '966'
            ? { type: 'tv', id: '30623', season: '1', episode: String(mapShinchanRegionalEp(ep)) }
            : (() => {
                const m = mapDoraemonRegionalEp(ep);
                return { type: 'tv', id: '57911', season: String(m.season), episode: String(m.episode) };
              })();
          const rawSpecial = await resolveSpecialRegionalAnime(specialInput).catch(() => []);
          const regionalStreams = rawSpecial
            .filter(a => ANIME_REGIONAL_LANG_SET.has(a.key))
            .map(a => {
              try {
                const opts = a.audioLang ? { audioLang: a.audioLang } : {};
                return {
                  key: a.key,
                  language: a.language,
                  label: a.label,
                  type: a.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL',
                  codec: a.codec || 'h264',
                  src: mediaUrl(a.url, a.proxyProvider || 'embedwave', a.headers || {}, opts)
                };
              } catch { return null; }
            }).filter(Boolean);
          const chosen = regionalStreams.find(r => r.key === lang) || regionalStreams.find(r => r.key === 'hi') || regionalStreams[0];
          if (chosen) {
            return json(res, {
              src: chosen.src,
              type: chosen.type || 'application/x-mpegURL',
              codec: chosen.codec || 'h264',
              kind: 'videojs',
              provider: 'EmbedWave',
              sourceKey: 'megaplay',
              server: chosen.label,
              activeLang: chosen.key,
              allowSub: id === '8687' && Number(ep) <= 156,
              allowDub: Number(ep) <= (id === '966' ? 78 : 52),
              tracks: [],
              regionalStreams,
              qualityStreams: [],
              intro: null,
              outro: null
            }, 200, req);
          }
        }

        const megaLang = isRegionalReq
          ? (available.sub === false || ovr?.subCount === 0 ? 'dub' : 'sub')
          : (lang === 'dub' || available.sub === false || ovr?.subCount === 0 ? 'dub' : 'sub');

        if (!ovr && available.id) {
          let seriesData = await anikotoSeries(available.id).catch(() => null);
          let row = seriesData?.episodes?.find(x => Number(x.number) === Number(ep));
          fallbackEmbed = row?.embed_url?.[megaLang] || null;
          subFallbackEmbed = row?.embed_url?.sub || null;
        }
        let mappingPromise = resolveAnimeTmdbMapping(id, available, ep);
        let subCompanionPromise = (megaLang === 'dub' && !ovr?.differentDubOrder && available.sub !== false)
          ? resolveMegaPlayDirect({ malId: id, aniId: effectiveAni, episode: ep, lang: 'sub', fallbackEmbed: subFallbackEmbed }).catch(() => null)
          : Promise.resolve(null);
        try {
          let [megaPrimary, { tmdbMapping }, subCompanion] = await Promise.all([
            resolveMegaPlayDirect({ malId: id, aniId: effectiveAni, episode: ep, lang: megaLang, fallbackEmbed }),
            mappingPromise,
            subCompanionPromise
          ]);
          if (!megaPrimary?.url) throw Error('No anime stream available');

          let regionalStreams = [];
          if (isRegionalReq && tmdbMapping && !ovr?.differentDubOrder) {
            const tmdbInput = {
              type: tmdbMapping.type,
              id: String(tmdbMapping.tmdbId),
              season: String(tmdbMapping.season || 1),
              episode: String(tmdbMapping.episode || 1)
            };
            const meta = await getTmdbMetaForResolver(tmdbInput).catch(() => ({ title: cleanAnimeDisplayTitle(available), originalLanguage: 'ja' }));
            const rawReg = await resolveAnimeRegionalAudio(tmdbInput, meta).catch(() => []);
            regionalStreams = rawReg.map(a => {
              try {
                const opts = a.audioLang ? { audioLang: a.audioLang } : {};
                return {
                  key: a.key,
                  language: a.language,
                  label: a.label,
                  type: a.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL',
                  codec: a.codec || 'h264',
                  src: mediaUrl(a.url, a.proxyProvider || 'embedwave', a.headers || {}, opts)
                };
              } catch { return null; }
            }).filter(Boolean);
          }

          let rawQualityStreams = await enrichAnimeQualityStreams({ primaryUrl: megaPrimary.url, lang: megaLang, tmdbMapping }).catch(() => []);
          let qualityStreams = rawQualityStreams.map(qs => {
            try { return { tier: qs.tier, height: qs.height, codec: qs.codec || 'h264', type: qs.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', src: mediaUrl(qs.url, qs.proxyProvider || 'megaplay', qs.headers || {}) }; }
            catch { return null; }
          }).filter(Boolean);

          // Compute exact studio-bumper offset when borrowing Sub captions for Anime Dub (e.g. +6.28s Demon Slayer / +16.0s Attack on Titan)
          let dubOffsetSec = 0;
          if (megaLang === 'dub' && subCompanion?.url && !ovr?.differentDubOrder) {
            const dubIntro = Number(megaPrimary?.intro?.start) || 0;
            const subIntro = Number(subCompanion?.intro?.start) || 0;
            if (dubIntro > 5 && subIntro > 5) {
              const introDiff = dubIntro - subIntro;
              if (Math.abs(introDiff) >= 1.5 && Math.abs(introDiff) <= 45) {
                dubOffsetSec = Number(introDiff.toFixed(2));
              }
            } else {
              const [dubDur, subDur] = await Promise.all([
                measureMegaHlsDurationSec(megaPrimary.url),
                measureMegaHlsDurationSec(subCompanion.url)
              ]);
              if (dubDur > 300 && subDur > 300) {
                const durDiff = dubDur - subDur;
                if (Math.abs(durDiff) >= 1.5 && Math.abs(durDiff) <= 45) {
                  dubOffsetSec = Number(durDiff.toFixed(2));
                }
              }
            }
          }

          let mergedMegaTracks = Array.isArray(megaPrimary?.tracks) ? megaPrimary.tracks.map(x => ({ ...x })) : [];
          if (megaLang === 'dub') {
            const isEng = t => /^en/i.test(t?.language || '') || /^english\b/i.test(String(t?.label || '').trim());
            const subTracks = (!ovr?.differentDubOrder && Array.isArray(subCompanion?.tracks))
              ? subCompanion.tracks.map(t => ({ ...t, ...(dubOffsetSec ? { offsetSec: dubOffsetSec } : {}) }))
              : [];
            const crunchySub = subTracks.find(t => /crunchyroll/i.test(t?.label || '')) || subTracks.find(isEng) || null;
            const dubEn = mergedMegaTracks.find(isEng) || null;

            if (crunchySub) {
              const crunchyEntry = { ...crunchySub, language: 'en', label: 'English (Crunchyroll)' };
              if (dubEn && dubEn.src !== crunchyEntry.src) {
                let dubCueCount = 999;
                try {
                  const vttRes = await fetch(dubEn.src, { headers: { 'User-Agent': 'Mozilla/5.0', Referer: 'https://megaplay.buzz/' }, signal: AbortSignal.timeout(1800) });
                  if (vttRes.ok) {
                    const vttTxt = await vttRes.text();
                    dubCueCount = (vttTxt.match(/-->/g) || []).length;
                  }
                } catch {}
                dubEn.label = dubCueCount < 90 ? 'English (Signs & Songs)' : 'English [CC]';
                mergedMegaTracks = [
                  crunchyEntry,
                  dubEn,
                  ...mergedMegaTracks.filter(t => t !== dubEn && !/crunchyroll/i.test(t.label)),
                  ...subTracks.filter(t => t.src !== crunchyEntry.src && !mergedMegaTracks.some(m => m.label.toLowerCase() === t.label.toLowerCase()))
                ];
              } else if (dubEn && dubEn.src === crunchyEntry.src) {
                dubEn.label = 'English (Crunchyroll)';
                if (dubOffsetSec) dubEn.offsetSec = dubOffsetSec;
                for (const st of subTracks) {
                  if (st.src !== dubEn.src && !mergedMegaTracks.some(m => m.label.toLowerCase() === st.label.toLowerCase())) {
                    mergedMegaTracks.push({ ...st });
                  }
                }
              } else {
                mergedMegaTracks = [
                  crunchyEntry,
                  ...mergedMegaTracks,
                  ...subTracks.filter(t => t.src !== crunchyEntry.src && !mergedMegaTracks.some(m => m.label.toLowerCase() === t.label.toLowerCase()))
                ];
              }
            } else if (dubEn && !/crunchyroll/i.test(dubEn.label)) {
              dubEn.label = ovr?.differentDubOrder ? 'English [CC]' : 'English (Crunchyroll)';
            }
          } else {
            const hasCrunchy = mergedMegaTracks.some(t => /crunchyroll/i.test(t?.label || ''));
            if (!hasCrunchy) {
              const firstEn = mergedMegaTracks.find(t => /^en/i.test(t?.language || '') || /^english$/i.test(String(t?.label || '').trim()));
              if (firstEn) firstEn.label = 'English (Crunchyroll)';
            }
          }

          let tracks = mergedMegaTracks.map(x => {
            try {
              const opts = x.offsetSec ? { offsetSec: x.offsetSec } : {};
              return { kind: 'subtitles', language: x.language || 'und', label: x.label || 'English', src: mediaUrl(x.src, 'megaplay', {}, opts) };
            } catch { return null; }
          }).filter(Boolean);

          if (!tracks.length && tmdbMapping && !ovr?.differentDubOrder) {
            const tmdbSubInput = {
              type: tmdbMapping.type,
              id: String(tmdbMapping.tmdbId),
              season: String(tmdbMapping.season || 1),
              episode: String(tmdbMapping.episode || 1)
            };
            const [ewSubs, vsSubs] = await Promise.all([
              fetchEmbedWaveSubtitles(tmdbSubInput).catch(() => []),
              fetchVidsparkSubtitles(tmdbSubInput).catch(() => [])
            ]);
            tracks = [...ewSubs, ...vsSubs].map((x, idx) => {
              try {
                const isFirstEn = idx === 0 && (/^en/i.test(x.language || '') || /^english/i.test(x.label || ''));
                return {
                  kind: x.kind || 'subtitles',
                  language: x.language || 'und',
                  label: isFirstEn ? 'English (Crunchyroll)' : (x.label || 'Subtitle'),
                  src: mediaUrl(x.src, x.proxyProvider || 'vidcore', x.headers || {})
                };
              } catch { return null; }
            }).filter(Boolean);
          }

          const chosenRegional = isRegionalReq ? regionalStreams.find(r => r.key === lang) : null;
          if (chosenRegional) {
            return json(res, {
              src: chosenRegional.src,
              type: chosenRegional.type || 'application/x-mpegURL',
              codec: chosenRegional.codec || 'h264',
              kind: 'videojs',
              provider: 'MegaPlay',
              sourceKey: 'megaplay',
              server: chosenRegional.label,
              activeLang: chosenRegional.key,
              tracks,
              regionalStreams,
              qualityStreams: [],
              intro: megaPrimary?.intro || null,
              outro: megaPrimary?.outro || null
            }, 200, req);
          }

          return json(res, {
            src: mediaUrl(megaPrimary.url, 'megaplay'),
            type: /\.mp4(?:\?|$)/i.test(megaPrimary.url) ? 'video/mp4' : 'application/x-mpegURL',
            kind: 'videojs',
            provider: 'MegaPlay',
            sourceKey: 'megaplay',
            server: megaLang === 'dub' ? 'English' : 'Japanese',
            activeLang: megaLang,
            allowSub: ovr ? Number(ep) <= Number(ovr.subCount || 0) : available.sub !== false,
            allowDub: ovr ? Number(ep) <= Number(ovr.dubCount || 0) : Boolean(available.dub),
            tracks,
            regionalStreams,
            qualityStreams,
            intro: megaPrimary?.intro || null,
            outro: megaPrimary?.outro || null
          }, 200, req);
        } catch {
          let otherLang = megaLang === 'dub' ? 'sub' : 'dub', otherFallback = null;
          if (available.id) {
            let seriesData = await anikotoSeries(available.id).catch(() => null);
            let row = seriesData?.episodes?.find(x => Number(x.number) === Number(ep));
            otherFallback = row?.embed_url?.[otherLang] || null;
          }
          let hasOpposite = await resolveMegaPlayDirect({ malId: id, aniId: effectiveAni, episode: ep, lang: otherLang, fallbackEmbed: otherFallback }).then(() => true).catch(() => false);
          if (hasOpposite) {
            return json(res, { error: megaLang === 'dub' ? 'Dub is not available for this episode.' : 'Sub is not available for this episode.', availableLang: otherLang }, 404, req);
          }
          return json(res, { error: 'This episode is not available right now.' }, 404, req);
        }
      }

      let input = { type, id, season, episode: ep };
      let resolved = await resolveOttWithFallback(input, provider, getTmdbMetaForResolver);
      let proxyProvider = resolved.proxyProvider || resolved.sourceKey || DEFAULT_OTT_SERVER;
      let src = resolved.kind === 'dash' ? dashUrl(resolved.url, proxyProvider, resolved.headers) : mediaUrl(resolved.url, proxyProvider, resolved.headers);
      let tracks = (resolved.tracks || []).map(x => {
        try {
          const opts = {};
          if (x.timeScale) opts.timeScale = x.timeScale;
          if (x.offsetSec) opts.offsetSec = x.offsetSec;
          return {
            kind: x.kind || 'subtitles',
            language: x.language || 'und',
            label: x.label || 'Subtitle',
            src: mediaUrl(x.src, x.proxyProvider || proxyProvider, x.headers || resolved.headers, opts)
          };
        } catch { return null; }
      }).filter(Boolean);
      let audioStreams = (resolved.audioStreams || []).map(a => {
        try {
          const opts = a.audioLang ? { audioLang: a.audioLang } : {};
          return {
            language: a.language,
            label: a.label,
            type: a.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL',
            codec: a.codec || 'h264',
            src: mediaUrl(a.url, a.proxyProvider || proxyProvider, a.headers || resolved.headers, opts)
          };
        } catch { return null; }
      }).filter(Boolean);
      let qualityStreams = (resolved.qualityStreams || []).map(qs => {
        try { return { tier: qs.tier, height: qs.height, codec: qs.codec || 'h264', type: qs.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', src: mediaUrl(qs.url, qs.proxyProvider || proxyProvider, qs.headers || resolved.headers || {}) }; }
        catch { return null; }
      }).filter(Boolean);
      return json(res, { src, type: resolved.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', codec: resolved.codec || 'h264', kind: 'videojs', provider: resolved.provider, sourceKey: resolved.sourceKey, server: resolved.server, tracks, audioStreams, qualityStreams }, 200, req);
    }

    return json(res, { error: 'Not found' }, 404);
  } catch (e) {
    return json(res, { error: e.message || 'Request failed' }, e.message?.includes('configured') ? 503 : 502);
  }
}

let jikanUnreachableUntil = 0;
async function jikanAnimeEpisodeMeta(malId, sliceNums) {
  if (Date.now() < jikanUnreachableUntil) return null;
  try {
    let jikanPage = Math.max(1, Math.ceil((sliceNums[0] || 1) / 100));
    let [epRes, vidRes] = await Promise.all([
      remote(`https://api.jikan.moe/v4/anime/${encodeURIComponent(malId)}/episodes?page=${jikanPage}`, { ttl: 21600000, timeout: 1800, headers: { Accept: 'application/json' } }).catch(err => {
        if (/timeout|abort|fetch/i.test(err.message)) jikanUnreachableUntil = Date.now() + 600000;
        return null;
      }),
      remote(`https://api.jikan.moe/v4/anime/${encodeURIComponent(malId)}/videos/episodes?page=1`, { ttl: 21600000, timeout: 1800, headers: { Accept: 'application/json' } }).catch(() => null)
    ]);
    if (!epRes?.data && !vidRes?.data) return null;
    let byNum = new Map();
    for (let row of epRes?.data || []) {
      let n = Number(row.mal_id);
      if (n > 0) byNum.set(n, { title: row.title || row.title_romanji || '', still: null, description: '' });
    }
    for (let row of vidRes?.data || []) {
      let n = Number(row.mal_id), img = row.images?.jpg?.image_url || null;
      if (n > 0) {
        let prev = byNum.get(n) || { title: '', still: null, description: '' };
        byNum.set(n, { title: prev.title || row.title || '', still: img || prev.still, description: prev.description });
      }
    }
    return byNum;
  } catch { return null; }
}

async function anizipEpisodeMeta(malId) {
  try {
    let d = await remote(`https://api.ani.zip/mappings?mal_id=${encodeURIComponent(malId)}`, { ttl: 21600000, timeout: 4500, headers: { Accept: 'application/json' } });
    let eps = d?.episodes || {};
    let byNum = new Map();
    for (let [k, ep] of Object.entries(eps)) {
      if (!/^\d+$/.test(k)) continue;
      let n = Number(k);
      if (!Number.isInteger(n) || n <= 0) continue;
      let rawTitle = typeof ep.title === 'string' ? ep.title : (ep.title?.en || ep.title?.['x-jat'] || ep.title?.ja || '');
      let rawDesc = String(ep.overview || ep.summary || '').replace(/\s*\(?\bSource:\s*[^)\n]+\)?\s*$/i, '').trim();
      let img = /^https:\/\//.test(ep.image || '') ? ep.image : null;
      byNum.set(n, { title: rawTitle, still: img, description: rawDesc });
    }
    return byNum;
  } catch { return null; }
}

const staticCache = new Map();
const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ttf': 'font/ttf',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2'
};
const CSP = "default-src 'self' https: data: blob:; frame-src 'none'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' https: data:; connect-src 'self' https: data: blob:; media-src 'self' https: data: blob:; worker-src 'self' blob:";

http.createServer(async (req, res) => {
  try {
    let u = new URL(req.url, 'http://localhost');
    if (u.pathname.startsWith('/browse/watch/')) {
      let dest = u.pathname.replace(/^\/browse\/watch\//, '/watch/');
      res.writeHead(301, { Location: dest + u.search });
      return res.end();
    }
    if (u.pathname === '/upcoming') {
      res.writeHead(302, { Location: '/browse' });
      return res.end();
    }
    if (/^\/(anime|ott)(\/|$)/.test(u.pathname)) {
      let dest = u.pathname.replace(/^\/(anime|ott)/, '/browse');
      res.writeHead(302, { Location: dest + u.search });
      return res.end();
    }
    if (u.pathname.startsWith('/api/dash/')) return handleDash(req, res, u);
    if (u.pathname === '/api/media') return handleMedia(req, res, u);
    if (u.pathname.startsWith('/api/')) return api(req, res, u);

    let pathname = u.pathname === '/' ? '/index.html' : u.pathname;
    let target = path.resolve(root, '.' + pathname);
    if (!target.startsWith(root + path.sep) || !fs.existsSync(target) || !fs.statSync(target).isFile()) {
      target = path.join(root, 'index.html');
    }
    let ext = path.extname(target), stat = fs.statSync(target), cached = staticCache.get(target);
    if (!cached || cached.mtime !== stat.mtimeMs) {
      let raw = fs.readFileSync(target), compressible = /^\.(?:html|js|css|svg|webmanifest)$/.test(ext);
      cached = { mtime: stat.mtimeMs, raw, gz: compressible ? zlib.gzipSync(raw, { level: 6 }) : null };
      staticCache.set(target, cached);
    }
    let immutable = u.pathname.startsWith('/vendor/') || u.pathname.startsWith('/fonts/') || u.pathname.startsWith('/images/') || u.searchParams.has('v');
    let headers = {
      'Content-Type': mimeTypes[ext] || 'application/octet-stream',
      'Cache-Control': ext === '.html' ? 'no-cache' : (immutable ? 'public, max-age=86400' : 'public, max-age=300'),
      'Content-Security-Policy': CSP
    };
    if (cached.gz && String(req.headers['accept-encoding'] || '').includes('gzip')) {
      headers['Content-Encoding'] = 'gzip';
      headers['Vary'] = 'Accept-Encoding';
      res.writeHead(200, headers);
      return res.end(cached.gz);
    }
    res.writeHead(200, headers);
    res.end(cached.raw);
  } catch (err) {
    if (!res.headersSent) {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Internal server error');
    }
  }
}).listen(process.env.PORT || 3000, '0.0.0.0', () => {
  console.log('kozuTV V5.4.6 listening on ' + (process.env.PORT || 3000));
});
