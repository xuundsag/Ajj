import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const ADMIN_PASS_HASH = crypto.createHash('sha256').update('Surya@67').digest();

export function createAdminSystem({ dataDir, getSystemHooks }) {
  const adminStatePath = path.join(dataDir, 'admin-state.json');
  const siteConfigPath = path.join(dataDir, 'site-config.json');

  const VALID_GENRES = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Horror', 'Mecha', 'Music', 'Mystery', 'Psychological', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller'];

  const DEFAULT_SITE_CONFIG = {
    brandName: 'kozuTV',
    accentColor: '#ff731c',
    accentSecondary: '#ff964f',
    gridCols: 6,
    posterRadius: 10,
    cardHoverScale: 1.045,
    showHero: true,
    spotlightSlideCount: 6,
    heroIntervalSec: 6.5,
    heroCtaText: 'Start Watching',
    trendingTitle: 'Trending Now',
    showContinueRow: true,
    showSuggestedRow: true,
    showRatings: true,
    showCardMeta: true,
    homeGenreCount: 3,
    showWatchlistIcon: true,
    showScheduleLink: true,
    showRandomLink: true,
    showFiltersLink: true,
    showFooter: true,
    footerTagline: 'Free entertainment for all',
    defaultOttServer: 'vidcore',
    enabledOttServers: ['vidcore', 'embedwave', 'cinesrc', 'vidlink', 'vidsrc'],
    defaultAnimeServer: 'megaplay',
    defaultAnimeLang: 'sub',
    defaultQuality: 'auto',
    defaultSpeed: '1',
    defaultAutoplay: true,
    defaultAutonext: true,
    defaultAutoskip: false,
    defaultMuted: false,
    enabledTypes: ['anime', 'movie', 'tv'],
    spotlightMode: 'mix',
    spotlightIds: [],
    featuredTitle: 'Featured',
    featuredIds: [],
    pinnedGenres: [],
    announcement: {
      enabled: false,
      badge: 'UPDATE',
      text: '',
      link: ''
    },
    maintenance: {
      enabled: false,
      message: 'kozuTV is performing scheduled streaming upgrades. Please check back shortly.'
    },
    pinnedHeroId: '',
    hiddenIds: []
  };

  let adminState = {
    authorizedIps: {},
    blockedAttempts: [],
    auditLog: []
  };
  let siteConfig = { ...DEFAULT_SITE_CONFIG };

  try {
    if (fs.existsSync(adminStatePath)) {
      const parsed = JSON.parse(fs.readFileSync(adminStatePath, 'utf8'));
      if (parsed && typeof parsed === 'object') {
        adminState.authorizedIps = parsed.authorizedIps && typeof parsed.authorizedIps === 'object' ? parsed.authorizedIps : {};
        adminState.blockedAttempts = Array.isArray(parsed.blockedAttempts) ? parsed.blockedAttempts.slice(0, 80) : [];
        adminState.auditLog = Array.isArray(parsed.auditLog) ? parsed.auditLog.slice(0, 80) : [];
      }
    }
  } catch {}

  try {
    if (fs.existsSync(siteConfigPath)) {
      const parsed = JSON.parse(fs.readFileSync(siteConfigPath, 'utf8'));
      if (parsed && typeof parsed === 'object') {
        siteConfig = sanitizeSiteConfig({ ...DEFAULT_SITE_CONFIG, ...parsed });
      }
    }
  } catch {}

  function persistAdminState() {
    try {
      fs.mkdirSync(dataDir, { recursive: true });
      fs.writeFileSync(adminStatePath, JSON.stringify(adminState, null, 2));
    } catch {}
  }

  function persistSiteConfig() {
    try {
      fs.mkdirSync(dataDir, { recursive: true });
      fs.writeFileSync(siteConfigPath, JSON.stringify(siteConfig, null, 2));
    } catch {}
  }

  function normalizeIp(raw) {
    let ip = String(raw || '').trim();
    if (!ip) return '0.0.0.0';
    if (ip.includes(',')) ip = ip.split(',')[0].trim();
    if (ip.startsWith('::ffff:')) ip = ip.slice(7);
    if (ip === '::1') ip = '127.0.0.1';
    return ip.slice(0, 64);
  }

  function getClientIp(req) {
    const cf = req.headers['cf-connecting-ip'];
    if (cf) return normalizeIp(cf);
    const xff = req.headers['x-forwarded-for'];
    if (xff) return normalizeIp(xff);
    const xri = req.headers['x-real-ip'];
    if (xri) return normalizeIp(xri);
    return normalizeIp(req.socket?.remoteAddress || '127.0.0.1');
  }

  function parseUserAgentSummary(uaRaw = '') {
    const ua = String(uaRaw || '');
    const osName = /iphone|ipad|ipod/i.test(ua) ? 'iOS'
      : /android/i.test(ua) ? 'Android'
      : /mac os x/i.test(ua) ? 'macOS'
      : /windows/i.test(ua) ? 'Windows'
      : /linux/i.test(ua) ? 'Linux' : 'Device';
    const browser = /edg\//i.test(ua) ? 'Edge'
      : /opr\/|opera/i.test(ua) ? 'Opera'
      : /firefox\//i.test(ua) ? 'Firefox'
      : /chrome\//i.test(ua) ? 'Chrome'
      : /safari\//i.test(ua) ? 'Safari' : 'Browser';
    return `${browser} · ${osName}`;
  }

  function isIpAuthorized(req) {
    const ip = getClientIp(req);
    const entry = adminState.authorizedIps[ip];
    if (!entry) return false;
    if (entry.expiresAt && Date.now() > entry.expiresAt) {
      delete adminState.authorizedIps[ip];
      persistAdminState();
      return false;
    }
    entry.lastSeen = Date.now();
    entry.hits = (Number(entry.hits) || 0) + 1;
    return true;
  }

  function recordAudit(action, ip, detail = '') {
    adminState.auditLog.unshift({
      time: Date.now(),
      ip,
      action: String(action).slice(0, 80),
      detail: String(detail).slice(0, 180)
    });
    if (adminState.auditLog.length > 80) adminState.auditLog.length = 80;
  }

  function recordBlockedAttempt(req, targetPath) {
    const ip = getClientIp(req);
    adminState.blockedAttempts.unshift({
      time: Date.now(),
      ip,
      path: String(targetPath || '/admin').slice(0, 80),
      device: parseUserAgentSummary(req.headers['user-agent'])
    });
    if (adminState.blockedAttempts.length > 80) adminState.blockedAttempts.length = 80;
    persistAdminState();
  }

  const ipAuthAttempts = new Map();
  function checkPassRateLimit(ip) {
    const now = Date.now();
    const rec = ipAuthAttempts.get(ip) || { fails: 0, lockUntil: 0 };
    if (now < rec.lockUntil) {
      const waitSec = Math.ceil((rec.lockUntil - now) / 1000);
      throw Error(`Too many failed attempts. Try again in ${waitSec}s.`);
    }
    return rec;
  }

  function verifyPasswordConstantTime(candidate) {
    const candHash = crypto.createHash('sha256').update(String(candidate ?? '')).digest();
    return crypto.timingSafeEqual(candHash, ADMIN_PASS_HASH);
  }

  const cleanKeyList = (arr, limit = 40) => Array.isArray(arr)
    ? [...new Set(arr.map(x => String(x || '').trim()).filter(x => /^(?:anime|movie|tv):\d+$/.test(x)))].slice(0, limit)
    : [];

  function sanitizeSiteConfig(raw = {}) {
    const validOtt = ['vidcore', 'embedwave', 'cinesrc', 'vidlink', 'vidsrc'];
    const validAnime = ['megaplay', 'vidlink'];
    const validQual = ['auto', '1080', '720', '480'];
    const validSpeed = ['1', '1.25', '1.5'];
    const validTypes = ['anime', 'movie', 'tv'];
    const hexRx = /^#[0-9a-fA-F]{6}$/;

    const enabledOtt = Array.isArray(raw.enabledOttServers)
      ? raw.enabledOttServers.filter(k => validOtt.includes(k))
      : validOtt;
    const finalOttList = enabledOtt.length ? enabledOtt : ['vidcore', 'embedwave'];
    const defOtt = validOtt.includes(raw.defaultOttServer) && finalOttList.includes(raw.defaultOttServer)
      ? raw.defaultOttServer
      : finalOttList[0];

    const enabledTypesRaw = Array.isArray(raw.enabledTypes)
      ? raw.enabledTypes.filter(t => validTypes.includes(t))
      : validTypes;
    const finalTypes = enabledTypesRaw.length ? enabledTypesRaw : validTypes;

    const gCountNum = Number(raw.homeGenreCount);
    const sCountNum = Number(raw.spotlightSlideCount);
    const gridColsNum = Number(raw.gridCols);
    const spotIds = cleanKeyList(raw.spotlightIds, 20);
    const legacyPin = /^(?:anime|movie|tv):\d+$/.test(String(raw.pinnedHeroId || '').trim()) ? String(raw.pinnedHeroId).trim() : '';
    const mergedSpot = legacyPin && !spotIds.includes(legacyPin) ? [legacyPin, ...spotIds] : spotIds;

    return {
      brandName: String(raw.brandName || 'kozuTV').trim().slice(0, 28) || 'kozuTV',
      accentColor: hexRx.test(raw.accentColor || '') ? raw.accentColor : '#ff731c',
      accentSecondary: hexRx.test(raw.accentSecondary || '') ? raw.accentSecondary : '#ff964f',
      gridCols: Number.isFinite(gridColsNum) ? Math.max(4, Math.min(8, Math.round(gridColsNum))) : 6,
      posterRadius: Number.isFinite(Number(raw.posterRadius)) ? Math.max(0, Math.min(24, Number(raw.posterRadius))) : 10,
      cardHoverScale: Number.isFinite(Number(raw.cardHoverScale)) ? Math.max(1, Math.min(1.12, Number(raw.cardHoverScale))) : 1.045,
      showHero: raw.showHero !== false,
      spotlightSlideCount: Number.isFinite(sCountNum) ? Math.max(2, Math.min(10, Math.round(sCountNum))) : 6,
      heroIntervalSec: Math.max(3, Math.min(30, Number(raw.heroIntervalSec ?? 6.5) || 6.5)),
      heroCtaText: String(raw.heroCtaText || 'Start Watching').trim().slice(0, 28) || 'Start Watching',
      trendingTitle: String(raw.trendingTitle || 'Trending Now').trim().slice(0, 34) || 'Trending Now',
      showContinueRow: raw.showContinueRow !== false,
      showSuggestedRow: raw.showSuggestedRow !== false,
      showRatings: raw.showRatings !== false,
      showCardMeta: raw.showCardMeta !== false,
      homeGenreCount: Number.isFinite(gCountNum) ? Math.max(0, Math.min(6, Math.round(gCountNum))) : 3,
      showWatchlistIcon: raw.showWatchlistIcon !== false,
      showScheduleLink: raw.showScheduleLink !== false,
      showRandomLink: raw.showRandomLink !== false,
      showFiltersLink: raw.showFiltersLink !== false,
      showFooter: raw.showFooter !== false,
      footerTagline: String(raw.footerTagline || 'Free entertainment for all').trim().slice(0, 80) || 'Free entertainment for all',
      defaultOttServer: defOtt,
      enabledOttServers: finalOttList,
      defaultAnimeServer: validAnime.includes(raw.defaultAnimeServer) ? raw.defaultAnimeServer : 'megaplay',
      defaultAnimeLang: raw.defaultAnimeLang === 'dub' ? 'dub' : 'sub',
      defaultQuality: validQual.includes(String(raw.defaultQuality || '')) ? String(raw.defaultQuality) : 'auto',
      defaultSpeed: validSpeed.includes(String(raw.defaultSpeed || '')) ? String(raw.defaultSpeed) : '1',
      defaultAutoplay: raw.defaultAutoplay !== false,
      defaultAutonext: raw.defaultAutonext !== false,
      defaultAutoskip: Boolean(raw.defaultAutoskip),
      defaultMuted: Boolean(raw.defaultMuted),
      enabledTypes: finalTypes,
      spotlightMode: raw.spotlightMode === 'custom' ? 'custom' : 'mix',
      spotlightIds: mergedSpot,
      featuredTitle: String(raw.featuredTitle || 'Featured').trim().slice(0, 32) || 'Featured',
      featuredIds: cleanKeyList(raw.featuredIds, 24),
      pinnedGenres: Array.isArray(raw.pinnedGenres)
        ? [...new Set(raw.pinnedGenres.filter(g => VALID_GENRES.includes(g)))].slice(0, 8)
        : [],
      announcement: {
        enabled: Boolean(raw.announcement?.enabled && String(raw.announcement?.text || '').trim()),
        badge: String(raw.announcement?.badge || 'UPDATE').trim().slice(0, 14) || 'UPDATE',
        text: String(raw.announcement?.text || '').trim().slice(0, 200),
        link: String(raw.announcement?.link || '').trim().slice(0, 160)
      },
      maintenance: {
        enabled: Boolean(raw.maintenance?.enabled),
        message: String(raw.maintenance?.message || DEFAULT_SITE_CONFIG.maintenance.message).trim().slice(0, 220)
      },
      pinnedHeroId: mergedSpot[0] || '',
      hiddenIds: cleanKeyList(raw.hiddenIds, 200)
    };
  }

  // ============================================================================
  // REAL-TIME PRESENCE & TELEMETRY ENGINE
  // ============================================================================
  const activeSessions = new Map();
  let peakConcurrent = 0;
  let totalHeartbeats = 0;

  function pruneSessions() {
    const cutoff = Date.now() - 42_000;
    for (const [sid, sess] of activeSessions) {
      if (sess.updatedAt < cutoff) activeSessions.delete(sid);
    }
  }

  function recordPresence(req, body = {}) {
    pruneSessions();
    const sid = String(body.sessionId || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40);
    if (!sid || sid.length < 6) return;
    const ip = getClientIp(req);
    const now = Date.now();
    const prev = activeSessions.get(sid);
    const activity = ['watching', 'detail', 'search', 'browse', 'schedule', 'filters', 'watchlist'].includes(body.activity)
      ? body.activity
      : 'browse';

    const media = body.media && typeof body.media === 'object' ? {
      type: ['anime', 'movie', 'tv'].includes(body.media.type) ? body.media.type : '',
      id: String(body.media.id || '').replace(/\D/g, '').slice(0, 12),
      title: String(body.media.title || '').slice(0, 110),
      poster: /^https:\/\//i.test(body.media.poster || '') ? String(body.media.poster).slice(0, 260) : '',
      season: Math.max(1, Number(body.media.season) || 1),
      episode: Math.max(1, Number(body.media.episode) || 1),
      server: String(body.media.server || '').slice(0, 28),
      audio: String(body.media.audio || '').slice(0, 28),
      quality: String(body.media.quality || '').slice(0, 20),
      currentTime: Math.max(0, Number(body.media.currentTime) || 0),
      duration: Math.max(0, Number(body.media.duration) || 0),
      paused: Boolean(body.media.paused)
    } : null;

    const route = String(body.route || '/browse').slice(0, 120);
    const query = String(body.query || '').slice(0, 60);
    const device = parseUserAgentSummary(req.headers['user-agent']);

    activeSessions.set(sid, {
      sessionId: sid,
      ip,
      device,
      route,
      query,
      activity,
      media,
      startedAt: prev?.startedAt || now,
      updatedAt: now
    });

    if (activeSessions.size > peakConcurrent) peakConcurrent = activeSessions.size;
    totalHeartbeats++;
    if (activeSessions.size > 500) {
      const oldestKey = activeSessions.keys().next().value;
      activeSessions.delete(oldestKey);
    }
  }

  function snapshotCpuTotals() {
    let idle = 0, total = 0;
    for (const core of os.cpus()) {
      for (const k of Object.keys(core.times)) total += core.times[k];
      idle += core.times.idle;
    }
    return { idle, total };
  }
  let prevCpu = snapshotCpuTotals();
  let currentCpuPct = 3;
  const telemetryHistory = [];

  function sampleSystemMetrics() {
    pruneSessions();
    const cur = snapshotCpuTotals();
    const dTotal = cur.total - prevCpu.total;
    const dIdle = cur.idle - prevCpu.idle;
    prevCpu = cur;
    if (dTotal > 0) {
      currentCpuPct = Math.max(1, Math.min(100, Math.round(((dTotal - dIdle) / dTotal) * 100)));
    }
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const memPct = Math.round(((totalMem - freeMem) / totalMem) * 100);
    const hooks = getSystemHooks();
    const proxy = hooks.getProxyTelemetry();
    const watchingCount = [...activeSessions.values()].filter(s => s.activity === 'watching').length;

    telemetryHistory.push({
      t: Date.now(),
      cpu: currentCpuPct,
      mem: memPct,
      users: activeSessions.size,
      watching: watchingCount,
      kbps: Math.round((proxy.bytesPerSec || 0) / 1024)
    });
    if (telemetryHistory.length > 60) telemetryHistory.shift();
  }
  sampleSystemMetrics();
  setInterval(sampleSystemMetrics, 2500).unref?.();

  function buildTelemetryPayload(req) {
    pruneSessions();
    const hooks = getSystemHooks();
    const proxy = hooks.getProxyTelemetry();
    const resolverStats = hooks.getOttResolverStats();
    const memUsage = process.memoryUsage();
    const totalMem = os.totalmem();
    const usedMem = totalMem - os.freemem();
    const sessions = [...activeSessions.values()]
      .sort((a, b) => (b.activity === 'watching' ? 1 : 0) - (a.activity === 'watching' ? 1 : 0) || b.updatedAt - a.updatedAt);

    return {
      now: Date.now(),
      yourIp: getClientIp(req),
      system: {
        uptimeSec: Math.floor(process.uptime()),
        cpuPercent: currentCpuPct,
        cpuCores: os.cpus().length,
        loadAvg: os.loadavg().map(n => Number(n.toFixed(2))),
        memPercent: Math.round((usedMem / totalMem) * 100),
        rssMb: Math.round(memUsage.rss / 1048576),
        heapUsedMb: Math.round(memUsage.heapUsed / 1048576),
        heapTotalMb: Math.round(memUsage.heapTotal / 1048576),
        sysUsedGb: Number((usedMem / 1073741824).toFixed(2)),
        sysTotalGb: Number((totalMem / 1073741824).toFixed(2)),
        catalogCounts: hooks.getCatalogCounts()
      },
      proxy,
      resolvers: resolverStats,
      presence: {
        onlineCount: sessions.length,
        watchingCount: sessions.filter(s => s.activity === 'watching').length,
        peakConcurrent: Math.max(peakConcurrent, sessions.length),
        totalHeartbeats,
        sessions
      },
      security: {
        authorizedIps: Object.entries(adminState.authorizedIps).map(([ip, info]) => ({ ip, ...info })),
        blockedAttempts: adminState.blockedAttempts.slice(0, 25),
        auditLog: adminState.auditLog.slice(0, 25)
      },
      savedUsersCount: hooks.getSavedUsersCount ? hooks.getSavedUsersCount() : 0,
      history: telemetryHistory,
      siteConfig
    };
  }

  const SHARED_FONT_FACE = `
@font-face{font-family:Archivo;src:url('/fonts/archivo-latin.woff2') format('woff2');font-weight:100 900;font-display:swap}
@font-face{font-family:Manrope;src:url('/fonts/manrope-latin.woff2') format('woff2');font-weight:200 800;font-display:swap}`;

  // Custom duotone architectural icon set
  const ADMIN_ICONS = {
    overview: `<svg viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4.5" fill="currentColor" fill-opacity=".13" stroke="currentColor" stroke-width="1.7"/><path d="M8 15.5v-3M12 15.5v-7M16 15.5v-4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`,
    settings: `<svg viewBox="0 0 24 24" fill="none"><path d="M4 7h9M17 7h3M4 17h3M11 17h9" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/><circle cx="15" cy="7" r="2.6" fill="currentColor" fill-opacity=".22" stroke="currentColor" stroke-width="1.75"/><circle cx="9" cy="17" r="2.6" fill="currentColor" fill-opacity=".22" stroke="currentColor" stroke-width="1.75"/></svg>`,
    catalog: `<svg viewBox="0 0 24 24" fill="none"><path d="M6.5 4.5h11a2 2 0 0 1 2 2v1" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" opacity=".55"/><rect x="3.5" y="7.5" width="17" height="12.5" rx="3" fill="currentColor" fill-opacity=".13" stroke="currentColor" stroke-width="1.7"/><path d="m10.5 11.3 4.2 2.45-4.2 2.45v-4.9Z" fill="currentColor"/></svg>`,
    security: `<svg viewBox="0 0 24 24" fill="none"><path d="M12 3.2 19 6v5.6c0 4.8-2.95 8.15-7 9.4-4.05-1.25-7-4.6-7-9.4V6l7-2.8Z" fill="currentColor" fill-opacity=".13" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><circle cx="12" cy="11.2" r="1.6" fill="currentColor"/><path d="M12 12.8v2.7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>`
  };

  // ============================================================================
  // 1. UNAUTHORIZED /admin VIEW — Logo on left + message ONLY
  // ============================================================================
  function renderForbiddenHtml() {
    return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>kozuTV</title>
<style>${SHARED_FONT_FACE}
*{box-sizing:border-box}
body{margin:0;min-height:100dvh;display:flex;align-items:center;justify-content:center;background:#09090b;color:#e4e4e7;font-family:Manrope,system-ui,-apple-system,sans-serif;padding:24px}
.row{display:flex;align-items:center;gap:18px;flex-wrap:wrap}
.row img{height:22px;width:auto;display:block}
.sep{width:1px;height:22px;background:#27272f}
.txt{font-size:14px;font-weight:500;color:#d4d4d8;letter-spacing:-.1px}
@media(max-width:520px){
  .row{flex-direction:column;align-items:flex-start;gap:12px}
  .sep{display:none}
}
</style></head><body>
<div class="row">
  <img src="/images/kozutv-logo.png" alt="kozuTV">
  <span class="sep" aria-hidden="true"></span>
  <span class="txt">IP not authorised. Your attempt has been logged.</span>
</div>
</body></html>`;
  }

  // ============================================================================
  // 2. /ip VIEW — kozuTV Logo up-left + "Authorize IP" + Passkey field ONLY
  // ============================================================================
  function renderIpGateHtml() {
    return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Authorize IP</title>
<style>${SHARED_FONT_FACE}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;min-height:100dvh;display:grid;place-items:center;background:#09090b;color:#f4f4f5;font-family:Manrope,system-ui,-apple-system,sans-serif;padding:18px}
.card{width:100%;max-width:348px;padding:24px;border-radius:12px;background:#111114;border:1px solid #232329}
.logo{height:18px;width:auto;display:block;margin-bottom:18px}
h1{margin:0 0 14px;font-family:Archivo,system-ui,sans-serif;font-size:18px;font-weight:700;letter-spacing:-.3px}
form{display:flex;flex-direction:column;gap:10px;margin:0}
input{width:100%;height:40px;padding:0 12px;border-radius:8px;border:1px solid #27272f;background:#09090b;color:#f4f4f5;font-size:16px;font-family:inherit;outline:none;transition:border-color .15s}
input:focus{border-color:#ff731c}
button{width:100%;height:40px;border:0;border-radius:8px;background:#ff731c;color:#140c06;font-family:inherit;font-size:13.5px;font-weight:700;cursor:pointer}
button:disabled{opacity:.5;cursor:wait}
.msg{margin-top:10px;font-size:12.5px;color:#fca5a5;display:none}
.msg.show{display:block}
</style></head><body>
<main class="card">
  <img class="logo" src="/images/kozutv-logo.png" alt="kozuTV">
  <h1>Authorize IP</h1>
  <form id="auth-form" autocomplete="off">
    <input id="password" name="password" type="password" placeholder="Passkey" aria-label="Passkey" required autofocus>
    <button type="submit" id="submit-btn">Authorize</button>
  </form>
  <div id="msg" class="msg"></div>
</main>
<script>
const form = document.getElementById('auth-form');
const msg = document.getElementById('msg');
const btn = document.getElementById('submit-btn');
form.addEventListener('submit', async e => {
  e.preventDefault();
  msg.className = 'msg';
  btn.disabled = true;
  try {
    const r = await fetch('/api/ip/authorize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: document.getElementById('password').value })
    });
    const d = await r.json();
    if (!r.ok) throw Error(d.error || 'Invalid passkey');
    location.href = '/admin';
  } catch (err) {
    msg.textContent = err.message;
    msg.className = 'msg show';
    btn.disabled = false;
  }
});
</script></body></html>`;
  }

  // ============================================================================
  // 3. /admin/system DEDICATED SYSTEM SPECS & SERVER DIAGNOSTICS PAGE
  // ============================================================================
  function renderSystemPageHtml() {
    return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><title>System — kozuTV</title>
<style>${SHARED_FONT_FACE}
:root{--bg:#09090b;--surface:#111114;--surface-2:#18181c;--border:#232329;--border-2:#2e2e36;--text:#f4f4f5;--muted:#8e8e99;--accent:#ff731c;--green:#22c55e;--red:#ef4444}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:var(--bg);color:var(--text);font-family:Manrope,system-ui,-apple-system,sans-serif;font-size:14px}
a{color:inherit;text-decoration:none}
button{font:inherit}
.wrap{max-width:860px;margin:0 auto;padding:28px 20px 60px}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:20px}
.back{display:inline-flex;align-items:center;gap:7px;font-size:13px;font-weight:600;color:var(--muted);padding:6px 11px;border-radius:8px;background:var(--surface);border:1px solid var(--border)}
.back:hover{color:var(--text);border-color:var(--border-2)}
h1{margin:0 0 16px;font-family:Archivo,system-ui,sans-serif;font-size:21px;font-weight:700;letter-spacing:-.4px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:10px;overflow:hidden}
.card-head{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid var(--border)}
.card-head h2{margin:0;font-size:13.5px;font-weight:700}
.kv{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px 16px;border-bottom:1px solid var(--border);font-size:13px}
.kv:last-child{border-bottom:0}
.kv span{color:var(--muted)}
.kv b{font-weight:600;font-variant-numeric:tabular-nums}
.btn{height:28px;padding:0 10px;border-radius:6px;border:1px solid var(--border-2);background:var(--surface-2);color:var(--text);font-size:12px;font-weight:600;cursor:pointer}
.btn:disabled{opacity:.5;cursor:wait}
.dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:#52525b;margin-right:8px}
.dot.up{background:var(--green)}
.dot.err{background:var(--red)}
@media(max-width:680px){.grid{grid-template-columns:1fr}.wrap{padding:18px 14px 44px}}
</style></head><body>
<div class="wrap">
  <div class="top">
    <a class="back" href="/admin">← Overview</a>
    <img src="/images/kozutv-logo.png" alt="kozuTV" style="height:17px;width:auto">
  </div>
  <h1>System</h1>
  <div class="grid">
    <div class="card">
      <div class="card-head"><h2>Hardware &amp; Runtime</h2></div>
      <div class="kv"><span>CPU Load</span><b id="s-cpu">—</b></div>
      <div class="kv"><span>CPU Cores</span><b id="s-cores">—</b></div>
      <div class="kv"><span>Load Average</span><b id="s-load">—</b></div>
      <div class="kv"><span>System Memory</span><b id="s-ram">—</b></div>
      <div class="kv"><span>Node Heap</span><b id="s-heap">—</b></div>
      <div class="kv"><span>Uptime</span><b id="s-up">—</b></div>
    </div>
    <div class="card">
      <div class="card-head">
        <h2>Stream Servers</h2>
        <button type="button" class="btn" id="probe-btn">Check</button>
      </div>
      <div id="s-servers"></div>
      <div class="kv"><span>Proxy Throughput</span><b id="s-bw">—</b></div>
      <div class="kv"><span>Indexed Catalog</span><b id="s-cat">—</b></div>
    </div>
  </div>
</div>
<script>
const fmtDur = sec => {
  sec = Math.max(0, Math.floor(Number(sec) || 0));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  if (h >= 24) return Math.floor(h / 24) + 'd ' + (h % 24) + 'h';
  return h ? h + 'h ' + m + 'm' : m + 'm ' + (sec % 60) + 's';
};
async function loadSys() {
  try {
    const r = await fetch('/api/admin/telemetry');
    if (r.status === 403) { location.href = '/admin'; return; }
    const d = await r.json();
    document.getElementById('s-cpu').textContent = d.system.cpuPercent + '%';
    document.getElementById('s-cores').textContent = d.system.cpuCores;
    document.getElementById('s-load').textContent = (d.system.loadAvg || []).join(' / ');
    document.getElementById('s-ram').textContent = d.system.sysUsedGb + ' / ' + d.system.sysTotalGb + ' GB (' + d.system.memPercent + '%)';
    document.getElementById('s-heap').textContent = d.system.heapUsedMb + ' / ' + d.system.rssMb + ' MB';
    document.getElementById('s-up').textContent = fmtDur(d.system.uptimeSec);
    const kbps = Math.round((d.proxy.bytesPerSec || 0) / 1024);
    document.getElementById('s-bw').textContent = kbps >= 1024 ? (kbps / 1024).toFixed(1) + ' MB/s' : kbps + ' KB/s';
    document.getElementById('s-cat').textContent = d.system.catalogCounts.anime.toLocaleString() + ' Anime · ' + d.system.catalogCounts.ott.toLocaleString() + ' OTT';
    const rTel = d.resolvers?.telemetry || {};
    const names = [['vidcore','VidCore'],['embedwave','EmbedWave'],['cinesrc','CineSrc'],['vidlink','VidLink'],['vidsrc','VidSrc']];
    document.getElementById('s-servers').innerHTML = names.map(([k, label]) => {
      const st = rTel[k] || { ok: 0, fail: 0, lastMs: 0 };
      const cls = st.ok > 0 ? 'up' : (st.fail > 0 ? 'err' : '');
      const txt = st.lastMs ? st.lastMs + ' ms' : (st.fail > 0 && !st.ok ? 'Error' : 'Idle');
      return '<div class="kv"><span><i class="dot ' + cls + '"></i>' + label + '</span><b>' + txt + '</b></div>';
    }).join('');
  } catch {}
}
document.getElementById('probe-btn').addEventListener('click', async e => {
  const b = e.target;
  b.disabled = true;
  b.textContent = '…';
  try { await fetch('/api/admin/probe', { method: 'POST' }); await loadSys(); }
  finally { b.disabled = false; b.textContent = 'Check'; }
});
loadSys();
setInterval(loadSys, 2500);
</script></body></html>`;
  }

  // ============================================================================
  // 4. /admin MAIN DASHBOARD
  // ============================================================================
  function renderAdminDashboardHtml() {
    const genreOptions = ['Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror', 'Mystery', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller'];
    return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><title>kozuTV</title>
<style>${SHARED_FONT_FACE}
:root{
  --bg:#09090b;
  --surface:#111114;
  --surface-2:#18181c;
  --border:#232329;
  --border-2:#2e2e36;
  --text:#f4f4f5;
  --muted:#8e8e99;
  --accent:#ff731c;
  --green:#22c55e;
  --red:#ef4444;
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;background:var(--bg);color:var(--text);font-family:Manrope,system-ui,-apple-system,sans-serif;font-size:14px;line-height:1.45;overflow-x:hidden}
a{color:inherit;text-decoration:none}
button,input,select{font:inherit;color:inherit}

.layout{display:grid;grid-template-columns:212px minmax(0,1fr);min-height:100dvh}

/* Sidebar */
.sidebar{position:sticky;top:0;height:100dvh;padding:20px 12px;background:var(--bg);border-right:1px solid var(--border);display:flex;flex-direction:column;gap:4px}
.brand-bar{display:flex;align-items:center;padding:4px 10px 18px}
.brand-bar img{height:19px;width:auto}
.nav-item{display:flex;align-items:center;gap:11px;width:100%;padding:9px 11px;border:0;border-radius:8px;background:transparent;color:var(--muted);font-size:13.5px;font-weight:600;cursor:pointer;text-align:left;transition:background .12s,color .12s}
.nav-item svg{width:18px;height:18px;flex:none}
.nav-item:hover{background:var(--surface);color:var(--text)}
.nav-item.active{background:var(--surface-2);color:var(--text)}
.nav-item.active svg{color:var(--accent)}
.sidebar-foot{margin-top:auto;padding-top:12px;border-top:1px solid var(--border)}
.ext-link{display:flex;align-items:center;justify-content:space-between;padding:8px 11px;border-radius:8px;background:var(--surface);border:1px solid var(--border);color:var(--text);font-weight:600;font-size:12.5px}
.ext-link:hover{border-color:var(--border-2)}

.mobile-top,.mobile-tabs{display:none}

/* Main Content */
.content{min-width:0;max-width:1020px;width:100%;margin:0 auto;padding:28px 28px 64px}
.page-head{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
.page-head h1{margin:0;font-family:Archivo,system-ui,sans-serif;font-size:20px;font-weight:700;letter-spacing:-.35px}
.head-actions{display:flex;align-items:center;gap:8px}

.pane{display:none}
.pane.active{display:block}

/* Minimal Overview Metrics */
.stats-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px}
.stat-card{display:block;width:100%;text-align:left;padding:15px 16px;border-radius:10px;background:var(--surface);border:1px solid var(--border);min-width:0;transition:border-color .14s,background .14s}
a.stat-card,button.stat-card{cursor:pointer}
a.stat-card:hover,button.stat-card:hover{border-color:var(--border-2);background:#151519}
.stat-label{display:flex;align-items:center;justify-content:space-between;color:var(--muted);font-size:12.5px;font-weight:500;margin-bottom:6px}
.stat-value{font-family:Archivo,system-ui,sans-serif;font-size:23px;font-weight:700;letter-spacing:-.5px;line-height:1.1;font-variant-numeric:tabular-nums}

/* Cards */
.stack{display:flex;flex-direction:column;gap:16px;min-width:0}
.card{background:var(--surface);border:1px solid var(--border);border-radius:10px;min-width:0;overflow:hidden}
.card-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 16px;border-bottom:1px solid var(--border);flex-wrap:wrap}
.card-head h2{margin:0;font-size:13.5px;font-weight:700;letter-spacing:-.1px}
.card-body{padding:14px 16px}
.card-body.flush{padding:0}

.seg{display:inline-flex;padding:2px;border-radius:7px;background:var(--bg);border:1px solid var(--border);flex-wrap:wrap}
.seg button{border:0;background:transparent;color:var(--muted);font-size:12px;font-weight:600;padding:4px 9px;border-radius:5px;cursor:pointer}
.seg button.active{background:var(--surface-2);color:var(--text)}

/* Buttons */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;height:34px;padding:0 13px;border-radius:7px;border:1px solid transparent;background:var(--accent);color:#140b05;font-size:13px;font-weight:700;cursor:pointer;white-space:nowrap}
.btn:hover{opacity:.92}
.btn:disabled{opacity:.5;cursor:wait}
.btn.secondary{background:var(--surface-2);border-color:var(--border-2);color:var(--text);font-weight:600}
.btn.secondary:hover{background:#222228}
.btn.secondary.on{background:#291910;border-color:var(--accent);color:var(--accent)}
.btn.danger{background:#251315;border-color:#471f23;color:#fca5a5;font-weight:600}
.btn.sm{height:28px;padding:0 10px;font-size:12px;border-radius:6px}

/* Visitors */
.list-divide > div{border-bottom:1px solid var(--border)}
.list-divide > div:last-child{border-bottom:0}
.viewer-row{display:flex;align-items:center;gap:12px;padding:11px 16px;min-width:0}
.v-thumb{width:32px;height:45px;border-radius:5px;object-fit:cover;background:var(--surface-2);flex:none}
.v-icon{width:32px;height:32px;border-radius:8px;background:var(--surface-2);border:1px solid var(--border-2);display:grid;place-items:center;color:var(--muted);font-size:11px;font-weight:700;flex:none}
.v-main{flex:1;min-width:0}
.v-title{font-size:13.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.v-title span{color:var(--muted);font-weight:500}
.v-meta{margin-top:2px;font-size:12px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.v-prog{height:3px;max-width:180px;background:#202027;border-radius:999px;overflow:hidden;margin-top:5px}
.v-prog > div{height:100%;background:var(--accent)}
.empty-note{padding:24px 16px;text-align:center;color:var(--muted);font-size:13px}

/* Settings & Catalog Rows */
.field-row{display:grid;grid-template-columns:minmax(0,1fr) 240px;align-items:center;gap:14px;padding:11px 16px;border-bottom:1px solid var(--border)}
.field-row:last-child{border-bottom:0}
.field-row.block{grid-template-columns:1fr;gap:9px}
.field-info strong{display:block;font-size:13.5px;font-weight:600}
.input,.select{width:100%;height:35px;padding:0 11px;border-radius:7px;border:1px solid var(--border-2);background:var(--bg);color:var(--text);font-size:13.5px;outline:none}
.input:focus,.select:focus{border-color:var(--accent)}

.color-ctrl{display:flex;align-items:center;gap:8px}
.color-ctrl input[type=color]{width:35px;height:35px;padding:2px;border-radius:7px;border:1px solid var(--border-2);background:var(--bg);cursor:pointer;flex:none}
.swatches{display:flex;align-items:center;gap:6px;margin-top:7px}
.swatch{width:19px;height:19px;border-radius:999px;border:2px solid #ffffff22;cursor:pointer;padding:0}

.chip-checks{display:flex;flex-wrap:wrap;gap:7px}
.chip-check{display:inline-flex;align-items:center;gap:6px;padding:5px 10px;border-radius:7px;background:var(--bg);border:1px solid var(--border-2);font-size:12.5px;font-weight:600;cursor:pointer;user-select:none}
.chip-check input{accent-color:var(--accent);margin:0}

.g-pill{padding:5px 10px;border-radius:7px;border:1px solid var(--border-2);background:var(--bg);color:var(--muted);font-size:12px;font-weight:600;cursor:pointer}
.g-pill.on{background:#291910;border-color:var(--accent);color:var(--accent)}

/* Switch */
.switch{position:relative;display:inline-block;width:40px;height:22px;flex:none;justify-self:end}
.switch input{opacity:0;width:0;height:0}
.slider{position:absolute;inset:0;cursor:pointer;background:#27272f;border-radius:999px;transition:background .18s}
.slider:before{content:"";position:absolute;height:16px;width:16px;left:3px;top:3px;background:#fff;border-radius:50%;transition:transform .18s}
.switch input:checked + .slider{background:var(--accent)}
.switch input:checked + .slider:before{transform:translateX(18px)}
.sub-fields{padding:12px 16px;background:#0c0c0f;border-bottom:1px solid var(--border);display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.sub-fields .full{grid-column:1/-1}
.sub-label{display:block;font-size:12px;font-weight:600;color:var(--muted);margin-bottom:4px}

/* Catalog Curation */
.three-col{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:start}
.two-col{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;align-items:start}
.mini-list{max-height:220px;overflow-y:auto}
.mini-item{display:flex;align-items:center;gap:9px;padding:8px 12px;border-bottom:1px solid var(--border);min-width:0}
.mini-item:last-child{border-bottom:0}
.mini-item img{width:24px;height:34px;border-radius:4px;object-fit:cover;background:var(--surface-2);flex:none}
.mini-item span{flex:1;min-width:0;font-size:12.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mini-actions{display:flex;align-items:center;gap:4px;flex:none}
.icon-btn{width:24px;height:24px;border-radius:5px;border:1px solid var(--border-2);background:var(--surface-2);color:var(--muted);display:grid;place-items:center;cursor:pointer;padding:0;font-size:12px;line-height:1}
.icon-btn:hover{color:var(--text)}
.icon-btn.del:hover{color:#f87171;border-color:#471f23}

.search-bar{display:flex;gap:8px;flex:1;min-width:0}
.catalog-toolbar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 16px;border-bottom:1px solid var(--border);flex-wrap:wrap}
.catalog-row{display:flex;align-items:center;gap:12px;padding:10px 16px;min-width:0}
.catalog-row img{width:34px;height:48px;border-radius:5px;object-fit:cover;background:var(--surface-2);flex:none}
.catalog-info{flex:1;min-width:0}
.catalog-info b{display:block;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.catalog-info small{color:var(--muted);font-size:12px}
.row-btns{display:flex;gap:6px;flex:none;flex-wrap:wrap}

.ip-item{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 16px;min-width:0}
.ip-item code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px;font-weight:600}
.ip-item small{display:block;color:var(--muted);font-size:12px;margin-top:1px}
.action-item{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px}
.action-item strong{display:block;font-size:13.5px}
.ev-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 16px;font-size:12.5px;min-width:0}
.ev-row span{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#d4d4d8}
.ev-row time{flex:none;font-size:11.5px;color:var(--muted)}
.muted-count{font-size:12px;color:var(--muted);font-weight:600}

.toast{position:fixed;bottom:22px;right:22px;padding:10px 14px;border-radius:8px;background:#18181d;border:1px solid var(--border-2);color:var(--text);font-size:13px;font-weight:600;box-shadow:0 10px 30px #0009;transform:translateY(20px);opacity:0;pointer-events:none;transition:all .18s;z-index:80}
.toast.show{transform:none;opacity:1}

/* Responsive */
@media(max-width:940px){
  .three-col,.two-col{grid-template-columns:1fr}
  .stats-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:820px){
  .layout{display:block;min-height:100dvh}
  .sidebar{display:none}
  .mobile-top{position:sticky;top:0;z-index:40;height:50px;padding:0 14px;background:#09090bf2;backdrop-filter:blur(10px);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:10px}
  .mobile-top img{height:17px;width:auto}
  .mobile-tabs{position:fixed;left:0;right:0;bottom:0;z-index:50;height:calc(58px + env(safe-area-inset-bottom));padding:4px 6px env(safe-area-inset-bottom);background:#0d0d10f5;backdrop-filter:blur(12px);border-top:1px solid var(--border);display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:2px}
  .m-tab{border:0;background:transparent;color:var(--muted);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;font-size:11px;font-weight:600;border-radius:8px;cursor:pointer;padding:4px 2px}
  .m-tab svg{width:19px;height:19px}
  .m-tab.active{color:var(--text)}
  .m-tab.active svg{color:var(--accent)}
  .content{padding:16px 14px calc(78px + env(safe-area-inset-bottom))}
  .page-head{margin-bottom:14px}
  .page-head h1{font-size:19px}
  .stats-grid{gap:10px}
  .stat-card{padding:13px 14px}
  .stat-value{font-size:21px}
  .input,.select{height:40px;font-size:16px}
  .field-row{grid-template-columns:1fr;gap:8px}
  .field-row.toggle-line{grid-template-columns:minmax(0,1fr) auto}
  .sub-fields{grid-template-columns:1fr}
  .catalog-toolbar{flex-direction:column;align-items:stretch}
  .catalog-row{flex-wrap:wrap}
  .catalog-row .row-btns{width:100%;justify-content:flex-end}
  .action-item .row-btns{width:auto;flex-wrap:nowrap}
  .viewer-row{padding:11px 13px;gap:10px}
  .toast{left:14px;right:14px;bottom:calc(68px + env(safe-area-inset-bottom));text-align:center}
}
</style></head><body>

<header class="mobile-top">
  <img src="/images/kozutv-logo.png" alt="kozuTV">
  <a class="btn secondary sm" href="/browse">Open Site ↗</a>
</header>

<div class="layout">
  <aside class="sidebar">
    <div class="brand-bar">
      <img src="/images/kozutv-logo.png" alt="kozuTV">
    </div>
    <button class="nav-item active" data-tab="overview" type="button">
      ${ADMIN_ICONS.overview}
      <span>Overview</span>
    </button>
    <button class="nav-item" data-tab="settings" type="button">
      ${ADMIN_ICONS.settings}
      <span>Settings</span>
    </button>
    <button class="nav-item" data-tab="catalog" type="button">
      ${ADMIN_ICONS.catalog}
      <span>Catalog</span>
    </button>
    <button class="nav-item" data-tab="security" type="button">
      ${ADMIN_ICONS.security}
      <span>Security</span>
    </button>
    <div class="sidebar-foot">
      <a class="ext-link" href="/browse" target="_blank" rel="noopener"><span>Open Site</span><span>↗</span></a>
    </div>
  </aside>

  <main class="content">
    <!-- TAB 1: OVERVIEW -->
    <section class="pane active" id="pane-overview">
      <div class="page-head">
        <h1>Overview</h1>
      </div>

      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-label"><span>Online</span></div>
          <div class="stat-value" id="val-users">0</div>
        </div>
        <div class="stat-card">
          <div class="stat-label"><span>Watching</span></div>
          <div class="stat-value" id="val-watch">0</div>
        </div>
        <button class="stat-card" type="button" id="titles-link-card" data-goto-tab="catalog">
          <div class="stat-label"><span>Titles</span><span>→</span></div>
          <div class="stat-value" id="val-catalog">—</div>
        </button>
        <a class="stat-card" href="/admin/system" id="system-link-card">
          <div class="stat-label"><span>System</span><span>↗</span></div>
          <div class="stat-value" id="val-cpu">—</div>
        </a>
      </div>

      <div class="card">
        <div class="card-head">
          <h2>Visitors</h2>
          <div class="seg" id="viewer-filter">
            <button type="button" class="active" data-vfilter="all">All</button>
            <button type="button" data-vfilter="watching">Watching</button>
            <button type="button" data-vfilter="browse">Browsing</button>
          </div>
        </div>
        <div class="card-body flush list-divide" id="presence-list">
          <div class="empty-note">No active visitors</div>
        </div>
      </div>
    </section>

    <!-- TAB 2: SETTINGS -->
    <section class="pane" id="pane-settings">
      <form id="config-form">
        <div class="page-head">
          <h1>Settings</h1>
          <div class="head-actions">
            <button type="button" class="btn secondary" id="reset-theme-btn">Reset</button>
            <button type="submit" class="btn">Save</button>
          </div>
        </div>

        <div class="stack">
          <div class="card">
            <div class="card-head"><h2>Playback</h2></div>
            <div class="card-body flush">
              <div class="field-row">
                <div class="field-info"><strong>Movie / TV Server</strong></div>
                <select class="select" name="defaultOttServer">
                  <option value="vidcore">VidCore</option>
                  <option value="embedwave">EmbedWave</option>
                  <option value="cinesrc">CineSrc</option>
                  <option value="vidlink">VidLink</option>
                  <option value="vidsrc">VidSrc</option>
                </select>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Anime Server</strong></div>
                <select class="select" name="defaultAnimeServer">
                  <option value="megaplay">MegaPlay</option>
                  <option value="vidlink">VidLink</option>
                </select>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Anime Audio</strong></div>
                <select class="select" name="defaultAnimeLang">
                  <option value="sub">Sub</option>
                  <option value="dub">Dub</option>
                </select>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Default Quality</strong></div>
                <select class="select" name="defaultQuality">
                  <option value="auto">Auto</option>
                  <option value="1080">1080p</option>
                  <option value="720">720p</option>
                  <option value="480">480p</option>
                </select>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Playback Speed</strong></div>
                <select class="select" name="defaultSpeed">
                  <option value="1">1.0x</option>
                  <option value="1.25">1.25x</option>
                  <option value="1.5">1.5x</option>
                </select>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Autoplay</strong></div>
                <label class="switch"><input type="checkbox" name="defaultAutoplay" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Auto Next Episode</strong></div>
                <label class="switch"><input type="checkbox" name="defaultAutonext" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Auto Skip Intro</strong></div>
                <label class="switch"><input type="checkbox" name="defaultAutoskip"><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Start Muted</strong></div>
                <label class="switch"><input type="checkbox" name="defaultMuted"><span class="slider"></span></label>
              </div>
              <div class="field-row block">
                <div class="field-info"><strong>Active Movie / TV Servers</strong></div>
                <div class="chip-checks" id="ott-server-checks">
                  <label class="chip-check"><input type="checkbox" value="vidcore" checked>VidCore</label>
                  <label class="chip-check"><input type="checkbox" value="embedwave" checked>EmbedWave</label>
                  <label class="chip-check"><input type="checkbox" value="cinesrc" checked>CineSrc</label>
                  <label class="chip-check"><input type="checkbox" value="vidlink" checked>VidLink</label>
                  <label class="chip-check"><input type="checkbox" value="vidsrc" checked>VidSrc</label>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h2>Appearance &amp; Home</h2></div>
            <div class="card-body flush">
              <div class="field-row">
                <div class="field-info"><strong>Site Name</strong></div>
                <input class="input" type="text" name="brandName" maxlength="28" value="kozuTV">
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Accent Color</strong></div>
                <div>
                  <div class="color-ctrl">
                    <input type="color" name="accentColor" id="accent-picker" value="#ff731c">
                    <input class="input" type="text" id="accent-hex" value="#ff731c" maxlength="7" aria-label="Accent hex">
                  </div>
                  <div class="swatches">
                    <button type="button" class="swatch" data-swatch="#ff731c" style="background:#ff731c"></button>
                    <button type="button" class="swatch" data-swatch="#e11d48" style="background:#e11d48"></button>
                    <button type="button" class="swatch" data-swatch="#3b82f6" style="background:#3b82f6"></button>
                    <button type="button" class="swatch" data-swatch="#10b981" style="background:#10b981"></button>
                    <button type="button" class="swatch" data-swatch="#8b5cf6" style="background:#8b5cf6"></button>
                    <button type="button" class="swatch" data-swatch="#f59e0b" style="background:#f59e0b"></button>
                  </div>
                </div>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Desktop Grid Columns</strong></div>
                <select class="select" name="gridCols">
                  <option value="5">5 Columns</option>
                  <option value="6" selected>6 Columns</option>
                  <option value="7">7 Columns</option>
                  <option value="8">8 Columns</option>
                </select>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Poster Radius (px)</strong></div>
                <input class="input" type="number" name="posterRadius" min="0" max="24" step="1" value="10">
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Hover Scale</strong></div>
                <input class="input" type="number" name="cardHoverScale" min="1" max="1.12" step="0.005" value="1.045">
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Hero Banner</strong></div>
                <label class="switch"><input type="checkbox" name="showHero" checked><span class="slider"></span></label>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Spotlight Slides</strong></div>
                <select class="select" name="spotlightSlideCount">
                  <option value="3">3</option>
                  <option value="5">5</option>
                  <option value="6" selected>6</option>
                  <option value="8">8</option>
                  <option value="10">10</option>
                </select>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Slide Interval (s)</strong></div>
                <input class="input" type="number" name="heroIntervalSec" min="3" max="30" step="0.5" value="6.5">
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Hero Button Text</strong></div>
                <input class="input" type="text" name="heroCtaText" maxlength="28" value="Start Watching">
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Trending Heading</strong></div>
                <input class="input" type="text" name="trendingTitle" maxlength="34" value="Trending Now">
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Continue Watching Row</strong></div>
                <label class="switch"><input type="checkbox" name="showContinueRow" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Suggested Row</strong></div>
                <label class="switch"><input type="checkbox" name="showSuggestedRow" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Card Ratings</strong></div>
                <label class="switch"><input type="checkbox" name="showRatings" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Card Year &amp; Type</strong></div>
                <label class="switch"><input type="checkbox" name="showCardMeta" checked><span class="slider"></span></label>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Home Genre Rows</strong></div>
                <select class="select" name="homeGenreCount">
                  <option value="0">0</option>
                  <option value="2">2</option>
                  <option value="3" selected>3</option>
                  <option value="4">4</option>
                  <option value="6">6</option>
                </select>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h2>Navigation &amp; Site</h2></div>
            <div class="card-body flush">
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Watchlist Header Icon</strong></div>
                <label class="switch"><input type="checkbox" name="showWatchlistIcon" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Schedule Menu Link</strong></div>
                <label class="switch"><input type="checkbox" name="showScheduleLink" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Random Menu Link</strong></div>
                <label class="switch"><input type="checkbox" name="showRandomLink" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Filters Menu Link</strong></div>
                <label class="switch"><input type="checkbox" name="showFiltersLink" checked><span class="slider"></span></label>
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Show Footer</strong></div>
                <label class="switch"><input type="checkbox" name="showFooter" checked><span class="slider"></span></label>
              </div>
              <div class="field-row">
                <div class="field-info"><strong>Footer Tagline</strong></div>
                <input class="input" type="text" name="footerTagline" maxlength="80" value="Free entertainment for all">
              </div>
              <div class="field-row toggle-line">
                <div class="field-info"><strong>Announcement Banner</strong></div>
                <label class="switch"><input type="checkbox" name="annEnabled" id="ann-toggle"><span class="slider"></span></label>
              </div>
              <div class="sub-fields" id="ann-fields" hidden>
                <div>
                  <label class="sub-label">Badge</label>
                  <input class="input" name="annBadge" value="UPDATE" maxlength="14">
                </div>
                <div>
                  <label class="sub-label">Link</label>
                  <input class="input" name="annLink" placeholder="/schedule" maxlength="160">
                </div>
                <div class="full">
                  <label class="sub-label">Message</label>
                  <input class="input" name="annText" placeholder="Banner text" maxlength="200">
                </div>
              </div>

              <div class="field-row toggle-line">
                <div class="field-info"><strong>Maintenance Mode</strong></div>
                <label class="switch"><input type="checkbox" name="maintEnabled" id="maint-toggle"><span class="slider"></span></label>
              </div>
              <div class="sub-fields" id="maint-fields" hidden>
                <div class="full">
                  <label class="sub-label">Message</label>
                  <input class="input" name="maintMsg" maxlength="220">
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </section>

    <!-- TAB 3: CATALOG (SIMPLE, EFFECTIVE & HIGHLY CUSTOMIZABLE) -->
    <section class="pane" id="pane-catalog">
      <div class="page-head">
        <h1>Catalog</h1>
        <div class="head-actions">
          <button type="button" class="btn" id="save-catalog-btn">Save</button>
        </div>
      </div>

      <div class="stack">
        <div class="card">
          <div class="card-head"><h2>Catalog Rules</h2></div>
          <div class="card-body flush">
            <div class="field-row block">
              <div class="field-info"><strong>Content Types</strong></div>
              <div class="chip-checks" id="cat-type-checks">
                <label class="chip-check"><input type="checkbox" value="anime" checked>Anime</label>
                <label class="chip-check"><input type="checkbox" value="movie" checked>Movies</label>
                <label class="chip-check"><input type="checkbox" value="tv" checked>TV Series</label>
              </div>
            </div>
            <div class="field-row">
              <div class="field-info"><strong>Banner Source</strong></div>
              <select class="select" id="cat-spot-mode">
                <option value="mix">Pinned + Auto Trending</option>
                <option value="custom">Pinned Only</option>
              </select>
            </div>
            <div class="field-row">
              <div class="field-info"><strong>Featured Row Title</strong></div>
              <input class="input" id="cat-feat-title" maxlength="32" value="Featured">
            </div>
            <div class="field-row block">
              <div class="field-info"><strong>Pinned Home Genres</strong></div>
              <div class="chip-checks" id="cat-genre-pills">
                ${genreOptions.map(g => `<button type="button" class="g-pill" data-g-pill="${g}">${g}</button>`).join('')}
              </div>
            </div>
          </div>
        </div>

        <div class="three-col">
          <div class="card">
            <div class="card-head">
              <h2>Banner Lineup</h2>
              <span class="muted-count" id="spot-count">0</span>
            </div>
            <div class="mini-list" id="spot-list"><div class="empty-note">Auto</div></div>
          </div>

          <div class="card">
            <div class="card-head">
              <h2>Featured Row</h2>
              <span class="muted-count" id="feat-count">0</span>
            </div>
            <div class="mini-list" id="feat-list"><div class="empty-note">None</div></div>
          </div>

          <div class="card">
            <div class="card-head">
              <h2>Hidden</h2>
              <span class="muted-count" id="hid-count">0</span>
            </div>
            <div class="mini-list" id="hidden-list"><div class="empty-note">None</div></div>
          </div>
        </div>

        <div class="card">
          <div class="catalog-toolbar">
            <div class="search-bar">
              <input class="input" id="curate-q" placeholder="Search anime, movie, or series…">
              <button type="button" class="btn" id="curate-search-btn">Search</button>
            </div>
            <div class="seg" id="cat-type-filter">
              <button type="button" class="active" data-cfilter="all">All</button>
              <button type="button" data-cfilter="anime">Anime</button>
              <button type="button" data-cfilter="movie">Movie</button>
              <button type="button" data-cfilter="tv">TV</button>
            </div>
          </div>
          <div class="card-body flush list-divide" id="curate-results"></div>
        </div>
      </div>
    </section>

    <!-- TAB 4: SECURITY -->
    <section class="pane" id="pane-security">
      <div class="page-head">
        <h1>Security</h1>
      </div>

      <div class="two-col">
        <div class="stack">
          <div class="card">
            <div class="card-head">
              <h2>User Cache</h2>
              <span class="muted-count" id="saved-users-count">0</span>
            </div>
            <div class="card-body flush list-divide">
              <div class="action-item">
                <div><strong>All Users Cache</strong></div>
                <div class="row-btns">
                  <button type="button" class="btn secondary sm" id="export-cache-btn">Export</button>
                  <button type="button" class="btn sm" id="import-cache-btn">Import</button>
                  <input type="file" id="import-cache-file" accept=".json,application/json" hidden>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h2>Whitelisted IPs</h2></div>
            <div class="card-body flush list-divide" id="ip-list"></div>
          </div>
        </div>

        <div class="stack">
          <div class="card">
            <div class="card-head"><h2>Server Cache</h2></div>
            <div class="card-body flush list-divide">
              <div class="action-item">
                <div><strong>Stream Resolvers</strong></div>
                <button type="button" class="btn secondary sm" data-purge="resolvers">Clear</button>
              </div>
              <div class="action-item">
                <div><strong>Media Proxy</strong></div>
                <button type="button" class="btn secondary sm" data-purge="proxy">Clear</button>
              </div>
              <div class="action-item">
                <div><strong>All Server Caches</strong></div>
                <button type="button" class="btn danger sm" data-purge="all">Clear All</button>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-head"><h2>Blocked Requests</h2></div>
            <div class="card-body flush list-divide" id="blocked-list">
              <div class="empty-note">None</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
</div>

<nav class="mobile-tabs" aria-label="Admin sections">
  <button class="m-tab active" data-tab="overview" type="button">
    ${ADMIN_ICONS.overview}
    <span>Overview</span>
  </button>
  <button class="m-tab" data-tab="settings" type="button">
    ${ADMIN_ICONS.settings}
    <span>Settings</span>
  </button>
  <button class="m-tab" data-tab="catalog" type="button">
    ${ADMIN_ICONS.catalog}
    <span>Catalog</span>
  </button>
  <button class="m-tab" data-tab="security" type="button">
    ${ADMIN_ICONS.security}
    <span>Security</span>
  </button>
</nav>

<div class="toast" id="toast"></div>

<script>
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtDur = sec => {
  sec = Math.max(0, Math.floor(Number(sec) || 0));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  if (h >= 24) return Math.floor(h / 24) + 'd ' + (h % 24) + 'h';
  return h ? h + 'h ' + m + 'm' : m + 'm ' + (sec % 60) + 's';
};
const fmtClock = sec => {
  sec = Math.max(0, Math.floor(Number(sec) || 0));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = String(sec % 60).padStart(2, '0');
  return h ? h + ':' + String(m).padStart(2, '0') + ':' + s : m + ':' + s;
};
function showToast(text) {
  const t = document.getElementById('toast');
  t.textContent = text;
  t.classList.add('show');
  clearTimeout(window._toastT);
  window._toastT = setTimeout(() => t.classList.remove('show'), 2200);
}

let catalogFeedLoaded = false;
let currentFeedItems = [];
let catalogMetaMap = {};
let catalogTypeFilter = 'all';

function switchTab(tab) {
  document.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.pane').forEach(p => p.classList.toggle('active', p.id === 'pane-' + tab));
  window.scrollTo(0, 0);
  if (tab === 'catalog' && !catalogFeedLoaded) loadCatalogState();
}
document.querySelectorAll('[data-tab]').forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});
document.querySelectorAll('[data-goto-tab]').forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.gotoTab));
});

let viewerFilter = 'all';
let latestSessions = [];
let configHydrated = false;
let latestConfig = null;

document.getElementById('viewer-filter').addEventListener('click', e => {
  const b = e.target.closest('[data-vfilter]');
  if (!b) return;
  viewerFilter = b.dataset.vfilter;
  document.querySelectorAll('#viewer-filter button').forEach(x => x.classList.toggle('active', x === b));
  renderPresenceRows(latestSessions);
});

document.getElementById('cat-type-filter').addEventListener('click', e => {
  const b = e.target.closest('[data-cfilter]');
  if (!b) return;
  catalogTypeFilter = b.dataset.cfilter;
  document.querySelectorAll('#cat-type-filter button').forEach(x => x.classList.toggle('active', x === b));
  renderCatalogFeed();
});

const annToggle = document.getElementById('ann-toggle');
const maintToggle = document.getElementById('maint-toggle');
const syncSubFields = () => {
  document.getElementById('ann-fields').hidden = !annToggle.checked;
  document.getElementById('maint-fields').hidden = !maintToggle.checked;
};
annToggle.addEventListener('change', syncSubFields);
maintToggle.addEventListener('change', syncSubFields);

const picker = document.getElementById('accent-picker');
const hexInput = document.getElementById('accent-hex');
picker.addEventListener('input', () => { hexInput.value = picker.value; });
hexInput.addEventListener('input', () => {
  if (/^#[0-9a-fA-F]{6}$/.test(hexInput.value.trim())) picker.value = hexInput.value.trim();
});
document.querySelectorAll('[data-swatch]').forEach(btn => {
  btn.addEventListener('click', () => {
    picker.value = btn.dataset.swatch;
    hexInput.value = btn.dataset.swatch;
  });
});

function hydrateConfigForm(cfg) {
  latestConfig = cfg;
  const f = document.getElementById('config-form');
  f.brandName.value = cfg.brandName || 'kozuTV';
  f.accentColor.value = cfg.accentColor || '#ff731c';
  hexInput.value = cfg.accentColor || '#ff731c';
  f.gridCols.value = String(cfg.gridCols ?? 6);
  f.posterRadius.value = cfg.posterRadius ?? 10;
  f.cardHoverScale.value = cfg.cardHoverScale ?? 1.045;
  f.showHero.checked = cfg.showHero !== false;
  f.spotlightSlideCount.value = String(cfg.spotlightSlideCount ?? 6);
  f.heroIntervalSec.value = cfg.heroIntervalSec ?? 6.5;
  f.heroCtaText.value = cfg.heroCtaText || 'Start Watching';
  f.trendingTitle.value = cfg.trendingTitle || 'Trending Now';
  f.showContinueRow.checked = cfg.showContinueRow !== false;
  f.showSuggestedRow.checked = cfg.showSuggestedRow !== false;
  f.showRatings.checked = cfg.showRatings !== false;
  f.showCardMeta.checked = cfg.showCardMeta !== false;
  f.homeGenreCount.value = String(cfg.homeGenreCount ?? 3);
  f.showWatchlistIcon.checked = cfg.showWatchlistIcon !== false;
  f.showScheduleLink.checked = cfg.showScheduleLink !== false;
  f.showRandomLink.checked = cfg.showRandomLink !== false;
  f.showFiltersLink.checked = cfg.showFiltersLink !== false;
  f.showFooter.checked = cfg.showFooter !== false;
  f.footerTagline.value = cfg.footerTagline || 'Free entertainment for all';
  f.defaultOttServer.value = cfg.defaultOttServer || 'vidcore';
  f.defaultAnimeServer.value = cfg.defaultAnimeServer || 'megaplay';
  f.defaultAnimeLang.value = cfg.defaultAnimeLang || 'sub';
  f.defaultQuality.value = cfg.defaultQuality || 'auto';
  f.defaultSpeed.value = cfg.defaultSpeed || '1';
  f.defaultAutoplay.checked = cfg.defaultAutoplay !== false;
  f.defaultAutonext.checked = cfg.defaultAutonext !== false;
  f.defaultAutoskip.checked = Boolean(cfg.defaultAutoskip);
  f.defaultMuted.checked = Boolean(cfg.defaultMuted);
  f.annEnabled.checked = Boolean(cfg.announcement?.enabled);
  f.annBadge.value = cfg.announcement?.badge || 'UPDATE';
  f.annText.value = cfg.announcement?.text || '';
  f.annLink.value = cfg.announcement?.link || '';
  f.maintEnabled.checked = Boolean(cfg.maintenance?.enabled);
  f.maintMsg.value = cfg.maintenance?.message || '';
  document.querySelectorAll('#ott-server-checks input').forEach(cb => {
    cb.checked = (cfg.enabledOttServers || []).includes(cb.value);
  });

  // Hydrate Catalog Rules
  const enabledTypes = cfg.enabledTypes || ['anime', 'movie', 'tv'];
  document.querySelectorAll('#cat-type-checks input').forEach(cb => {
    cb.checked = enabledTypes.includes(cb.value);
  });
  document.getElementById('cat-spot-mode').value = cfg.spotlightMode || 'mix';
  document.getElementById('cat-feat-title').value = cfg.featuredTitle || 'Featured';
  const pinnedG = cfg.pinnedGenres || [];
  document.querySelectorAll('[data-g-pill]').forEach(p => {
    p.classList.toggle('on', pinnedG.includes(p.dataset.gPill));
  });

  syncSubFields();
  renderCurationLists(cfg);
  renderCatalogFeed();
}

function renderMiniList(boxId, countId, listName, keys, emptyLabel, allowMove) {
  const box = document.getElementById(boxId);
  const cnt = document.getElementById(countId);
  cnt.textContent = keys.length;
  if (!keys.length) {
    box.innerHTML = '<div class="empty-note">' + emptyLabel + '</div>';
    return;
  }
  box.innerHTML = keys.map((k, idx) => {
    const meta = catalogMetaMap[k];
    const title = meta?.title || k;
    const poster = meta?.poster ? '<img src="' + esc(meta.poster) + '" alt="">' : '';
    const upBtn = allowMove && idx > 0
      ? '<button type="button" class="icon-btn" data-move-list="' + listName + '" data-move-key="' + esc(k) + '" data-move-dir="-1" title="Move up">↑</button>'
      : '';
    return '<div class="mini-item">' + poster + '<span>' + esc(title) + '</span>'
      + '<div class="mini-actions">' + upBtn
      + '<button type="button" class="icon-btn del" data-rem-list="' + listName + '" data-rem-key="' + esc(k) + '" aria-label="Remove">×</button>'
      + '</div></div>';
  }).join('');
}

function renderCurationLists(cfg) {
  if (!cfg) return;
  renderMiniList('spot-list', 'spot-count', 'spotlightIds', cfg.spotlightIds || [], 'Auto', true);
  renderMiniList('feat-list', 'feat-count', 'featuredIds', cfg.featuredIds || [], 'None', true);
  renderMiniList('hidden-list', 'hid-count', 'hiddenIds', cfg.hiddenIds || [], 'None', false);
}

function renderCatalogFeed() {
  const box = document.getElementById('curate-results');
  if (!box) return;
  const cfg = latestConfig || {};
  const spotSet = new Set(cfg.spotlightIds || []);
  const featSet = new Set(cfg.featuredIds || []);
  const hidSet = new Set(cfg.hiddenIds || []);
  const list = currentFeedItems.filter(it => catalogTypeFilter === 'all' || it.type === catalogTypeFilter);
  if (!list.length) {
    box.innerHTML = '<div class="empty-note">No titles</div>';
    return;
  }
  box.innerHTML = list.slice(0, 20).map(it => {
    const key = it.type + ':' + it.id;
    catalogMetaMap[key] = { title: it.title, poster: it.poster || '' };
    const inSpot = spotSet.has(key);
    const inFeat = featSet.has(key);
    const inHid = hidSet.has(key);
    return '<div class="catalog-row">'
      + (it.poster ? '<img src="' + esc(it.poster) + '" alt="">' : '')
      + '<div class="catalog-info"><b>' + esc(it.title) + '</b><small>' + esc(it.type.toUpperCase()) + (it.year ? ' · ' + esc(it.year) : '') + (it.rating ? ' · ★ ' + esc(it.rating) : '') + '</small></div>'
      + '<div class="row-btns">'
      + '<button type="button" class="btn secondary sm ' + (inSpot ? 'on' : '') + '" data-toggle-list="spotlightIds" data-item-key="' + esc(key) + '">' + (inSpot ? 'In Banner' : 'Banner') + '</button>'
      + '<button type="button" class="btn secondary sm ' + (inFeat ? 'on' : '') + '" data-toggle-list="featuredIds" data-item-key="' + esc(key) + '">' + (inFeat ? 'Featured' : 'Feature') + '</button>'
      + '<button type="button" class="btn ' + (inHid ? 'danger' : 'secondary') + ' sm" data-toggle-list="hiddenIds" data-item-key="' + esc(key) + '">' + (inHid ? 'Hidden' : 'Hide') + '</button>'
      + '</div></div>';
  }).join('');
}

async function loadCatalogState() {
  try {
    const r = await fetch('/api/admin/catalog-state');
    if (!r.ok) return;
    const d = await r.json();
    catalogFeedLoaded = true;
    for (const it of [...(d.resolved || []), ...(d.feed || [])]) {
      if (it?.type && it?.id) catalogMetaMap[it.type + ':' + it.id] = { title: it.title, poster: it.poster || '' };
    }
    if (!document.getElementById('curate-q').value.trim()) {
      currentFeedItems = d.feed || [];
    }
    renderCurationLists(latestConfig);
    renderCatalogFeed();
  } catch {}
}

async function saveConfigPatch(payload, msgText = 'Saved') {
  const r = await fetch('/api/admin/config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const d = await r.json();
  if (r.ok) {
    hydrateConfigForm(d.siteConfig);
    document.documentElement.style.setProperty('--accent', d.siteConfig.accentColor);
    if (msgText) showToast(msgText);
  }
}

function renderPresenceRows(sessions) {
  const box = document.getElementById('presence-list');
  const filtered = sessions.filter(s => {
    if (viewerFilter === 'watching') return s.activity === 'watching';
    if (viewerFilter === 'browse') return s.activity !== 'watching';
    return true;
  });
  if (!filtered.length) {
    box.innerHTML = '<div class="empty-note">No active visitors</div>';
    return;
  }
  box.innerHTML = filtered.map(s => {
    const m = s.media;
    const isWatch = s.activity === 'watching' && m?.title;
    const pct = isWatch && m.duration > 0 ? Math.min(100, Math.round((m.currentTime / m.duration) * 100)) : 0;
    const epLabel = !isWatch ? '' : m.type === 'movie' ? 'Movie' : m.type === 'tv' ? 'S' + m.season + 'E' + m.episode : 'EP ' + m.episode;
    const thumb = isWatch && m.poster
      ? '<img class="v-thumb" src="' + esc(m.poster) + '" alt="">'
      : '<div class="v-icon">' + esc((s.device || 'U').slice(0, 2).toUpperCase()) + '</div>';
    const title = isWatch
      ? esc(m.title) + ' <span>· ' + esc(epLabel) + '</span>'
      : s.activity === 'search' && s.query ? 'Search “' + esc(s.query) + '”'
      : s.activity === 'detail' && m?.title ? esc(m.title)
      : esc(s.route === '/browse' ? 'Home' : (s.route || 'Home'));
    const metaParts = isWatch
      ? [m.server, m.audio, m.duration ? fmtClock(m.currentTime) + ' / ' + fmtClock(m.duration) : '', s.device, s.ip].filter(Boolean)
      : [s.device, s.ip, fmtDur((Date.now() - s.startedAt) / 1000)].filter(Boolean);
    return '<div class="viewer-row">' + thumb
      + '<div class="v-main"><div class="v-title">' + title + '</div><div class="v-meta">' + esc(metaParts.join(' · ')) + '</div>'
      + (isWatch && m.duration > 0 ? '<div class="v-prog"><div style="width:' + pct + '%"></div></div>' : '')
      + '</div></div>';
  }).join('');
}

async function pollTelemetry() {
  try {
    const r = await fetch('/api/admin/telemetry');
    if (r.status === 403) { location.reload(); return; }
    const d = await r.json();

    document.getElementById('val-users').textContent = d.presence.onlineCount;
    document.getElementById('val-watch').textContent = d.presence.watchingCount;
    document.getElementById('val-cpu').textContent = d.system.cpuPercent + '%';

    const totalTitles = (d.system.catalogCounts.anime || 0) + (d.system.catalogCounts.ott || 0);
    document.getElementById('val-catalog').textContent = totalTitles.toLocaleString();

    latestSessions = d.presence.sessions || [];
    renderPresenceRows(latestSessions);

    const uCount = Number(d.savedUsersCount) || 0;
    document.getElementById('saved-users-count').textContent = uCount + (uCount === 1 ? ' user' : ' users');

    const ips = d.security.authorizedIps || [];
    document.getElementById('ip-list').innerHTML = ips.length
      ? ips.map(row =>
          '<div class="ip-item"><div style="min-width:0"><code>' + esc(row.ip) + '</code><small>' + esc(row.label || '') + '</small></div>'
          + '<button class="btn danger sm" type="button" data-revoke-ip="' + esc(row.ip) + '">Revoke</button></div>'
        ).join('')
      : '<div class="empty-note">None</div>';

    const blk = (d.security.blockedAttempts || []).slice(0, 10);
    document.getElementById('blocked-list').innerHTML = blk.length
      ? blk.map(b => '<div class="ev-row"><span><code>' + esc(b.ip) + '</code> → ' + esc(b.path) + '</span><time>' + new Date(b.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + '</time></div>').join('')
      : '<div class="empty-note">None</div>';

    if (!configHydrated && d.siteConfig) {
      configHydrated = true;
      hydrateConfigForm(d.siteConfig);
      document.documentElement.style.setProperty('--accent', d.siteConfig.accentColor);
    } else if (d.siteConfig) {
      latestConfig = d.siteConfig;
      renderCurationLists(d.siteConfig);
    }
  } catch {}
}

document.addEventListener('click', async e => {
  const gPill = e.target.closest('[data-g-pill]');
  if (gPill) {
    gPill.classList.toggle('on');
    return;
  }
  const togBtn = e.target.closest('[data-toggle-list]');
  if (togBtn && latestConfig) {
    const field = togBtn.dataset.toggleList;
    const key = togBtn.dataset.itemKey;
    const cur = [...(latestConfig[field] || [])];
    const next = cur.includes(key) ? cur.filter(x => x !== key) : [key, ...cur];
    const patch = { ...latestConfig, [field]: next };
    if (field === 'spotlightIds') patch.pinnedHeroId = next[0] || '';
    await saveConfigPatch(patch, '');
    return;
  }
  const remBtn = e.target.closest('[data-rem-list]');
  if (remBtn && latestConfig) {
    const field = remBtn.dataset.remList;
    const key = remBtn.dataset.remKey;
    const next = (latestConfig[field] || []).filter(x => x !== key);
    const patch = { ...latestConfig, [field]: next };
    if (field === 'spotlightIds') patch.pinnedHeroId = next[0] || '';
    await saveConfigPatch(patch, '');
    return;
  }
  const moveBtn = e.target.closest('[data-move-list]');
  if (moveBtn && latestConfig) {
    const field = moveBtn.dataset.moveList;
    const key = moveBtn.dataset.moveKey;
    const dir = Number(moveBtn.dataset.moveDir) || -1;
    const arr = [...(latestConfig[field] || [])];
    const idx = arr.indexOf(key);
    const target = idx + dir;
    if (idx >= 0 && target >= 0 && target < arr.length) {
      [arr[idx], arr[target]] = [arr[target], arr[idx]];
      const patch = { ...latestConfig, [field]: arr };
      if (field === 'spotlightIds') patch.pinnedHeroId = arr[0] || '';
      await saveConfigPatch(patch, '');
    }
    return;
  }
  const revokeBtn = e.target.closest('[data-revoke-ip]');
  if (revokeBtn) {
    const ip = revokeBtn.dataset.revokeIp;
    const r = await fetch('/api/admin/ips', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'revoke', ip })
    });
    if (r.ok) { showToast('Revoked ' + ip); pollTelemetry(); }
  }
});

document.getElementById('save-catalog-btn').addEventListener('click', async () => {
  if (!latestConfig) return;
  const enabledTypes = [...document.querySelectorAll('#cat-type-checks input:checked')].map(c => c.value);
  const pinnedGenres = [...document.querySelectorAll('[data-g-pill].on')].map(p => p.dataset.gPill);
  await saveConfigPatch({
    ...latestConfig,
    enabledTypes: enabledTypes.length ? enabledTypes : ['anime', 'movie', 'tv'],
    spotlightMode: document.getElementById('cat-spot-mode').value,
    featuredTitle: document.getElementById('cat-feat-title').value,
    pinnedGenres
  });
});

document.getElementById('config-form').addEventListener('submit', async e => {
  e.preventDefault();
  const f = e.target;
  const enabledOttServers = [...document.querySelectorAll('#ott-server-checks input:checked')].map(c => c.value);
  const chosenHex = /^#[0-9a-fA-F]{6}$/.test(hexInput.value.trim()) ? hexInput.value.trim() : f.accentColor.value;
  await saveConfigPatch({
    ...(latestConfig || {}),
    brandName: f.brandName.value,
    accentColor: chosenHex,
    accentSecondary: chosenHex,
    gridCols: Number(f.gridCols.value),
    posterRadius: Number(f.posterRadius.value),
    cardHoverScale: Number(f.cardHoverScale.value),
    showHero: f.showHero.checked,
    spotlightSlideCount: Number(f.spotlightSlideCount.value),
    heroIntervalSec: Number(f.heroIntervalSec.value),
    heroCtaText: f.heroCtaText.value,
    trendingTitle: f.trendingTitle.value,
    showContinueRow: f.showContinueRow.checked,
    showSuggestedRow: f.showSuggestedRow.checked,
    showRatings: f.showRatings.checked,
    showCardMeta: f.showCardMeta.checked,
    homeGenreCount: Number(f.homeGenreCount.value),
    showWatchlistIcon: f.showWatchlistIcon.checked,
    showScheduleLink: f.showScheduleLink.checked,
    showRandomLink: f.showRandomLink.checked,
    showFiltersLink: f.showFiltersLink.checked,
    showFooter: f.showFooter.checked,
    footerTagline: f.footerTagline.value,
    defaultOttServer: f.defaultOttServer.value,
    enabledOttServers,
    defaultAnimeServer: f.defaultAnimeServer.value,
    defaultAnimeLang: f.defaultAnimeLang.value,
    defaultQuality: f.defaultQuality.value,
    defaultSpeed: f.defaultSpeed.value,
    defaultAutoplay: f.defaultAutoplay.checked,
    defaultAutonext: f.defaultAutonext.checked,
    defaultAutoskip: f.defaultAutoskip.checked,
    defaultMuted: f.defaultMuted.checked,
    announcement: {
      enabled: f.annEnabled.checked,
      badge: f.annBadge.value,
      text: f.annText.value,
      link: f.annLink.value
    },
    maintenance: {
      enabled: f.maintEnabled.checked,
      message: f.maintMsg.value
    }
  });
});

document.getElementById('reset-theme-btn').addEventListener('click', async () => {
  await saveConfigPatch({
    ...DEFAULT_RESET,
    enabledTypes: latestConfig?.enabledTypes || ['anime', 'movie', 'tv'],
    spotlightMode: latestConfig?.spotlightMode || 'mix',
    spotlightIds: latestConfig?.spotlightIds || [],
    featuredTitle: latestConfig?.featuredTitle || 'Featured',
    featuredIds: latestConfig?.featuredIds || [],
    pinnedGenres: latestConfig?.pinnedGenres || [],
    pinnedHeroId: latestConfig?.pinnedHeroId || '',
    hiddenIds: latestConfig?.hiddenIds || []
  });
});

const DEFAULT_RESET = {
  brandName: 'kozuTV',
  accentColor: '#ff731c',
  accentSecondary: '#ff964f',
  gridCols: 6,
  posterRadius: 10,
  cardHoverScale: 1.045,
  showHero: true,
  spotlightSlideCount: 6,
  heroIntervalSec: 6.5,
  heroCtaText: 'Start Watching',
  trendingTitle: 'Trending Now',
  showContinueRow: true,
  showSuggestedRow: true,
  showRatings: true,
  showCardMeta: true,
  homeGenreCount: 3,
  showWatchlistIcon: true,
  showScheduleLink: true,
  showRandomLink: true,
  showFiltersLink: true,
  showFooter: true,
  footerTagline: 'Free entertainment for all',
  defaultOttServer: 'vidcore',
  enabledOttServers: ['vidcore', 'embedwave', 'cinesrc', 'vidlink', 'vidsrc'],
  defaultAnimeServer: 'megaplay',
  defaultAnimeLang: 'sub',
  defaultQuality: 'auto',
  defaultSpeed: '1',
  defaultAutoplay: true,
  defaultAutonext: true,
  defaultAutoskip: false,
  defaultMuted: false,
  announcement: { enabled: false, badge: 'UPDATE', text: '', link: '' },
  maintenance: { enabled: false, message: 'kozuTV is performing scheduled streaming upgrades. Please check back shortly.' }
};

document.getElementById('export-cache-btn').addEventListener('click', () => {
  const a = document.createElement('a');
  a.href = '/api/admin/user-cache/export';
  a.download = 'kozutv-user-cache.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  showToast('Exporting…');
});

const importFileInput = document.getElementById('import-cache-file');
document.getElementById('import-cache-btn').addEventListener('click', () => importFileInput.click());
importFileInput.addEventListener('change', async () => {
  const file = importFileInput.files && importFileInput.files[0];
  importFileInput.value = '';
  if (!file) return;
  const btn = document.getElementById('import-cache-btn');
  btn.disabled = true;
  btn.textContent = '…';
  try {
    const text = await file.text();
    const r = await fetch('/api/admin/user-cache/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: text
    });
    const d = await r.json();
    if (!r.ok) throw Error(d.error || 'Import failed');
    if (d.siteConfig) {
      hydrateConfigForm(d.siteConfig);
      document.documentElement.style.setProperty('--accent', d.siteConfig.accentColor);
    }
    showToast('Restored ' + d.restoredVisitors + ' user' + (d.restoredVisitors === 1 ? '' : 's'));
    pollTelemetry();
  } catch (err) {
    showToast(err.message || 'Invalid file');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Import';
  }
});

document.querySelectorAll('[data-purge]').forEach(btn => {
  btn.addEventListener('click', async () => {
    const scope = btn.dataset.purge;
    const r = await fetch('/api/admin/cache-purge', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ scope })
    });
    if (r.ok) { showToast('Cleared ' + scope); pollTelemetry(); }
  });
});

async function runCatalogSearch() {
  const q = document.getElementById('curate-q').value.trim();
  if (!q) {
    catalogFeedLoaded = false;
    loadCatalogState();
    return;
  }
  const box = document.getElementById('curate-results');
  box.innerHTML = '<div class="empty-note">Searching…</div>';
  const r = await fetch('/api/search-all?q=' + encodeURIComponent(q));
  const d = await r.json();
  currentFeedItems = d.items || [];
  renderCatalogFeed();
}
document.getElementById('curate-search-btn').addEventListener('click', runCatalogSearch);
document.getElementById('curate-q').addEventListener('keydown', e => {
  if (e.key === 'Enter') { e.preventDefault(); runCatalogSearch(); }
});

pollTelemetry();
setInterval(pollTelemetry, 2500);
</script></body></html>`;
  }

  // ============================================================================
  // HTTP ROUTE HANDLER
  // ============================================================================
  const ADMIN_CSP = "default-src 'self' https: data: blob:; frame-src 'none'; font-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' https: data:; connect-src 'self'";

  async function readBodyJson(req, maxBytes = 65_536) {
    const chunks = [];
    let len = 0;
    for await (const chunk of req) {
      len += chunk.length;
      if (len > maxBytes) throw Error('Payload too large');
      chunks.push(chunk);
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    return raw ? JSON.parse(raw) : {};
  }

  function sendJson(res, payload, status = 200) {
    const body = JSON.stringify(payload);
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store'
    });
    res.end(body);
  }

  function sendHtml(res, html, status = 200) {
    res.writeHead(status, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store',
      'Content-Security-Policy': ADMIN_CSP
    });
    res.end(html);
  }

  async function handleRequest(req, res, pathname) {
    if (pathname === '/api/site-config' && req.method === 'GET') {
      return sendJson(res, {
        siteConfig,
        isAdminIp: isIpAuthorized(req)
      });
    }

    if (pathname === '/api/presence' && req.method === 'POST') {
      try {
        const body = await readBodyJson(req, 131_072);
        recordPresence(req, body);
        if (body.browserCache && typeof body.browserCache === 'object') {
          getSystemHooks().syncBrowserCache?.(req, res, body.browserCache, body.visitorId);
        }
        return sendJson(res, { ok: true, maintenance: Boolean(siteConfig.maintenance?.enabled && !isIpAuthorized(req)) });
      } catch {
        return sendJson(res, { ok: false }, 400);
      }
    }

    if (pathname === '/ip' || pathname === '/ip/') {
      return sendHtml(res, renderIpGateHtml(), 200);
    }

    if (pathname === '/api/ip/authorize' && req.method === 'POST') {
      const ip = getClientIp(req);
      try {
        const rec = checkPassRateLimit(ip);
        const body = await readBodyJson(req);
        if (!verifyPasswordConstantTime(body.password)) {
          rec.fails++;
          if (rec.fails >= 5) rec.lockUntil = Date.now() + 30_000;
          ipAuthAttempts.set(ip, rec);
          recordBlockedAttempt(req, '/ip (bad password)');
          return sendJson(res, { error: 'Invalid passkey.' }, 401);
        }
        ipAuthAttempts.delete(ip);
        const label = parseUserAgentSummary(req.headers['user-agent']);
        adminState.authorizedIps[ip] = {
          label,
          authorizedAt: Date.now(),
          lastSeen: Date.now(),
          hits: 1
        };
        recordAudit('Authorized IP via /ip', ip, label);
        persistAdminState();
        return sendJson(res, { ok: true, ip });
      } catch (err) {
        return sendJson(res, { error: err.message || 'Authorization failed' }, 429);
      }
    }

    if (pathname === '/admin' || pathname === '/admin/' || pathname === '/admin/system' || pathname === '/admin/system/' || pathname.startsWith('/api/admin/')) {
      if (!isIpAuthorized(req)) {
        recordBlockedAttempt(req, pathname);
        if (pathname.startsWith('/api/admin/')) {
          return sendJson(res, { error: 'Forbidden: Unauthorized IP address.' }, 403);
        }
        return sendHtml(res, renderForbiddenHtml(), 403);
      }

      if (pathname === '/admin/system' || pathname === '/admin/system/') {
        persistAdminState();
        return sendHtml(res, renderSystemPageHtml(), 200);
      }

      if (pathname === '/admin' || pathname === '/admin/') {
        persistAdminState();
        return sendHtml(res, renderAdminDashboardHtml(), 200);
      }

      if (pathname === '/api/admin/telemetry' && req.method === 'GET') {
        return sendJson(res, buildTelemetryPayload(req));
      }

      if (pathname === '/api/admin/catalog-state' && req.method === 'GET') {
        const hooks = getSystemHooks();
        const allKeys = [...new Set([...(siteConfig.spotlightIds || []), ...(siteConfig.featuredIds || []), ...(siteConfig.hiddenIds || [])])];
        const resolved = hooks.resolveCatalogItems ? await hooks.resolveCatalogItems(allKeys) : [];
        const feed = hooks.getDefaultCatalogFeed ? hooks.getDefaultCatalogFeed() : [];
        return sendJson(res, { resolved, feed });
      }

      if (pathname === '/api/admin/config' && req.method === 'POST') {
        try {
          const body = await readBodyJson(req);
          siteConfig = sanitizeSiteConfig(body);
          recordAudit('Updated site settings', getClientIp(req), siteConfig.brandName);
          persistSiteConfig();
          persistAdminState();
          return sendJson(res, { ok: true, siteConfig });
        } catch (err) {
          return sendJson(res, { error: err.message }, 400);
        }
      }

      if (pathname === '/api/admin/ips' && req.method === 'POST') {
        try {
          const body = await readBodyJson(req);
          const targetIp = normalizeIp(body.ip);
          if (!targetIp || targetIp === '0.0.0.0') return sendJson(res, { error: 'Invalid IP' }, 400);
          if (body.action !== 'revoke') return sendJson(res, { error: 'Use /ip to authorize new IPs' }, 400);
          delete adminState.authorizedIps[targetIp];
          recordAudit('Revoked IP', getClientIp(req), targetIp);
          persistAdminState();
          return sendJson(res, { ok: true });
        } catch (err) {
          return sendJson(res, { error: err.message }, 400);
        }
      }

      if (pathname === '/api/admin/user-cache/export' && req.method === 'GET') {
        const dump = getSystemHooks().exportAllUsersCache();
        const body = JSON.stringify(dump, null, 2);
        recordAudit('Exported user caches', getClientIp(req), `${Object.keys(dump.visitors || {}).length} users`);
        persistAdminState();
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Content-Disposition': 'attachment; filename="kozutv-user-cache.json"',
          'Cache-Control': 'no-store'
        });
        res.end(body);
        return true;
      }

      if (pathname === '/api/admin/user-cache/import' && req.method === 'POST') {
        try {
          const body = await readBodyJson(req, 26_214_400);
          const result = getSystemHooks().importAllUsersCache(body);
          if (result.siteConfig && typeof result.siteConfig === 'object') {
            siteConfig = sanitizeSiteConfig(result.siteConfig);
            persistSiteConfig();
          }
          recordAudit('Imported user caches', getClientIp(req), `${result.restoredVisitors} users`);
          persistAdminState();
          return sendJson(res, {
            ok: true,
            restoredVisitors: result.restoredVisitors,
            cacheRevision: result.cacheRevision,
            siteConfig
          });
        } catch (err) {
          return sendJson(res, { error: err.message || 'Import failed' }, 400);
        }
      }

      if (pathname === '/api/admin/cache-purge' && req.method === 'POST') {
        const body = await readBodyJson(req).catch(() => ({}));
        const scope = String(body.scope || 'all');
        getSystemHooks().purgeCaches(scope);
        recordAudit('Purged server caches', getClientIp(req), scope);
        persistAdminState();
        return sendJson(res, { ok: true, scope });
      }

      if (pathname === '/api/admin/probe' && req.method === 'POST') {
        const summary = await getSystemHooks().probeAllResolvers();
        recordAudit('Checked stream servers', getClientIp(req), summary);
        persistAdminState();
        return sendJson(res, { ok: true, summary });
      }

      return sendJson(res, { error: 'Admin endpoint not found' }, 404);
    }

    return false;
  }

  return {
    handleRequest,
    isIpAuthorized,
    getSiteConfig: () => siteConfig
  };
}
