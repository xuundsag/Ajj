import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';
import path from 'node:path';
import Busboy from 'busboy';

const root = path.resolve(import.meta.dirname, '..');

async function freePort() {
  const server = createServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  await new Promise((resolve) => server.close(resolve));
  return port;
}

function json(res, value, status = 200) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(value));
}

async function postJson(url, body, method = 'POST') {
  return fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
}

test('multi-file bundles, raw uploads, add/download/delete, and docs', { timeout: 20_000 }, async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-api-'));
  const documents = new Map();
  const deleted = [];
  const telegram = createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname === '/botTEST_TOKEN/getMe') return json(res, { ok: true, result: { id: 1, is_bot: true } });
    if (url.pathname === '/botTEST_TOKEN/deleteMessage') {
      let body = '';
      req.on('data', (chunk) => { body += chunk; });
      req.on('end', () => { deleted.push(JSON.parse(body).message_id); json(res, { ok: true, result: true }); });
      return;
    }
    if (url.pathname === '/botTEST_TOKEN/sendDocument') {
      const saveDocument = (buffer) => {
        const id = `id-${documents.size}`;
        documents.set(id, buffer);
        json(res, {
          ok: true,
          result: {
            message_id: 1000 + documents.size,
            chat: { id: -100123 },
            document: { file_id: id, file_size: buffer.length },
          },
        });
      };
      if (req.headers['content-type']?.includes('application/json')) {
        let body = '';
        req.on('data', (chunk) => { body += chunk; });
        req.on('end', async () => {
          const input = JSON.parse(body);
          saveDocument(await readFile(fileURLToPath(input.document)));
        });
        return;
      }
      const busboy = Busboy({ headers: req.headers });
      let buffer = null;
      busboy.on('file', (name, stream) => {
        const chunks = [];
        stream.on('data', (chunk) => chunks.push(chunk));
        stream.on('end', () => { buffer = Buffer.concat(chunks); });
      });
      busboy.on('close', () => saveDocument(buffer));
      req.pipe(busboy);
      return;
    }
    if (url.pathname === '/botTEST_TOKEN/getFile') {
      const id = url.searchParams.get('file_id');
      return json(res, { ok: true, result: { file_id: id, file_path: `documents/${id}` } });
    }
    if (url.pathname.startsWith('/file/botTEST_TOKEN/documents/')) {
      const body = documents.get(url.pathname.split('/').pop());
      res.writeHead(200, { 'Content-Length': body.length, 'Content-Type': 'application/octet-stream' });
      res.end(body);
      return;
    }
    res.writeHead(404).end();
  });
  await new Promise((resolve) => telegram.listen(0, '127.0.0.1', resolve));
  const appPort = await freePort();
  const base = `http://127.0.0.1:${appPort}`;
  const child = spawn(process.execPath, ['src/server.js'], {
    cwd: root,
    env: {
      ...process.env,
      BOT_TOKEN: 'TEST_TOKEN',
      TELEGRAM_CHAT_ID: '-100123',
      TELEGRAM_API_BASE_URL: `http://127.0.0.1:${telegram.address().port}`,
      TELEGRAM_API_ID: '12345',
      TELEGRAM_API_HASH: 'test-hash',
      PORT: String(appPort),
      DATA_FILE: path.join(directory, 'meg.json'),
      TEMP_DIR: path.join(directory, 'tmp'),
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  t.after(async () => {
    child.kill('SIGTERM');
    telegram.closeAllConnections();
    await new Promise((resolve) => telegram.close(resolve));
    await rm(directory, { recursive: true, force: true });
  });
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('App startup timed out')), 8_000);
    child.stdout.on('data', (chunk) => {
      if (chunk.toString().includes('listening')) { clearTimeout(timer); resolve(); }
    });
    child.stderr.on('data', (chunk) => process.stderr.write(chunk));
    child.once('exit', (code) => { clearTimeout(timer); reject(new Error(`App exited: ${code}`)); });
  });

  const encryptedForm = new FormData();
  encryptedForm.append('encrypted', 'true');
  encryptedForm.append('file', new Blob(['hello cloud storage']), 'hello.txt');
  encryptedForm.append('file', new Blob(['second file']), 'second.txt');
  const uploadResponse = await fetch(`${base}/api/upload`, { method: 'POST', body: encryptedForm });
  assert.equal(uploadResponse.status, 200);
  const uploaded = await uploadResponse.json();
  assert.match(uploaded.fileKey, /^[A-Z0-9]{8}$/);
  assert.equal(uploaded.fileCount, 2);
  assert.ok(uploaded.encKey);
  assert.notEqual(documents.get('id-0').toString(), 'hello cloud storage');
  assert.notEqual(documents.get('id-1').toString(), 'second file');

  const locked = await (await postJson(`${base}/api/files`, { fileKey: uploaded.fileKey })).json();
  assert.equal(locked.requiresEncKey, true);
  assert.equal(locked.files, undefined);
  assert.equal((await postJson(`${base}/api/files`, { fileKey: uploaded.fileKey, encKey: 'A'.repeat(43) })).status, 400);

  let list = await (await postJson(`${base}/api/files`, uploaded)).json();
  assert.equal(list.files.length, 2);
  assert.deepEqual(list.files.map((file) => file.name), ['hello.txt', 'second.txt']);
  const firstId = list.files[0].id;
  const deleteId = list.files[1].id;

  const wrongKey = await postJson(`${base}/api/download`, { ...uploaded, fileId: firstId, encKey: 'A'.repeat(43) });
  assert.equal(wrongKey.status, 400);
  const download = await postJson(`${base}/api/download`, { ...uploaded, fileId: firstId });
  assert.equal(download.status, 200);
  assert.equal(await download.text(), 'hello cloud storage');

  const addForm = new FormData();
  addForm.append('fileKey', uploaded.fileKey);
  addForm.append('encKey', uploaded.encKey);
  addForm.append('file', new Blob(['third file']), 'third.txt');
  const addedResponse = await fetch(`${base}/api/upload`, { method: 'POST', body: addForm });
  assert.equal(addedResponse.status, 200);
  assert.equal((await addedResponse.json()).fileCount, 3);
  list = await (await postJson(`${base}/api/files`, uploaded)).json();
  assert.equal(list.files.length, 3);

  const remove = await postJson(`${base}/api/files/delete`, { ...uploaded, fileId: deleteId });
  assert.equal(remove.status, 200);
  assert.equal((await remove.json()).fileCount, 2);
  assert.equal(deleted.length, 1);
  list = await (await postJson(`${base}/api/files`, uploaded)).json();
  assert.equal(list.files.some((file) => file.id === deleteId), false);

  const rawForm = new FormData();
  rawForm.append('encrypted', 'false');
  rawForm.append('file', new Blob(['RAW CONTENT']), 'raw.txt');
  const rawUploadResponse = await fetch(`${base}/api/upload`, { method: 'POST', body: rawForm });
  const rawUpload = await rawUploadResponse.json();
  assert.equal(rawUpload.encKey, null);
  assert.equal(documents.get('id-3').toString(), 'RAW CONTENT');
  const rawList = await (await postJson(`${base}/api/files`, { fileKey: rawUpload.fileKey })).json();
  assert.equal(rawList.requiresEncKey, false);
  const rawDownload = await postJson(`${base}/api/download`, { fileKey: rawUpload.fileKey, fileId: rawList.files[0].id });
  assert.equal(await rawDownload.text(), 'RAW CONTENT');

  const stored = await readFile(path.join(directory, 'meg.json'), 'utf8');
  assert.equal(stored.includes(uploaded.encKey), false);
  assert.equal(stored.includes('"messageId": 1001'), true);
  const apiInfo = await (await fetch(`${base}/api`)).json();
  assert.equal(apiInfo.maxFileSize, 2_000_000_000);
  assert.equal(apiInfo.maxFilesPerRequest, 20);
  assert.equal((await fetch(`${base}/docs`)).status, 200);
  assert.equal((await fetch(`${base}/download`)).status, 200);
});
