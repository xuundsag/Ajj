import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { JsonStore } from '../src/store.js';
import { UploadManager } from '../src/uploads.js';

class FakeTelegram {
  constructor() { this.files = []; }
  async sendDocumentFile(filePath, fileSize, name) {
    const buffer = await readFile(filePath);
    assert.equal(buffer.length, fileSize);
    const index = this.files.push(buffer) - 1;
    return { fileId: `id-${index}`, filePath: `documents/${name}`, pathObtainedAt: Date.now() };
  }
}

test('single streaming encrypted upload stores one Telegram document without storing its ENC_KEY', async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-upload-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const store = new JsonStore(path.join(directory, 'meg.json'));
  await store.init();
  const telegram = new FakeTelegram();
  const manager = new UploadManager(store, telegram);
  const filePath = path.join(directory, 'incoming');
  await writeFile(filePath, Buffer.alloc(1024 * 1024, 7));

  const result = await manager.single({
    path: filePath,
    size: 1024 * 1024,
    name: '../sample.bin',
    mimeType: 'application/octet-stream',
    fields: { encrypted: 'true' },
  });

  assert.match(result.fileKey, /^[A-Z0-9]{8}$/);
  assert.ok(result.encKey);
  const record = store.get(result.fileKey);
  assert.equal(record.files.length, 1);
  assert.equal(record.files[0].name, 'sample.bin');
  assert.equal(record.files[0].chunks.length, 1);
  assert.equal(record.files[0].chunks[0].storedSize, 1024 * 1024);
  assert.equal(record.encrypted, true);
  assert.equal(record.files[0].encryption.algorithm, 'AES-256-GCM');
  assert.equal(JSON.stringify(record).includes(result.encKey), false);
  assert.equal(telegram.files.length, 1);
  assert.equal(telegram.files[0].length, 1024 * 1024);
  await assert.rejects(readFile(filePath), { code: 'ENOENT' });
  await assert.rejects(readFile(`${filePath}.encrypted`), { code: 'ENOENT' });
});
