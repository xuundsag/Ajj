import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { TelegramStorage } from '../src/telegram.js';

test('absolute local Bot API path downloads directly without refreshing file_id', async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-local-download-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const filePath = path.join(directory, 'cached.bin');
  await writeFile(filePath, 'local raw file');
  const storage = new TelegramStorage();
  const response = await storage.openDownload({
    fileId: 'valid-but-not-needed',
    filePath,
    pathObtainedAt: 0,
  });
  assert.equal(response.status, 200);
  assert.equal(await response.text(), 'local raw file');
});
