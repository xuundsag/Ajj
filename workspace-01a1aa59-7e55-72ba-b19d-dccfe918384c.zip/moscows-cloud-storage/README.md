# Moscow's Cloud Storage

A minimal Telegram-backed file host with multi-file bundles, optional encryption, server-side downloads, and a small file manager.

- Up to **20 files per request**, **2 GB per file**
- One FILE_KEY for the whole bundle
- One shared ENC_KEY only when encryption is enabled at bundle creation
- Raw files are uploaded byte-for-byte without encryption when disabled
- Add, list, download, and delete individual files inside a bundle
- Server-side AES-256-GCM encryption/decryption in memory-bounded 16 MiB segments
- Automatic local Telegram Bot API startup

Metadata and Telegram file paths are stored in `meg.json`; ENC_KEY values are never stored. A one-way key hash is stored for new encrypted bundles so adding files can validate the supplied key.

## Requirements

- Node.js 20 or newer
- Telegram bot token and storage chat ID
- Telegram `api_id` and `api_hash` from [my.telegram.org](https://my.telegram.org)
- Git, CMake, a C++ compiler, OpenSSL, zlib, and gperf for automatic Bot API compilation

See [BOT_SETUP.md](BOT_SETUP.md) for the complete server guide.

## Configuration

Edit the provided `.env`:

```env
BOT_TOKEN=123456789:replace_me
TELEGRAM_CHAT_ID=-1001234567890
TELEGRAM_API_ID=123456
TELEGRAM_API_HASH=replace_me
TELEGRAM_API_BASE_URL=http://127.0.0.1:8081
TELEGRAM_AUTO_START=true
TELEGRAM_LOCAL_FILE_UPLOAD=true
TELEGRAM_BUILD_JOBS=2
PORT=3000
```

Then:

```bash
npm install
npm start
```

Open `http://localhost:3000/upload`.

### Automatic Bot API server

If the configured Bot API is unavailable and `TELEGRAM_AUTO_START=true`, the app builds a missing binary, starts it with `--local`, waits for `getMe`, and stops the managed process during graceful shutdown.

When Node and Bot API share a filesystem, `TELEGRAM_LOCAL_FILE_UPLOAD=true` uses Telegram's `file://` handoff to avoid a second large HTTP transfer. Set it to `false` for a remote Bot API or containers without a shared volume.

### Build RAM control

- `TELEGRAM_BUILD_JOBS=2`: intended for approximately 16 GB RAM systems
- `TELEGRAM_BUILD_JOBS=1`: recommended when targeting approximately 8 GB RAM

The build uses bounded jobs, `-O2`, and the GNU linker's `--no-keep-memory`. Job control is not a hard RAM quota.

## Pages

- `/upload` — upload up to 20 files together under one key. Encryption applies to the whole new bundle.
- `/download` — enter FILE_KEY. ENC_KEY appears only if the bundle is encrypted, then the **Files** manager opens.
- Files manager — download or delete individual files and use **Add more** to append files to the same key.
- `/docs` — simple public API documentation with copyable examples.

Adding to an encrypted bundle requires its ENC_KEY. Adding to a raw bundle keeps new files raw; the bundle's encryption mode cannot be changed later.

## API summary

Full copyable examples are available at `/docs`.

| Action | Method and endpoint | Required data |
|---|---|---|
| Create bundle | `POST /api/upload` | Multipart `file` fields, optional `encrypted=true` |
| Add files | `POST /api/upload` | Multipart files plus `fileKey`, and `encKey` if encrypted |
| List files | `POST /api/files` | JSON `fileKey`, and `encKey` if encrypted |
| Download | `POST /api/download` | JSON `fileKey`, `fileId`, and `encKey` if encrypted |
| Delete | `POST /api/files/delete` | JSON `fileKey`, `fileId`, and `encKey` if encrypted |

Upload response:

```json
{
  "fileKey": "A1B2C3D4",
  "encKey": null,
  "fileCount": 2
}
```

Listing an encrypted bundle without its key returns only:

```json
{
  "fileKey": "A1B2C3D4",
  "encrypted": true,
  "requiresEncKey": true
}
```

The server downloads the selected Telegram document, decrypts it when required, and streams the file to the client. No Telegram file URLs are exposed to browsers.

## Telegram paths and downloads

The app first uses an accessible absolute local Bot API `file_path` directly. Otherwise it tries the stored Telegram path before refreshing `file_id`. A refresh happens only when Telegram rejects the known path, avoiding unnecessary `getFile` failures for files that are still downloadable.

## Storage and operation

- New `meg.json` records contain a `files` array. Original one-file records remain readable through a compatibility layer.
- Each file has its own UUID, original metadata, Telegram file ID/path, and Telegram message ID where available.
- `tmp/` holds transient incoming and encrypted upload files, removed after processing.
- One maximum-size encrypted upload can temporarily require over 4 GB across incoming and encrypted files.
- Uploads and downloads consume Node and Bot API resources. Use a queue or concurrency limits for heavy public traffic.
- A reverse proxy must allow at least 2 GB request bodies and long upload/download timeouts.
- Use HTTPS in production, especially because ENC_KEY is sent to the server for decryption.

## Tests

```bash
npm test
```
