const title = document.querySelector('#page-title');
const lookup = document.querySelector('#lookup');
const form = document.querySelector('#download-form');
const fileKeyInput = document.querySelector('#file-key-input');
const encField = document.querySelector('#enc-field');
const encKeyInput = document.querySelector('#enc-key-input');
const openButton = document.querySelector('#download-button');
const manager = document.querySelector('#file-manager');
const fileList = document.querySelector('#file-list');
const addButton = document.querySelector('#add-more');
const moreFiles = document.querySelector('#more-files');
const progress = document.querySelector('#progress');
const progressBar = document.querySelector('#progress-bar');
const progressValue = document.querySelector('#progress-value');
const status = document.querySelector('#status');
let collection = null;
let busy = false;

fileKeyInput.addEventListener('input', () => {
  fileKeyInput.value = fileKeyInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
});

function formatBytes(bytes) {
  const units = ['B', 'KB', 'MB', 'GB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) { value /= 1024; unit += 1; }
  return `${value.toFixed(unit ? 1 : 0)} ${units[unit]}`;
}

function setProgress(bytes, total) {
  const percent = total ? Math.min(100, Math.floor(bytes / total * 100)) : 100;
  progressBar.style.width = `${percent}%`;
  progressValue.textContent = `${percent}%`;
}

function setBusy(value) {
  busy = value;
  openButton.disabled = value;
  addButton.disabled = value;
  for (const button of fileList.querySelectorAll('button')) button.disabled = value;
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || 'Request failed');
  }
  return response;
}

function jsonOptions(method, body) {
  return { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
}

function credentials() {
  return { fileKey: fileKeyInput.value, encKey: encKeyInput.value.trim() };
}

function renderFiles() {
  fileList.replaceChildren();
  for (const file of collection.files) {
    const row = document.createElement('div');
    row.className = 'file-row';
    const info = document.createElement('div');
    info.className = 'file-info';
    const name = document.createElement('span');
    name.className = 'file-name';
    name.textContent = file.name;
    const size = document.createElement('span');
    size.className = 'file-size';
    size.textContent = formatBytes(file.size);
    info.append(name, size);

    const actions = document.createElement('div');
    actions.className = 'file-actions';
    const download = document.createElement('button');
    download.className = 'icon-button';
    download.title = 'Download';
    download.setAttribute('aria-label', `Download ${file.name}`);
    download.innerHTML = '<svg viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 17v3h14v-3"/></svg>';
    download.addEventListener('click', () => downloadFile(file));
    const remove = document.createElement('button');
    remove.className = 'icon-button danger';
    remove.title = 'Delete';
    remove.setAttribute('aria-label', `Delete ${file.name}`);
    remove.innerHTML = '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3m-9 0 1 14h10l1-14M10 11v6m4-6v6"/></svg>';
    remove.addEventListener('click', () => deleteFile(file));
    actions.append(download, remove);
    row.append(info, actions);
    fileList.append(row);
  }
}

function openManager(data) {
  collection = data;
  title.textContent = 'Files';
  lookup.hidden = true;
  manager.hidden = false;
  document.querySelector('#main').classList.add('wide');
  renderFiles();
}

async function openFiles() {
  const response = await api('/api/files', jsonOptions('POST', credentials()));
  const data = await response.json();
  if (data.requiresEncKey) {
    encField.hidden = false;
    encKeyInput.required = true;
    encKeyInput.focus();
    return;
  }
  openManager(data);
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (busy) return;
  status.textContent = '';
  setBusy(true);
  try { await openFiles(); }
  catch (error) { status.textContent = error.message; }
  finally { setBusy(false); }
});

function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

async function downloadFile(file) {
  if (busy) return;
  status.textContent = '';
  setBusy(true);
  let writable = null;
  try {
    const memoryOnly = !window.showSaveFilePicker;
    if (memoryOnly && file.size > 256 * 1024 ** 2) throw new Error('Use a Chromium browser to download this file');
    if (!memoryOnly) {
      const handle = await window.showSaveFilePicker({ suggestedName: file.name });
      writable = await handle.createWritable();
    }
    const response = await api('/api/download', jsonOptions('POST', { ...credentials(), fileId: file.id }));
    progress.hidden = false;
    setProgress(0, file.size);
    if (memoryOnly) {
      saveBlob(await response.blob(), file.name);
      setProgress(file.size, file.size);
    } else {
      const reader = response.body.getReader();
      let completed = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        await writable.write(value);
        completed += value.byteLength;
        setProgress(completed, file.size);
      }
      await writable.close();
      writable = null;
    }
    progress.hidden = true;
  } catch (error) {
    if (writable) await writable.abort().catch(() => {});
    if (error.name !== 'AbortError') status.textContent = error.message;
    progress.hidden = true;
  } finally {
    setBusy(false);
  }
}

async function deleteFile(file) {
  if (busy || !window.confirm(`Delete ${file.name}?`)) return;
  status.textContent = '';
  setBusy(true);
  try {
    await api('/api/files/delete', jsonOptions('POST', { ...credentials(), fileId: file.id }));
    await openFiles();
  } catch (error) {
    status.textContent = error.message;
  } finally {
    setBusy(false);
  }
}

addButton.addEventListener('click', () => { if (!busy) moreFiles.click(); });
moreFiles.addEventListener('change', async () => {
  const files = [...moreFiles.files];
  moreFiles.value = '';
  if (!files.length || busy) return;
  status.textContent = '';
  if (files.length > 20) { status.textContent = 'Maximum 20 files at once'; return; }
  if (files.some((file) => file.size < 1 || file.size > 2_000_000_000)) {
    status.textContent = 'Files must be non-empty and up to 2 GB each';
    return;
  }
  setBusy(true);
  progress.hidden = false;
  const total = files.reduce((sum, file) => sum + file.size, 0);
  setProgress(0, total);
  try {
    await new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/upload');
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable && event.total) setProgress(Math.floor(total * event.loaded / event.total), total);
      };
      xhr.onerror = () => reject(new Error('Network error'));
      xhr.onload = () => {
        let data = {};
        try { data = JSON.parse(xhr.responseText); } catch { /* handled below */ }
        if (xhr.status >= 200 && xhr.status < 300) resolve(data);
        else reject(new Error(data.error || 'Upload failed'));
      };
      const body = new FormData();
      body.append('fileKey', collection.fileKey);
      body.append('encKey', encKeyInput.value.trim());
      for (const file of files) body.append('file', file, file.name);
      xhr.send(body);
    });
    await openFiles();
    progress.hidden = true;
  } catch (error) {
    status.textContent = error.message;
    progress.hidden = true;
  } finally {
    setBusy(false);
  }
});
