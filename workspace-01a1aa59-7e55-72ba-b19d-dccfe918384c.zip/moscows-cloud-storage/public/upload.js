const form = document.querySelector('#upload-form');
const fileInput = document.querySelector('#file');
const dropzone = document.querySelector('#dropzone');
const fileLabel = document.querySelector('#file-label');
const fileMeta = document.querySelector('#file-meta');
const encryptedInput = document.querySelector('#encrypted');
const button = document.querySelector('#upload-button');
const progress = document.querySelector('#progress');
const progressBar = document.querySelector('#progress-bar');
const progressValue = document.querySelector('#progress-value');
const keys = document.querySelector('#keys');
const status = document.querySelector('#status');
const MAX_SIZE = 2_000_000_000;
const MAX_FILES = 20;

function formatBytes(bytes) {
  const units = ['B', 'KB', 'MB', 'GB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) { value /= 1024; unit += 1; }
  return `${value.toFixed(unit ? 1 : 0)} ${units[unit]}`;
}

function showFiles(files) {
  fileLabel.textContent = files.length === 1 ? files[0].name : (files.length ? `${files.length} files` : 'Choose files');
  fileMeta.textContent = files.length ? formatBytes(files.reduce((total, file) => total + file.size, 0)) : '';
  status.textContent = '';
}

fileInput.addEventListener('change', () => showFiles([...fileInput.files]));
for (const event of ['dragenter', 'dragover']) {
  dropzone.addEventListener(event, (event) => { event.preventDefault(); dropzone.classList.add('dragging'); });
}
for (const event of ['dragleave', 'drop']) {
  dropzone.addEventListener(event, (event) => { event.preventDefault(); dropzone.classList.remove('dragging'); });
}
dropzone.addEventListener('drop', (event) => {
  if (!event.dataTransfer.files.length) return;
  fileInput.files = event.dataTransfer.files;
  showFiles([...fileInput.files]);
});

function setProgress(bytes, total) {
  const percent = Math.min(100, Math.floor(bytes / total * 100));
  progressBar.style.width = `${percent}%`;
  progressValue.textContent = `${percent}%`;
}

function uploadFiles(files, encrypted, totalSize, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/upload');
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && event.total) {
        onProgress(Math.min(totalSize, Math.floor(totalSize * event.loaded / event.total)));
      }
    };
    xhr.onerror = () => reject(new Error('Network error'));
    xhr.onload = () => {
      let data = {};
      try { data = JSON.parse(xhr.responseText); } catch { /* handled below */ }
      if (xhr.status >= 200 && xhr.status < 300) resolve(data);
      else reject(new Error(data.error || 'Upload failed'));
    };
    const body = new FormData();
    body.append('encrypted', String(encrypted));
    for (const file of files) body.append('file', file, file.name);
    xhr.send(body);
  });
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const files = [...fileInput.files];
  status.textContent = '';
  if (!files.length) return;
  if (files.length > MAX_FILES) { status.textContent = 'Maximum 20 files at once'; return; }
  if (files.some((file) => file.size < 1)) { status.textContent = 'Empty files are not supported'; return; }
  if (files.some((file) => file.size > MAX_SIZE)) { status.textContent = 'Maximum file size is 2 GB per file'; return; }

  const totalSize = files.reduce((total, file) => total + file.size, 0);
  button.disabled = true;
  fileInput.disabled = true;
  encryptedInput.disabled = true;
  keys.hidden = true;
  progress.hidden = false;
  setProgress(0, totalSize);

  try {
    const result = await uploadFiles(files, encryptedInput.checked, totalSize, (bytes) => setProgress(bytes, totalSize));
    setProgress(totalSize, totalSize);
    document.querySelector('#file-key').textContent = result.fileKey;
    document.querySelector('#enc-key').textContent = result.encKey || '';
    document.querySelector('#enc-key-row').hidden = !result.encKey;
    keys.hidden = false;
    progress.hidden = true;
    form.hidden = true;
  } catch (error) {
    status.textContent = error.message;
    progress.hidden = true;
    button.disabled = false;
    fileInput.disabled = false;
    encryptedInput.disabled = false;
  }
});

for (const copyButton of document.querySelectorAll('[data-copy]')) {
  copyButton.addEventListener('click', async () => {
    await navigator.clipboard.writeText(document.getElementById(copyButton.dataset.copy).textContent);
    copyButton.textContent = 'Copied';
    setTimeout(() => { copyButton.textContent = 'Copy'; }, 1200);
  });
}
