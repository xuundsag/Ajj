const origin = window.location.origin;
document.querySelector('#base-url').textContent = origin;
for (const block of document.querySelectorAll('.code-block')) {
  const code = block.querySelector('code');
  code.textContent = code.textContent.replaceAll('BASE_URL', origin);
  const button = block.querySelector('button');
  button.addEventListener('click', async () => {
    await navigator.clipboard.writeText(code.textContent);
    button.textContent = 'Copied';
    setTimeout(() => { button.textContent = 'Copy'; }, 1200);
  });
}
