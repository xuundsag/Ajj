import { rm } from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { config } from './config.js';
import { createEncryptionKey, createFileKey, FILE_KEY_PATTERN } from './keys.js';
import { encryptFile } from './crypto.js';
import { keyHash, normalizeCollection, verifyCollectionKey } from './records.js';

function cleanName(value) {
  const base = path.basename(String(value || 'file').replace(/\\/g, '/')).replace(/[\u0000-\u001f\u007f]/g, '').trim();
  return (base || 'file').slice(0, 255);
}

function cleanMime(value) {
  const mime = String(value || 'application/octet-stream');
  return /^[\w.+-]+\/[\w.+-]+$/.test(mime) ? mime.slice(0, 200) : 'application/octet-stream';
}

function enabled(value) {
  return value === true || value === 'true' || value === '1';
}

export class UploadManager {
  constructor(store, telegram) {
    this.store = store;
    this.telegram = telegram;
  }

  uniqueFileKey() {
    let key;
    do { key = createFileKey(); } while (this.store.has(key));
    return key;
  }

  validate(files) {
    if (!files.length) throw Object.assign(new Error('No files supplied'), { status: 400 });
    for (const file of files) {
      if (file.size < 1) throw Object.assign(new Error(`Empty file: ${file.name}`), { status: 400 });
      if (file.size > config.maxFileSize) {
        throw Object.assign(new Error(`Maximum size is 2 GB per file: ${file.name}`), { status: 413 });
      }
    }
  }

  async uploadInto(record, files, encKey) {
    this.validate(files);
    const uploaded = [];
    try {
      for (const file of files) {
        const name = cleanName(file.name);
        const encryptedPath = record.encrypted ? `${file.path}.encrypted` : null;
        const uploadPath = encryptedPath || file.path;
        let encryption = null;
        if (record.encrypted) encryption = await encryptFile(file.path, encryptedPath, encKey);
        const telegram = await this.telegram.sendDocumentFile(
          uploadPath,
          file.size,
          record.encrypted ? `${name}.enc` : name,
        );
        uploaded.push({
          id: randomUUID(),
          name,
          size: file.size,
          mimeType: cleanMime(file.mimeType),
          encrypted: record.encrypted,
          encryption,
          createdAt: new Date().toISOString(),
          chunks: [{ index: 0, storedSize: file.size, ...telegram }],
        });
      }
      record.files.push(...uploaded);
      return uploaded;
    } catch (error) {
      // Best-effort rollback if a multi-file bundle fails partway through.
      await Promise.all(uploaded.map((file) => this.telegram.deleteDocument?.(file.chunks[0].messageId).catch(() => {})));
      throw error;
    }
  }

  async cleanup(files) {
    await Promise.all(files.flatMap((file) => [
      rm(file.path, { force: true }),
      rm(`${file.path}.encrypted`, { force: true }),
    ]));
  }

  async create(files, fields = {}) {
    const encrypted = enabled(fields.encrypted);
    const encKey = encrypted ? createEncryptionKey() : null;
    const fileKey = this.uniqueFileKey();
    const record = {
      version: 2,
      encrypted,
      keyHash: encrypted ? keyHash(encKey) : null,
      createdAt: new Date().toISOString(),
      files: [],
    };
    try {
      await this.uploadInto(record, files, encKey);
      await this.store.put(fileKey, record);
      return { fileKey, encKey, fileCount: record.files.length };
    } finally {
      await this.cleanup(files);
    }
  }

  async add(fileKeyValue, files, fields = {}) {
    const fileKey = String(fileKeyValue || '').toUpperCase();
    if (!FILE_KEY_PATTERN.test(fileKey)) throw Object.assign(new Error('Invalid FILE_KEY'), { status: 400 });
    const original = this.store.get(fileKey);
    if (!original) throw Object.assign(new Error('File key not found'), { status: 404 });
    const record = normalizeCollection(original);
    const encKey = record.encrypted ? fields.encKey : null;
    if (!verifyCollectionKey(record, encKey)) {
      throw Object.assign(new Error('Invalid ENC_KEY'), { status: 400 });
    }
    try {
      const added = await this.uploadInto(record, files, encKey);
      await this.store.update(fileKey, record);
      return { fileKey, fileCount: record.files.length, added: added.length };
    } finally {
      await this.cleanup(files);
    }
  }

  async single(file) {
    return this.create([file], file.fields);
  }

  async deleteFile(fileKey, fileId, encKey) {
    const original = this.store.get(fileKey);
    if (!original) throw Object.assign(new Error('File key not found'), { status: 404 });
    const record = normalizeCollection(original);
    if (!verifyCollectionKey(record, encKey)) throw Object.assign(new Error('Invalid ENC_KEY'), { status: 400 });
    const index = record.files.findIndex((file) => file.id === fileId);
    if (index < 0) throw Object.assign(new Error('File not found'), { status: 404 });
    const [file] = record.files.splice(index, 1);
    await this.telegram.deleteDocument(file.chunks[0].messageId);
    await this.store.update(fileKey, record);
    return { deleted: fileId, fileCount: record.files.length };
  }
}
