import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { Readable } from 'node:stream';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import http from 'node:http';
import https from 'node:https';
import FormData from 'form-data';
import { config } from './config.js';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function apiError(status, payload, rawBody = '') {
  const description = payload?.description || rawBody.trim().slice(0, 500) || `HTTP ${status}`;
  const error = new Error(`Telegram Bot API: ${description}`);
  error.status = status;
  error.telegramStatus = status;
  error.clientStatus = status >= 500 ? 502 : status;
  error.public = true;
  error.retryAfter = Number(payload?.parameters?.retry_after || 0);
  return error;
}

function connectionError(error) {
  if (error.public) return error;
  const wrapped = new Error(
    `Telegram Bot API connection failed${error.code ? ` (${error.code})` : ''}. `
    + 'Check the Bot API server log and Telegram channel before retrying.',
  );
  wrapped.status = 502;
  wrapped.clientStatus = 502;
  wrapped.public = true;
  wrapped.cause = error;
  return wrapped;
}

export class TelegramStorage {
  constructor() {
    this.pathCache = new Map();
  }

  async request(method, { query, json, timeout = 30_000, retry = true } = {}) {
    if (!config.botToken || !config.chatId) throw new Error('Telegram is not configured');
    const url = new URL(`${config.telegramApiBase}/bot${config.botToken}/${method}`);
    for (const [key, value] of Object.entries(query || {})) url.searchParams.set(key, String(value));
    const attempts = retry ? 4 : 1;
    let lastError;

    for (let attempt = 0; attempt < attempts; attempt += 1) {
      const controller = new AbortController();
      const timer = timeout > 0 ? setTimeout(() => controller.abort(), timeout) : null;
      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: json ? { 'Content-Type': 'application/json' } : undefined,
          body: json ? JSON.stringify(json) : undefined,
          signal: controller.signal,
        });
        const rawBody = await response.text();
        let payload = null;
        try { payload = JSON.parse(rawBody); } catch { /* included in errors below */ }
        if (response.ok && payload?.ok) return payload.result;
        throw apiError(response.status, payload, rawBody);
      } catch (error) {
        const permanent = error.status && error.status !== 429 && error.status < 500;
        if (permanent || attempt === attempts - 1) throw error;
        lastError = error;
        await sleep(Math.max(Number(error.retryAfter || 0) * 1000, 500 * 2 ** attempt));
      } finally {
        if (timer) clearTimeout(timer);
      }
    }
    throw lastError;
  }

  postDocument(url, filePath, fileSize, fileName) {
    return new Promise((resolve, reject) => {
      const form = new FormData();
      form.append('chat_id', config.chatId);
      form.append('disable_content_type_detection', 'true');
      form.append('document', createReadStream(filePath), {
        filename: fileName,
        contentType: 'application/octet-stream',
        knownLength: fileSize,
      });
      form.getLength((lengthError, length) => {
        if (lengthError) return reject(lengthError);
        let responseStarted = false;
        const request = (url.protocol === 'https:' ? https : http).request(url, {
          method: 'POST',
          headers: { ...form.getHeaders(), 'Content-Length': length },
        }, (response) => {
          responseStarted = true;
          form.destroy();
          let body = '';
          response.on('data', (chunk) => {
            if (body.length < 65_536) body += chunk;
          });
          response.on('end', () => {
            let payload = null;
            try { payload = JSON.parse(body); } catch { /* included in errors below */ }
            resolve({ status: response.statusCode, payload, rawBody: body });
          });
          response.on('error', reject);
        });
        // An early Bot API error can close the socket while form-data is still
        // writing. Preserve the real HTTP response and ignore the later EPIPE.
        request.on('error', (error) => {
          if (!responseStarted) {
            reject(error);
            form.destroy();
          }
        });
        request.setTimeout(0);
        form.on('error', (error) => {
          if (!responseStarted) {
            reject(error);
            request.destroy(error);
          }
        });
        form.pipe(request);
        return null;
      });
    });
  }

  useLocalFileHandoff() {
    const hostname = new URL(config.telegramApiBase).hostname;
    return config.telegramLocalFileUpload && ['127.0.0.1', 'localhost', '::1'].includes(hostname);
  }

  async sendDocumentFile(filePath, fileSize, fileName) {
    if (!config.botToken || !config.chatId) throw new Error('Telegram is not configured');
    let message;

    if (this.useLocalFileHandoff()) {
      try {
        message = await this.request('sendDocument', {
          json: {
            chat_id: config.chatId,
            disable_content_type_detection: true,
            document: pathToFileURL(path.resolve(filePath)).href,
          },
          timeout: 0,
          retry: false,
        });
      } catch (error) {
        throw connectionError(error);
      }
    } else {
      const url = new URL(`${config.telegramApiBase}/bot${config.botToken}/sendDocument`);
      for (let attempt = 0; attempt < 4; attempt += 1) {
        try {
          const { status, payload, rawBody } = await this.postDocument(url, filePath, fileSize, fileName);
          if (status >= 200 && status < 300 && payload?.ok) {
            message = payload.result;
            break;
          }
          throw apiError(status, payload, rawBody);
        } catch (error) {
          // HTTP 500 and EPIPE are ambiguous for a large upload: retrying could
          // duplicate a document that Telegram already accepted. Only 429 is retried.
          if (error.status !== 429 || attempt === 3) throw connectionError(error);
          await sleep(Math.max(Number(error.retryAfter || 0) * 1000, 500 * 2 ** attempt));
        }
      }
    }

    const document = message?.document || message;
    const messageId = message?.message_id || null;
    if (!document?.file_id) throw new Error('Telegram returned no file_id');
    const file = await this.request('getFile', { query: { file_id: document.file_id } });
    if (!file?.file_path) throw new Error('Telegram returned no file_path');
    const obtainedAt = Date.now();
    this.pathCache.set(document.file_id, { path: file.file_path, obtainedAt });
    return { fileId: document.file_id, filePath: file.file_path, pathObtainedAt: obtainedAt, messageId };
  }

  fileUrl(filePath) {
    const encodedPath = String(filePath).replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/');
    return `${config.telegramApiBase}/file/bot${config.botToken}/${encodedPath}`;
  }

  async getFileUrl(chunk, refresh = false) {
    const cached = this.pathCache.get(chunk.fileId);
    const fresh = cached && Date.now() - cached.obtainedAt < 45 * 60 * 1000;
    if (!refresh && fresh) return this.fileUrl(cached.path);
    if (!refresh && chunk.filePath && Date.now() - Number(chunk.pathObtainedAt || 0) < 45 * 60 * 1000) {
      return this.fileUrl(chunk.filePath);
    }
    const file = await this.request('getFile', { query: { file_id: chunk.fileId } });
    if (!file?.file_path) throw new Error('Telegram returned no file_path');
    this.pathCache.set(chunk.fileId, { path: file.file_path, obtainedAt: Date.now() });
    return this.fileUrl(file.file_path);
  }

  async openLocalDownload(filePath) {
    if (!filePath || !path.isAbsolute(filePath)) return null;
    try {
      const info = await stat(filePath);
      if (!info.isFile()) return null;
      return new Response(Readable.toWeb(createReadStream(filePath)), {
        status: 200,
        headers: { 'Content-Length': String(info.size), 'Content-Type': 'application/octet-stream' },
      });
    } catch {
      return null;
    }
  }

  async openDownload(chunk) {
    // Local Bot API --local commonly returns an absolute path. Reading it
    // directly avoids unnecessary getFile calls and expired file_id refreshes.
    const local = await this.openLocalDownload(chunk.filePath);
    if (local) return local;

    // Try the known path first even when it is old. Refresh file_id only when
    // Telegram actually rejects that path, not merely because it is 45 min old.
    let response = await fetch(chunk.filePath ? this.fileUrl(chunk.filePath) : await this.getFileUrl(chunk));
    if ([400, 401, 403, 404].includes(response.status)) {
      response.body?.cancel();
      response = await fetch(await this.getFileUrl(chunk, true));
    }
    if (!response.ok || !response.body) {
      response.body?.cancel();
      throw new Error(`Telegram download failed (${response.status})`);
    }
    return response;
  }

  async deleteDocument(messageId) {
    if (!messageId) return; // Legacy metadata may not contain message_id.
    return this.request('deleteMessage', {
      json: { chat_id: config.chatId, message_id: messageId },
      retry: false,
    });
  }
}
