import express from 'express';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { config, assertConfig } from './config.js';
import { JsonStore } from './store.js';
import { TelegramStorage } from './telegram.js';
import { UploadManager } from './uploads.js';
import { receiveFiles } from './multipart.js';
import { FILE_KEY_PATTERN, isEncryptionKey } from './keys.js';
import { decryptStream } from './crypto.js';
import { normalizeCollection, publicFiles, verifyCollectionKey } from './records.js';
import { ensureTelegramServer, stopTelegramServer } from './telegram-process.js';

assertConfig();
await ensureTelegramServer();
const store = new JsonStore(config.dataFile);
await store.init();
const telegram = new TelegramStorage();
const uploads = new UploadManager(store, telegram);
const app = express();
const asyncRoute = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

app.disable('x-powered-by');
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'X-Frame-Options': 'DENY',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  });
  next();
});
app.use(express.json({ limit: '32kb' }));

function collectionForKey(value) {
  const fileKey = String(value || '').toUpperCase();
  if (!FILE_KEY_PATTERN.test(fileKey)) throw Object.assign(new Error('Invalid FILE_KEY'), { status: 400 });
  const stored = store.get(fileKey);
  if (!stored) throw Object.assign(new Error('File key not found'), { status: 404 });
  return { fileKey, record: normalizeCollection(stored) };
}

function checkKey(record, encKey) {
  if (record.encrypted && (!isEncryptionKey(encKey) || !verifyCollectionKey(record, encKey))) {
    throw Object.assign(new Error('A valid ENC_KEY is required'), { status: 400 });
  }
}

function fileListPayload(fileKey, record) {
  return {
    fileKey,
    encrypted: record.encrypted,
    requiresEncKey: false,
    fileCount: record.files.length,
    totalSize: record.files.reduce((total, file) => total + file.size, 0),
    files: publicFiles(record),
  };
}

function listFiles(req, res) {
  const { fileKey, record } = collectionForKey(req.body?.fileKey);
  const encKey = req.body?.encKey;
  if (record.encrypted && !encKey) return res.json({ fileKey, encrypted: true, requiresEncKey: true });
  checkKey(record, encKey);
  return res.json(fileListPayload(fileKey, record));
}

function selectedFile(record, fileId) {
  if (!fileId && record.files.length === 1) return record.files[0];
  const file = record.files.find((item) => item.id === fileId);
  if (!file) throw Object.assign(new Error('A valid fileId is required'), { status: 400 });
  return file;
}

async function* prepend(first, rest) {
  yield first;
  yield* rest;
}

app.get('/', (req, res) => res.redirect('/upload'));
app.get('/upload', (req, res) => res.sendFile(path.join(config.root, 'public', 'upload.html')));
app.get('/download', (req, res) => res.sendFile(path.join(config.root, 'public', 'download.html')));
app.get('/docs', (req, res) => res.sendFile(path.join(config.root, 'public', 'docs.html')));

app.get('/api', (req, res) => res.json({
  name: "Moscow's Cloud Storage",
  endpoints: { upload: '/api/upload', files: '/api/files', download: '/api/download', docs: '/docs' },
  maxFileSize: config.maxFileSize,
  maxFilesPerRequest: 20,
  downloadMode: 'server-decrypted-stream',
}));

app.post('/api/upload', asyncRoute(async (req, res) => {
  const { files, fields } = await receiveFiles(req, config.maxFileSize, 20);
  res.json(fields.fileKey
    ? await uploads.add(fields.fileKey, files, fields)
    : await uploads.create(files, fields));
}));

app.post('/api/files', listFiles);
app.post('/api/files/delete', asyncRoute(async (req, res) => {
  const { fileKey, record } = collectionForKey(req.body?.fileKey);
  checkKey(record, req.body?.encKey);
  res.json(await uploads.deleteFile(fileKey, req.body?.fileId, req.body?.encKey));
}));

app.post('/api/download', asyncRoute(async (req, res) => {
  if (req.body?.metadata === true) return listFiles(req, res);
  const { record } = collectionForKey(req.body?.fileKey);
  const encKey = req.body?.encKey;
  checkKey(record, encKey);
  const file = selectedFile(record, req.body?.fileId);
  const response = await telegram.openDownload(file.chunks[0]);
  let stream = Readable.fromWeb(response.body);
  if (file.encrypted) {
    const decrypted = decryptStream(stream, file.size, file.encryption, encKey);
    const first = await decrypted.next();
    if (first.done) throw new Error('Encrypted file is empty');
    stream = Readable.from(prepend(first.value, decrypted));
  }
  res.status(200);
  res.set({
    'Content-Type': file.mimeType,
    'Content-Length': String(file.size),
    'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(file.name)}`,
    'Cache-Control': 'private, no-store',
  });
  await pipeline(stream, res);
}));

app.get('/api/download', (req, res) => {
  res.set('Allow', 'POST');
  res.status(405).json({ error: 'Use POST with JSON fileKey, fileId and encKey when required' });
});

app.use(express.static(path.join(config.root, 'public'), { maxAge: 0, index: false }));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((req, res) => res.status(404).sendFile(path.join(config.root, 'public', 'upload.html')));

app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  const status = error.clientStatus || error.status || (error instanceof SyntaxError ? 400 : 500);
  if (status >= 500) console.error(error);
  const message = error.public || status < 500 ? error.message : 'Storage request failed';
  res.status(status).json({ error: message });
});

const server = app.listen(config.port, '0.0.0.0', () => {
  console.log(`Moscow's Cloud Storage listening on http://0.0.0.0:${config.port}`);
});
server.requestTimeout = 0;
server.headersTimeout = 60_000;

let shuttingDown = false;
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    if (shuttingDown) return;
    shuttingDown = true;
    server.close(async () => {
      await stopTelegramServer();
      process.exit(0);
    });
  });
}
