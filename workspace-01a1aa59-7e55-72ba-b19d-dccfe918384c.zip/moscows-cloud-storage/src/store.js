import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

export class JsonStore {
  constructor(file) {
    this.file = file;
    this.data = { version: 1, files: {} };
    this.writeQueue = Promise.resolve();
  }

  async init() {
    await mkdir(path.dirname(this.file), { recursive: true });
    try {
      const parsed = JSON.parse(await readFile(this.file, 'utf8'));
      if (!parsed.files || typeof parsed.files !== 'object') throw new Error('Invalid meg.json format');
      this.data = parsed;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      await this.persist();
    }
  }

  has(fileKey) {
    return Object.hasOwn(this.data.files, fileKey);
  }

  get(fileKey) {
    const record = this.data.files[fileKey];
    return record ? structuredClone(record) : null;
  }

  async put(fileKey, record) {
    if (this.has(fileKey)) throw new Error('FILE_KEY collision');
    this.data.files[fileKey] = record;
    await this.persist();
  }

  async update(fileKey, record) {
    if (!this.has(fileKey)) throw Object.assign(new Error('File not found'), { status: 404 });
    this.data.files[fileKey] = record;
    await this.persist();
  }

  async persist() {
    const snapshot = JSON.stringify(this.data, null, 2) + '\n';
    const temporary = `${this.file}.tmp-${process.pid}-${Date.now()}`;
    this.writeQueue = this.writeQueue.then(async () => {
      await writeFile(temporary, snapshot, { mode: 0o600 });
      await rename(temporary, this.file);
    });
    return this.writeQueue;
  }
}
