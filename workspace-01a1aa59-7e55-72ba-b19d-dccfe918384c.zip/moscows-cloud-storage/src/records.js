import { createHash, timingSafeEqual } from 'node:crypto';

export function keyHash(encKey) {
  return createHash('sha256').update(String(encKey)).digest('base64url');
}

export function normalizeCollection(record) {
  if (record.files) return record;
  // Backward compatibility for the original one-file-per-key metadata.
  return {
    encrypted: record.encrypted,
    keyHash: record.keyHash || null,
    createdAt: record.createdAt,
    files: [{ ...record, id: '0' }],
  };
}

export function verifyCollectionKey(record, encKey) {
  if (!record.encrypted) return true;
  if (!encKey) return false;
  if (!record.keyHash) return true; // Legacy records authenticate during decryption.
  const expected = Buffer.from(record.keyHash, 'base64url');
  const supplied = Buffer.from(keyHash(encKey), 'base64url');
  return expected.length === supplied.length && timingSafeEqual(expected, supplied);
}

export function publicFiles(record) {
  return record.files.map((file) => ({
    id: file.id,
    name: file.name,
    size: file.size,
    mimeType: file.mimeType,
    encrypted: file.encrypted,
    createdAt: file.createdAt,
  }));
}
