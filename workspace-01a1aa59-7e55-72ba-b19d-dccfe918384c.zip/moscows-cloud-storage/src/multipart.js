import Busboy from 'busboy';
import { createWriteStream } from 'node:fs';
import { mkdir, rm } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { config } from './config.js';

export async function receiveFiles(req, maxBytes, maxFiles = 20) {
  await mkdir(config.tempDir, { recursive: true });
  let busboy;
  try {
    busboy = Busboy({
      headers: req.headers,
      limits: { fileSize: maxBytes, files: maxFiles, fields: 20, parts: maxFiles + 20 },
    });
  } catch {
    const error = new Error('Expected multipart/form-data');
    error.status = 400;
    throw error;
  }

  return new Promise((resolve, reject) => {
    const fields = {};
    const files = [];
    const pending = [];
    let failure = null;

    const cleanup = () => Promise.all(files.map((file) => rm(file.path, { force: true }).catch(() => {})));
    const fail = (error) => { if (!failure) failure = error; };

    busboy.on('field', (name, value) => { fields[name] = value; });
    busboy.on('file', (name, stream, info) => {
      if (name !== 'file') { stream.resume(); return; }
      const file = {
        path: path.join(config.tempDir, `${randomUUID()}.part`),
        name: info.filename || 'file',
        mimeType: info.mimeType || 'application/octet-stream',
        size: 0,
        truncated: false,
      };
      files.push(file);
      const output = createWriteStream(file.path, { flags: 'wx', mode: 0o600 });
      stream.on('data', (chunk) => { file.size += chunk.length; });
      stream.on('limit', () => { file.truncated = true; });
      const task = pipeline(stream, output);
      task.catch(fail);
      pending.push(task);
    });
    busboy.on('filesLimit', () => fail(Object.assign(new Error(`Maximum ${maxFiles} files per request`), { status: 400 })));
    busboy.on('partsLimit', () => fail(Object.assign(new Error('Too many multipart parts'), { status: 400 })));
    busboy.on('error', (error) => { fail(error); cleanup().finally(() => reject(error)); });
    req.on('aborted', () => fail(Object.assign(new Error('Upload aborted'), { status: 400 })));

    busboy.on('close', async () => {
      try {
        await Promise.all(pending);
        if (failure) throw failure;
        if (files.some((file) => file.truncated)) {
          throw Object.assign(new Error('Each file must be 2 GB or smaller'), { status: 413 });
        }
        if (!files.length) throw Object.assign(new Error('No files supplied'), { status: 400 });
        resolve({ files, fields });
      } catch (error) {
        await cleanup();
        reject(error);
      }
    });
    req.pipe(busboy);
  });
}

export async function receiveFile(req, maxBytes) {
  const { files, fields } = await receiveFiles(req, maxBytes, 1);
  return { ...files[0], fields };
}
