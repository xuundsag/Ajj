# MoscowTV V4.2

A responsive anime, movie, and web-series catalog with an Anikoto-powered anime catalog, provider-resolved Video.js playback, custom captions and audio controls, Watchlist, Continue Watching, and the completed mobile/desktop Spotlight artwork.

## Start

```sh
node start.js
```

The launcher installs production dependencies and Playwright Chromium when needed, then starts on port `3000`. Node 20+ is required. On a fresh Linux VPS, install Chromium's system libraries with `npx playwright install-deps chromium` if the browser reports missing shared libraries. Edit `PORT` in `start.js` to change the port.

Set `TMDB_API_KEY` for reliable TMDB access; otherwise the server tries publicly shared keys from `freekeys`, which can fail or be rate-limited. `VIDSRC_PLAYER_KEY` is an optional override for Vidsrc's public browser player key; the browser resolver can also refresh it automatically.

## V4.2 player revision

- MoscowTV uses its own **Video.js 8.23.4** player and responsive MegaPlay/JW-inspired control layer. Provider iframes, advertising, and provider player JavaScript are not shipped to the viewer; the page enforces `frame-src 'none'`.
- **Empty video clicks/taps only toggle the controls.** They do not play or pause the video. The center Play/Resume button appears only while paused, performs playback only when explicitly pressed, and fades with the rest of the controls. Default autoplay and normal inactivity fading remain enabled.
- The bottom controls retain Play/Pause, ±10 seconds, volume, time, CC, settings, PiP, and fullscreen as space allows. The seek rail has orange played progress, a held-position dot, and a fast thumbnail/time preview drawn from the actual stream. Releasing the seek gesture hides the preview immediately.
- **Manual Skip Intro and Skip Outro** buttons appear inside their supplied marker ranges and seek to the marker end when pressed. Optional automatic skipping remains available in playback settings. Intro/outro availability depends on the provider; the UI test uses explicitly injected marker ranges to verify the buttons.
- Native Video.js cue rendering is replaced by a custom caption flow so simultaneous cues do not overlap. CC includes Off, available provider subtitles, and eight customization options: **size, text color, background color, background opacity, text opacity, font, edge style, and vertical position**. Changes apply immediately and persist in the browser.
- The old below-player Sub/Dub selector and extra non-player control section are removed. **Server, audio, subtitle, speed, and quality choices live inside the player.** Anime Sub/Dub selection still loads the distinct provider source, and real HLS audio tracks remain available when exposed.
- Mobile fullscreen requests a **landscape orientation lock** where supported and unlocks on exit. If the browser denies or does not implement orientation locking, fullscreen continues without an uncaught error. Video remains `object-fit: contain`, preserving the complete frame with letterboxing when necessary.
- Saved progress resumes on the first playable frame. Playback lifecycle, seeking, playback speed, PiP, fullscreen, Data Saver, Auto Next, quality selection, and the six completed text-free Spotlight portraits are preserved.

### Sources, quality, and startup

- Movies and web series retain **Stream 1 / Stream 2** from CineSrc and add **Vidlink / Vidsrc Proxy** choices inside player settings. Anime continues to use independently resolved MegaPlay Sub and Dub sources.
- Stream assets, visitor state, and media resolution initialize in parallel. An eight-second primary-source deadline triggers compatible fallback resolution instead of leaving the viewer waiting indefinitely. CineSrc results are cached for five minutes; Vidlink/Vidsrc results for ten minutes.
- Vidlink uses its standard playback-environment API and selects a browser-compatible MP4/HLS/DASH source. HEVC-only results are rejected rather than presented as playable on incompatible browsers, and the server tries another provider. Vidsrc tries its authenticated direct source API first, validates a real media segment, and retains a server-side browser resolver as backup.
- HLS, DASH, MP4, subtitles, required provider headers, cookies, referers, and byte ranges are handled by signed same-origin proxy routes. DASH can be repackaged as HLS, but repackaging cannot make an unsupported video codec decodable.
- **Quality** lists the actual HLS renditions plus Auto. Manual selection enables only the chosen level; Auto restores adaptive selection. Verification measured decoded **1920×1080** video at 1080p and **1280×720** at 720p. A single-file MP4 fallback can honestly expose Auto only.
- Video.js and the custom player assets load only on watch pages. Data Saver disables preload/autoplay until Play is pressed and avoids populating renditions before that gesture.

## Verification

The supplied `MoscowTV-VideoJS-Proof.html` is a self-contained gallery with screenshots and machine-readable result summaries. Final checks cover:

- Movie Stream 1, Movie Stream 2, Web Series Stream 1, Anime Sub, and Anime Dub with decoded video frames, decoded audio, advancing playback, and no uncaught page errors.
- Actual Vidlink movie playback selected inside the player, plus actual Vidsrc movie and web-series playback. An HEVC-only Vidlink series request was also checked for honest failover to Vidsrc.
- A **28/28 Android-sized touch interaction suite**, including empty-tap behavior, autoplay, inactivity fade, center Resume, captions, seek thumbnails, skip buttons, settings, and fullscreen. This is Chromium/CDP device emulation, not a claim of testing on every physical Android device.
- Real 1080p/720p decoded rendition switching, Auto restoration, Streams 2 resume after reload, Data Saver, unsupported-orientation handling, six episode/season boundaries, and distinct anime Sub/Dub source URLs.

Upstream providers can change or disappear. These results describe the tested sources at verification time, not permanent availability.

## Resolver and VPS requirements

CineSrc and browser-backup fallback resolution use server-side Chromium. MegaPlay currently resolves through its encrypted source response without a browser. Provider scripts run only in isolated resolver pages, never in MoscowTV's viewer.

**Raw-stream resolution is not a guarantee of ad-free playback or low server bandwidth.** Upstream HLS can change, expire, or contain advertising. Required headers and CORS are handled by the same-origin media proxy, so proxied video bandwidth passes through the MoscowTV server. Hundreds of simultaneous viewers require bandwidth and upstream-capacity planning even though the frontend itself is small.

## Anime catalog and episode data

**Anikoto is the primary anime catalog.** `data/megaplay-catalog.json` contains titles, alternate titles, artwork, descriptions, genres, years, formats, ratings, status, MAL/AniList IDs, episode counts, and provider series IDs.

- Browse, Search, genre shelves, Random, Advanced Filters, and released anime details use this catalog directly. Only entries with artwork and at least one listed episode enter normal discovery.
- AniList supplies real airing schedules, upcoming anime, and selective season relationships. TMDB remains the movie/web-series catalog and can supply matching wide artwork.
- MegaPlay uses the exact `embed_url.sub` or `embed_url.dub` for the requested provider episode. Missing episodes or language tracks return an error rather than a fabricated URL.
- Anime movies and upcoming titles do not show inappropriate episode controls. Unrelated successors are not merged into a season family.
- Next/Auto Next follows actual TMDB or Anikoto boundaries. A season finale advances only to a listed next-season episode 1, and there is no next target at the final catalog episode.

To refresh the Anikoto snapshot, run the following command and restart the server. The importer respects the published 60-requests-per-120-seconds limit and takes a few minutes.

```sh
python3 scripts/update-megaplay-catalog.py
```

## Interface and saving

- Watchlist and history save automatically to the current browser through a persistent HttpOnly visitor cookie and `data/states.json`.
- Continue Watching uses the saved title, episode, season, duration, and playback position. The Watchlist icon remains beside Search on desktop and mobile.
- The Spotlight retains the six completed **848×1264 text-free portrait assets** on mobile with a dark lower fade; desktop landscape backdrops and layout remain unchanged.
- The interface keeps its crown wordmark, bold inline SVG icons, responsive catalog grids, search, Schedule, Upcoming, Random, Advanced Filters, expandable descriptions, and circular loading indicators.
- Accounts, Profiles, login, registration, Comments, Community, and Watchlist statuses remain removed.

## Typography, logo, and attribution

Headings request **Atyp Display** and fall back to bundled **Archivo**. Body copy requests **Atyp Text** and falls back to bundled **Manrope**. Atyp is a commercial Suitcase Type Foundry family and is not bundled without a license. Archivo and Manrope licenses are included in `public/fonts/`.

Video.js is self-hosted under `public/vendor/`; its license is retained in `VIDEOJS-LICENSE.txt`. The transparent crown wordmark is stored as `public/images/moscowtv-crown-wordmark.png`.

The interface takes inspiration from Anipaca and the supplied design references. The responsive control layer follows the supplied MegaPlay references; MegaPlay's player, advertising, and sandbox JavaScript are not bundled. Anipaca's GPL-3.0 license is retained in `ANIPACA-LICENSE.txt`, and Lucide-style notices in `LUCIDE-LICENSE.txt`. Catalog data comes from Anikoto, AniList, and TMDB. Review content rights and provider terms before deployment.

**JW icon licensing / noncommercial restriction:** inline control icons are adapted from [JW Player SVG assets](https://github.com/jwplayer/jwplayer/tree/master/src/assets/SVG), including a Forward 10 adaptation. The upstream license is **Creative Commons Attribution-NonCommercial-ShareAlike 3.0**, retained in `JWPLAYER-LICENSE.txt`. Keep this attribution and the same license with the assets. **Do not use these JW-derived icons commercially.** Replace them with appropriately licensed icons before commercial deployment.
