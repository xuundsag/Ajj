import { chromium } from 'playwright';

// Provider pages run only in this server-side resolver browser. Their scripts,
// ads, and embeds are never shipped to MoscowTV's viewer.
let browserPromise = null;
let active = 0;
const waiting = [];
const cache = new Map();
const CACHE_MS = 10 * 60_000;
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

function browser() {
  if (!browserPromise) {
    browserPromise = chromium.launch({ headless: true, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
    browserPromise.then(instance => instance.on('disconnected', () => { browserPromise = null; })).catch(() => { browserPromise = null; });
  }
  return browserPromise;
}

async function acquire() {
  if (active >= 2) await new Promise(resolve => waiting.push(resolve));
  active++;
}
function release() {
  active--;
  waiting.shift()?.();
}
async function withPage(work) {
  await acquire();
  let page;
  try {
    const instance = await browser();
    page = await instance.newPage({ viewport: { width: 960, height: 540 } });
    await page.route('**/*', route => {
      const host = new URL(route.request().url()).hostname;
      if (/google-analytics|googletagmanager|doubleclick|rapidadexchange|mc\.yandex|id5-sync|pippio/i.test(host)) return route.abort();
      return route.continue();
    });
    return await work(page);
  } finally {
    await page?.close().catch(() => {});
    release();
  }
}

function embedPath(input, provider) {
  if (provider === 'vidlink') return 'https://vidlink.pro/' + (input.type === 'tv' ? `tv/${input.id}/${input.season}/${input.episode}` : `movie/${input.id}`);
  return 'https://vidsrc.pm/embed/' + (input.type === 'tv' ? `tv/${input.id}/${input.season}/${input.episode}` : `movie/${input.id}`);
}

function allowedHeaders(headers = {}) {
  const clean = {};
  for (const key of ['Cookie', 'Referer', 'Origin']) {
    if (typeof headers[key] === 'string' && headers[key].length < 8192) clean[key] = headers[key];
  }
  return clean;
}

async function validateManifest(stream) {
  const response = await fetch(stream.url, {
    headers: { ...allowedHeaders(stream.headers), ...(stream.headers?.Referer || stream.sourceKey !== 'vidlink' ? { Referer: stream.headers?.Referer || stream.referer } : {}), 'User-Agent': stream.sourceKey === 'vidlink' ? 'MoscowTV/4.2 (media proxy)' : UA, ...(stream.kind === 'mp4' ? { Range: 'bytes=0-1023' } : {}) },
    signal: AbortSignal.timeout(15_000)
  });
  if (!response.ok) throw Error(`Media request failed (${response.status}).`);
  if (stream.kind === 'mp4') {
    await response.body?.cancel();
    return stream;
  }
  const text = await response.text();
  if (stream.kind === 'dash') {
    if (!/<MPD[\s>]/i.test(text)) throw Error('Vidlink returned an invalid DASH manifest.');
    const codecs = [...text.matchAll(/codecs="([^"]+)"/g)].map(match => match[1]);
    if (codecs.length && !codecs.some(codec => /^(?:avc1|avc3)\./i.test(codec))) throw Error('Vidlink exposed only unsupported HEVC video.');
  }
  if (stream.kind === 'hls') {
    if (!text.trimStart().startsWith('#EXTM3U')) throw Error('The provider returned an invalid HLS playlist.');
    const codecs = [...text.matchAll(/CODECS="([^"]+)"/g)].flatMap(match => match[1].split(','));
    if (codecs.length && !codecs.some(codec => /^(?:avc1|avc3)\./i.test(codec.trim()))) throw Error('Vidlink exposed only unsupported HEVC video.');
  }
  return stream;
}

async function vidlink(input) {
  return withPage(async page => {
    let apiResolve;
    const api = new Promise(resolve => { apiResolve = resolve; });
    page.on('response', response => {
      if (!/\/api\/b\/(?:movie|tv)\//.test(response.url())) return;
      response.json().then(data => {
        if (data?.stream && ((/^https:\/\//.test(data.stream.playlist || '')) || Object.values(data.stream.qualities || {}).some(value => /^https:\/\//.test(value?.url || '')))) apiResolve(data);
      }).catch(() => {});
    });
    await page.route('https://vidlink.pro/api/b/**', route => route.continue({ headers: { ...route.request().headers(), 'x-playback-environment': 'standard' } }));
    await page.goto(embedPath(input, 'vidlink'), { waitUntil: 'commit', timeout: 20_000 });
    const data = await Promise.race([
      api,
      new Promise((_, reject) => setTimeout(() => reject(Error('Vidlink did not expose a stream.')), 30_000))
    ]);
    const source = data.stream;
    const tracks = (source.captions || []).filter(track => /^https:\/\//.test(track.url || '')).slice(0, 30).map(track => ({
      src: track.url,
      label: String(track.language || 'Subtitle').slice(0, 60),
      language: /english/i.test(track.language || '') ? 'en' : 'und',
      kind: 'subtitles',
      default: false
    }));
    const common = { referer: 'https://vidlink.pro/', provider: 'Vidlink', sourceKey: 'vidlink', server: 'Vidlink', tracks };
    const compatible = Object.entries(source.qualities || {}).filter(([, value]) => /^https:\/\//.test(value?.url || '') && !/hevc|h265|x265/i.test(value?.codecName || '')).sort((a, b) => Number(b[0]) - Number(a[0]));
    if (compatible.length) {
      const [, quality] = compatible[0];
      return validateManifest({ ...common, url: quality.url, kind: quality.type === 'hls' ? 'hls' : 'mp4', headers: allowedHeaders(quality.headers) });
    }
    if (source.playlist) {
      const kind = source.type === 'dash' || /\.mpd(?:\?|$)/i.test(source.playlist) ? 'dash' : 'hls';
      return validateManifest({ ...common, url: source.playlist, kind, headers: allowedHeaders(source.playlistHeaders) });
    }
    throw Error('Vidlink exposed only unsupported HEVC video.');
  });
}

let vidsrcPlayerKey = process.env.VIDSRC_PLAYER_KEY || 'f3b72e73c80c9a996574379798703796a1936efa3516a7105cb0e43048b46b5a';

async function validateVidsrcSegment(stream) {
  const headers = { Referer: 'https://vidsrc.pm/', 'User-Agent': UA };
  const masterResponse = await fetch(stream.url, { headers, signal: AbortSignal.timeout(12_000) });
  if (!masterResponse.ok) throw Error('Vidsrc playlist unavailable.');
  const master = await masterResponse.text();
  if (!master.trimStart().startsWith('#EXTM3U')) throw Error('Vidsrc returned an invalid playlist.');
  let playlistUrl = masterResponse.url || stream.url, playlist = master;
  if (/#EXT-X-STREAM-INF/.test(master)) {
    const lines = master.split(/\r?\n/), index = lines.findIndex(line => line.startsWith('#EXT-X-STREAM-INF'));
    const variant = lines.slice(index + 1).find(line => line.trim() && !line.startsWith('#'));
    if (!variant) throw Error('Vidsrc master playlist has no rendition.');
    const response = await fetch(new URL(variant, playlistUrl), { headers, signal: AbortSignal.timeout(12_000) });
    if (!response.ok) throw Error('Vidsrc rendition unavailable.');
    playlist = await response.text();
    playlistUrl = response.url || new URL(variant, playlistUrl).href;
    if (!playlist.trimStart().startsWith('#EXTM3U')) throw Error('Vidsrc returned an invalid rendition.');
  }
  const mapped = playlist.match(/#EXT-X-MAP:URI="([^"]+)"/)?.[1];
  const segment = mapped || playlist.split(/\r?\n/).find(line => line.trim() && !line.startsWith('#'));
  if (!segment) throw Error('Vidsrc playlist has no media segments.');
  const response = await fetch(new URL(segment, playlistUrl), { headers: { ...headers, Range: 'bytes=0-1023' }, signal: AbortSignal.timeout(12_000) });
  if (!response.ok) throw Error('Vidsrc segment unavailable.');
  const buffer = await response.arrayBuffer();
  if (buffer.byteLength < 16) throw Error('Vidsrc returned an empty media segment.');
  return stream;
}

async function vidsrcDirect(input) {
  const embed = embedPath(input, 'vidsrc');
  const endpoint = input.type === 'tv' ? `https://vidsrc.pm/api/vidora/v1/tv/${input.id}/${input.season}/${input.episode}` : `https://vidsrc.pm/api/vidora/v1/movie/${input.id}`;
  const attempts = ['k2mq', 'b4tz', 'nzv4', 'w7dn'].map(source => (async () => {
    const response = await fetch(`${endpoint}?source=${source}`, { headers: { 'x-player-key': vidsrcPlayerKey, Referer: embed, 'User-Agent': UA }, signal: AbortSignal.timeout(12_000) });
    if (!response.ok) throw Error('Vidsrc source API unavailable.');
    const data = await response.json();
    if (!data.result) throw Error(data.message || 'Vidsrc source rejected.');
    const sources = (data.sources || []).filter(item => /^https:\/\//.test(item.url || '')).slice(0, 3);
    if (!sources.length) throw Error('Vidsrc returned no source.');
    return Promise.any(sources.map(item => validateVidsrcSegment({ url: item.url, kind: 'hls', headers: {}, referer: 'https://vidsrc.pm/', provider: 'Vidsrc', sourceKey: 'vidsrc', server: 'Vidsrc Proxy', tracks: [] })));
  })());
  return Promise.any(attempts);
}

async function vidsrcBrowser(input) {
  return withPage(async page => {
    const candidates = [];
    page.on('request', request => { if (/\/api\/vidora\//.test(request.url()) && request.headers()['x-player-key']) vidsrcPlayerKey = request.headers()['x-player-key']; });
    page.on('response', response => {
      const url = response.url();
      if (!/\.m3u8(?:[?#]|$)|[?&]type=(?:\/index\.)?m3u8/i.test(url)) return;
      response.text().then(text => {
        if (text.trimStart().startsWith('#EXTM3U')) candidates.push({ url, master: /#EXT-X-(?:STREAM-INF|MEDIA|SESSION)/.test(text) });
      }).catch(() => {});
    });
    const embed = embedPath(input, 'vidsrc');
    await page.route('https://resolver.moscowtv/', route => route.fulfill({
      contentType: 'text/html',
      body: `<iframe src="${embed}" allow="autoplay; fullscreen" allowfullscreen style="width:960px;height:540px"></iframe>`
    }));
    await page.goto('https://resolver.moscowtv/', { waitUntil: 'domcontentloaded', timeout: 20_000 });
    const deadline = Date.now() + 35_000;
    let decoded = false;
    while (Date.now() < deadline && !decoded) {
      for (const frame of page.frames()) {
        try {
          decoded = await frame.evaluate(() => {
            for (const video of document.querySelectorAll('video')) {
              if (video.readyState >= 2) {
                if (video.paused) video.play().catch(() => {});
                if (video.currentTime > 0) return true;
              }
            }
            return false;
          });
        } catch {}
        if (decoded) break;
      }
      if (!decoded) await page.waitForTimeout(300);
    }
    if (!decoded) throw Error('Vidsrc did not decode a playable stream.');
    const candidateDeadline = Date.now() + 5_000;
    while (!candidates.length && Date.now() < candidateDeadline) await page.waitForTimeout(100);
    if (!candidates.length) throw Error('Vidsrc did not expose an HLS playlist.');
    candidates.sort((a, b) => Number(b.master) - Number(a.master));
    let lastError;
    for (const candidate of candidates.slice(0, 4)) {
      try {
        return await validateManifest({ ...candidate, kind: 'hls', headers: {}, referer: 'https://vidsrc.pm/', provider: 'Vidsrc', sourceKey: 'vidsrc', server: 'Vidsrc Proxy', tracks: [] });
      } catch (error) { lastError = error; }
    }
    throw lastError || Error('Vidsrc media validation failed.');
  });
}

async function vidsrc(input) {
  try { return await vidsrcDirect(input); }
  catch { return vidsrcBrowser(input); }
}

function cached(key, resolver) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.time < CACHE_MS) return Promise.resolve(hit.value);
  return resolver().then(value => {
    cache.set(key, { value, time: Date.now() });
    return value;
  });
}

export function resolveVidlink(input) {
  return cached(['vidlink', input.type, input.id, input.season, input.episode].join(':'), () => vidlink(input));
}
export function resolveVidsrc(input) {
  return cached(['vidsrc', input.type, input.id, input.season, input.episode].join(':'), () => vidsrc(input));
}
