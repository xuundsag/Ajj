import crypto from 'node:crypto';

const UA='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const key=Buffer.from(process.env.MEGAPLAY_AES_KEY_HEX||'693f4c4d5441783051362c3a7d35305500000000000000000000000000000000','hex');
const iv=Buffer.from(process.env.MEGAPLAY_AES_IV_HEX||'57303b3237546f6155706c5f50252763','hex');
const sourceCache=new Map(),CACHE_MS=5*60_000;
async function fetchJson(url){let r=await fetch(url,{headers:{'User-Agent':UA,Referer:'https://megaplay.buzz/','X-Requested-With':'XMLHttpRequest',Accept:'application/json'},signal:AbortSignal.timeout(15_000)});if(!r.ok)throw Error('MegaPlay source request failed ('+r.status+').');return r.json()}
function sourceFile(data){
 if(data?.sources?.file)return data.sources.file;
 if(!data?.enc)return null;
 let decipher=crypto.createDecipheriv('aes-256-cbc',key,iv),plain=Buffer.concat([decipher.update(Buffer.from(data.enc,'base64url')),decipher.final()]).toString('utf8');
 return JSON.parse(plain).file;
}
export async function resolveMegaPlay(embedUrl){
 let cached=sourceCache.get(embedUrl);if(cached&&Date.now()-cached.time<CACHE_MS)return cached.value;
 let page=await fetch(embedUrl,{headers:{'User-Agent':UA,Referer:'https://anikotoapi.site/'},signal:AbortSignal.timeout(15_000)});
 if(!page.ok)throw Error('MegaPlay embed request failed ('+page.status+').');
 let html=await page.text(),fileId=html.match(/data-id=["']?(\d+)/)?.[1]||html.match(/File\s+(\d+)\s+-/)?.[1];
 if(!fileId)throw Error('MegaPlay did not provide a source ID for this episode.');
 let data=await fetchJson('https://megaplay.buzz/stream/getSourcesNew?id='+fileId).catch(()=>fetchJson('https://megaplay.buzz/stream/getSources?id='+fileId)),file=sourceFile(data);
 if(!file||!/^https:\/\//.test(file))throw Error('MegaPlay did not return a playable media file.');
 let languageNames={english:'en',portuguese:'pt',spanish:'es',french:'fr',german:'de',italian:'it',japanese:'ja',arabic:'ar',hindi:'hi'};
 let tracks=(data.tracks||[]).filter(x=>x?.kind==='captions'&&/^https:\/\//.test(x.file||'')).map(x=>{let label=String(x.label||'English').slice(0,60),lower=label.toLowerCase(),inferred=Object.entries(languageNames).find(([name])=>lower.startsWith(name))?.[1];return {src:x.file,label,language:inferred||String(x.srclang||'und'),default:false}});
 let value={url:file,tracks,intro:data.intro||null,outro:data.outro||null};
 sourceCache.set(embedUrl,{value,time:Date.now()});
 if(sourceCache.size>200)for(let [k,v] of sourceCache)if(Date.now()-v.time>=CACHE_MS||sourceCache.size>200)sourceCache.delete(k);
 return value;
}
