// OTT Stream, Multi-Audio & Subtitle Resolvers — Strictly 3 Providers Only:
// 1. vidcore  -> VidCore (DEFAULT: vidcore.io 4K/1080p/720p H.264 + VidSpark 1080p/720p + Hexa 1080p/720p)
// 2. vidlink  -> VidLink (vidlink.pro 1080p/720p HLS/DASH/MP4 + Hexa 1080p H.264 fallback)
// 3. vidsrc   -> VidSrc  (Hexa 1080p/720p H.264 + vidup.to 4K/1080p/720p H.264 + Vidora HD)

import crypto from 'node:crypto';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

export const OTT_SERVERS = [
  ['vidcore', 'VidCore'],
  ['vidlink', 'VidLink'],
  ['vidsrc', 'VidSrc']
];
export const OTT_SERVER_KEYS = new Set(OTT_SERVERS.map(([k]) => k));
export const DEFAULT_OTT_SERVER = 'vidcore';

let vidsparkPrimaryKey = '3a67e8866ae1d2bb9e81fe7f73315a56eb3bdf5e3e755c7554c8be6910aa6b13';
let vidoraCdnKey = 'f3b72e73c80c9a996574379798703796a1936efa3516a7105cb0e43048b46b5a';
const keyRefreshAt = { primary: 0, cdn: 0 };

async function refreshVidoraKey(kind) {
  const now = Date.now();
  if (now - keyRefreshAt[kind] < 60_000) return kind === 'primary' ? vidsparkPrimaryKey : vidoraCdnKey;
  keyRefreshAt[kind] = now;
  const host = kind === 'primary' ? 'https://vidspark.to' : 'https://cdn.vidspark.to';
  try {
    const html = await fetch(`${host}/movie/533535`, {
      headers: { 'User-Agent': UA, Referer: `${host}/` },
      signal: AbortSignal.timeout(4500)
    }).then(r => r.text());
    const scripts = [...html.matchAll(/src=["']([^"']+\.js[^"']*)["']/g)].map(m => m[1]);
    for (const sc of scripts) {
      if (!/main|index/i.test(sc)) continue;
      const js = await fetch(new URL(sc, host).href, {
        headers: { 'User-Agent': UA, Referer: `${host}/` },
        signal: AbortSignal.timeout(5000)
      }).then(r => r.text());
      const m = js.match(/["'`]([a-f0-9]{64})["'`]/);
      if (m?.[1]) {
        if (kind === 'primary') vidsparkPrimaryKey = m[1];
        else vidoraCdnKey = m[1];
        break;
      }
    }
  } catch {}
  return kind === 'primary' ? vidsparkPrimaryKey : vidoraCdnKey;
}

const langDisplay = (() => {
  try { return new Intl.DisplayNames(['en'], { type: 'language' }); }
  catch { return null; }
})();

const LANG_FALLBACK = {
  en: 'English', eng: 'English', hi: 'Hindi', hin: 'Hindi', ko: 'Korean', kor: 'Korean',
  ja: 'Japanese', jpn: 'Japanese', es: 'Spanish', spa: 'Spanish', fr: 'French', fra: 'French', fre: 'French',
  de: 'German', deu: 'German', ger: 'German', it: 'Italian', ita: 'Italian', pt: 'Portuguese', por: 'Portuguese',
  pb: 'Portuguese (BR)', pob: 'Portuguese (BR)', ru: 'Russian', rus: 'Russian', ar: 'Arabic', ara: 'Arabic',
  zh: 'Chinese', zho: 'Chinese', chi: 'Chinese', tr: 'Turkish', tur: 'Turkish', th: 'Thai', tha: 'Thai',
  vi: 'Vietnamese', vie: 'Vietnamese', id: 'Indonesian', ind: 'Indonesian', ms: 'Malay', may: 'Malay',
  ta: 'Tamil', tam: 'Tamil', te: 'Telugu', tel: 'Telugu', ml: 'Malayalam', mal: 'Malayalam',
  kn: 'Kannada', kan: 'Kannada', bn: 'Bengali', ben: 'Bengali', mr: 'Marathi', mar: 'Marathi',
  pa: 'Punjabi', pan: 'Punjabi', ur: 'Urdu', urd: 'Urdu', nl: 'Dutch', nld: 'Dutch', dut: 'Dutch',
  pl: 'Polish', pol: 'Polish', sv: 'Swedish', swe: 'Swedish', no: 'Norwegian', nor: 'Norwegian',
  da: 'Danish', dan: 'Danish', fi: 'Finnish', fin: 'Finnish', cs: 'Czech', ces: 'Czech', cze: 'Czech',
  el: 'Greek', ell: 'Greek', gre: 'Greek', hu: 'Hungarian', hun: 'Hungarian', ro: 'Romanian', ron: 'Romanian', rum: 'Romanian',
  uk: 'Ukrainian', ukr: 'Ukrainian', he: 'Hebrew', heb: 'Hebrew', fa: 'Persian', per: 'Persian', fas: 'Persian'
};

function readableLanguage(code, rawLabel = '') {
  const cleanLabel = String(rawLabel || '').trim();
  if (cleanLabel && cleanLabel.length > 3 && !/^[a-z]{2,3}$/i.test(cleanLabel)) return cleanLabel;
  const norm = String(code || cleanLabel || '').trim().toLowerCase();
  if (!norm) return 'Unknown';
  if (LANG_FALLBACK[norm]) return LANG_FALLBACK[norm];
  const base = norm.split(/[-_]/)[0];
  if (LANG_FALLBACK[base]) return LANG_FALLBACK[base];
  try {
    const resolved = langDisplay?.of(base);
    if (resolved && resolved.toLowerCase() !== base) return resolved;
  } catch {}
  return cleanLabel || norm.toUpperCase();
}

function mediaPathFor({ type, id, season, episode }) {
  return type === 'tv' ? `tv/${id}/${season}/${episode}` : `movie/${id}`;
}

async function fetchJsonSafe(url, { method = 'GET', headers = {}, body = undefined, timeout = 7500 } = {}) {
  const res = await fetch(url, {
    method,
    headers: { 'User-Agent': UA, Accept: 'application/json, text/plain, */*', ...headers },
    body,
    redirect: 'follow',
    signal: AbortSignal.timeout(timeout)
  });
  if (!res.ok) {
    const err = Error(`HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }
  const text = await res.text();
  try { return JSON.parse(text); } catch { return null; }
}

function sortAndDedupeTracks(tracks) {
  const seenUrl = new Set();
  const seenLabel = new Map();
  const out = [];
  for (const t of tracks) {
    if (!t?.src || !/^https:\/\//i.test(t.src)) continue;
    if (seenUrl.has(t.src)) continue;
    seenUrl.add(t.src);
    const baseLabel = readableLanguage(t.language, t.label);
    const count = (seenLabel.get(baseLabel.toLowerCase()) || 0) + 1;
    seenLabel.set(baseLabel.toLowerCase(), count);
    out.push({
      src: t.src,
      kind: 'subtitles',
      language: String(t.language || 'und').toLowerCase().slice(0, 12),
      label: count > 1 ? `${baseLabel} (${count})` : baseLabel,
      proxyProvider: t.proxyProvider,
      headers: t.headers || {}
    });
  }
  out.sort((a, b) => {
    const aEn = /^en\b|^english/i.test(a.language) || /^english/i.test(a.label);
    const bEn = /^en\b|^english/i.test(b.language) || /^english/i.test(b.label);
    if (aEn !== bEn) return aEn ? -1 : 1;
    return a.label.localeCompare(b.label);
  });
  return out;
}

const subtitleCache = new Map();

async function fetchVidsparkSubtitles(input) {
  const path = mediaPathFor(input);
  const cacheKey = 'vs-sub:' + path;
  const hit = subtitleCache.get(cacheKey);
  if (hit && Date.now() - hit.time < 20 * 60_000) return hit.tracks;

  let data = null;
  try {
    data = await fetchJsonSafe(`https://vidspark.to/api/vidora/v1/subtitles/${path}`, {
      headers: { 'x-player-key': vidsparkPrimaryKey, Referer: `https://vidspark.to/${path}` },
      timeout: 4800
    });
  } catch (err) {
    if (err?.status === 401 || err?.status === 403) {
      const fresh = await refreshVidoraKey('primary');
      data = await fetchJsonSafe(`https://vidspark.to/api/vidora/v1/subtitles/${path}`, {
        headers: { 'x-player-key': fresh, Referer: `https://vidspark.to/${path}` },
        timeout: 4800
      }).catch(() => null);
    }
  }

  const rawTracks = Array.isArray(data?.tracks) ? data.tracks : [];
  const mapped = [];
  for (const tr of rawTracks) {
    if (!tr?.src || tr.kind === 'thumbnails') continue;
    let absUrl;
    try {
      absUrl = /^https?:\/\//i.test(tr.src)
        ? tr.src
        : new URL(String(tr.src).replace(/^\/+/, ''), 'https://vidspark.to/api/vidora/').href;
    } catch { continue; }
    mapped.push({
      src: absUrl,
      language: tr.language || tr.srclang || 'und',
      label: tr.languageName || tr.label || '',
      proxyProvider: 'vidcore',
      headers: { Referer: 'https://vidspark.to/' }
    });
  }
  const tracks = sortAndDedupeTracks(mapped);
  if (tracks.length) {
    subtitleCache.set(cacheKey, { tracks, time: Date.now() });
    if (subtitleCache.size > 300) subtitleCache.delete(subtitleCache.keys().next().value);
  }
  return tracks;
}

async function fetchOpenSubtitles(input, imdbId) {
  const cleanImdb = String(imdbId || '').replace(/^tt/i, '').replace(/\D/g, '');
  if (!cleanImdb) return [];
  const cacheKey = `os:${cleanImdb}:${input.type === 'tv' ? `${input.season}:${input.episode}` : 'movie'}`;
  const hit = subtitleCache.get(cacheKey);
  if (hit && Date.now() - hit.time < 30 * 60_000) return hit.tracks;

  const endpoint = input.type === 'tv'
    ? `https://rest.opensubtitles.org/search/episode-${input.episode}/imdbid-${cleanImdb}/season-${input.season}`
    : `https://rest.opensubtitles.org/search/imdbid-${cleanImdb}`;

  const rows = await fetchJsonSafe(endpoint, {
    headers: { 'X-User-Agent': 'TemporaryUserAgent' },
    timeout: 5000
  }).catch(() => null);

  if (!Array.isArray(rows) || !rows.length) return [];
  const bestByLang = new Map();
  for (const row of rows) {
    const dl = row?.SubDownloadLink;
    const fmt = String(row?.SubFormat || '').toLowerCase();
    if (!dl || !/^https:\/\//i.test(dl) || (fmt && !['srt', 'vtt', 'subrip'].includes(fmt))) continue;
    const langKey = String(row.ISO639 || row.SubLanguageID || row.LanguageName || 'und').toLowerCase();
    const downloads = Number(row.SubDownloadsCnt) || 0;
    const prev = bestByLang.get(langKey);
    if (!prev || downloads > prev.downloads) {
      bestByLang.set(langKey, {
        downloads,
        src: dl,
        language: row.ISO639 || langKey,
        label: row.LanguageName || readableLanguage(langKey),
        proxyProvider: 'opensubtitles',
        headers: {}
      });
    }
  }
  const sorted = [...bestByLang.values()]
    .sort((a, b) => {
      const aEn = /^en/i.test(a.language) || /^english/i.test(a.label);
      const bEn = /^en/i.test(b.language) || /^english/i.test(b.label);
      if (aEn !== bEn) return aEn ? -1 : 1;
      return b.downloads - a.downloads;
    })
    .slice(0, 28);

  const tracks = sortAndDedupeTracks(sorted);
  if (tracks.length) {
    subtitleCache.set(cacheKey, { tracks, time: Date.now() });
    if (subtitleCache.size > 300) subtitleCache.delete(subtitleCache.keys().next().value);
  }
  return tracks;
}

function mapSourceTracks(rawTracks = [], proxyProvider, referer) {
  const out = [];
  for (const t of rawTracks) {
    const rawUrl = t?.file || t?.src || t?.url;
    if (!rawUrl || t?.kind === 'thumbnails' || /thumbnails/i.test(t?.label || '')) continue;
    try {
      const abs = new URL(rawUrl, referer).href;
      if (!/^https:\/\//i.test(abs)) continue;
      out.push({
        src: abs,
        language: t.language || t.srclang || t.lang || 'und',
        label: t.languageName || t.label || '',
        proxyProvider,
        headers: referer ? { Referer: referer } : {}
      });
    } catch {}
  }
  return out;
}

function mapSourceQualities(rawQualities = [], proxyProvider, headers = {}) {
  if (!Array.isArray(rawQualities) || !rawQualities.length) return [];
  const out = [];
  for (const q of rawQualities) {
    const u = q?.url || q?.file;
    const h = Number(q?.height || String(q?.quality || q?.label || '').replace(/\D/g, '')) || 0;
    if (!u || !/^https:\/\//i.test(u) || !h) continue;
    out.push({
      tier: h >= 2000 ? 2160 : h >= 1350 ? 1440 : h >= 1000 ? 1080 : h >= 680 ? 720 : h >= 440 ? 480 : 360,
      height: h,
      url: u,
      kind: /\.mp4(?:\?|$)/i.test(u) ? 'mp4' : 'hls',
      codec: 'h264',
      proxyProvider,
      headers
    });
  }
  out.sort((a, b) => b.tier - a.tier);
  return out;
}

// ============================================================================
// SHARED HIGH-BITRATE MULTI-QUALITY ENGINES (VIDCORE.IO, VIDUP.TO, HEXA, VIDORA)
// ============================================================================
async function resolveEncDecSite(input, siteHost, encEndpoint, decEndpoint, proxyProvider) {
  const pagePath = input.type === 'tv'
    ? `tv/${input.id}/${input.season}/${input.episode}/`
    : `movie/${input.id}/`;
  const referer = `${siteHost}/`;
  const origin = siteHost;

  const html = await fetch(`${siteHost}/${pagePath}`, {
    headers: { 'User-Agent': UA, Referer: referer },
    redirect: 'follow',
    signal: AbortSignal.timeout(5500)
  }).then(r => {
    if (!r.ok) throw Error(`${siteHost} HTTP ${r.status}`);
    return r.text();
  });

  const enMatch = html.match(/\\"(?:en|token)\\":\\"(.*?)\\"/);
  const enToken = enMatch?.[1];
  if (!enToken) throw Error(`${siteHost} token missing`);

  const stage1Data = await fetchJsonSafe(
    `https://enc-dec.app/api/${encEndpoint}?text=${encodeURIComponent(enToken)}&stage=1`,
    { timeout: 4500 }
  );
  const p1 = stage1Data?.result;
  if (!p1?.stage1) throw Error(`${siteHost} stage1 failed`);

  const xhrHeaders = {
    'User-Agent': UA,
    Referer: referer,
    Origin: origin,
    'X-Requested-With': 'XMLHttpRequest'
  };
  if (p1.token) xhrHeaders['X-CSRF-Token'] = p1.token;

  const t1 = await fetch(p1.stage1, {
    method: 'POST',
    headers: xhrHeaders,
    signal: AbortSignal.timeout(4800)
  }).then(r => {
    if (!r.ok) throw Error(`${siteHost} stage1 post HTTP ${r.status}`);
    return r.text();
  });

  const stage2Data = await fetchJsonSafe(
    `https://enc-dec.app/api/${encEndpoint}?text=${encodeURIComponent(t1)}&stage=2`,
    { timeout: 4500 }
  );
  const p2 = stage2Data?.result;
  if (!p2?.servers || !p2?.stream) throw Error(`${siteHost} stage2 failed`);

  if (p2.token) xhrHeaders['X-CSRF-Token'] = p2.token;
  else delete xhrHeaders['X-CSRF-Token'];

  const srvEncrypted = await fetch(p2.servers, {
    method: 'POST',
    headers: xhrHeaders,
    signal: AbortSignal.timeout(4800)
  }).then(r => {
    if (!r.ok) throw Error(`${siteHost} servers HTTP ${r.status}`);
    return r.text();
  });

  const srvDec = await fetchJsonSafe(`https://enc-dec.app/api/${decEndpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: srvEncrypted }),
    timeout: 4500
  });
  const serverList = Array.isArray(srvDec?.result) ? srvDec.result.filter(s => s?.data) : [];
  if (!serverList.length) throw Error(`${siteHost} returned no servers`);

  for (const srv of serverList.slice(0, 3)) {
    try {
      const streamEnc = await fetch(`${p2.stream}/${srv.data}`, {
        method: 'POST',
        headers: xhrHeaders,
        signal: AbortSignal.timeout(4800)
      }).then(r => (r.ok ? r.text() : ''));
      if (!streamEnc) continue;

      const streamDec = await fetchJsonSafe(`https://enc-dec.app/api/${decEndpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: streamEnc }),
        timeout: 4500
      });
      const resObj = streamDec?.result;
      const streamUrl = resObj?.url || resObj?.file || resObj?.playlist;
      if (typeof streamUrl === 'string' && /^https:\/\//i.test(streamUrl)) {
        const streamHeaders = resObj?.noReferrer ? {} : { Referer: referer, Origin: origin };
        // Quick manifest sanity check to guarantee live 1080p/4K playlist
        const check = await fetch(streamUrl, {
          headers: { 'User-Agent': UA, ...streamHeaders },
          signal: AbortSignal.timeout(3800)
        });
        if (!check.ok) {
          check.body?.cancel?.().catch(() => {});
          continue;
        }
        const headText = await check.text();
        if (!headText.trimStart().startsWith('#EXTM3U')) continue;
        const resMatches = [...headText.matchAll(/RESOLUTION=(\d+)x(\d+)/gi)];
        const maxH = resMatches.reduce((mx, m) => Math.max(mx, Number(m[2]) || 0, Number(m[1]) >= 3200 ? 2160 : Number(m[1]) >= 1800 ? 1080 : Number(m[1]) >= 1200 ? 720 : 0), 0);
        const score = maxH >= 2000 ? 145 : maxH >= 1000 ? 135 : maxH >= 700 ? 105 : 85;
        return {
          url: streamUrl,
          kind: 'hls',
          codec: 'h264',
          score,
          headers: streamHeaders,
          tracks: mapSourceTracks(resObj?.tracks || [], proxyProvider, referer),
          qualityStreams: []
        };
      }
    } catch {}
  }
  throw Error(`${siteHost} had no live stream`);
}

let hexaCapState = { token: '', usesLeft: 0, expiresAt: 0, inflight: null };

async function getHexaCapToken() {
  if (hexaCapState.token && hexaCapState.usesLeft > 0 && Date.now() < hexaCapState.expiresAt) {
    hexaCapState.usesLeft--;
    return hexaCapState.token;
  }
  if (hexaCapState.inflight) return hexaCapState.inflight;
  hexaCapState.inflight = (async () => {
    try {
      const chHeaders = { Origin: 'https://hexa.su', Referer: 'https://hexa.su/', 'User-Agent': UA };
      const challenge = await fetchJsonSafe('https://cap.hexa.su/15d2cf0395/challenge', {
        method: 'POST',
        headers: chHeaders,
        timeout: 4500
      });
      const solved = await fetchJsonSafe('https://enc-dec.app/api/enc-hexa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ challenge_data: challenge }),
        timeout: 4800
      });
      if (!solved?.result) throw Error('Hexa PoW solve failed');
      const redeemed = await fetchJsonSafe('https://cap.hexa.su/15d2cf0395/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...chHeaders },
        body: JSON.stringify(solved.result),
        timeout: 4500
      });
      if (!redeemed?.token) throw Error('Hexa token redeem failed');
      hexaCapState = {
        token: redeemed.token,
        usesLeft: 16,
        expiresAt: Date.now() + 8 * 60_000,
        inflight: null
      };
      return redeemed.token;
    } finally {
      hexaCapState.inflight = null;
    }
  })();
  return hexaCapState.inflight;
}

async function resolveHexaStream(input, proxyProvider) {
  const capToken = await getHexaCapToken();
  const key = crypto.randomBytes(32).toString('hex');
  const apiUrl = input.type === 'tv'
    ? `https://theemoviedb.hexa.su/api/tmdb/tv/${input.id}/season/${input.season}/episode/${input.episode}/images`
    : `https://theemoviedb.hexa.su/api/tmdb/movie/${input.id}/images`;

  const encrypted = await fetch(apiUrl, {
    headers: {
      'User-Agent': UA,
      Referer: 'https://hexa.su/',
      Accept: 'text/plain',
      'X-Fingerprint-Lite': 'e9136c41504646444',
      'X-Cap-Token': capToken,
      'X-Api-Key': key
    },
    signal: AbortSignal.timeout(5000)
  }).then(r => {
    if (!r.ok) {
      if (r.status === 401 || r.status === 403) hexaCapState.usesLeft = 0;
      throw Error(`Hexa HTTP ${r.status}`);
    }
    return r.text();
  });

  const dec = await fetchJsonSafe('https://enc-dec.app/api/dec-hexa', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: encrypted, key }),
    timeout: 4500
  });
  const sources = Array.isArray(dec?.result?.sources) ? dec.result.sources.filter(s => s?.url && /^https:\/\//i.test(s.url)) : [];
  if (!sources.length) throw Error('Hexa returned no sources');

  const preferredOrder = ['alpha', 'charlie', 'bravo', 'delta', 'foxtrot'];
  sources.sort((a, b) => {
    const ia = preferredOrder.indexOf(String(a.server || '').toLowerCase());
    const ib = preferredOrder.indexOf(String(b.server || '').toLowerCase());
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
  });

  const streamHeaders = { Referer: 'https://hexa.su/', Origin: 'https://hexa.su' };
  const verified = await Promise.all(sources.slice(0, 3).map(async s => {
    try {
      const r = await fetch(s.url, {
        headers: { 'User-Agent': UA, ...streamHeaders },
        signal: AbortSignal.timeout(3800)
      });
      if (!r.ok) return null;
      const txt = await r.text();
      if (!txt.trimStart().startsWith('#EXTM3U')) return null;
      const resMatches = [...txt.matchAll(/RESOLUTION=(\d+)x(\d+)/gi)];
      const maxH = resMatches.reduce((mx, m) => Math.max(mx, Number(m[2]) || 0, Number(m[1]) >= 1800 ? 1080 : Number(m[1]) >= 1200 ? 720 : 0), 0);
      const score = maxH >= 1000 ? 122 : maxH >= 700 ? 96 : resMatches.length ? 65 : 50;
      return { url: s.url, score };
    } catch { return null; }
  }));

  const best = verified.filter(Boolean).sort((a, b) => b.score - a.score)[0];
  if (!best) throw Error('Hexa playlists unreachable');

  return {
    url: best.url,
    kind: 'hls',
    codec: 'h264',
    score: best.score,
    headers: streamHeaders,
    tracks: [],
    qualityStreams: []
  };
}

function scoreVidoraCandidate(cand) {
  if (!cand?.url) return 0;
  const u = cand.url.toLowerCase();
  if (Array.isArray(cand.qualities) && cand.qualities.length >= 2) return 112;
  // Multi-bitrate VidSpark primary (.urlset/master.m3u8 on paretocdn / workerscloud) is genuine 1080p + 720p H.264!
  if (cand.sourceKey === 'vidspark' || u.includes('.urlset/master.m3u8') || u.includes('paretocdn.') || u.includes('workerscloud')) return 110;
  if (u.includes('hd4u.') || cand.sourceKey === 'w7dn' || cand.sourceKey === 'fq1k') return 100;
  if (u.includes('majorplay.') || cand.sourceKey === 'nzv4') return 85;
  if (u.includes('followguchimany.workers.dev')) return 30;
  if (/\/(?:480|360|240)\//.test(u)) return 20;
  if (u.includes('hscow.') || cand.sourceKey === 'vjej') return 60;
  return 55;
}

async function fetchVidsparkPrimary(input) {
  const path = mediaPathFor(input);
  let d = null;
  try {
    d = await fetchJsonSafe(`https://vidspark.to/api/vidora/v1/${path}`, {
      headers: { 'x-player-key': vidsparkPrimaryKey, Referer: `https://vidspark.to/${path}` },
      timeout: 4500
    });
  } catch (err) {
    if (err?.status === 401 || err?.status === 403) {
      const fresh = await refreshVidoraKey('primary');
      d = await fetchJsonSafe(`https://vidspark.to/api/vidora/v1/${path}`, {
        headers: { 'x-player-key': fresh, Referer: `https://vidspark.to/${path}` },
        timeout: 4500
      });
    } else {
      throw err;
    }
  }
  const validSources = (d?.sources || []).filter(s => s?.url && /^https:\/\//i.test(s.url));
  if (!validSources.length) throw Error('VidSpark primary unavailable');
  const primary = {
    sourceKey: 'vidspark',
    imdbId: d?.imdb_id || '',
    url: validSources[0].url,
    kind: /\.mp4(?:\?|$)/i.test(validSources[0].url) && !/\.m3u8|proxy/i.test(validSources[0].url) ? 'mp4' : 'hls',
    headers: { Referer: 'https://vidspark.to/', Origin: 'https://vidspark.to' },
    tracks: Array.isArray(validSources[0].tracks) ? validSources[0].tracks : [],
    qualities: Array.isArray(validSources[0].qualities) ? validSources[0].qualities : [],
    sources: validSources
  };
  primary.score = scoreVidoraCandidate(primary);
  return primary;
}

async function queryVidoraSource(host, path, sourceKey, refererBase, timeout = 4400) {
  const endpoint = `${host}/api/vidora/v1/${path}?source=${encodeURIComponent(sourceKey)}`;
  let data = null;
  try {
    data = await fetchJsonSafe(endpoint, {
      headers: { 'x-player-key': vidoraCdnKey, Referer: `${refererBase}/${path}` },
      timeout
    });
  } catch (err) {
    if (err?.status === 401 || err?.status === 403) {
      const fresh = await refreshVidoraKey('cdn');
      data = await fetchJsonSafe(endpoint, {
        headers: { 'x-player-key': fresh, Referer: `${refererBase}/${path}` },
        timeout
      });
    } else {
      throw err;
    }
  }
  const srcObj = data?.sources?.find(s => s?.url && /^https:\/\//i.test(s.url));
  if (!srcObj) throw Error(`${sourceKey} unavailable`);
  const streamHeaders = { Referer: `${refererBase}/`, Origin: refererBase };
  const cand = {
    sourceKey,
    imdbId: data.imdb_id || '',
    url: srcObj.url,
    kind: /\.mp4(?:\?|$)/i.test(srcObj.url) && !/\.m3u8|proxy/i.test(srcObj.url) ? 'mp4' : 'hls',
    headers: streamHeaders,
    tracks: Array.isArray(srcObj.tracks) ? srcObj.tracks : [],
    qualities: Array.isArray(srcObj.qualities) ? srcObj.qualities : []
  };
  cand.score = scoreVidoraCandidate(cand);
  return cand;
}

// ============================================================================
// 1. VidCore (DEFAULT) — 4K / 1080p / 720p / 480p H.264 Multi-Quality
// ============================================================================
async function resolveVidcore(input, meta = {}) {
  const origLang = String(meta?.originalLanguage || '').toLowerCase();
  const subsPromise = fetchVidsparkSubtitles(input).catch(() => []);

  // Race genuine 4K/1080p/720p vidcore.io and 1080p/720p VidSpark primary concurrently
  const [vcDirect, vsPrimary] = await Promise.all([
    resolveEncDecSite(input, 'https://vidcore.io', 'enc-vidcore', 'dec-vidcore', 'vidcore').catch(() => null),
    fetchVidsparkPrimary(input).catch(() => null)
  ]);

  let chosen = [vcDirect, vsPrimary].filter(Boolean).sort((a, b) => (b.score || 0) - (a.score || 0))[0] || null;
  if (!chosen) {
    chosen = await resolveHexaStream(input, 'vidcore').catch(() => null);
  }
  if (!chosen) {
    const path = mediaPathFor(input);
    const fallbacks = await Promise.all([
      queryVidoraSource('https://cdn.vidspark.to', path, 'w7dn', 'https://cdn.vidspark.to', 4000).catch(() => null),
      queryVidoraSource('https://cdn.vidspark.to', path, 'fq1k', 'https://cdn.vidspark.to', 4000).catch(() => null),
      queryVidoraSource('https://cdn.vidspark.to', path, 'vjej', 'https://cdn.vidspark.to', 4000).catch(() => null)
    ]);
    chosen = fallbacks.filter(Boolean).sort((a, b) => (b.score || 0) - (a.score || 0))[0] || null;
  }

  if (!chosen) throw Error('VidCore has no playable stream for this title right now.');

  const audioStreams = [];
  if (vsPrimary?.sources?.length > 1) {
    for (const [idx, s] of vsPrimary.sources.entries()) {
      audioStreams.push({
        language: s.lang || s.language || (idx === 0 ? (origLang || 'und') : `und-${idx}`),
        label: s.label || s.name || (idx === 0 ? `${readableLanguage(origLang || 'en')} (Original)` : `Audio ${idx + 1}`),
        url: s.url,
        proxyProvider: 'vidcore',
        headers: { Referer: 'https://vidspark.to/', Origin: 'https://vidspark.to' }
      });
    }
  }

  const vsSubs = await subsPromise;
  const inlineTracks = [
    ...(Array.isArray(chosen.tracks) && chosen.tracks[0]?.proxyProvider ? chosen.tracks : mapSourceTracks(chosen.tracks || [], 'vidcore', chosen.headers?.Referer || 'https://vidcore.io/')),
    ...(vsPrimary && vsPrimary !== chosen ? mapSourceTracks(vsPrimary.tracks || [], 'vidcore', 'https://vidspark.to/') : [])
  ];
  let tracks = sortAndDedupeTracks([...inlineTracks, ...vsSubs]);
  if (!tracks.length) {
    const imdbId = vsPrimary?.imdbId || chosen?.imdbId || meta?.imdbId || '';
    tracks = await fetchOpenSubtitles(input, imdbId).catch(() => []);
  }

  return {
    url: chosen.url,
    kind: chosen.kind || 'hls',
    codec: chosen.codec || 'h264',
    headers: chosen.headers || {},
    tracks,
    audioStreams,
    qualityStreams: mapSourceQualities(chosen.qualities || [], 'vidcore', chosen.headers || {}),
    provider: 'VidCore',
    sourceKey: 'vidcore',
    proxyProvider: 'vidcore',
    server: 'VidCore'
  };
}

// ============================================================================
// 2. VidLink — 1080p / 720p / 480p Multi-Quality + Universal H.264 Support
// ============================================================================
const vidlinkEncCache = new Map();
let sharedPlaywrightBrowser = null;

async function getVidlinkEncryptedId(tmdbId) {
  const key = String(tmdbId);
  const hit = vidlinkEncCache.get(key);
  if (hit && Date.now() - hit.time < 6 * 3600_000) return hit.token;
  const d = await fetchJsonSafe(`https://enc-dec.app/api/enc-vidlink?text=${encodeURIComponent(key)}`, { timeout: 5000 });
  const token = typeof d?.result === 'string' && d.result.length > 8 ? d.result : null;
  if (token) {
    vidlinkEncCache.set(key, { token, time: Date.now() });
    if (vidlinkEncCache.size > 500) vidlinkEncCache.delete(vidlinkEncCache.keys().next().value);
  }
  return token;
}

async function fetchVidlinkViaPlaywright({ type, id, season, episode }) {
  const { chromium } = await import('playwright');
  if (!sharedPlaywrightBrowser || !sharedPlaywrightBrowser.isConnected()) {
    sharedPlaywrightBrowser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  }
  const pageUrl = type === 'tv' ? `https://vidlink.pro/tv/${id}/${season}/${episode}` : `https://vidlink.pro/movie/${id}`;
  const context = await sharedPlaywrightBrowser.newContext({
    userAgent: UA,
    extraHTTPHeaders: { 'X-Playback-Environment': 'hls' }
  });
  const page = await context.newPage();
  try {
    await page.route('**/*', route => {
      const u = route.request().url();
      const rt = route.request().resourceType();
      if (['image', 'font', 'media', 'stylesheet'].includes(rt) || /yandex|clarity|google|analytics|doubleclick|mercury|venus|rapidad|intellipopup/i.test(u)) {
        return route.abort();
      }
      return route.continue();
    });
    const apiPromise = page.waitForResponse(r => r.url().includes('/api/b/') && r.status() === 200, { timeout: 14_000 });
    await page.goto(pageUrl, { waitUntil: 'domcontentloaded', timeout: 14_000 });
    const res = await apiPromise;
    return await res.json();
  } finally {
    await context.close().catch(() => {});
  }
}

function tierNumberFromKey(rawKey, valueObj = {}) {
  const k = String(rawKey || '').toLowerCase();
  if (k.includes('4k') || k.includes('2160') || k.includes('uhd')) return 2160;
  if (k.includes('2k') || k.includes('1440') || k.includes('qhd')) return 1440;
  const digits = Number(k.replace(/\D/g, '')) || Number(valueObj?.height) || 0;
  if (digits >= 2000) return 2160;
  if (digits >= 1350) return 1440;
  if (digits >= 1000) return 1080;
  if (digits >= 680) return 720;
  if (digits >= 440) return 480;
  if (digits >= 320) return 360;
  return digits > 0 ? 240 : 0;
}

function parseVidlinkStreamPayload(payload) {
  const stream = payload?.stream;
  if (!stream) return null;

  const captions = (Array.isArray(stream.captions) ? stream.captions : [])
    .filter(c => c?.url && /^https:\/\//i.test(c.url))
    .map(c => ({
      src: c.url,
      language: c.language || c.srclang || 'und',
      label: c.language || c.label || '',
      proxyProvider: 'vidlink',
      headers: {}
    }));

  const audioStreams = [];
  const rawDubs = payload?.dubs || stream?.dubs || stream?.audioTracks || payload?.audioTracks;
  if (Array.isArray(rawDubs)) {
    for (const dub of rawDubs) {
      const dubUrl = dub?.playlist || dub?.url || dub?.file;
      if (!dubUrl || !/^https:\/\//i.test(dubUrl)) continue;
      audioStreams.push({
        language: dub.language || dub.lang || 'und',
        label: readableLanguage(dub.language || dub.lang, dub.label || dub.name),
        url: dubUrl,
        proxyProvider: 'vidlink',
        headers: dub.headers || stream.playlistHeaders || {}
      });
    }
  }

  if (typeof stream.playlist === 'string' && /^https:\/\//i.test(stream.playlist) && (stream.type === 'hls' || /\.m3u8/i.test(stream.playlist))) {
    const playlistHeaders = stream.playlistHeaders && typeof stream.playlistHeaders === 'object'
      ? stream.playlistHeaders
      : { Referer: 'https://vidlink.pro/', Origin: 'https://vidlink.pro' };
    return {
      url: stream.playlist,
      kind: 'hls',
      codec: 'h264',
      headers: playlistHeaders,
      captions,
      audioStreams,
      qualityStreams: []
    };
  }

  if (typeof stream.playlist === 'string' && /^https:\/\//i.test(stream.playlist) && (stream.type === 'dash' || /\.mpd(?:\?|$)/i.test(stream.playlist))) {
    const u = new URL(stream.playlist);
    const cookie = stream.playlistHeaders?.Cookie || stream.playlistHeaders?.cookie || '';
    let dashTarget = stream.playlist;
    if (/\.hakunaymatata\.com$/i.test(u.hostname)) {
      const sub = u.hostname.split('.')[0];
      const sc = cookie ? Buffer.from(cookie, 'utf8').toString('base64').replace(/\+/g, '-').replace(/\//g, '_') : '';
      dashTarget = `https://surge.flooderrr.store/${sub}${u.pathname}?host=${encodeURIComponent(u.origin)}${sc ? `&sc=${sc}` : ''}`;
    }
    const isHevc = /hevc|h265|x265|hev1|hvc1/i.test(String(stream.playbackMetadata?.codecName || stream.playlist));
    return {
      url: dashTarget,
      kind: 'dash',
      codec: isHevc ? 'hevc' : 'h264',
      headers: { Referer: 'https://vidlink.pro/', Origin: 'https://vidlink.pro' },
      captions,
      audioStreams,
      qualityStreams: []
    };
  }

  const qualitiesObj = stream.qualities && typeof stream.qualities === 'object' ? stream.qualities : {};
  const qualityStreams = [];
  for (const [key, val] of Object.entries(qualitiesObj)) {
    const qUrl = typeof val === 'string' ? val : val?.url;
    if (!qUrl || !/^https:\/\//i.test(qUrl) || /\.hakunaymatata\.com$/i.test(new URL(qUrl).hostname)) continue;
    const tier = tierNumberFromKey(key, val);
    if (!tier) continue;
    const isHevc = /hevc|h265|x265|hev1|hvc1/i.test(String(val?.codecName || val?.codec || qUrl));
    qualityStreams.push({
      tier,
      height: tier,
      url: qUrl,
      kind: 'mp4',
      codec: isHevc ? 'hevc' : 'h264',
      proxyProvider: 'vidlink',
      headers: { Referer: 'https://vidlink.pro/' }
    });
  }
  if (!qualityStreams.length) return null;

  qualityStreams.sort((a, b) => (b.tier - a.tier) || ((a.codec === 'h264' ? 0 : 1) - (b.codec === 'h264' ? 0 : 1)));
  const bestH264 = qualityStreams.find(q => q.codec === 'h264');
  const defaultPick = bestH264 || qualityStreams[0];

  return {
    url: defaultPick.url,
    kind: 'mp4',
    codec: defaultPick.codec,
    headers: { Referer: 'https://vidlink.pro/' },
    captions,
    audioStreams,
    qualityStreams
  };
}

async function resolveVidlink(input, meta = {}) {
  let parsed = null;
  const enc = await getVidlinkEncryptedId(input.id).catch(() => null);
  const pageRef = input.type === 'tv'
    ? `https://vidlink.pro/tv/${input.id}/${input.season}/${input.episode}`
    : `https://vidlink.pro/movie/${input.id}`;

  if (enc) {
    const baseApi = input.type === 'tv'
      ? `https://vidlink.pro/api/b/tv/${enc}/${input.season}/${input.episode}`
      : `https://vidlink.pro/api/b/movie/${enc}`;
    const [webkitData, hlsData] = await Promise.all([
      fetchJsonSafe(`${baseApi}?multiLang=0`, {
        headers: { Referer: pageRef, Origin: 'https://vidlink.pro', 'X-Playback-Environment': 'webkit' },
        timeout: 7000
      }).catch(() => null),
      fetchJsonSafe(`${baseApi}?multiLang=1`, {
        headers: { Referer: pageRef, Origin: 'https://vidlink.pro', 'X-Playback-Environment': 'hls' },
        timeout: 7000
      }).catch(() => null)
    ]);

    const pWebkit = parseVidlinkStreamPayload(webkitData);
    const pHls = parseVidlinkStreamPayload(hlsData);

    if (pHls?.kind === 'hls') {
      parsed = { ...pHls, captions: [...pHls.captions, ...(pWebkit?.captions || [])] };
    } else if (pWebkit) {
      parsed = { ...pWebkit, captions: [...pWebkit.captions, ...(pHls?.captions || [])] };
    } else {
      parsed = pHls;
    }
  } else {
    const pwData = await fetchVidlinkViaPlaywright(input).catch(() => null);
    parsed = parseVidlinkStreamPayload(pwData);
  }

  // Ensure universal H.264 1080p compatibility when VidLink payload is HEVC-only or unavailable
  if (!parsed || parsed.codec === 'hevc') {
    const hexaH264 = await resolveHexaStream(input, 'vidlink').catch(() => null);
    if (!parsed && hexaH264) {
      parsed = {
        url: hexaH264.url,
        kind: 'hls',
        codec: 'h264',
        headers: hexaH264.headers,
        captions: [],
        audioStreams: [],
        qualityStreams: []
      };
    } else if (parsed && hexaH264) {
      parsed.qualityStreams = [
        ...(parsed.qualityStreams || []),
        { tier: 1080, height: 1080, url: hexaH264.url, kind: 'hls', codec: 'h264', proxyProvider: 'vidlink', headers: hexaH264.headers }
      ];
    }
  }

  if (!parsed) throw Error('VidLink has no playable stream for this title right now.');

  let tracks = sortAndDedupeTracks(parsed.captions || []);
  if (!tracks.length) {
    tracks = await fetchVidsparkSubtitles(input).catch(() => []);
    if (!tracks.length && meta?.imdbId) {
      tracks = await fetchOpenSubtitles(input, meta.imdbId).catch(() => []);
    }
  }

  return {
    url: parsed.url,
    kind: parsed.kind,
    codec: parsed.codec || 'h264',
    headers: parsed.headers,
    tracks,
    audioStreams: parsed.audioStreams || [],
    qualityStreams: parsed.qualityStreams || [],
    provider: 'VidLink',
    sourceKey: 'vidlink',
    proxyProvider: 'vidlink',
    server: 'VidLink'
  };
}

// ============================================================================
// 3. VidSrc — 1080p / 720p Multi-Quality H.264 (Hexa + VidUp 4K/1080p + Vidora)
// ============================================================================
async function resolveVidsrc(input, meta = {}) {
  const subsPromise = fetchVidsparkSubtitles(input).catch(() => []);

  const [hexaRes, vidupRes] = await Promise.all([
    resolveHexaStream(input, 'vidsrc').catch(() => null),
    resolveEncDecSite(input, 'https://vidup.to', 'enc-vidup', 'dec-vidup', 'vidsrc').catch(() => null)
  ]);

  let chosen = [vidupRes, hexaRes].filter(Boolean).sort((a, b) => (b.score || 0) - (a.score || 0))[0] || null;
  if (!chosen) {
    const path = mediaPathFor(input);
    const fallbacks = await Promise.all([
      fetchVidsparkPrimary(input).catch(() => null),
      queryVidoraSource('https://vidsrc.pm', path, 'w7dn', 'https://vidsrc.pm', 4000).catch(() => null),
      queryVidoraSource('https://vidsrc.pm', path, 'fq1k', 'https://vidsrc.pm', 4000).catch(() => null),
      queryVidoraSource('https://vidsrc.pm', path, 'vjej', 'https://vidsrc.pm', 4000).catch(() => null)
    ]);
    chosen = fallbacks.filter(Boolean).sort((a, b) => (b.score || 0) - (a.score || 0))[0] || null;
  }

  if (!chosen) throw Error('VidSrc has no playable stream for this title right now.');

  const vsSubs = await subsPromise;
  const inlineTracks = [
    ...(Array.isArray(chosen.tracks) && chosen.tracks[0]?.proxyProvider ? chosen.tracks : mapSourceTracks(chosen.tracks || [], 'vidsrc', chosen.headers?.Referer || 'https://vidup.to/')),
    ...(vidupRes && vidupRes !== chosen ? vidupRes.tracks || [] : [])
  ];
  let tracks = sortAndDedupeTracks([...inlineTracks, ...vsSubs]);
  if (!tracks.length && meta?.imdbId) {
    tracks = await fetchOpenSubtitles(input, meta.imdbId).catch(() => []);
  }

  return {
    url: chosen.url,
    kind: chosen.kind || 'hls',
    codec: chosen.codec || 'h264',
    headers: chosen.headers || {},
    tracks,
    audioStreams: [],
    qualityStreams: mapSourceQualities(chosen.qualities || [], 'vidsrc', chosen.headers || {}),
    provider: 'VidSrc',
    sourceKey: 'vidsrc',
    proxyProvider: 'vidsrc',
    server: 'VidSrc'
  };
}

// ============================================================================
// UNIFIED OTT ROUTER + STRICT 3-SERVER FAILOVER
// ============================================================================
const RESOLVER_BY_KEY = {
  vidcore: resolveVidcore,
  vidlink: resolveVidlink,
  vidsrc: resolveVidsrc
};

const resolvedCache = new Map();

export async function resolveOttWithFallback(input, requestedProvider = DEFAULT_OTT_SERVER, getTmdbMeta = null) {
  const startKey = OTT_SERVER_KEYS.has(requestedProvider) ? requestedProvider : DEFAULT_OTT_SERVER;
  const order = [startKey, ...['vidcore', 'vidlink', 'vidsrc'].filter(k => k !== startKey)];

  const meta = getTmdbMeta ? await getTmdbMeta(input).catch(() => ({})) : {};
  let lastError = null;

  for (const key of order) {
    const cacheKey = `${key}:${input.type}:${input.id}:${input.type === 'tv' ? `${input.season}:${input.episode}` : 'm'}`;
    const hit = resolvedCache.get(cacheKey);
    if (hit && Date.now() - hit.time < 180_000) return hit.value;

    try {
      const value = await RESOLVER_BY_KEY[key](input, meta);
      resolvedCache.set(cacheKey, { value, time: Date.now() });
      if (resolvedCache.size > 250) resolvedCache.delete(resolvedCache.keys().next().value);
      return value;
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || Error('No playable stream found across VidCore, VidLink, or VidSrc.');
}
