import { chromium } from 'playwright';
const BASE='http://127.0.0.1:8777';
const browser=await chromium.launch({headless:true,args:['--no-sandbox','--autoplay-policy=no-user-gesture-required']});
const ctx=await browser.newContext({viewport:{width:390,height:844}});
await ctx.addInitScript(()=>{window.__dl=[];window.__calls=[];
 window.kozutvDownloads={list:()=>JSON.stringify([]),start:s=>{window.__calls.push(s);window.__dl.push(1);return JSON.stringify({ok:true})},remove:()=>'{"ok":true}',clear:()=>'{"ok":true}',usedBytes:()=>0};});
const page=await ctx.newPage();
page.on('console',m=>console.log('CONSOLE',m.type(),m.text().slice(0,200)));
page.on('pageerror',e=>console.log('PAGEERROR',String(e).slice(0,300)));
await page.goto(BASE+'/watch/anime/57334?episode=1&lang=sub',{waitUntil:'domcontentloaded'});
await page.waitForTimeout(6000);
const r=await page.evaluate(async()=>{
 const out={};
 out.hasFn=typeof startDownload;
 try{out.detail=Boolean(detail&&detail.item)}
 catch(e){out.detailErr=String(e)}
 out.btn=Boolean(document.querySelector('.mp-download-button'));
 const b=document.querySelector('.mp-download-button');
 // click and capture the toast + any synchronous throw
 try{if(b)b.click()}catch(e){out.clickErr=String(e)}
 await new Promise(x=>setTimeout(x,2500));
 out.toast=(document.querySelector('#kozutv-toast')?.textContent||'');
 out.calls=window.__calls.length;
 out.cls=b?b.className:'(gone)';
 return out;
});
console.log(JSON.stringify(r,null,1));
await browser.close();
