// Offline support for the installed app (and any browser that allows workers).
//
// Two jobs:
//   1. register the service worker that caches the shell + last API answers
//   2. seed the /api/* cache from the build-time snapshot, so a fresh install
//      has a browsable catalogue before it has ever talked to the server.
//
// This file is inert in a normal browser tab until the worker takes control; it
// never delays first paint.
(function () {
  if (!('serviceWorker' in navigator)) return;
  var started = false;

  function seed(worker) {
    // Only needed once: the bundled snapshot fills gaps the network left.
    fetch('/offline-manifest.json', { cache: 'no-cache' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (manifest) {
        if (!manifest || !Array.isArray(manifest.seed)) return;
        worker.postMessage({ type: 'warm', urls: manifest.seed });
      })
      .catch(function () {});
  }

  function register() {
    if (started) return;
    started = true;
    navigator.serviceWorker.register('/sw.js', { scope: '/' }).then(function (reg) {
      var worker = reg.active || reg.installing || reg.waiting;
      if (worker) seed(worker);
      navigator.serviceWorker.ready.then(function (ready) { seed(ready.active); });
    }).catch(function () {});
  }

  // Register after the first paint so it can never slow the app down.
  if (document.readyState === 'complete') requestAnimationFrame(register);
  else window.addEventListener('load', function () { requestAnimationFrame(register); }, { once: true });

  // Expose a tiny status helper for Settings ("Works offline: yes/no").
  window.kozutvOfflineState = function () {
    return { supported: 'serviceWorker' in navigator, controlled: Boolean(navigator.serviceWorker.controller) };
  };
})();
