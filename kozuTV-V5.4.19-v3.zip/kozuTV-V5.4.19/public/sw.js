// kozuTV offline shell.
//
// The site is a client-rendered app: index.html + app.js draw every page, and
// the catalogue arrives from /api/*. That means the whole app can work with no
// network at all, as long as those two things are on the device. This worker
// does exactly that:
//
//   static files (html/js/css/fonts/images) -> cache first, refresh in background
//   /api/*                                   -> network first, fall back to the
//                                               last good answer (and to the
//                                               bundled snapshot on first run)
//
// The bundled snapshot is what /offline-manifest.json lists, so a fresh install
// has a browsable catalogue before it has ever reached the server.
//
// Streming video still needs a connection - that cannot be bundled.

const VERSION = 'kozutv-v2';
const SHELL = `${VERSION}-shell`;
const API = `${VERSION}-api`;
const IMAGES = `${VERSION}-images`;
const META = `${VERSION}-meta`;

// Endpoints whose last answer is worth keeping so the app opens offline.
// Static assets are added to the shell cache as they are first fetched.
const PRELOAD_SHELL = [
  '/', '/index.html', '/app.js', '/style.css', '/icons.js',
  '/megaplay-controls.js', '/megaplay-controls.css',
  '/site.webmanifest', '/vendor/video-js.min.css', '/vendor/video.min.js',
  '/fonts/archivo-latin.woff2', '/fonts/manrope-latin.woff2',
  '/images/favicon-192.png'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL);
    // One failure must not abort the install: a missing font is not fatal.
    await Promise.all(PRELOAD_SHELL.map(url => cache.add(url).catch(() => {})));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(n => !n.startsWith(VERSION)).map(n => caches.delete(n)));
    await self.clients.claim();
  })());
});

function isApi(url) {
  return url.pathname.startsWith('/api/');
}

function isImage(url, request) {
  return request.destination === 'image' || /\.(png|jpe?g|webp|gif|svg|ico)$/i.test(url.pathname);
}

async function networkFirstApi(request, url) {
  const cache = await caches.open(API);
  const key = url.pathname.replace(/^\/api\//, '') + (url.search || '');
  try {
    const response = await fetch(request);
    if (response && response.ok) {
      // Store the body under the endpoint key so it can be replayed later.
      cache.put(new Request(`/__api/${key}`), response.clone()).catch(() => {});
    }
    return response;
  } catch (error) {
    const cached = await cache.match(new Request(`/__api/${key}`));
    if (cached) {
      const body = await cached.blob();
      return new Response(body, {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'X-Kozutv-Offline': '1' }
      });
    }
    return new Response(JSON.stringify({ offline: true, error: 'You are offline.' }), {
      status: 503,
      headers: { 'Content-Type': 'application/json', 'X-Kozutv-Offline': '1' }
    });
  }
}

async function cacheFirstStatic(request) {
  const cache = await caches.open(SHELL);
  const cached = await cache.match(request, { ignoreSearch: true });
  if (cached) {
    // Refresh quietly so the next launch has the newest build.
    fetch(request).then(response => {
      if (response && response.ok) cache.put(request, response.clone());
    }).catch(() => {});
    return cached;
  }
  try {
    const response = await fetch(request);
    if (response && response.ok) cache.put(request, response.clone()).catch(() => {});
    return response;
  } catch (error) {
    // Navigation with no document cached: show the shell we do have.
    if (request.mode === 'navigate') {
      const shell = await cache.match('/index.html');
      if (shell) return shell;
    }
    throw error;
  }
}

async function cacheFirstImage(request) {
  const cache = await caches.open(IMAGES);
  const cached = await cache.match(request, { ignoreSearch: true });
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response && (response.ok || response.type === 'opaque')) {
      cache.put(request, response.clone()).catch(() => {});
    }
    return response;
  } catch (error) {
    // Inline placeholder so a missing poster never breaks layout.
    return new Response(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600"><rect width="400" height="600" fill="#0a0b0e"/></svg>',
      { headers: { 'Content-Type': 'image/svg+xml' } });
  }
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  // Only kozutv.bond traffic is ours; never touch other origins (image CDNs,
  // stream hosts, image CDNs are left to the browser).
  const sameOrigin = url.origin === self.location.origin;
  if (!sameOrigin) return;

  if (isApi(url)) {
    event.respondWith(networkFirstApi(request, url));
    return;
  }
  if (isImage(url, request)) {
    event.respondWith(cacheFirstImage(request));
    return;
  }
  event.respondWith(cacheFirstStatic(request));
});

// Let the app ask for a pre-warm of the API cache while online.
self.addEventListener('message', event => {
  const data = event.data || {};
  if (data.type === 'warm' && Array.isArray(data.urls)) {
    event.waitUntil((async () => {
      const cache = await caches.open(API);
      await Promise.all(data.urls.map(async path => {
        try {
          const response = await fetch(path, { credentials: 'same-origin' });
          if (!response.ok) return;
          const key = path.replace(/^\/api\//, '');
          await cache.put(new Request(`/__api/${key}`), response.clone());
        } catch (error) {
          /* offline right now - the existing entry stays */
        }
      }));
    })());
  }
});
