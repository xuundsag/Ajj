import { chromium } from 'playwright';

// CineSrc currently requires its browser challenge before it reveals an HLS
// playlist. One shared browser is used only during resolution; provider code is
// never shipped to or executed in the viewer's MoscowTV page.
let browserPromise=null,queue=Promise.resolve();
const cache=new Map(),CACHE_MS=60_000;
async function browser(){
 if(!browserPromise){
  browserPromise=chromium.launch({headless:true,args:['--no-sandbox','--autoplay-policy=no-user-gesture-required']});
  browserPromise.then(b=>b.on('disconnected',()=>{browserPromise=null})).catch(()=>{browserPromise=null});
 }
 return browserPromise;
}
function embedPath({type,id,season,episode},server){
 let path=type==='tv'?`/embed/tv/${id}?s=${season}&e=${episode}`:`/embed/movie/${id}?`;
 return 'https://cinesrc.st'+path+(path.includes('?')?'&':'?')+new URLSearchParams({autoplay:'true',muted:'true',controls:'false',lastserver:server,prioritize:'true'});
}
async function resolveWithServer(input,server){
 let b=await browser(),page=await b.newPage({viewport:{width:960,height:540}}),candidates=[];
 page.on('response',response=>{
  if(!/\.m3u8(?:\?|$)/i.test(response.url()))return;
  response.text().then(text=>{if(text.startsWith('#EXTM3U'))candidates.push({url:response.url(),master:/#EXT-X-(?:STREAM-INF|MEDIA|SESSION)/.test(text)})}).catch(()=>{});
 });
 try{
  await page.goto(embedPath(input,server),{waitUntil:'domcontentloaded',timeout:45_000});
  // A resolved URL is not accepted until the provider itself has decoded and
  // played the media. This catches stale playlists and empty source responses.
  await page.waitForFunction(()=>[...document.querySelectorAll('video')].some(v=>v.readyState>=2&&v.currentTime>0),{timeout:35_000});
  await page.waitForTimeout(250);
  if(!candidates.length)throw Error('CineSrc did not expose an HLS playlist.');
  candidates.sort((a,b)=>Number(b.master)-Number(a.master));
  return {url:candidates[0].url,server};
 }finally{await page.close().catch(()=>{})}
}
export function resolveCineSrc(input,provider='default'){
 let key=[input.type,input.id,input.season,input.episode,provider].join(':'),cached=cache.get(key);
 if(cached&&Date.now()-cached.time<CACHE_MS)return Promise.resolve(cached.value);
 let run=queue.then(async()=>{
  let existing=cache.get(key);if(existing&&Date.now()-existing.time<CACHE_MS)return existing.value;
  let servers=provider==='second'?['wave','orbit','light']:['nebula','orbit'],lastError;
  for(let server of servers){
   try{let value=await resolveWithServer(input,server);cache.set(key,{value,time:Date.now()});return value}
   catch(error){lastError=error}
  }
  throw Error('CineSrc could not resolve a playable stream. '+(lastError?.message||''));
 });
 queue=run.catch(()=>{});return run;
}

const subtitleCache=new Map();
export async function cinesrcSubtitles(input){
 let key=[input.type,input.id,input.season,input.episode].join(':'),cached=subtitleCache.get(key);if(cached&&Date.now()-cached.time<6*60*60_000)return cached;
 let body=input.type==='tv'?{tmdbId:String(input.id),season:Number(input.season),episode:Number(input.episode),builtInSubtitles:[]}:{tmdbId:String(input.id),builtInSubtitles:[]};
 let response=await fetch('https://cinesrc.st/api/subtitles/search',{method:'POST',headers:{'Content-Type':'application/json',Referer:'https://cinesrc.st/',Accept:'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(15_000)});
 if(!response.ok)throw Error('CineSrc subtitle search failed ('+response.status+').');
 let data=await response.json(),best=new Map(),badRelease=/(?:^|[.\s_-])(?:cam|hdcam|ts|hdts|telesync|tc|dvdscr|screener|r5|r6)(?:[.\s_-]|$)/i;
 for(let track of data.subtitles||[]){
  if(track.format!=='srt'||!track.language||!track.display||!/^https:\/\//.test(track.url||'')||track.isCommentary||track.isSignsAndSongs)continue;
  let release=String(track.release||''),score=Number(track.matchScore)||0;
  score+=Number(track.community?.score||0)*10+(track.isHearingImpaired?0:3)+(/blu.?ray|web|hdtv|dvdrip/i.test(release)?8:0)-(badRelease.test(release)?35:0);
  let previous=best.get(track.language);if(!previous||score>previous.score)best.set(track.language,{src:track.url,label:String(track.display).slice(0,60),language:String(track.language).slice(0,12),kind:'subtitles',default:false,score});
 }
 let tracks=[...best.values()].sort((a,b)=>({en:0,hi:1}[a.language]??2)-({en:0,hi:1}[b.language]??2)||a.label.localeCompare(b.label)).slice(0,30).map(({score,...track})=>track);
 subtitleCache.set(key,tracks);return tracks;
}
