# MoscowTV V4.1

A responsive anime, movie and web-series catalog with an Anikoto-powered anime catalog, provider-resolved Video.js playback, real subtitle and audio controls, a simple Watchlist, Continue Watching, and a bold mobile/desktop Spotlight.

## Start

```sh
node start.js
```

The launcher installs production dependencies and the Playwright Chromium browser when needed, then starts on port `3000`. On a fresh Linux VPS, install the browser system libraries with `npx playwright install-deps chromium` if Chromium reports missing shared libraries. Edit `PORT` in `start.js` to change it. Node 20+ is recommended. Set `TMDB_API_KEY` for reliable TMDB access; otherwise the server tries publicly shared keys from `freekeys`, which can fail or be rate-limited.

## V4.1 Video.js playback and refinement

- Provider iframes are replaced by self-hosted **Video.js 8.23.4** with a MoscowTV-owned **MegaPlay/JW-style responsive control layer**. The page enforces `frame-src 'none'` and uses no provider player JavaScript in the viewer.
- Original inline JW SVG geometry is used for the polished controls, with an adapted matching **Forward 10** icon. The settings panel has five tabs: **CC, Speed, Quality, Audio, and Volume**. See the JW icon licensing restriction under **Attribution** before deployment.
- Played seek progress uses MoscowTV orange **`#ff731c`**; complementary intro/outro markers use **`#ffe3a6`**. Portrait controls retain central play, duration, volume, ±10 seconds, CC, settings, PiP, and fullscreen. Landscape fullscreen and desktop restore bottom play plus elapsed / duration time.
- **Quality** lists only renditions exposed by the current HLS master playlist, plus **Auto**. Manual selection locks the real rendition and Auto restores adaptive selection. Verification measured actual decoded video at **1920×1080** for 1080p and **1280×720** for 720p rather than merely checking highlighted menu rows.
- The separate **Audio** tab switches real HLS audio tracks when available. For anime it also switches Japanese Sub / English Dub sources. A single CineSrc audio track is shown honestly as **Original**. **Volume** is reserved for the optional Volume Boost, Off by default and up to +300% through Web Audio on supported non-Apple-touch browsers.
- Movies/web series keep **Stream 1** and **Stream 2**, both resolved from CineSrc. Anime keeps **Sub** and **Dub**, resolved independently from MegaPlay. CineSrc and MegaPlay subtitles remain in **CC**; Subtitle Settings provides real color, opacity, and size changes. Speed choices are 0.5x, 0.75x, 1x, 1.25x, 1.5x, and 2x.
- Fullscreen video uses centered **`object-fit: contain`**, preserving the entire source frame with letterboxing when the source and screen aspect ratios differ. Both a 1920×804 widescreen movie and a 1920×1080 web-series episode were measured in an 844×390 landscape viewport with no cropping.
- Video.js and the custom player assets load **only on watch pages**, while watch state and stream resolution initialize in parallel. Conservative initial ABR/buffer settings, no cross-title bandwidth estimate reuse, and Data Saver support reduce avoidable startup load. With Data Saver, preloading/autoplay remain off until the viewer presses Play.
- Loading indicators are circular animations rather than plain “Loading” text. The footer reveals with the main page content. On mobile, the current Spotlight slides use cleaned, text-free versions of their own vertical catalog posters at full height with a dark lower fade; desktop keeps the original landscape backdrops and layout unchanged.
- Saved playback resumes after the first playable frame instead of seeking at `loadedmetadata`; this avoids a Chromium/VHS segment-boundary stall seen when continuing one title through another server.
- HLS playlists, media segments, and subtitle files use signed same-origin proxy URLs. The proxy forwards required provider Referers and byte ranges; it does not guarantee that upstream streams will remain available.
- Next/Prev uses actual TMDB or Anikoto episode/season boundaries. A season finale advances only to a listed next-season episode 1, and Next is disabled at the final catalog episode.
- Five playback scenarios, decoded video/audio, advancing time, subtitles, real Audio/Quality controls, seeking, anime source separation, fullscreen aspect ratios, Data Saver, and six catalog boundaries were verified in Chromium. The supplied `MoscowTV-VideoJS-Proof.html` contains screenshots and metrics.

### Resolver and VPS requirements

CineSrc resolution uses one shared, serial Chromium worker with a 60-second result cache; MegaPlay currently resolves through its encrypted source response without a browser. Node 20+ is required. The first launch downloads Chromium, which needs additional disk space and memory beyond the static frontend.

**Raw-stream resolution is not a guarantee of ad-free playback or low server bandwidth.** Upstream HLS can change, expire, or contain advertising. In this build, required headers and CORS are handled by the same-origin media proxy, so proxied video bandwidth passes through the MoscowTV server. Hundreds of simultaneous viewers therefore require bandwidth and upstream-capacity planning even though the HTML frontend itself is small.

## V3.2 discovery and color refinements

- **Continue Watching** now appears above Trending on the home page whenever real watch history exists. It uses the same saved episode, season, progress, and resume links as the Watchlist history view.
- Home starts with three genre shelves. A compact **Show more** button below the shelves loads three more at a time and disappears after all genres are shown.
- The menu, home shelves, and Advanced Filters share **20 genre choices**: Action, Adventure, Animation, Comedy, Crime, Documentary, Drama, Family, Fantasy, Horror, Mecha, Music, Mystery, Psychological, Romance, Sci-Fi, Slice of Life, Sports, Supernatural, and Thriller.
- Accent colors use the Spotlight orange (`#ff731c`) consistently for primary buttons, badges, icons, active states, and progress. Secondary surfaces remain dark.
- The player’s “You are now watching” notice is reduced to 12px on desktop and 11px on mobile.

## V3.1 refinements

- Adds the supplied transparent **MoscowTV Crown Wordmark** in the header and footer, cropped and sized for desktop/mobile.
- Keeps the bold **Archivo/Atyp Display** heading stack and switches body copy to **Manrope/Atyp Text**.
- Mobile Spotlight artwork now covers the full Spotlight height and fades smoothly into the page instead of ending in the middle.
- Spotlight indicators sit directly below the actions with consistent spacing. Clicking anywhere on the Spotlight outside its action controls opens the details page.
- Details descriptions remain click-to-expand but no longer have a boxed background or border.
- The desktop Watchlist header icon is borderless like mobile. Expanded mobile Search stays aligned between the menu and Watchlist icons.

## Anikoto anime catalog

**Anikoto is now the primary anime catalog**, rather than only an availability check.

- `data/megaplay-catalog.json` contains Anikoto titles, English/alternate titles, posters, wide artwork, descriptions, genres, years, formats, ratings, status, MAL/AniList IDs, episode counts, and provider series IDs.
- Browse, Search, genre shelves, Random, Advanced Filters, and released anime details use this catalog directly.
- Only entries with a poster and at least one listed episode enter the normal anime catalog.
- AniList remains in use for real airing schedules, upcoming anime, and season-relationship metadata. TMDB remains the OTT catalog and can supply a matching wide backdrop.
- Cross-catalog duplicates and localized anime duplicates are removed. Unreleased titles remain separate from normal discovery.

To refresh the Anikoto snapshot, run the following command and restart the server. The importer respects the published 60-requests-per-120-seconds limit and takes a few minutes.

```sh
python3 scripts/update-megaplay-catalog.py
```

## Playback and episode data

- Anime details and episode lists use the selected Anikoto series.
- MegaPlay playback uses the exact `embed_url.sub` or `embed_url.dub` returned for the requested provider episode. Missing episodes/language tracks produce a short error rather than a fabricated player URL.
- Selective AniList season relationships remain available; unrelated successors are not merged.
- Anime movies do not show episode counts, episode lists, Previous/Next, or Auto Next.
- Upcoming detail pages have no Watch button, episode counts, episode lists, or episode controls.
- Movies/web series retain Stream 1 and Stream 2 selectors, both using CineSrc.

Provider entries can change. V4.1 verifies decoded Video.js playback rather than treating a provider URL or HTTP 200 response as proof of availability.

## Interface and saving

- Accounts, Profiles, login, registration, Comments, Community, Watchlist statuses, and account-backup notices are removed.
- Watchlist/history save automatically to the current browser through a persistent HttpOnly visitor cookie and `data/states.json`.
- The Watchlist icon sits beside Search on desktop and mobile.
- The Spotlight includes wide artwork, a Start Watching button, a circular Watchlist action, and segmented indicators.
- Bold inline SVG icons are used for headings and menu categories; there are no emoji icons or external icon scripts.
- Details descriptions expand/collapse when anywhere in the description text area is clicked. Enter/Space also works when focused.
- Two-row orange player controls, Light mode, report control, watching notice, actual-history Continue, search, Schedule, Upcoming, Random, and Advanced Filters remain.

## Typography and logo

Headings request **Atyp Display** and fall back to bundled **Archivo**. Body copy requests **Atyp Text** and falls back to bundled **Manrope**. Atyp is a commercial Suitcase Type Foundry family and is not bundled without a license. Archivo and Manrope licenses are included in `public/fonts/`. Video.js is self-hosted under `public/vendor/`; its license is retained in `VIDEOJS-LICENSE.txt`.

The crown wordmark is the user-supplied `MoscowTV Crown Wordmark.png`, preserved with transparency and stored as `public/images/moscowtv-crown-wordmark.png`.

## Attribution

The interface takes inspiration from Anipaca and the supplied Crunchyroll Spotlight screenshot. The responsive control-layer implementation follows the user's supplied MegaPlay control references; MegaPlay's player, advertising, and sandbox JavaScript are not bundled. Anipaca's GPL-3.0 license is retained in `ANIPACA-LICENSE.txt`. Lucide-style inline SVG notices are retained in `LUCIDE-LICENSE.txt`. Catalog data comes from Anikoto, AniList, and TMDB. Review content rights and provider terms before deployment.

**JW icon licensing / noncommercial restriction:** the inline control icons are adapted from the [JW Player SVG assets](https://github.com/jwplayer/jwplayer/tree/master/src/assets/SVG), including a Forward 10 adaptation built from that geometry. The upstream JW Player license is **Creative Commons Attribution-NonCommercial-ShareAlike 3.0**, retained in `JWPLAYER-LICENSE.txt`. Keep this attribution and the same license with the assets. **Do not use these JW-derived icons commercially.** Replace them with appropriately licensed icons before any commercial deployment.
