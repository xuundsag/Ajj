import crypto from 'node:crypto';
import { Readable } from 'node:stream';
import net from 'node:net';

const secret=crypto.createHash('sha256').update(process.env.MEDIA_PROXY_SECRET||crypto.randomBytes(32)).digest();
const providers={megaplay:{referer:'https://megaplay.buzz/'},cinesrc:{referer:'https://cinesrc.st/'}};
const UA='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const signature=(url,provider)=>crypto.createHmac('sha256',secret).update(provider+'\n'+url).digest('hex').slice(0,40);
const privateHost=host=>/^(localhost|0\.0\.0\.0|::1)$/i.test(host)||(net.isIP(host)&&(/^(10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|fc|fd|fe80:)/i.test(host)));
export function mediaUrl(url,provider){
 let parsed=new URL(url);if(parsed.protocol!=='https:'||!providers[provider]||privateHost(parsed.hostname))throw Error('Unsupported media URL.');
 return '/api/media?provider='+provider+'&url='+encodeURIComponent(parsed.href)+'&sig='+signature(parsed.href,provider);
}
function validSignature(value,url,provider){
 if(!/^[a-f0-9]{40}$/.test(value||''))return false;
 let expected=Buffer.from(signature(url,provider)),actual=Buffer.from(value);
 return expected.length===actual.length&&crypto.timingSafeEqual(expected,actual);
}
function rewritePlaylist(text,base,provider){
 return text.split(/(\r?\n)/).map(part=>{
  if(/^\r?\n$/.test(part))return part;
  let value=part.trim();if(!value)return part;
  if(value.startsWith('#'))return part.replace(/URI=(["'])(.*?)\1/g,(match,quote,uri)=>`URI=${quote}${mediaUrl(new URL(uri,base).href,provider)}${quote}`);
  return mediaUrl(new URL(value,base).href,provider);
 }).join('');
}
export async function handleMedia(req,res,url){
 let target=url.searchParams.get('url')||'',provider=url.searchParams.get('provider')||'',sig=url.searchParams.get('sig')||'',upstream;
 try{
  let parsed=new URL(target);if(parsed.protocol!=='https:'||!providers[provider]||privateHost(parsed.hostname)||!validSignature(sig,target,provider))throw Error('Invalid media signature.');
  let controller=new AbortController(),timer=setTimeout(()=>controller.abort(),45_000);
  res.once('close',()=>{if(!res.writableEnded){clearTimeout(timer);controller.abort()}});
  upstream=await fetch(parsed,{headers:{Referer:providers[provider].referer,'User-Agent':UA,...(req.headers.range?{Range:req.headers.range}:{})},signal:controller.signal,redirect:'follow'});
  clearTimeout(timer);
  let final=new URL(upstream.url||parsed);if(final.protocol!=='https:'||privateHost(final.hostname))throw Error('Unsafe media redirect.');
  let type=String(upstream.headers.get('content-type')||'').toLowerCase(),playlist=/\.m3u8(?:\?|$)/i.test(final.pathname+final.search)||type.includes('mpegurl');
  if(playlist&&upstream.ok){
   let text=await upstream.text();if(!text.trimStart().startsWith('#EXTM3U'))throw Error('The provider returned an invalid playlist.');
   let body=rewritePlaylist(text,final.href,provider);res.writeHead(200,{'Content-Type':'application/vnd.apple.mpegurl; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});return res.end(body);
  }
  let isSubtitle=/[?&]format=srt(?:&|$)/i.test(final.search)||/\.srt(?:$|\?)/i.test(final.href),isVtt=/\.vtt(?:$|\?)/i.test(final.href);
  if((isSubtitle||isVtt)&&upstream.ok){
   let buffer=Buffer.from(await upstream.arrayBuffer());if(buffer.length>8*1024*1024)throw Error('Subtitle file too large');
   let encoding=final.searchParams.get('encoding')||'utf-8';encoding=encoding.replace(/^cp(\d+)$/i,'windows-$1');let text;try{text=new TextDecoder(encoding).decode(buffer)}catch{text=new TextDecoder().decode(buffer)}
   let vtt=text.replace(/^\uFEFF/,'').replace(/\r/g,'');if(!/^WEBVTT/i.test(vtt))vtt='WEBVTT\n\n'+vtt.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g,'$1.$2');
   res.writeHead(200,{'Content-Type':'text/vtt; charset=utf-8','Cache-Control':'private, max-age=3600','Access-Control-Allow-Origin':'*'});return res.end(vtt);
  }
  if(!upstream.ok){upstream.body?.cancel().catch(()=>{});res.writeHead(502,{'Content-Type':'text/plain; charset=utf-8'});return res.end('Upstream media unavailable ('+upstream.status+').')}
  let headers={'Content-Type':upstream.headers.get('content-type')||(/\.vtt(?:\?|$)/i.test(final.pathname)?'text/vtt; charset=utf-8':'application/octet-stream'),'Cache-Control':upstream.headers.get('cache-control')||'no-store','Access-Control-Allow-Origin':'*'};
  for(let key of ['content-length','content-range','accept-ranges','etag','last-modified']){let value=upstream.headers.get(key);if(value)headers[key.replace(/(^|-)(\w)/g,(_,a,b)=>a+b.toUpperCase())]=value}
  res.writeHead(upstream.status,headers);
  if(!upstream.body)return res.end();
  Readable.fromWeb(upstream.body).on('error',()=>res.destroy()).pipe(res);
 }catch(error){
  upstream?.body?.cancel().catch(()=>{});if(res.headersSent)return res.destroy();
  res.writeHead(502,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'});res.end('Media request failed: '+error.message);
 }
}
