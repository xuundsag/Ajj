import freekeys from 'freekeys';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('public'), db=path.resolve('data/user.json');
const initial={watchlist:[],history:[]};
if(!fs.existsSync(db))fs.writeFileSync(db,JSON.stringify(initial));
const read=()=>{try{return JSON.parse(fs.readFileSync(db))}catch{return initial}};
const json=(res,data,status=200)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data))};
const cache=new Map();
async function remote(url,options={}){let ttl=options.ttl??300000,c=cache.get(url);if(c&&Date.now()-c.time<(c.ttl||ttl))return c.data;let r=await fetch(url,{headers:{'User-Agent':'MoscowTV/1.0 (catalog app)',...(options.headers||{})},signal:AbortSignal.timeout(options.timeout||9000)});if(!r.ok)throw Error('Catalog unavailable ('+r.status+')');let data=await r.json();cache.set(url,{data,time:Date.now(),ttl});return data}
const genreNames={28:'Action',12:'Adventure',16:'Animation',35:'Comedy',80:'Crime',99:'Documentary',18:'Drama',10751:'Family',14:'Fantasy',36:'History',27:'Horror',10402:'Music',9648:'Mystery',10749:'Romance',878:'Science Fiction',10770:'TV Movie',53:'Thriller',10752:'War',37:'Western',10759:'Action & Adventure',10765:'Sci-Fi & Fantasy'};
const ott=x=>({id:String(x.id),type:x.media_type==='tv'||(!x.media_type&&x.first_air_date)?'tv':'movie',title:x.title||x.name||'',poster:x.poster_path?'https://image.tmdb.org/t/p/w500'+x.poster_path:null,backdrop:x.backdrop_path?'https://image.tmdb.org/t/p/original'+x.backdrop_path:null,description:x.overview||'',rating:x.vote_average?Number(x.vote_average.toFixed(1)):null,year:(x.release_date||x.first_air_date||'').slice(0,4),genres:x.genres?.map(g=>g.name)||x.genre_ids?.map(id=>genreNames[id]).filter(Boolean)||[],seasons:x.number_of_seasons});
const aniCache=new Map();async function anilist(query,variables={}){let key=JSON.stringify([query,variables]),cached=aniCache.get(key);if(cached&&Date.now()-cached.time<300000)return cached.data;let r=await fetch('https://graphql.anilist.co',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query,variables}),signal:AbortSignal.timeout(9000)});if(!r.ok)throw Error('Anime catalog unavailable');let d=await r.json();if(d.errors)throw Error(d.errors[0].message);aniCache.set(key,{data:d.data,time:Date.now()});return d.data}
const fields='id idMal title{english romaji} coverImage{extraLarge large} bannerImage description(asHtml:false) averageScore format seasonYear startDate{year month day} episodes nextAiringEpisode{episode} genres status';
const positiveInt=value=>Number.isInteger(Number(value))&&Number(value)>0?Number(value):null;
function animeEpisodeCount(media){
 if(media.format==='MOVIE'||media.status==='NOT_YET_RELEASED')return null;
 let total=positiveInt(media.episodes);
 if(media.status==='RELEASING'){
  let released=positiveInt((media.nextAiringEpisode?.episode||1)-1);
  if(released)return total?Math.min(total,released):released;
 }
 return total;
}
const ani=x=>{
 let isMovie=x.format==='MOVIE',episodes=animeEpisodeCount(x);
 return {id:String(x.idMal),anilistId:String(x.id),type:'anime',title:x.title?.english||x.title?.romaji||'',poster:x.coverImage?.extraLarge||x.coverImage?.large,backdrop:x.bannerImage||x.coverImage?.extraLarge,description:(x.description||'').replace(/<[^>]*>/g,''),rating:x.averageScore?Number((x.averageScore/10).toFixed(1)):null,year:x.seasonYear||x.startDate?.year,episodes,episodeCountKind:x.status==='RELEASING'?'released':'total',genres:x.genres||[],status:x.status,format:x.format||null,isMovie};
};
async function animeRecord(id){
 let d=await anilist(`query($id:Int){Media(idMal:$id,type:ANIME){${fields}}}`,{id:Number(id)});
 return d.Media;
}
let jikanRetryAfter=0;
async function jikan(path){
 if(Date.now()<jikanRetryAfter)throw Error('Jikan is temporarily unavailable');
 try{return await remote('https://api.jikan.moe/v4/'+path,{timeout:4000,ttl:86400000,headers:{Accept:'application/json'}})}
 catch(error){jikanRetryAfter=Date.now()+60000;throw error}
}
const kitsuOptions={ttl:86400000,headers:{Accept:'application/vnd.api+json'}};
async function kitsuEpisodes(malId,offset,limit){
 let mapping=await remote(`https://kitsu.io/api/edge/mappings?filter%5BexternalSite%5D=myanimelist%2Fanime&filter%5BexternalId%5D=${malId}`,kitsuOptions);
 let link=mapping.data?.find(x=>x.attributes?.externalSite==='myanimelist/anime'&&String(x.attributes?.externalId)===String(malId))?.relationships?.item?.links?.related;
 if(!link)return null;
 let anime=await remote(link,kitsuOptions),kitsuId=anime.data?.id;
 if(!kitsuId)return null;
 let response=await remote(`https://kitsu.io/api/edge/anime/${kitsuId}/episodes?page%5Blimit%5D=${limit}&page%5Boffset%5D=${offset}&sort=number`,kitsuOptions);
 return {kitsuId,response};
}
function kitsuEpisode(row){
 let a=row.attributes||{},number=Number(a.number);
 return {number,title:a.titles?.en_us||a.titles?.en||a.titles?.en_jp||a.canonicalTitle||null,description:a.synopsis||a.description||'',still:a.thumbnail?.original||null,aired:a.airdate||null,duration:Number(a.length)||null,filler:false,recap:false};
}
function jikanEpisode(row){
 return {number:Number(row.mal_id),title:row.title||row.title_romanji||row.title_japanese||null,description:row.synopsis||'',still:row.images?.jpg?.image_url||row.images?.webp?.image_url||null,aired:row.aired||null,duration:Number(row.duration)||null,score:Number(row.score)||null,filler:Boolean(row.filler),recap:Boolean(row.recap)};
}
function mergeEpisode(fallback,primary){
 if(!fallback)return primary;
 return {...fallback,...Object.fromEntries(Object.entries(primary).filter(([,value])=>value!==null&&value!==''&&value!==undefined)),still:primary.still||fallback.still,description:primary.description||fallback.description,title:primary.title||fallback.title};
}
let sharedKey=null;
async function tmdbKey(){if(process.env.TMDB_API_KEY)return process.env.TMDB_API_KEY;if(!sharedKey)sharedKey=(await freekeys()).tmdb_key;return sharedKey}
async function tmdb(route,params={}){let key=await tmdbKey();let q=new URLSearchParams({...params,api_key:key,language:'en-US'});try{return await remote('https://api.themoviedb.org/3/'+route+'?'+q)}catch(e){if(process.env.TMDB_API_KEY)throw e;sharedKey=(await freekeys()).tmdb_key;q.set('api_key',sharedKey);return remote('https://api.themoviedb.org/3/'+route+'?'+q)}}
function num(s){return /^\d{1,10}$/.test(s||'')?s:null}
async function api(req,res,url){let p=url.pathname, q=url.searchParams;try{
if(p==='/api/state'){return json(res,read())}
if(p==='/api/watchlist'&&req.method==='POST'||p==='/api/history'&&req.method==='POST'){let chunks=[];for await(let ch of req){chunks.push(ch);if(Buffer.concat(chunks).length>10000)throw Error('Payload too large')}let item=JSON.parse(Buffer.concat(chunks).toString());if(!['anime','movie','tv'].includes(item.type)||!num(String(item.id)))throw Error('Invalid item');let state=read(), field=p.endsWith('watchlist')?'watchlist':'history';let record={id:String(item.id),type:item.type,title:String(item.title||'').slice(0,200),poster:String(item.poster||'').slice(0,500),episode:Math.max(1,Number(item.episode)||1),season:Math.max(1,Number(item.season)||1),updated:Date.now()};record.genres=Array.isArray(item.genres)?item.genres.map(String).slice(0,10):[];record.format=typeof item.format==='string'?item.format.slice(0,20):null;record.currentTime=Math.max(0,Number(item.currentTime)||0);record.duration=Math.max(0,Number(item.duration)||0);let found=state[field].findIndex(x=>x.id===record.id&&x.type===record.type);if(found>=0){let old=state[field].splice(found,1)[0];if(field==='history'&&old.episode===record.episode&&old.season===record.season){record.currentTime=item.currentTime==null?old.currentTime||0:record.currentTime;record.duration=item.duration==null?old.duration||0:record.duration}if(!record.genres.length)record.genres=old.genres||[]}if(field==='history'||!item.remove)state[field].unshift(record);state[field]=state[field].slice(0,100);fs.writeFileSync(db,JSON.stringify(state));return json(res,state)}
if(p==='/api/browse'){let [a,o]=await Promise.allSettled([anilist(`query {Page(page:1,perPage:18){media(type:ANIME,sort:TRENDING_DESC,isAdult:false){${fields}}}}`),tmdb('trending/all/week')]);let animeItems=a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal).map(ani):[];let ottItems=o.status==='fulfilled'?o.value.results.filter(x=>x.media_type==='tv'||x.media_type==='movie').map(ott):[];if(!animeItems.length&&!ottItems.length)throw Error('Catalogs are unavailable');let movies=ottItems.filter(x=>x.type==='movie'),shows=ottItems.filter(x=>x.type==='tv'),mixed=[];for(let i=0;i<Math.max(animeItems.length,movies.length,shows.length);i++){if(animeItems[i])mixed.push(animeItems[i]);if(movies[i])mixed.push(movies[i]);if(shows[i])mixed.push(shows[i])}let history=read().history,watchedGenres=new Map();for(let [index,h] of history.entries())for(let g of h.genres||[])watchedGenres.set(g.toLowerCase(),(watchedGenres.get(g.toLowerCase())||0)+Math.max(1,8-index));let watched=new Set(history.map(h=>h.type+':'+h.id));let suggestions=mixed.filter(x=>!watched.has(x.type+':'+x.id)).map(x=>({...x,match:(x.genres||[]).reduce((n,g)=>n+(watchedGenres.get(g.toLowerCase())||0),0)})).filter(x=>x.match>0).sort((a,b)=>b.match-a.match).slice(0,12);return json(res,{items:mixed,suggestions,hasPreferences:watchedGenres.size>0})}
if(p==='/api/search-all'){let term=(q.get('q')||'').trim().slice(0,100);if(!term)return json(res,{items:[]});let [a,o]=await Promise.allSettled([anilist(`query($search:String){Page(page:1,perPage:15){media(type:ANIME,search:$search,isAdult:false){${fields}}}}`,{search:term}),tmdb('search/multi',{query:term,include_adult:'false'})]);return json(res,{items:[...(a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal).map(ani):[]),...(o.status==='fulfilled'?o.value.results.filter(x=>['tv','movie'].includes(x.media_type)).map(ott):[])]})}
if(p==='/api/genre'){let g=q.get('name');if(!['Action','Adventure','Animation','Comedy','Drama','Fantasy','Horror','Romance','Thriller'].includes(g))return json(res,{error:'Unknown genre'},400);let id={Action:28,Adventure:12,Animation:16,Comedy:35,Drama:18,Fantasy:14,Horror:27,Romance:10749,Thriller:53}[g];let [a,o]=await Promise.allSettled([anilist(`query($genre:String){Page(page:1,perPage:8){media(type:ANIME,genre:$genre,sort:POPULARITY_DESC,isAdult:false){${fields}}}}`,{genre:g}),tmdb('discover/movie',{with_genres:String(id),sort_by:'popularity.desc',page:'1'})]);let animeItems=a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal).map(ani):[];let movieItems=o.status==='fulfilled'?o.value.results.slice(0,8).map(ott):[];let mixed=[];for(let i=0;i<8;i++){if(animeItems[i])mixed.push(animeItems[i]);if(movieItems[i])mixed.push(movieItems[i])}return json(res,{items:mixed.slice(0,12)})}
if(p==='/api/detail'){let id=num(q.get('id')),type=q.get('type');if(!id||!['anime','tv','movie'].includes(type))return json(res,{error:'Invalid title'},400);if(type==='anime'){
 let media=await animeRecord(id);
 if(!media)return json(res,{error:'Anime not found'},404);
 // Every AniList anime entry is standalone. Never merge prequels, sequels,
 // successors, or separately cataloged seasons into another anime's page.
 return json(res,{item:ani(media),episodes:[],seasons:[]});
 }let d=await tmdb(type+'/'+id);return json(res,{item:ott({...d,media_type:type}),seasons:d.seasons?.filter(x=>x.season_number>=0).map(x=>({number:x.season_number,name:x.name,episodes:x.episode_count}))||[]})}
if(p==='/api/anime-episodes'){
 let id=num(q.get('id')),page=Math.max(1,Math.min(10000,Math.floor(Number(q.get('page'))||1))),limit=20,offset=(page-1)*limit;
 if(!id)return json(res,{error:'Invalid anime'},400);
 let jikanPage=Math.floor(offset/100)+1,jikanOffset=offset%100;
 let [media,jikanResult,kitsuResult]=await Promise.all([
  animeRecord(id).catch(()=>null),
  jikan(`anime/${id}/episodes?page=${jikanPage}`).catch(error=>({error:error.message})),
  kitsuEpisodes(id,offset,limit).catch(error=>({error:error.message}))
 ]);
 let jd=jikanResult?.pagination?jikanResult:null,kd=kitsuResult?.response||null;
 if(!jd&&!kd&&(jikanResult?.error||kitsuResult?.error))return json(res,{error:'Jikan and the episode metadata fallback are temporarily unavailable.'},502);
 let known=media?animeEpisodeCount(media):null,rows=new Map();
 for(let row of kd?.data||[]){let episode=kitsuEpisode(row);if(Number.isInteger(episode.number)&&episode.number>0&&(!known||episode.number<=known))rows.set(episode.number,episode)}
 for(let row of (jd?.data||[]).slice(jikanOffset,jikanOffset+limit)){
  let episode=jikanEpisode(row);if(!Number.isInteger(episode.number)||episode.number<1||(known&&episode.number>known))continue;
  rows.set(episode.number,mergeEpisode(rows.get(episode.number),episode));
 }
 let episodes=[...rows.values()].sort((a,b)=>a.number-b.number),jikanTotal=Number(jd?.pagination?.items?.total)||0,kitsuTotal=Number(kd?.meta?.count)||0,total=Math.max(jikanTotal,kitsuTotal);
 if(known)total=total?Math.min(total,known):known;
 let hasNext=total?offset+limit<total:Boolean(jd?.pagination?.has_next_page||kd?.links?.next);
 return json(res,{episodes,page,perPage:limit,total:total||null,hasNext,sources:[...(jd?['jikan']:[]),...(kd?['kitsu']:[])]});
}
if(p==='/api/season'){let id=num(q.get('id')),season=q.get('season')==='0'?'0':num(q.get('season'));if(!id||season===null)return json(res,{error:'Invalid season'},400);let d=await tmdb(`tv/${id}/season/${season}`);return json(res,{episodes:(d.episodes||[]).map(e=>({number:e.episode_number,title:e.name,description:e.overview,still:e.still_path?'https://image.tmdb.org/t/p/w300'+e.still_path:null}))})}
if(p==='/api/play'){let id=num(q.get('id')),type=q.get('type'),ep=num(q.get('episode')||'1'),season=q.get('season')==='0'?'0':num(q.get('season')||'1'),lang=q.get('lang')==='dub'?'dub':'sub',provider=q.get('provider')==='second'?'second':'default',aniId=num(q.get('anilistId'));if(!id||!ep||!season||!['anime','movie','tv'].includes(type))return json(res,{error:'Invalid playback request'},400);let src=type==='anime'?`https://animeembed.com/embed/ani/${aniId||id}/${ep}?track=${provider==='second'?'dub':'sub'}&accent=ffac59&autoPlay=${q.get('autoplay')==='true'?'1':'0'}&autoNext=0&autoSkip=${q.get('autoskip')==='false'?'0':'1'}`:type==='movie'?(provider==='second'?`https://embedwave.cc/embed/movie/${id}`:`https://vidcore.org/embed/movie/${id}`):(provider==='second'?`https://embedwave.cc/embed/tv/${id}/${season}/${ep}`:`https://vidcore.org/embed/tv/${id}/${season}/${ep}`);if(q.get('autoplay')==='true'&&type!=='anime'&&provider!=='second')src+='?autoplay=true';let resume=Math.min(86400,Math.max(0,Math.floor(Number(q.get('start'))||0)));if(resume){if(type==='anime')src+='&start='+resume;else if(provider!=='second')src+=(src.includes('?')?'&':'?')+'startAt='+resume}return json(res,{src,provider:type==='anime'?'AnimEmbed':provider==='second'?'EmbedWave':'VidCore'})}
return json(res,{error:'Not found'},404)
}catch(e){return json(res,{error:e.message||'Request failed'},e.message?.includes('configured')?503:502)}}
http.createServer((req,res)=>{let u=new URL(req.url,'http://localhost');if(/^\/(anime|ott)(\/|$)/.test(u.pathname)){let dest=u.pathname.replace(/^\/(anime|ott)/,'/browse');res.writeHead(302,{Location:dest+u.search});return res.end()}if(u.pathname.startsWith('/api/'))return api(req,res,u);let pathname=u.pathname==='/'?'/index.html':u.pathname;let target=path.resolve(root,'.'+pathname);if(!target.startsWith(root+path.sep)||!fs.existsSync(target)||!fs.statSync(target).isFile())target=path.join(root,'index.html');let ext=path.extname(target);res.writeHead(200,{'Content-Type':({'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.ttf':'font/ttf'}[ext]||'application/octet-stream'),'Content-Security-Policy':"default-src 'self' https: data: blob:; frame-src https://animeembed.com https://vidcore.org https://embedwave.cc; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' https: data:; connect-src 'self'"});fs.createReadStream(target).pipe(res)}).listen(process.env.PORT||3000,'0.0.0.0',()=>console.log('MoscowTV listening on '+(process.env.PORT||3000)));
