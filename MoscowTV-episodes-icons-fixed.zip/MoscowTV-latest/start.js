// Change this value to run MoscowTV on a different port.
const PORT = 3000;

import { spawn, spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const cwd = dirname(fileURLToPath(import.meta.url));
if (!existsSync(join(cwd, 'node_modules', 'freekeys'))) {
  console.log('Installing production dependencies…');
  const result = spawnSync('npm', ['install', '--omit=dev'], { cwd, stdio: 'inherit', shell: process.platform === 'win32' });
  if (result.status !== 0) process.exit(result.status || 1);
}
// The frontend is static HTML/CSS/JS; it has no separate build step.
const server = spawn(process.execPath, ['server.js'], {
  cwd,
  env: { ...process.env, PORT: String(PORT) },
  stdio: 'inherit'
});
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.kill(signal));
server.on('exit', code => process.exit(code || 0));
