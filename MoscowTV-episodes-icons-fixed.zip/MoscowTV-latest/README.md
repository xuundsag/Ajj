# MoscowTV

A dark, orange-accented anime, movie and web-series catalog with search, title details, watchlist, Continue Watching and third-party iframe players. Node 20+ is recommended.

## Start

```sh
node start.js
```

Edit `PORT` at the top of `start.js` to change the default port (`3000`). The launcher installs dependencies if needed. The frontend is static and has no build step. Set `TMDB_API_KEY` for a reliable movie/TV catalog; otherwise the server tries publicly shared keys from `freekeys`, which can fail or be rate-limited.

## Catalog and playback

- **Anime metadata:** AniList GraphQL, queried by MyAnimeList ID. Anime entries retain their AniList ID for playback.
- **Anime episode metadata:** Jikan v4 is attempted first for each 100-episode upstream page. Kitsu is used as the approved fallback and to fill thumbnails/descriptions missing from Jikan's bulk rows. Kitsu is resolved through its exact `myanimelist/anime` mapping, never by guessing a title. Episode responses are cached; a Jikan connection failure backs off briefly while Kitsu remains available.
- **Anime playback:** AnimeEmbed (`animeembed.com`) iframes with Sub/Dub, orange accent, autoplay preference, auto-skip preference and resume start time.
- **Movie/web-series metadata:** TMDB. TV seasons, specials, episode names, descriptions and stills come from TMDB and were not changed by the anime metadata correction.
- **Movie/web-series playback:** VidCore is Stream 1 and EmbedWave is Stream 2. Provider names are not exposed in those selector labels.
- Watchlist and history use one shared local profile in `data/user.json`; this is not a multi-user account system.

## Standalone anime entries and episode handling

Every anime is a standalone AniList entry. MoscowTV does not use prequel/sequel relations to combine titles and does not provide a shared anime season/entry selector:

- Naruto, Naruto: Shippuden and Boruto have separate pages and episode lists.
- Separately cataloged seasons and parts of other franchises also remain separate entries. For example, Attack on Titan and Attack on Titan Season 2 are not merged.
- Anime details and watch pages show an **Episodes** heading for the current entry only. TV/web-series pages retain their TMDB season selectors.
- `MOVIE` format is treated as an anime film. It has no episode count badge, episode grid, episode-range selector, Previous/Next episode buttons or Auto Next control. Its watch page uses episode `1` internally only because the embed URL requires an episode segment.
- Finished entries use AniList's cataloged `episodes` value. Releasing entries use the currently released count derived from `nextAiringEpisode - 1`, capped by an announced total when one exists, and are labeled as released rather than final totals.
- Unknown or unreleased episode totals stay unknown. The UI displays an availability message and never substitutes 24 or another fabricated count.
- Anime details and watch pages use the same clickable image/title/description rows as web series. The old 1–100 range selector and numbered-button grid are removed.
- Episode metadata loads 20 rows at a time. Long anime provide a compact gray **Show more** button when another page is available; a watch page starts at the page containing the active episode.
- Jikan titles/fields take priority when available. Kitsu supplies missing thumbnails and descriptions. If neither supplies a thumbnail, the current anime's artwork is used as a visual fallback. Missing titles appear as `Episode N`; the description element is omitted when no description exists.
- Episode counts and Next navigation remain bounded by the current standalone entry's known count. Counts can change as metadata providers update.

## Interface

- Mixed `/browse` catalog; legacy `/anime` and `/ott` routes redirect to Browse.
- Three genre shelves are randomly selected per Browse load from Action, Adventure, Animation, Comedy, Drama, Fantasy, Horror, Romance and Thriller. Spotlights rotate independently every 6.5 seconds and pause in hidden tabs.
- Search expands across the mobile header and replaces the catalog with results as the user types.
- Details-page mobile actions are `Watch` and `+ Add`; desktop actions are `Watch Now` and `+ Add to Watchlist`. MoscowTV's Watch and Stream selectors have no triangular play symbol.
- Mobile descriptions are shortened. Mobile spotlights use the same backdrop artwork as desktop with narrow-screen alignment.
- The player control strip follows the reference structure: Expand, Auto Play, Auto Next where applicable, Auto Skip for anime, Light, Previous/Next where applicable and Add to List.
- A bundled Lucide line-icon set uses a shared 24×24 viewBox and 1.8px stroke. Mobile header icons are 22px, mobile player icons 16px, and desktop player icons 17px; rating and metadata icons use smaller optical sizes deliberately. Watch buttons remain text-only.
- Continue Watching retains vertical posters, orange progress, media labels and elapsed time only. A missing time is shown as `00:00`; no synthetic progress is inserted.

## Provider limitations

Playback availability varies by title and provider. The app does not proxy streams or replace provider-owned controls inside cross-origin iframes. AnimeEmbed warns that sandboxing can break playback, so its iframe is not sandboxed. No guarantee is made about upstream ads, redirects, popups, playback, Dub availability or progress support.

AnimeEmbed's documented versioned `postMessage` progress is checked by sender and origin before being stored. VidCore accepts `startAt` when a saved position exists, but its public events do not establish reliable time reporting. EmbedWave has no verified seek/progress integration here. Opening a watch page creates history without fabricating viewing progress.

Verify content rights and provider terms before deploying. Do not expose this single-profile storage as a multi-user service without authentication and private per-user storage.

## Screenshots

The `screenshots/current-*` files are real Chromium captures at 390px mobile and 1440px desktop widths. Additional `separate-*` captures verify standalone Naruto, Shippuden and long-running One Piece pages. These are interface captures, not proof of third-party video playback.

## Attribution

The dark spotlight layout takes inspiration from Anipaca; its GPL-3.0 license is retained in `ANIPACA-LICENSE.txt`. MoscowTV uses a separate text-only wordmark and bundled Manrope fonts. Lucide's ISC/Feather MIT notices are retained in `LUCIDE-LICENSE.txt`.
