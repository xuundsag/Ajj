const app=document.querySelector('#app'),search=document.querySelector('#search'),headerEl=document.querySelector('.header');
let items=[],spotlightItems=[],suggestions=[],genreRows={},activeGenres=[],genreQueue=[],continueItems=[],slide=0,detail=null,season=1,episode=1,provider='vidcore',searchTimer,lastProgressSent=0,savedKeys=new Set(),animeEpisodeLists={detail:null,watch:null},tvEpisodeLists={detail:null,watch:null},videoPlayer=null,playGeneration=0,lang='sub';
let pagedState={mode:'',endpointBase:'',page:1,hasMore:false,seen:new Set(),total:0};
let episodeSwitchGeneration=0,routeGeneration=0;
let browseRowsSession=null,genrePagesSession=null;
const tvEpisodeRequest={detail:0,watch:0};

const siteFooter=document.querySelector('footer');
function syncFooter(){let loading=app.firstElementChild?.classList.contains('loading');document.body.classList.toggle('route-ready',app.childElementCount>0&&!loading)}
new MutationObserver(syncFooter).observe(app,{childList:true});syncFooter();

let playerAssetsPromise=null;
function loadPlayerAssets(){
 if(window.videojs&&window.MegaPlayUI)return Promise.resolve();
 if(!playerAssetsPromise)playerAssetsPromise=(async()=>{
  for(let src of ['/vendor/video.min.js','/megaplay-controls.js?v=5.4.13b'])await new Promise((resolve,reject)=>{
   let script=document.createElement('script');script.src=src;script.async=true;script.onload=resolve;
   script.onerror=()=>{script.remove();reject(Error('The player assets could not be loaded.'))};
   document.head.append(script);
  });
 })().catch(error=>{playerAssetsPromise=null;throw error});
 return playerAssetsPromise;
}

const DEFAULT_DOC_TITLE='kozuTV - Watch Free Anime, Movies & Series Online in HD Sub & Dub';
const OTT_PROVIDERS=['vidcore','embedwave','cinesrc','vidlink','vidsrc'];
const ANIME_LANGS=['sub','dub','hi','ta','te','ml','kn','bn'];
const ANIME_REGIONAL_LANGS=['hi','ta','te','ml','kn','bn'];
const animeCatalogBucket=value=>ANIME_REGIONAL_LANGS.includes(value)?'reg':value;
const animeNeedsEpisodeOne=(item,from,to)=>Boolean(item?.differentDubOrder&&animeCatalogBucket(from)!==animeCatalogBucket(to));
const animeFallbackOrder=first=>[...new Set([first,'dub','sub'].filter(value=>ANIME_LANGS.includes(value)))];
const newAnimePlan=(from,ep)=>({originLang:from,originEpisode:ep,order:animeFallbackOrder(from),tried:[]});
// Normalize only known audio languages; an unknown stream is never renamed as
// the preference. Direct source variants can be chosen before playback starts.
const OTT_AUDIO_NAMES={en:'English',ja:'Japanese',hi:'Hindi',ta:'Tamil',te:'Telugu',ml:'Malayalam',kn:'Kannada',bn:'Bengali',ko:'Korean',es:'Spanish',fr:'French',de:'German',it:'Italian',pt:'Portuguese',ru:'Russian',zh:'Chinese',ar:'Arabic',tr:'Turkish',th:'Thai',vi:'Vietnamese',id:'Indonesian',mr:'Marathi',pa:'Punjabi',gu:'Gujarati',ur:'Urdu',nl:'Dutch',pl:'Polish',sv:'Swedish',da:'Danish',fi:'Finnish',cs:'Czech',el:'Greek',hu:'Hungarian',ro:'Romanian',uk:'Ukrainian',he:'Hebrew',fa:'Persian',ms:'Malay'};
const OTT_AUDIO_ALIASES={eng:'en',jpn:'ja',hin:'hi',tam:'ta',tel:'te',mal:'ml',kan:'kn',ben:'bn',kor:'ko',spa:'es',fra:'fr',fre:'fr',deu:'de',ger:'de',ita:'it',por:'pt',rus:'ru',zho:'zh',chi:'zh',ara:'ar',tur:'tr',tha:'th',vie:'vi',ind:'id',mar:'mr',pan:'pa',guj:'gu',urd:'ur'};
function ottAudioCode(track){
 const raw=String(track?.language||'').trim().toLowerCase().split(/[-_]/)[0];
 if(OTT_AUDIO_NAMES[raw])return raw;if(OTT_AUDIO_ALIASES[raw])return OTT_AUDIO_ALIASES[raw];
 const label=String(track?.label||'').trim().toLowerCase();
 return Object.keys(OTT_AUDIO_NAMES).find(key=>label===OTT_AUDIO_NAMES[key].toLowerCase()||label.startsWith(OTT_AUDIO_NAMES[key].toLowerCase()+' '))||'';
}
function ottPreferredAudio(){
 let setting=null;try{setting=localStorage.getItem('kozutv-ott-audio')}catch{}
 if(setting!==null)return setting==='auto'?'':ottAudioCode({language:setting});
 try{const legacy=JSON.parse(localStorage.getItem('kozutv-audio-pref')||'null');return legacy?ottAudioCode(legacy):''}catch{return ''}
}
function ottSourceOrder(data){
 const all=Array.isArray(data.audioStreams)?data.audioStreams.filter(a=>a?.src):[];
 const primary=all.find(a=>a.src===data.src)||{src:data.src,type:data.type,language:data.audioLang,label:data.audioLabel,tracks:data.tracks,primary:true};
 const pref=ottPreferredAudio(),out=[],seen=new Set();
 const add=track=>{if(track?.src&&!seen.has(track.src)){seen.add(track.src);out.push(track)}};
 if(!pref)add(primary);
 for(const code of [...new Set([pref,'en','ja'].filter(Boolean))])for(const track of all)if(ottAudioCode(track)===code)add(track);
 add(primary);
 return out;
}
function ottWithSource(data,stream){
 if(!stream||stream.src===data.src)return {...data};
 return {...data,src:stream.src,type:stream.type||data.type,audioLang:stream.language||'und',audioLabel:stream.label||'Original audio',sourceKey:stream.sourceKey||data.sourceKey,server:stream.server||data.server,provider:stream.provider||data.provider,tracks:stream.tracks||[],qualityStreams:[]};
}

const TV_EP_CHUNK=60;
const isFeature=x=>x?.type==='movie'||x?.isMovie||x?.format==='MOVIE';
const short=(s,n)=>{let t=String(s||'').replace(/\s+/g,' ').trim();return t.length>n?t.slice(0,n).replace(/\s+\S*$/,'')+'…':t};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const url=(type,id)=>`/browse/${type}/${id}`;
const responseJSON=async r=>{let text=await r.text(),d;try{d=JSON.parse(text)}catch{throw Error(r.ok?'The service returned an invalid response.':`Request failed (${r.status}).`)}if(!r.ok){let err=Error(d.error||'Request failed');if(d.availableLang)err.availableLang=d.availableLang;throw err}return d};
const get=async p=>responseJSON(await fetch(p));
const post=async(p,body)=>responseJSON(await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}));
function readPreference(key,fallback=''){try{return localStorage.getItem(key)??fallback}catch{return fallback}}
// One-time migration of preferences saved under the legacy moscowtv- prefix.
// Values are only copied when the kozuTV key is unset, then legacy keys are removed.
const LEGACY_PREF_KEYS=['autoplay','autonext','autoskip','resume-playback','seek-step','save-history','spotlight-autoplay','reduce-motion','ai-transcription','anime-lang','ott-audio','server-pref','quality','speed','muted','audio-pref','brightness'];
function migrateLegacyPreferences(){
 if(typeof localStorage==='undefined')return;
 try{
  if(localStorage.getItem('kozutv:migrated-prefs-v1')==='true')return;
  for(const name of LEGACY_PREF_KEYS){
   const old='moscowtv-'+name,next='kozutv-'+name;
   try{const value=localStorage.getItem(old);if(value!==null){if(localStorage.getItem(next)===null)localStorage.setItem(next,value);localStorage.removeItem(old)}}catch{}
  }
  localStorage.setItem('kozutv:migrated-prefs-v1','true');
 }catch{}
}
migrateLegacyPreferences();
function saveHistory(data){
 // Turning history off stops all app-generated progress writes; earlier history
 // and the watchlist are deliberately left intact.
 if(readPreference('kozutv-save-history','true')==='false')return Promise.resolve();
 return post('/api/history',data).catch(()=>{});
}
function applyDisplayPreferences(){
 document.documentElement.classList.toggle('reduce-motion',readPreference('kozutv-reduce-motion','false')==='true');
 document.documentElement.classList.toggle('spotlight-paused',readPreference('kozutv-spotlight-autoplay','true')==='false');
}
const params=()=>new URLSearchParams(location.search);
// All app-owned preference writes go through the token sync queue.
function savePreference(key,value){
 if(window.KozuCacheToken)return window.KozuCacheToken.setPref(key,value);
 try{localStorage.setItem(key,String(value));return true}catch{return false}
}
function removePreference(key){
 if(window.KozuCacheToken)return window.KozuCacheToken.removePref(key);
 try{localStorage.removeItem(key)}catch{}
}


const PROXIED_IMG_HOST_RE=/^https:\/\/(?:[a-z0-9-]+\.)*(?:tmdb\.org|themoviedb\.org|anipixcdn\.co|anilist\.co|anili\.st|thetvdb\.com|myanimelist\.net|kitsu\.app|kitsu\.io|tvmaze\.com)\//i;
const FALLBACK_STILL_DATA_URI='data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#22252e"/><stop offset="100%" stop-color="#14161c"/></linearGradient></defs><rect width="320" height="180" fill="url(#g)"/><circle cx="160" cy="90" r="24" fill="#ff731c" fill-opacity="0.16"/><path d="M154 79l18 11-18 11z" fill="#ff731c"/></svg>');
const FALLBACK_POSTER_DATA_URI='data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#22252e"/><stop offset="100%" stop-color="#13151c"/></linearGradient></defs><rect width="400" height="600" fill="url(#g)"/><circle cx="200" cy="280" r="38" fill="#ff731c" fill-opacity="0.15"/><path d="M190 262l28 18-28 18z" fill="#ff731c"/></svg>');

function safeImage(s){
 let raw=String(s||'').trim();
 if(!raw)return '';
 if(PROXIED_IMG_HOST_RE.test(raw))return esc('/api/img?u='+encodeURIComponent(raw));
 if(/^(?:https:\/\/|\/images\/|\/api\/img\?|data:image\/svg\+xml)/i.test(raw))return esc(raw);
 return '';
}

window.addEventListener('error',e=>{
 const img=e.target;
 if(!img||img.tagName!=='IMG'||img.dataset.fallbackApplied)return;
 const alternate=img.dataset.altSrc;
 if(alternate&&!img.dataset.altTried){img.dataset.altTried='1';img.src=alternate;return}
 img.dataset.fallbackApplied='1';
 const isPoster=Boolean(img.closest('.poster,.detail-layout,.continue-image,.schedule-row,.hero-image-mobile'));
 img.src=isPoster?FALLBACK_POSTER_DATA_URI:FALLBACK_STILL_DATA_URI;
},true);

const catalogGenres=['Action','Adventure','Animation','Comedy','Crime','Documentary','Drama','Family','Fantasy','Horror','Mecha','Music','Mystery','Psychological','Romance','Sci-Fi','Slice of Life','Sports','Supernatural','Thriller'];
const spotlightPortraits={'anime:21':'/images/spotlight/anime-21.jpg','movie:1263337':'/images/spotlight/movie-1263337.jpg','anime:61607':'/images/spotlight/anime-61607.jpg','movie:1423191':'/images/spotlight/movie-1423191.jpg','tv:289517':'/images/spotlight/tv-289517.jpg','movie:1294189':'/images/spotlight/movie-1294189.jpg'};

function effectiveAnimeEpisodeCount(x,curLang=lang){
 if(!x)return 1;
 if(ANIME_REGIONAL_LANGS.includes(curLang)&&Number.isInteger(x.regionalCount)&&x.regionalCount>0)return x.regionalCount;
 if(curLang==='dub'&&Number.isInteger(x.dubCount)&&x.dubCount>0)return x.dubCount;
 if(curLang==='sub'&&Number.isInteger(x.subCount)&&x.subCount>0)return x.subCount;
 if(Number.isInteger(x.regionalCount)&&x.regionalCount>0)return x.regionalCount;
 if(Number.isInteger(x.dubCount)&&x.dubCount>0&&x.sub===false)return x.dubCount;
 return Math.max(1,Number(x.episodes)||1);
}

function renderRegionalSeasonSelect(d,idPrefix,curEp=1,curLang=lang){
 let rs=Array.isArray(d?.regionalSeasons)?d.regionalSeasons:(Array.isArray(d?.item?.regionalSeasons)?d.item.regionalSeasons:[]);
 if(rs.length<2||!ANIME_REGIONAL_LANGS.includes(curLang))return '';
 let activeStart=rs[0].startEp;
 for(let s of rs)if(curEp>=s.startEp&&curEp<=s.endEp){activeStart=s.startEp;break}
 return `<select class="season-select" id="${idPrefix}-regional-season" aria-label="Season">${rs.map(s=>`<option value="${s.startEp}" ${s.startEp===activeStart?'selected':''}>${esc(s.name||s.label)}</option>`).join('')}</select>`;
}

function pokemonRegion(d,id,ep){
 const groups=Array.isArray(d?.pokemonRegions)?d.pokemonRegions:[];
 const current=groups.find(g=>String(g.id)===String(id)&&ep>=g.startEp&&ep<=g.endEp);
 if(current)return current;
 const first=groups.find(g=>String(g.id)===String(id))||null;
 // Existing Journeys 137–146 links overlap Master 1–10. Keep their own
 // direct episode lists usable, while the normal chronological path skips them.
 return first&&String(id)==='40351'&&ep>=137&&ep<=146?{...first,endEp:146}:first;
}
function renderPokemonSelect(d,idPrefix,curEp){
 const groups=Array.isArray(d?.pokemonRegions)?d.pokemonRegions:[];
 if(!groups.length)return '';
 const current=pokemonRegion(d,d.item?.id,curEp);
 return `<select class="season-select" id="${idPrefix}-pokemon-region" aria-label="Pokémon region and series">${groups.map(g=>`<option value="${esc(g.id)}:${g.startEp}" ${current&&g.id===current.id&&g.startEp===current.startEp?'selected':''}>${esc(g.name)}</option>`).join('')}</select>`;
}
function nextAvailableAnimeNumber(x,n,step){
 const numbers=Array.isArray(x?.availableEpisodeNumbers)?x.availableEpisodeNumbers:null;
 if(!numbers)return n+step;
 return step>0?(numbers.find(v=>v>n)||null):([...numbers].reverse().find(v=>v<n)||null);
}
function disposeVideo(){playGeneration++;if(videoPlayer){try{videoPlayer.dispose()}catch{}videoPlayer=null}}

function closeSearchBox(){
 document.querySelector('.searchbox')?.classList.remove('open');
 headerEl?.classList.remove('search-open');
}

function nav(path){
 clearTimeout(searchTimer);
 episodeSwitchGeneration++;
 disposeVideo();
 history.pushState({},'',path);
 let nextQ=new URLSearchParams(location.search).get('q')||'';
 search.value=nextQ;
 if(!nextQ)closeSearchBox();
 render();
 window.scrollTo(0,0);
}

function card(x){return `<article class="card" data-open="${url(x.type,x.id)}"><div class="poster"><img loading="lazy" src="${safeImage(x.poster||x.backdrop)||FALLBACK_POSTER_DATA_URI}" data-alt-src="${safeImage(x.backdrop||'')}" alt="${esc(x.title)}">${x.rating?`<span class="rating">${ico('star')}${esc(x.rating)}</span>`:''}</div><h3 title="${esc(x.title)}">${esc(x.title)}</h3><p>${esc(x.year||'New')} &nbsp;·&nbsp; ${x.type==='anime'?(x.isMovie?'Anime Movie':'Anime Series'):x.type==='tv'?'TV Series':'Movie'}</p></article>`}
function grid(data,idAttr=''){return data.length?`<div class="grid"${idAttr?` id="${idAttr}"`:''}>${data.map(card).join('')}</div>`:'<div class="empty">No titles found.</div>'}

function hero(data){
 let x=data[slide%data.length];if(!x)return '';
 let feature=isFeature(x),key=x.type+':'+x.id,saved=savedKeys.has(key);
 let watch=`/watch/${x.type}/${x.id}${feature?'':'?season=1&episode=1'}`;
 let art=safeImage(x.backdrop||x.poster);
 let mobileArt=safeImage(x.spotlightHighRes||x.spotlightBanner||spotlightPortraits[key]||x.poster||x.backdrop);
 let genreSummary=Array.isArray(x.genres)&&x.genres.length?`<span>${esc(x.genres.slice(0,2).join(' · '))}</span>`:'';
 return `<section class="hero" data-hero-details="${url(x.type,x.id)}"><img class="hero-image" src="${art||FALLBACK_STILL_DATA_URI}" data-alt-src="${safeImage(x.poster||'')}" alt="" fetchpriority="high" decoding="async"><img class="hero-image-mobile" src="${mobileArt||FALLBACK_POSTER_DATA_URI}" data-alt-src="${safeImage(x.spotlightBanner||spotlightPortraits[key]||x.backdrop||'')}" alt="" fetchpriority="high" decoding="async"><div class="container hero-content"><div class="hero-copy"><h1><a href="${url(x.type,x.id)}">${esc(x.title)}</a></h1><div class="meta hero-meta"><span>${ico(x.type==='anime'?(feature?'film':'tv'):x.type==='tv'?'tv':'film')}${x.type==='anime'?(feature?'Anime Movie':'Anime'):x.type==='tv'?'Web Series':'Movie'}</span>${genreSummary}${x.year?`<span>${ico('calendar')}${esc(x.year)}</span>`:''}<span class="quality">HD</span>${x.rating?`<span>${ico('star')}${esc(x.rating)}</span>`:''}</div><p class="description">${esc(short(x.description||'',220))}</p><div class="hero-actions"><button class="btn hero-watch" data-open="${watch}">${ico('play')}<span>Start Watching${feature?'':' E1'}</span></button><button class="hero-save ${saved?'saved':''}" data-hero-save="${key}" aria-label="${saved?'Remove from':'Add to'} Watchlist" title="Watchlist">${ico('bookmark')}</button></div></div><div class="dots">${data.slice(0,6).map((_,i)=>`<button data-slide="${i}" class="${i===slide?'active':''}" aria-label="Spotlight ${i+1}"></button>`).join('')}</div></div></section>`;
}

async function catalog(isSearch=false){
 const route=++routeGeneration;
 stopBrowseRows();stopGenrePages();
 let p=params(),urlQ=(p.get('q')||'').trim();
 if(urlQ&&!search.value.trim())search.value=urlQ;
 let term=search.value.trim();
 if(term)isSearch=true;
 let genre=isSearch?null:p.get('genre'),collection=isSearch?null:p.get('collection');
 document.title=isSearch?`Search “${term}” — kozuTV`:(genre||collection)?`${genre||collection} — kozuTV`:DEFAULT_DOC_TITLE;
 app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let endpoint=isSearch?`/api/search-all?q=${encodeURIComponent(term)}&page=1`:collection?`/api/collection?name=${encodeURIComponent(collection)}&page=1`:genre?`/api/genre?name=${encodeURIComponent(genre)}&page=1`:'/api/browse';
  let [d,state]=await Promise.all([get(endpoint),get('/api/state')]);
  if(route!==routeGeneration)return;
  items=d.items||[];
  spotlightItems=!isSearch&&!genre&&!collection?(d.spotlight?.length?d.spotlight.slice(0,6):items.filter(x=>x.poster&&x.title&&x.backdrop).slice(0,6)):[];
  suggestions=isSearch||genre||collection?[]:d.suggestions||[];
  savedKeys=new Set((state.watchlist||[]).map(x=>x.type+':'+x.id));
  continueItems=isSearch||genre||collection?[]:(state.history||[]).slice(0,8);
  genreRows={};
  genreQueue=[];activeGenres=[];
  slide=0;
  let filtered=isSearch||Boolean(genre)||Boolean(collection);
  if(filtered){
   pagedState={
    mode:isSearch?'search':collection?'collection':'genre',
    endpointBase:isSearch?`/api/search-all?q=${encodeURIComponent(term)}`:collection?`/api/collection?name=${encodeURIComponent(collection)}`:`/api/genre?name=${encodeURIComponent(genre)}`,
    page:1,
    hasMore:Boolean(d.hasMore),
    seen:new Set(items.map(x=>`${x.type}:${x.id}`)),
    total:Number(d.totalResults)||items.length
   };
  }else{
   pagedState={mode:'',endpointBase:'',page:1,hasMore:false,seen:new Set(),total:0};
  }
  drawCatalog(filtered,genre||collection||term,Boolean(genre||collection));
  if(!filtered)startBrowseRows();
  else if(pagedState.mode==='genre')startGenrePages();
 }catch(e){
  if(route!==routeGeneration)return;
  app.innerHTML=`<div class="container content"><div class="empty"><h2>Catalog unavailable</h2><p class="error">${esc(e.message)}</p><button class="btn" data-retry>Try again</button></div></div>`;
 }
}

const collectionIcons={'Hindi Dubbed':'headphones','Tamil Dubbed':'headphones','Telugu Dubbed':'headphones','New in 2026':'calendar'};
const genreIcons={Action:'swords',Adventure:'compass',Animation:'sparkles',Comedy:'laugh',Crime:'shield',Documentary:'film',Drama:'theater',Family:'users',Fantasy:'wand',Horror:'ghost',Mecha:'cpu',Music:'music',Mystery:'search',Psychological:'brain',Romance:'heart','Sci-Fi':'rocket','Slice of Life':'coffee',Sports:'trophy',Supernatural:'sparkles',Thriller:'zap'};
function sectionTitle(title,icon='sparkles',tag='h2'){return `<${tag} class="section-title"><span class="section-icon">${ico(icon)}</span><span>${esc(title)}</span></${tag}>`}

// Randomized, demand-loaded category rows. Only nearby rows have cards in
// the DOM; measured placeholders preserve scroll position and are reversible.
const shuffleRows=list=>{let a=[...list];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
function stopBrowseRows(){if(!browseRowsSession)return;browseRowsSession.stopped=true;browseRowsSession.observer?.disconnect();browseRowsSession.sentinelObserver?.disconnect();browseRowsSession=null}
function startBrowseRows(){
 stopBrowseRows();
 const area=document.querySelector('#browse-categories'),sentinel=document.querySelector('#browse-sentinel');
 if(!area||!sentinel)return;
 const session={stopped:false,queue:shuffleRows([...catalogGenres,...Object.keys(collectionIcons)]),cycle:1,serial:0,cache:new Map(),busy:false,empty:0};
 browseRowsSession=session;
 const alive=()=>browseRowsSession===session&&!session.stopped&&area.isConnected;
 function endpoint(row){return `/api/${row.kind==='collection'?'collection':'genre'}?home=1&name=${encodeURIComponent(row.name)}&page=${row.page}`}
 function cacheSet(key,value){session.cache.delete(key);session.cache.set(key,value);while(session.cache.size>24)session.cache.delete(session.cache.keys().next().value)}
 function mount(el,rows){
  if(!alive()||!el.isConnected||el.dataset.near!=='1')return;
  el.style.height='';el.classList.remove('is-virtual');
  if(!rows.length){el.remove();return}
  const name=el.dataset.name,icon=genreIcons[name]||collectionIcons[name]||'sparkles';
  const destination=el.dataset.kind==='collection'?`/browse?collection=${encodeURIComponent(name)}`:`/browse?genre=${encodeURIComponent(name)}`;
  el.innerHTML=`<div class="category-heading"><h2 class="section-title"><a href="${destination}" class="category-title-link"><span class="section-icon">${ico(icon)}</span><span>${esc(name)}</span></a></h2></div>${grid(rows.slice(0,12))}`;
  el.removeAttribute('aria-busy');
 }
 async function populate(el){
  if(!alive()||!el.isConnected||el.dataset.fetching==='1')return;
  const key=el.dataset.key,cached=session.cache.get(key);
  if(cached){cacheSet(key,cached);mount(el,cached);return}
  el.dataset.fetching='1';el.setAttribute('aria-busy','true');
  const row={name:el.dataset.name,kind:el.dataset.kind,page:Number(el.dataset.page)};
  try{
   let d=await get(endpoint(row));if(!alive()||!el.isConnected)return;
   let rows=(d.items||[]).filter(x=>x?.poster&&x?.title);
   cacheSet(key,rows);session.empty=rows.length?0:session.empty+1;
   if(!rows.length){el.remove();if(session.empty>=8){session.exhausted=true;session.sentinelObserver?.disconnect();sentinel.textContent='You are all caught up.'}return}
   mount(el,rows);
  }catch{if(alive()&&el.isConnected){el.innerHTML='<div class="category-unavailable">This category is temporarily unavailable.</div>';el.style.height='';el.removeAttribute('aria-busy')}}
  finally{delete el.dataset.fetching}
 }
 session.observer=new IntersectionObserver(entries=>{
  for(const entry of entries){const el=entry.target;if(!alive()||!el.isConnected)continue;
   el.dataset.near=entry.isIntersecting?'1':'0';
   if(entry.isIntersecting)populate(el);
   else if(el.children.length&&!el.querySelector('.category-unavailable')){
    const height=el.getBoundingClientRect().height;if(height>30){el.style.height=height+'px';el.classList.add('is-virtual');el.replaceChildren()}
   }
  }
 },{rootMargin:'1200px 0px'});
 function nextRow(){
  if(!session.queue.length){session.cycle++;session.queue=shuffleRows(catalogGenres)}
  const name=session.queue.shift(),kind=Object.hasOwn(collectionIcons,name)?'collection':'genre';
  return {name,kind,page:kind==='collection'?1:session.cycle};
 }
 function append(){
  if(!alive()||session.busy||session.exhausted)return;session.busy=true;
  for(let i=0;i<2;i++){
   const row=nextRow(),el=document.createElement('section');el.className='genre-section category-row is-virtual';
   el.dataset.name=row.name;el.dataset.kind=row.kind;el.dataset.page=String(row.page);el.dataset.key=String(++session.serial);
   el.style.height=window.innerWidth<650?'780px':'650px';el.innerHTML='<div class="loading category-loading">Loading category…</div>';
   area.append(el);session.observer.observe(el);
  }
  session.busy=false;
  // A short row can leave the sentinel inside its root margin after append.
  // Reobserve it after layout so loading continues rather than stalling at the bottom.
  requestAnimationFrame(()=>{if(alive()&&!session.exhausted){session.sentinelObserver?.unobserve(sentinel);session.sentinelObserver?.observe(sentinel)}});
 }
 session.sentinelObserver=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting))append()},{rootMargin:'1400px 0px'});
 append();session.sentinelObserver.observe(sentinel);
}

// A Spotlight slide transition keeps the outgoing and incoming slides in a
// clipped stage. Pointer swipes deliberately follow kozuTV's requested
// direction: left = previous; right = next.
let heroGesture=null,suppressHeroClickUntil=0,suppressHeroPoint=null;
function reducedMotion(){return readPreference('kozutv-reduce-motion','false')==='true'||window.matchMedia?.('(prefers-reduced-motion: reduce)').matches}
function showSlide(next,direction=1){
 const stage=document.querySelector('.hero-stage'),current=stage?.querySelector('.hero:not(.hero-leaving)');
 if(!current||!spotlightItems.length)return;
 const count=spotlightItems.length,index=((next%count)+count)%count;if(index===slide)return;
 stage.querySelectorAll('.hero-leaving').forEach(el=>el.remove());
 slide=index;
 const frag=document.createRange().createContextualFragment(hero(spotlightItems)),incoming=frag.firstElementChild;
 if(reducedMotion()){current.replaceWith(incoming);return}
 current.classList.add('hero-leaving',direction<0?'hero-leave-left':'hero-leave-right');
 current.setAttribute('aria-hidden','true');current.setAttribute('inert','');
 incoming.classList.add(direction<0?'hero-enter-right':'hero-enter-left');
 stage.append(incoming);
 setTimeout(()=>{current.remove();incoming.classList.remove('hero-enter-right','hero-enter-left')},470);
}
document.addEventListener('pointerdown',event=>{
 const hero=event.target.closest?.('.hero:not(.hero-leaving)');
 if(!hero||event.button!==0||event.target.closest('button,input,select')||!spotlightItems.length)return;
 heroGesture={id:event.pointerId,x:event.clientX,y:event.clientY};
});
document.addEventListener('pointercancel',event=>{if(heroGesture?.id===event.pointerId)heroGesture=null});
document.addEventListener('pointerup',event=>{
 if(!heroGesture||heroGesture.id!==event.pointerId)return;
 const dx=event.clientX-heroGesture.x,dy=event.clientY-heroGesture.y;heroGesture=null;
 if(Math.abs(dx)<55||Math.abs(dx)<Math.abs(dy)*1.35)return;
 suppressHeroClickUntil=performance.now()+500;suppressHeroPoint={x:event.clientX,y:event.clientY};
 showSlide(slide+(dx<0?-1:1),dx<0?-1:1);
});
document.addEventListener('click',event=>{
 if(event.detail&&performance.now()<suppressHeroClickUntil&&suppressHeroPoint&&Math.hypot(event.clientX-suppressHeroPoint.x,event.clientY-suppressHeroPoint.y)<28){
  suppressHeroClickUntil=0;event.preventDefault();event.stopImmediatePropagation();
 }
},true);
document.addEventListener('dragstart',event=>{if(event.target.closest?.('.hero'))event.preventDefault()});
const carousel=setInterval(()=>{
 if(readPreference('kozutv-spotlight-autoplay','true')==='false'||location.pathname!=='/browse'||params().has('genre')||params().has('collection')||params().has('q')||search.value.trim()||document.hidden||!spotlightItems.length)return;
 showSlide(slide+1,1);
},6500);

function drawCatalog(filtered=false,term='',isGenre=false){
 let data=items.filter(x=>x.poster&&x.title);
 let continueSection=!filtered&&continueItems.length?`<section class="continue-section home-continue">${sectionTitle('Continue Watching','history')}${continueGrid(continueItems)}</section>`:'';
 let categories=!filtered?'<div id="browse-categories"></div><div id="browse-sentinel" class="browse-sentinel" aria-live="polite"></div>':'';
 let isGenrePage=filtered&&pagedState.mode==='genre';
 let moreResults=filtered&&!isGenrePage&&pagedState.hasMore?`<div class="category-more"><button class="category-more-button" data-more-results aria-label="Show more titles">${ico('plus')}<span>Show more</span></button></div>`:'';
 let headingIcon=filtered?(isGenre?(genreIcons[term]||collectionIcons[term]||'sparkles'):'search'):'flame';
 let headingText=filtered?(isGenre?term:`Results for “${term}”`):'Trending Now';
 let headingTag=filtered?'h1':'h2';
 app.innerHTML=`${!filtered&&spotlightItems.length?`<div class="hero-stage">${hero(spotlightItems)}</div>`:''}<div class="container content">${continueSection}${sectionTitle(headingText,headingIcon,headingTag)}${isGenrePage?'<div id="genre-pages"></div><div id="genre-sentinel" class="genre-sentinel" aria-live="polite"></div>':grid(data,filtered?'paged-grid':'')}${!filtered&&suggestions.length?`<section class="suggestions">${sectionTitle('Suggested for you','sparkles')}${grid(suggestions)}</section>`:''}${categories}${moreResults}</div>`;
}

// Genre pages keep only a small LRU of item records and nearby card DOM. Each
// measured page is replaced with a reversible height-preserving placeholder.
// Refetching an evicted page is cheap because the server caches normalized pages.
function stopGenrePages(){
 const session=genrePagesSession;if(!session)return;
 session.stopped=true;session.observer?.disconnect();session.sentinelObserver?.disconnect();
 for(const controller of session.controllers)controller.abort();
 window.removeEventListener('resize',session.onResize);genrePagesSession=null;
}
function startGenrePages(){
 stopGenrePages();
 const area=document.querySelector('#genre-pages'),sentinel=document.querySelector('#genre-sentinel');
 if(!area||!sentinel)return;
 const session={stopped:false,page:1,hasMore:pagedState.hasMore,busy:false,error:false,empty:0,seen:new Set(),cache:new Map(),records:[],controllers:new Set()};
 genrePagesSession=session;
 const alive=()=>genrePagesSession===session&&!session.stopped&&area.isConnected;
 const itemKey=x=>`${x.type}:${x.id}`;
 const valid=x=>x?.poster&&x?.title&&x?.type&&x?.id;
 function cacheSet(page,rows){session.cache.delete(page);session.cache.set(page,rows);while(session.cache.size>8)session.cache.delete(session.cache.keys().next().value)}
 function columns(){return innerWidth<=380?2:innerWidth<=650?3:innerWidth<=800?4:innerWidth<=1050?5:6}
 function gaps(){return innerWidth<=380?[11,18]:innerWidth<=650?[10,19]:[16,24]}
 function mount(record,rows){
  const el=record.el;if(!alive()||!el.isConnected||el.dataset.near!=='1')return;
  el.style.height='';el.removeAttribute('aria-hidden');el.classList.remove('is-virtual');
  el.innerHTML=rows.length?`<div class="grid">${rows.map(card).join('')}</div>`:'<div class="empty">These titles are temporarily unavailable.</div>';
 }
 async function fetchPage(page){
  const controller=new AbortController();session.controllers.add(controller);
  try{return await responseJSON(await fetch(`${pagedState.endpointBase}&page=${page}`,{signal:controller.signal}))}
  finally{session.controllers.delete(controller)}
 }
 async function populate(record){
  const el=record.el;if(!alive()||el.dataset.fetching==='1')return;
  const cached=session.cache.get(record.page);
  if(cached){cacheSet(record.page,cached);mount(record,cached);return}
  el.dataset.fetching='1';
  try{
   const d=await fetchPage(record.page);if(!alive())return;
   const wanted=new Set(record.keys),rows=(d.items||[]).filter(x=>valid(x)&&wanted.has(itemKey(x)));
   cacheSet(record.page,rows);mount(record,rows);
  }catch(error){
   if(alive()&&error?.name!=='AbortError'&&el.dataset.near==='1'){
    el.style.height='';el.classList.remove('is-virtual');el.removeAttribute('aria-hidden');
    el.innerHTML='<div class="empty">This page could not be loaded. <button type="button" class="btn secondary" data-genre-page-retry>Try again</button></div>';
   }
  }finally{delete el.dataset.fetching}
 }
 session.observer=new IntersectionObserver(entries=>{
  for(const entry of entries){
   const el=entry.target,record=el._genreRecord;if(!alive()||!record||!el.isConnected)continue;
   el.dataset.near=entry.isIntersecting?'1':'0';
   if(entry.isIntersecting)populate(record);
   else if(el.children.length&&!el.querySelector('[data-genre-page-retry]')){
    const height=el.getBoundingClientRect().height;
    if(height>30){record.measure={height,width:area.clientWidth,cols:columns(),gaps:gaps()};el.style.height=height+'px';el.classList.add('is-virtual');el.setAttribute('aria-hidden','true');el.replaceChildren()}
   }
  }
 },{rootMargin:'1400px 0px'});
 function addRecord(page,rows){
  if(!rows.length)return;
  const el=document.createElement('section'),record={page,keys:rows.map(itemKey),el,measure:null};
  el.className='genre-page';el.dataset.page=String(page);el.dataset.near='1';el._genreRecord=record;
  session.records.push(record);area.append(el);cacheSet(page,rows);mount(record,rows);session.observer.observe(el);
 }
 const initial=items.filter(valid).filter(x=>{const k=itemKey(x);if(session.seen.has(k))return false;session.seen.add(k);return true});
 addRecord(1,initial);
 if(!initial.length&&!session.hasMore)area.innerHTML='<div class="empty">No titles found.</div>';
 async function loadMore(){
  if(!alive()||session.busy||!session.hasMore||session.error)return;
  session.busy=true;sentinel.innerHTML='<span class="button-loader" aria-label="Loading"></span>';
  try{
   const next=session.page+1,d=await fetchPage(next);if(!alive())return;
   session.page=next;
   const fresh=(d.items||[]).filter(valid).filter(x=>{const k=itemKey(x);if(session.seen.has(k))return false;session.seen.add(k);return true});
   session.empty=fresh.length?0:session.empty+1;addRecord(next,fresh);
   // Avoid retry loops on finite or broken upstream catalogs, including pages
   // that contain only duplicates or unusable posters.
   session.hasMore=Boolean(d.hasMore)&&next<2000&&session.empty<4;
   sentinel.innerHTML='';
   if(!session.hasMore)session.sentinelObserver?.disconnect();
  }catch(error){
   if(alive()&&error?.name!=='AbortError'){
    session.error=true;session.sentinelObserver?.disconnect();
    sentinel.innerHTML='<button type="button" class="btn secondary" data-genre-retry>Try again</button>';
   }
  }finally{
   session.busy=false;
   requestAnimationFrame(()=>{if(alive()&&session.hasMore&&!session.error){session.sentinelObserver?.unobserve(sentinel);session.sentinelObserver?.observe(sentinel)}});
  }
 }
 session.retry=()=>{if(!alive())return;session.error=false;sentinel.innerHTML='';loadMore()};
 session.retryPage=el=>{const record=el.closest('.genre-page')?._genreRecord;if(record)populate(record)};
 session.sentinelObserver=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting))loadMore()},{rootMargin:'1400px 0px'});
 if(session.hasMore)session.sentinelObserver.observe(sentinel);
 let resizeFrame=0;
 session.onResize=()=>{
  cancelAnimationFrame(resizeFrame);resizeFrame=requestAnimationFrame(()=>{
   if(!alive())return;const width=area.clientWidth,cols=columns(),[colGap,rowGap]=gaps();
   for(const r of session.records){
    const m=r.measure;if(!m||!r.el.classList.contains('is-virtual')||!r.keys.length)continue;
    const oldRows=Math.ceil(r.keys.length/m.cols),newRows=Math.ceil(r.keys.length/cols);
    const oldPoster=(m.width-(m.cols-1)*m.gaps[0])/m.cols*1.5;
    const extra=Math.max(0,(m.height+m.gaps[1])/oldRows-oldPoster-m.gaps[1]);
    const poster=(width-(cols-1)*colGap)/cols*1.5;
    const height=Math.max(1,newRows*(poster+extra+rowGap)-rowGap);
    r.el.style.height=height+'px';r.measure={height,width,cols,gaps:[colGap,rowGap]};
   }
  });
 };
 window.addEventListener('resize',session.onResize,{passive:true});
}

const icons={
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
 bookmark:'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
 autoplay:'<path d="M21 12a9 9 0 1 1-2.64-6.36L21 8"/><path d="M21 3v5h-5"/>',
 autonext:'<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
 autoskip:'<path d="m3 5 8 7-8 7z"/><path d="m13 5 8 7-8 7z"/>',
 light:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.66 6.34l1.41-1.41"/>',
 prev:'<path d="M19 20 9 12l10-8z"/><path d="M5 19V5"/>',
 next:'<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
 expand:'<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 check:'<path d="m5 12 4 4L19 6"/>',
 'bookmark-plus':'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/><path d="M12 7v6M9 10h6"/>',
 'bookmark-check':'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/><path d="m9 10 2 2 4-4"/>',
 star:'<path d="m12 2 3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01z"/>',
 calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
 tv:'<rect x="2" y="7" width="20" height="13" rx="2"/><path d="m17 2-5 5-5-5"/>',
 film:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4"/>',
 play:'<path d="m8 5 11 7-11 7z"/>',
 playback:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m10 8 5 4-5 4z"/>',
 flame:'<path d="M12 22c4.4 0 8-3.2 8-7.5 0-2.2-1.1-4.2-3-6.5.1 2-1 3.5-2.2 4.2.3-3.8-1.7-7.2-5.3-10.2.2 3.5-1.8 5.7-3.3 7.6C5.1 11.1 4 12.8 4 14.5 4 18.8 7.6 22 12 22Z"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>',
 compass:'<circle cx="12" cy="12" r="9"/><path d="m16 8-2.5 5.5L8 16l2.5-5.5Z"/>',
 sparkles:'<path d="m12 3 1.3 3.7L17 8l-3.7 1.3L12 13l-1.3-3.7L7 8l3.7-1.3ZM5 14l.9 2.1L8 17l-2.1.9L5 20l-.9-2.1L2 17l2.1-.9ZM18 14l.9 2.1L21 17l-2.1.9L18 20l-.9-2.1L15 17l2.1-.9Z"/>',
 laugh:'<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 3 4 3 4-3 4-3ZM9 9h.01M15 9h.01"/>',
 theater:'<path d="M4 4h16v6a8 8 0 0 1-16 0ZM8 9h.01M16 9h.01M8 13c2 1.5 6 1.5 8 0M12 18v3M8 21h8"/>',
 wand:'<path d="m15 4 5 5L8 21H3v-5ZM14 6l4 4M6 3v3M4.5 4.5h3M20 15v4M18 17h4"/>',
 ghost:'<path d="M5 21V10a7 7 0 0 1 14 0v11l-2.5-2-2.3 2-2.2-2-2.2 2-2.3-2ZM9 10h.01M15 10h.01"/>',
 zap:'<path d="M13 2 4 14h7l-1 8 9-12h-7Z"/>',
 swords:'<path d="m14.5 4.5 5-1-1 5L8 19l-3 1 1-3ZM14 9l3 3M4 4l16 16M4 9l-1-5 5 1 11 11"/>',
 shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
 users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
 cpu:'<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
 music:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
 brain:'<path d="M12 5a3 3 0 1 0-6 .1 4 4 0 0 0-2.5 5.8 4 4 0 0 0 .5 6.6A4 4 0 1 0 12 18ZM12 5a3 3 0 1 1 6 .1 4 4 0 0 1 2.5 5.8 4 4 0 0 1-.5 6.6A4 4 0 1 1 12 18ZM12 5v13"/>',
 rocket:'<path d="M14 4c3-3 7-2 7-2s1 4-2 7l-7 7-5-5Z"/><path d="m7 11-4 1 3 3M12 16l-1 4 3-3"/><circle cx="16" cy="8" r="1"/><path d="M7 17c-2 1-3 3-3 5 2 0 4-1 5-3"/>',
 coffee:'<path d="M17 8h1a4 4 0 1 1 0 8h-1M3 8h14v7a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4ZM6 2v2M10 2v2M14 2v2"/>',
 trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0ZM7 6H4v2a4 4 0 0 0 4 4M17 6h3v2a4 4 0 0 1-4 4"/>',
 history:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l3 2"/>',
 sliders:'<path d="M4 6h10M18 6h2M4 12h3M11 12h9M4 18h8M16 18h4"/><circle cx="16" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="14" cy="18" r="2"/>',
 shuffle:'<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 episodes:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 9h8M8 13h5"/>',
 home:'<path d="m3 11 9-8 9 8v9a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
 headphones:'<path d="M3 14v-3a9 9 0 0 1 18 0v3"/><path d="M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM21 14h-3a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2z"/>',
 settings:'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
 key:'<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3 2-2-3-3"/>',
 copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
 lock:'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
 chevron:'<path d="m7 10 5 5 5-5"/>'
};
function ico(n,extra=''){return `<svg class="ui-icon ${extra}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${icons[n]||''}</svg>`}

function animeEpisodeRow(x,id,active){
 let art=x.still||detail?.item.backdrop||detail?.item.poster;
 let src=art?safeImage(art):FALLBACK_STILL_DATA_URI;
 return `<button class="episode-row ${x.number===active?'selected':''}" data-open="/watch/anime/${id}?episode=${x.number}&lang=${lang}"><img loading="lazy" src="${src}" data-alt-src="${safeImage(detail?.item?.backdrop||detail?.item?.poster||'')}" alt=""><span><strong>${x.number}. ${esc(x.title||`Episode ${x.number}`)}</strong>${x.description?`<small>${esc(short(x.description,190))}</small>`:''}</span></button>`;
}
function renderAnimeEpisodes(mode){
 let state=animeEpisodeLists[mode],container=document.querySelector(`#${mode}-anime-episodes`);if(!state||!container)return;
 let pages=[...state.pages.keys()].sort((a,b)=>a-b),episodes=new Map();
 for(let page of pages)for(let x of state.pages.get(page).episodes||[])if((!state.startFrom||x.number>=state.startFrom)&&(!state.endAt||x.number<=state.endAt))episodes.set(x.number,x);
 let last=pages.at(-1)||1,lastRows=state.pages.get(last)?.episodes||[],more=state.pages.get(last)?.hasNext&&(!state.endAt||!lastRows.length||Number(lastRows.at(-1)?.number)<state.endAt),button=(page,label)=>`<div class="anime-pagination"><button class="btn secondary" data-anime-page="${page}" data-anime-mode="${mode}">${label}</button></div>`;
 container.innerHTML=state.error?'<div class="empty">Episodes are unavailable right now.</div>':`<div class="episode-detail-list anime-episode-list">${[...episodes.values()].sort((a,b)=>a.number-b.number).map(x=>animeEpisodeRow(x,state.id,state.active)).join('')||'<div class="empty">No episodes listed.</div>'}</div>${more?button(last+1,'Show more'):''}`;
}
async function loadAnimeEpisodes(id,mode,page=1,active=0,reset=false,startFrom=0,endAt=0){
 let container=document.querySelector(`#${mode}-anime-episodes`);if(!container)return;
 let epLang=ANIME_REGIONAL_LANGS.includes(lang)?lang:(lang==='dub'?'dub':'sub');
 let state=animeEpisodeLists[mode];
 if(reset||!state||state.id!==id||state.epLang!==epLang){state={id,epLang,pages:new Map(),active,error:'',loading:false,startFrom,endAt};animeEpisodeLists[mode]=state;container.innerHTML='<div class="loading">Loading episodes…</div>'}
 if(state.loading)return;state.loading=true;state.error='';let clicked=container.querySelector(`[data-anime-page="${page}"]`);if(clicked){clicked.disabled=true;clicked.innerHTML='<span class="button-loader" aria-label="Loading"></span>';clicked.classList.add('is-loading')}
 try{let d=await get(`/api/anime-episodes?id=${id}&page=${page}&lang=${epLang}`);if(animeEpisodeLists[mode]!==state)return;state.pages.set(page,d);state.active=active||state.active}
 catch(e){state.error=e.message;if(reset)state.pages.clear()}
 finally{state.loading=false;if(animeEpisodeLists[mode]===state)renderAnimeEpisodes(mode)}
}

function tvEpisodeRow(e,id,seasonNum,active){
 let art=e.still||detail?.item?.backdrop||detail?.item?.poster;
 let src=art?safeImage(art):FALLBACK_STILL_DATA_URI;
 return `<button class="episode-row ${e.number===active?'selected':''}" data-open="/watch/tv/${id}?season=${seasonNum}&episode=${e.number}"><img loading="lazy" src="${src}" data-alt-src="${safeImage(detail?.item?.backdrop||detail?.item?.poster||'')}" alt=""><span><strong>${e.number}. ${esc(e.title)}</strong>${e.description?`<small>${esc(short(e.description,160))}</small>`:''}</span></button>`;
}
function renderTvEpisodes(mode){
 let st=tvEpisodeLists[mode];
 let box=document.querySelector(mode==='detail'?'#detail-episodes':'#watch-episodes');
 if(!st||!box)return;
 if(!st.episodes.length){
  box.innerHTML=mode==='detail'?'No episode information available.':'No episodes available.';
  return;
 }
 let slice=st.episodes.slice(st.startIdx,st.endIdx);
 let prevBtn=st.startIdx>0?`<div class="anime-pagination"><button class="btn secondary" type="button" data-tv-more="prev" data-tv-mode="${mode}">Show earlier episodes</button></div>`:'';
 let nextBtn=st.endIdx<st.episodes.length?`<div class="anime-pagination"><button class="btn secondary" type="button" data-tv-more="next" data-tv-mode="${mode}">Show more</button></div>`:'';
 box.innerHTML=prevBtn+slice.map(e=>tvEpisodeRow(e,st.id,st.seasonNum,st.active)).join('')+nextBtn;
}
async function loadTvEpisodes(mode,id,seasonNum,active=0){
 let box=document.querySelector(mode==='detail'?'#detail-episodes':'#watch-episodes');
 if(!box)return;
 const request=++tvEpisodeRequest[mode];
 box.innerHTML='<div class="loading">Loading episodes…</div>';
 try{
  let d=await get(`/api/season?id=${id}&season=${seasonNum}`);
  if(request!==tvEpisodeRequest[mode]||!box.isConnected)return;
  let eps=Array.isArray(d.episodes)?d.episodes:[];
  let startIdx=0,endIdx=eps.length;
  if(eps.length>TV_EP_CHUNK){
   if(active>0){
    let activePos=eps.findIndex(e=>Number(e.number)===Number(active));
    if(activePos<0)activePos=0;
    startIdx=Math.floor(activePos/TV_EP_CHUNK)*TV_EP_CHUNK;
    endIdx=Math.min(eps.length,startIdx+TV_EP_CHUNK);
   }else{
    startIdx=0;
    endIdx=TV_EP_CHUNK;
   }
  }
  tvEpisodeLists[mode]={id,seasonNum,active,episodes:eps,startIdx,endIdx};
  renderTvEpisodes(mode);
 }catch{
  if(request===tvEpisodeRequest[mode]&&box.isConnected)box.textContent='Episodes unavailable right now.';
 }
}
async function loadDetailEpisodes(id,num){return loadTvEpisodes('detail',id,num,0)}
async function loadWatchEpisodes(id,number,active){return loadTvEpisodes('watch',id,number,active)}

function watchlistButton(){return `<button class="btn secondary" data-save>${ico('plus')}<span class="desktop-action">Add to Watchlist</span><span class="mobile-action">Add</span></button>`}

function episodeTargets(){
 if(!detail||isFeature(detail.item))return {prev:null,next:null};let x=detail.item;
 if(x.type==='anime'){
  let seasons=Array.isArray(detail.seasons)?detail.seasons:[],count=effectiveAnimeEpisodeCount(x,lang),own=n=>({type:'anime',id:x.id,season:1,episode:n});
  const groups=Array.isArray(detail.pokemonRegions)?detail.pokemonRegions:[];
  const gi=groups.findIndex(g=>String(g.id)===String(x.id)&&episode>=g.startEp&&episode<=g.endEp);
  const prior=nextAvailableAnimeNumber(x,episode,-1),following=nextAvailableAnimeNumber(x,episode,1);
  if(String(x.id)==='40351'&&episode>=137&&episode<=146){
   return {prev:own(episode-1),next:episode<146?own(episode+1):{type:'anime',id:'53874',season:1,episode:11}};
  }
  if(gi>=0){const g=groups[gi],before=groups[gi-1],after=groups[gi+1];
   return {prev:prior&&prior>=g.startEp?own(prior):before?{type:'anime',id:before.id,season:1,episode:before.endEp}:null,
    next:following&&following<=Math.min(g.endEp,count)?own(following):after?{type:'anime',id:after.id,season:1,episode:after.startEp}:null};
  }
  let index=seasons.findIndex(s=>String(s.id)===String(x.id));
  return {prev:prior&&prior>=1?own(prior):index>0?{type:'anime',id:seasons[index-1].id,season:1,episode:Math.max(1,Number(seasons[index-1].episodes)||1)}:null,next:following&&following<=count?own(following):index>=0&&seasons[index+1]?{type:'anime',id:seasons[index+1].id,season:1,episode:1}:null};
 }
 let seasons=(detail.seasons||[]).filter(s=>Number(s.episodes)>0).sort((a,b)=>a.number-b.number),index=seasons.findIndex(s=>Number(s.number)===Number(season)),current=seasons[index],count=Math.max(1,Number(current?.episodes)||1),own=n=>({type:'tv',id:x.id,season,episode:n});
 return {prev:episode>1?own(episode-1):index>0?{type:'tv',id:x.id,season:seasons[index-1].number,episode:Number(seasons[index-1].episodes)}:null,next:episode<count?own(episode+1):index>=0&&seasons[index+1]?{type:'tv',id:x.id,season:seasons[index+1].number,episode:1}:null};
}

function timeAgo(timestamp){let seconds=Math.round((Number(timestamp)-Date.now())/1000),abs=Math.abs(seconds),unit=abs>=86400?'day':abs>=3600?'hour':abs>=60?'minute':'second',value=Math.round(seconds/(unit==='day'?86400:unit==='hour'?3600:unit==='minute'?60:1)),r=new Intl.RelativeTimeFormat('en',{numeric:'auto'});return r.format(value,unit)}

function pickInitialAnimeLang(x,urlLang=''){
 let u=String(urlLang||'').toLowerCase();
 if(ANIME_LANGS.includes(u))return u;
 let saved='';
 try{saved=String(localStorage.getItem('kozutv-anime-lang')||'').toLowerCase()}catch{}
 if(ANIME_LANGS.includes(saved))return saved;
 if(x.regionalDefault)return x.regionalDefault;
 return x.sub===false&&x.dub?'dub':'sub';
}

async function details(type,id){
 const route=routeGeneration;
 app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let d=await get(`/api/detail?type=${type}&id=${id}`);if(route!==routeGeneration)return;detail=d;let x=d.item,resumeEpisode=0,resumeSeason=1,state=await get('/api/state');if(route!==routeGeneration)return;savedKeys=new Set((state.watchlist||[]).map(i=>i.type+':'+i.id));
  if(type==='anime'){
   if(String(x.id)!==String(id))history.replaceState({},'',url('anime',x.id));
   lang=pickInitialAnimeLang(x,'');
  }
  if(type==='anime'&&!x.upcoming){let requested=Number(params().get('episode'))||0,seen=state.history.find(h=>h.type==='anime'&&h.id===x.id);if(requested>0||seen){resumeEpisode=Math.max(1,requested||Number(seen.episode)||1);let maxEp=effectiveAnimeEpisodeCount(x,lang);if(maxEp)resumeEpisode=Math.min(resumeEpisode,maxEp)}}
  else if(type==='tv'&&!x.upcoming){let seen=state.history.find(h=>h.type==='tv'&&h.id===x.id);if(seen){resumeEpisode=Math.max(1,Number(seen.episode)||1);resumeSeason=Math.max(1,Number(seen.season)||1)}}
  document.title=`${x.title} — kozuTV`;
  let watch=type==='tv'&&resumeEpisode?`/watch/tv/${x.id}?season=${resumeSeason}&episode=${resumeEpisode}`:`/watch/${type}/${x.id}${resumeEpisode?`?episode=${resumeEpisode}`:''}`;
  let watchLabel=resumeEpisode?'Continue':'Watch Now';
  let epDisplayCount=type==='anime'?effectiveAnimeEpisodeCount(x,lang):x.episodes;
  let showEpisodes=!x.upcoming&&!isFeature(x),actions=`<div class="actions">${!x.upcoming?`<button class="btn" data-open="${watch}">${ico('play')}<span>${watchLabel}</span></button>`:''}${watchlistButton()}</div>`;
  let regSeasonSelect=type==='anime'&&showEpisodes?(renderPokemonSelect(d,'detail',resumeEpisode||1)||renderRegionalSeasonSelect(d,'detail',resumeEpisode||1,lang)):'';
  app.innerHTML=`<div class="container content detail"><div class="detail-layout"><img class="detail-poster" src="${safeImage(x.poster)}" alt="${esc(x.title)}"><div class="detail-heading"><h1>${esc(x.title)}</h1><div class="meta"><span>${ico('star')}${esc(x.rating||'N/A')}</span><span class="quality">HD</span>${x.upcoming?'<span class="upcoming-badge">Upcoming</span>':showEpisodes&&epDisplayCount?`<span>${epDisplayCount} episodes</span>`:''}</div></div><div class="detail-body"><div class="description detail-description" data-description-toggle role="button" tabindex="0" aria-expanded="false">${esc(x.description||'No description available.')}</div><div class="chips">${(x.genres||[]).map(g=>`<span class="chip">${esc(g)}</span>`).join('')}</div>${actions}</div></div>${type==='anime'&&showEpisodes?`<section class="season-section">${sectionTitle((d.seasons.length>1||regSeasonSelect)?'Seasons & Episodes':'Episodes','episodes')}${regSeasonSelect||((d.seasons.length>1)?`<select class="season-select" id="detail-anime-season" aria-label="Anime season">${d.seasons.map(s=>`<option value="${s.id}" ${String(s.id)===String(x.id)?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:'')}<div id="detail-anime-episodes" class="anime-episodes"><div class="loading">Loading…</div></div></section>`:''}${type==='tv'&&!x.upcoming?`<section class="season-section">${sectionTitle('Seasons & Episodes','episodes')}<select class="season-select" id="detail-tv-season" aria-label="Season">${d.seasons.map(s=>`<option value="${s.number}">${esc(s.name)}</option>`).join('')}</select><div id="detail-episodes" class="episode-detail-list">Loading…</div></section>`:''}</div>`;
  updateSave(state);
  if(type==='tv'&&!x.upcoming&&d.seasons?.length)loadDetailEpisodes(x.id,d.seasons[0].number);
  if(type==='anime'&&showEpisodes){const r=pokemonRegion(d,x.id,resumeEpisode||1);loadAnimeEpisodes(x.id,'detail',resumeEpisode?Math.floor((resumeEpisode-1)/20)+1:1,resumeEpisode,true,r?.startEp||resumeEpisode,r?.endEp||0)}
 }catch(e){if(route===routeGeneration)failure(e)}
}

async function updateSave(state=null){
 if(!detail)return;let d=state||await get('/api/state'),saved=d.watchlist.some(i=>i.id===detail.item.id&&i.type===detail.item.type),button=document.querySelector('.detail [data-save]');
 if(button)button.innerHTML=saved?`${ico('check')}<span class="desktop-action">In Watchlist</span><span class="mobile-action">Added</span>`:`${ico('plus')}<span class="desktop-action">Add to Watchlist</span><span class="mobile-action">Add</span>`;
}

function watchUrl(){
 let x=detail?.item;
 if(x.type==='anime')return `/watch/anime/${x.id}?episode=${episode}&lang=${lang}`;
 if(x.type==='movie')return `/watch/movie/${x.id}${provider&&provider!=='vidcore'?`?provider=${provider}`:''}`;
 return `/watch/tv/${x.id}?season=${season}&episode=${episode}${provider&&provider!=='vidcore'?`&provider=${provider}`:''}`;
}

// The fullscreen element is #player, not the episode list or Video.js child.
// Keep that element mounted while replacing only its contents and stream.
function watchEpisodesMarkup(d,x){
 if(isFeature(x))return '';
 const reg=x.type==='anime'?(renderPokemonSelect(d,'watch',episode)||renderRegionalSeasonSelect(d,'watch',episode,lang)):'';
 return `${sectionTitle('Episodes','episodes')}${x.type==='tv'?`<select class="season-select" id="season" aria-label="Season">${(d.seasons||[]).map(s=>`<option value="${s.number}" ${Number(s.number)===Number(season)?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:''}${reg||((x.type==='anime'&&(d.seasons||[]).length>1)?`<select class="season-select" id="anime-season" aria-label="Anime season">${d.seasons.map(s=>`<option value="${s.id}" ${String(s.id)===String(x.id)?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:'')}${x.type==='tv'?`<div id="watch-episodes" class="episode-detail-list"><div class="loading">Loading episodes…</div></div>`:`<div id="watch-anime-episodes" class="anime-episodes"><div class="loading">Loading episodes…</div></div>`}`;
}
function syncWatchEpisodePanel(rebuild=false){
 const x=detail?.item,area=document.querySelector('#watch-episode-area');
 if(!x||!area)return;
 const title=document.querySelector('#watch-title');if(title)title.textContent=x.title;
 document.title=`Watch ${x.title} — kozuTV`;
 if(rebuild){area.innerHTML=watchEpisodesMarkup(detail,x);animeEpisodeLists.watch=null;tvEpisodeLists.watch=null}
 if(isFeature(x))return;
 if(x.type==='tv'){
  const sel=area.querySelector('#season');if(sel)sel.value=String(season);
  const st=tvEpisodeLists.watch;
  if(st&&String(st.id)===String(x.id)&&Number(st.seasonNum)===Number(season)){
   st.active=episode;
   const pos=st.episodes.findIndex(e=>Number(e.number)===Number(episode));
   if(pos>=0&&(pos<st.startIdx||pos>=st.endIdx)){st.startIdx=Math.floor(pos/TV_EP_CHUNK)*TV_EP_CHUNK;st.endIdx=Math.min(st.episodes.length,st.startIdx+TV_EP_CHUNK)}
   renderTvEpisodes('watch');
  }else loadWatchEpisodes(x.id,season,episode);
 }else if(x.type==='anime'){
  const regSeasons=Array.isArray(detail.regionalSeasons)?detail.regionalSeasons:[];
  const rs=pokemonRegion(detail,x.id,episode)||(ANIME_REGIONAL_LANGS.includes(lang)?regSeasons.find(s=>episode>=s.startEp&&episode<=s.endEp):null);
  const sel=area.querySelector('#watch-regional-season');if(sel&&rs)sel.value=String(rs.startEp);
  const pokeSel=area.querySelector('#watch-pokemon-region');if(pokeSel&&rs)pokeSel.value=`${rs.id}:${rs.startEp}`;
  const st=animeEpisodeLists.watch,page=Math.floor((episode-1)/20)+1,epLang=ANIME_REGIONAL_LANGS.includes(lang)?lang:(lang==='dub'?'dub':'sub');
  if(st&&String(st.id)===String(x.id)&&st.epLang===epLang&&st.pages.has(page)&&(!rs||(st.startFrom===rs.startEp&&st.endAt===(rs.endEp||0)))){
   st.active=episode;renderAnimeEpisodes('watch');
  }else loadAnimeEpisodes(x.id,'watch',page,episode,true,rs?rs.startEp:0,rs?.endEp||0);
 }
}
async function switchWatchEpisode(target,{historyMode='push',nextLang='',nextProvider='',resolvedPayload=null}={}){
 const container=document.querySelector('#player');
 if(!target||!container||!detail?.item)return;
 const token=++episodeSwitchGeneration,oldItem=detail.item;
 // Video.js can be the fullscreen element on legacy browsers. Where the
 // standard API exists, move fullscreen to the stable parent before disposal.
 const full=document.fullscreenElement||document.webkitFullscreenElement;
 if(full&&full!==container&&container.contains(full)&&container.requestFullscreen){
  try{await container.requestFullscreen({navigationUI:'hide'})}catch{}
  if(token!==episodeSwitchGeneration||!container.isConnected)return;
 }
 // Snapshot the old coordinates before changing globals, so history never records
 // the old playback position against the new episode.
 if(videoPlayer&&!videoPlayer.isDisposed?.()){
  try{saveHistory({...oldItem,episode,season,currentTime:videoPlayer.currentTime()||0,duration:videoPlayer.duration()||0})}catch{}
 }
 const changedTitle=String(target.id)!==String(oldItem.id)||target.type!==oldItem.type;
 if(changedTitle){
  disposeVideo();container.innerHTML='<div class="loading">Loading player…</div>';
  try{
   const nextDetail=await get(`/api/detail?type=${target.type}&id=${target.id}`);
   if(token!==episodeSwitchGeneration||!container.isConnected)return;
   if(!nextDetail.item||nextDetail.item.upcoming)throw Error('This title is not available yet.');
   detail=nextDetail;
  }catch(error){if(token===episodeSwitchGeneration&&container.isConnected)showPlayerError(error);return}
 }
 if(token!==episodeSwitchGeneration||!container.isConnected)return;
 season=Math.max(0,Number(target.season)||0);episode=Math.max(1,Number(target.episode)||1);
 if(detail.item.type==='anime'){
  season=1;lang=pickInitialAnimeLang(detail.item,nextLang||lang);
  episode=isFeature(detail.item)?1:Math.min(episode,effectiveAnimeEpisodeCount(detail.item,lang));
 }else{
  if(nextProvider&&OTT_PROVIDERS.includes(nextProvider))provider=nextProvider;
  const current=(detail.seasons||[]).find(s=>Number(s.number)===Number(season));
  if(current?.episodes)episode=Math.min(episode,Number(current.episodes));
 }
 const destination=watchUrl();
 if(historyMode==='push')history.pushState({},'',destination);
 else if(historyMode==='replace')history.replaceState({},'',destination);
 syncWatchEpisodePanel(changedTitle);
 await play(detail.item,null,resolvedPayload?{firstPayload:resolvedPayload,skipResume:true}:null);
}
function changeEpisode(step){
 const target=episodeTargets()[step>0?'next':'prev'];
 if(target)switchWatchEpisode(target);
}

async function watch(type,id){
 const route=routeGeneration;
 app.innerHTML='<div class="loading">Preparing your player…</div>';
 let p=params();
 try{
  let d=await get(`/api/detail?type=${type}&id=${id}`);if(route!==routeGeneration)return;detail=d;let x=d.item;if(x.upcoming)throw Error('This title has not been released yet.');
  season=p.has('season')?Math.max(0,Number(p.get('season'))||0):1;
  episode=Math.max(1,Number(p.get('episode')||p.get('ep'))||1);
  if(type==='anime'){
   lang=pickInitialAnimeLang(x,p.get('lang')||'');
   if(x.isMovie)episode=1;
   else episode=Math.min(episode,effectiveAnimeEpisodeCount(x,lang));
   if(String(x.id)!==String(id))history.replaceState({},'',watchUrl());
  }else if(type==='tv'){
   let current=d.seasons.find(s=>Number(s.number)===Number(season));
   if(current?.episodes)episode=Math.min(episode,Number(current.episodes));
  }
  let requestedProvider=p.get('provider')||localStorage.getItem('kozutv-server-pref')||'vidcore';
  provider=type==='anime'?'megaplay':(OTT_PROVIDERS.includes(requestedProvider)?requestedProvider:'vidcore');
  document.title=`Watch ${x.title} — kozuTV`;
  app.innerHTML=`<div class="container content"><div class="player-wrap"><h1 class="watch-title" id="watch-title">${esc(x.title)}</h1><div class="player" id="player"><div class="loading">Loading player…</div></div><div id="watch-episode-area">${watchEpisodesMarkup(d,x)}</div></div></div>`;
  animeEpisodeLists.watch=null;tvEpisodeLists.watch=null;
  let state=await get('/api/state');
  if(route!==routeGeneration)return;
  await updateSave(state);
  if(route!==routeGeneration)return;
  if(type==='tv')loadWatchEpisodes(x.id,season,episode);
  else if(type==='anime'&&!x.isMovie){
   let rs=Array.isArray(d.regionalSeasons)?d.regionalSeasons:[];
   let curRegSeason=pokemonRegion(d,x.id,episode)||(ANIME_REGIONAL_LANGS.includes(lang)?rs.find(s=>episode>=s.startEp&&episode<=s.endEp):null);
   loadAnimeEpisodes(x.id,'watch',Math.floor((episode-1)/20)+1,episode,true,curRegSeason?curRegSeason.startEp:0,curRegSeason?.endEp||0);
  }
  await play(x,state);
 }catch(e){if(route===routeGeneration)failure(e)}
}

function showPlayerError(error){
 let container=document.querySelector('#player');if(!container)return failure(error);
 const raw=String(error?.message||'');
 const message=/selected language|requested audio|language is not|dub is not|sub is not|audio is unavailable|source did not provide/i.test(raw)?'No playable source is available right now.':(raw||'The stream could not be loaded.');
 container.innerHTML=`<div class="empty player-error"><strong>Playback unavailable</strong><span>${esc(message)}</span><button class="btn" data-retry>Try again</button></div>`;
}

function syncAnimeEpisodeRowLang(nextLang){
 document.querySelectorAll('.anime-episode-list [data-open]').forEach(btn=>{
  btn.dataset.open=btn.dataset.open.replace(/([?&]lang=)[^&]+/,`$1${encodeURIComponent(nextLang)}`);
 });
}

// Attempt the chosen anime language first, then English and Japanese. A plan
// records failed languages across both API and actual media errors, preventing
// retries from cycling. In incompatible catalogs each destination starts at 1.
async function play(x,state=null,attempts=null){
 disposeVideo();const generation=playGeneration;
 const isAnime=x.type==='anime',ctx=attempts||{};
 const plan=isAnime?(ctx.anime||newAnimePlan(lang,episode)):null;
 const candidate=isAnime?plan.order.find(value=>!plan.tried.includes(value)):'';
 if(isAnime&&!candidate){showPlayerError(Error('No playable source is available right now.'));return}
 const playingEpisode=isAnime?(isFeature(x)||animeNeedsEpisodeOne(x,plan.originLang,candidate)?1:plan.originEpisode):episode;
 const playingSeason=isAnime?1:season,requestedProvider=provider;
 if(isAnime)plan.tried.push(candidate);
 const playerContainer=document.querySelector('#player');
 if(playerContainer)playerContainer.innerHTML='<div class="loading">Loading player…</div>';
 try{
  let [,resolvedState]=await Promise.all([loadPlayerAssets(),state?Promise.resolve(state):get('/api/state')]);
  state=resolvedState;if(generation!==playGeneration)return;
  let d;
  try{
   if(isAnime&&ctx.firstPayload)d=ctx.firstPayload;
   else if(!isAnime&&ctx.ott?.payload)d=ctx.ott.payload;
   else {
    const excluded=!isAnime&&ctx.ott?.exclude?.length?`&exclude=${encodeURIComponent(ctx.ott.exclude.join(','))}`:'';
    d=await get(`/api/play?type=${x.type}&id=${x.id}&episode=${playingEpisode}&season=${playingSeason}&lang=${isAnime?candidate:lang}&provider=${requestedProvider}&anilistId=${x.anilistId||''}${excluded}`);
   }
   if(!d?.src)throw Error('The stream could not be loaded.');
   if(isAnime&&d.activeLang!==candidate)throw Error('The source did not provide the selected language.');
  }catch(error){
   if(generation!==playGeneration)return;
   if(isAnime&&plan.order.some(value=>!plan.tried.includes(value)))return play(x,state,{anime:plan,skipResume:ctx.skipResume});
   throw error;
  }
  if(generation!==playGeneration)return;
  const ottRaw=!isAnime?JSON.parse(JSON.stringify(d)):null;
  const ottSources=!isAnime?ottSourceOrder(ottRaw):[];
  const ottTried=new Set(ctx.ott?.audioTried||[]);
  if(!isAnime)d=ottWithSource(ottRaw,ottSources.find(source=>!ottTried.has(source.src)));
  if(isAnime){
   const changed=lang!==candidate||episode!==playingEpisode;
   lang=candidate;episode=playingEpisode;season=1;
   if(changed){history.replaceState({},'',watchUrl());syncWatchEpisodePanel(true)}
  }else if(OTT_PROVIDERS.includes(d.sourceKey)){
   // The resolver may have selected a different server; the URL and the menu
   // describe the actual source, without changing the saved preference.
   provider=d.sourceKey;history.replaceState({},'',watchUrl());
  }
  const clonePayload=payload=>JSON.parse(JSON.stringify(payload));
  let audioRequest=0,audioAbort=null,animePlan=plan;
  const animePlayCache=new Map(),regionalMap=new Map();
  if(isAnime){
   if(lang==='sub'||lang==='dub')animePlayCache.set(lang,clonePayload(d));
   for(const r of d.regionalStreams||[]){if(r?.key&&r?.src)regionalMap.set(r.key,r)}
  }
  let saved=(state.history||[]).find(h=>h.type===x.type&&String(h.id)===String(x.id)&&Number(h.episode)===Number(playingEpisode)&&Number(h.season)===Number(playingSeason));
  let resumeAt=Number(ctx.resumeAt)>0?Number(ctx.resumeAt):(!ctx.skipResume&&!(isAnime&&animeNeedsEpisodeOne(x,plan.originLang,candidate))&&readPreference('kozutv-resume-playback','true')!=='false'&&saved?.currentTime>15&&saved?.duration-saved?.currentTime>20?Math.max(0,Number(saved.currentTime)+.25):0);
  let saveData=Boolean(navigator.connection?.saveData),autoplay=typeof ctx.resumePlaying==='boolean'?ctx.resumePlaying:(!saveData&&readPreference('kozutv-autoplay','true')!=='false');
  let container=document.querySelector('#player');if(!container)return;
  container.dataset.provider=d.provider||'';container.dataset.server=d.server||'';
  container.innerHTML='<video id="kozutv-video" class="video-js vjs-default-skin vjs-big-play-centered" playsinline webkit-playsinline disableremoteplayback></video>';
  let player=videojs('kozutv-video',{controls:false,preload:saveData?'none':'auto',playbackRates:[.5,.75,1,1.25,1.5,2],html5:{vhs:{overrideNative:true,useBandwidthFromLocalStorage:false,useNetworkInformationApi:true,limitRenditionByPlayerDimensions:false,useDevicePixelRatio:false,bandwidth:saveData?500000:16000000,enableLowInitialPlaylist:false,smoothQualityChange:true,goalBufferLength:20,maxGoalBufferLength:30,backBufferLength:15,maxBufferLowWaterLine:16,bufferHighWaterLine:20},nativeAudioTracks:false,nativeTextTracks:false}});
  videoPlayer=player;
  try{player.tech({}).el().setAttribute('disableremoteplayback','')}catch{}
  player.src({src:d.src,type:d.type||'application/x-mpegURL'});
  let save=(current=0,duration=0)=>saveHistory({...x,episode:playingEpisode,season:playingSeason,currentTime:current,duration});
  let targets=episodeTargets();
  let ui=MegaPlayUI.create(player,{
   item:x,data:d,lang,server:d.sourceKey||provider,autoplay,audioPreselected:!isAnime&&ottSources.length>1,
   hasPrevEpisode:Boolean(targets.prev),hasNextEpisode:Boolean(targets.next),
   onPrevEpisode:()=>changeEpisode(-1),onNextEpisode:()=>changeEpisode(1),
   onSourceCommit:payload=>{
    if(isAnime||!OTT_PROVIDERS.includes(payload?.sourceKey))return;
    provider=payload.sourceKey;container.dataset.provider=payload.provider||'';container.dataset.server=payload.server||payload.sourceKey;
    history.replaceState({},'',watchUrl());
   },
   onAudioChange:async value=>{
    if(!isAnime||!ANIME_LANGS.includes(value)||ui?.isSourceSwitching?.())return;
    const token=++audioRequest;audioAbort?.abort();audioAbort=null;
    // Remember the requested preference, not an automatically chosen fallback.
    savePreference('kozutv-anime-lang',value);
    if(value===lang)return;
    save(player.currentTime(),player.duration());
    const requestedOrder=animeFallbackOrder(value),failed=[];
    for(const nextLang of requestedOrder){
     if(token!==audioRequest||generation!==playGeneration)return;
     const crossing=animeNeedsEpisodeOne(x,lang,nextLang);
     const nextEpisode=crossing?1:playingEpisode;
     if(nextLang===lang&&nextEpisode===playingEpisode&&!player.error())return;
     let nextPayload=null;
     try{
      // A cached alternate belongs to this exact episode/order only.
      if(!crossing){
       if(nextLang==='sub'||nextLang==='dub')nextPayload=animePlayCache.get(nextLang);
       if(!nextPayload)nextPayload=regionalMap.get(nextLang);
      }
      if(!nextPayload){
       audioAbort=new AbortController();
       const request=`/api/play?type=anime&id=${x.id}&episode=${nextEpisode}&season=1&lang=${nextLang}&anilistId=${x.anilistId||''}`;
       nextPayload=await responseJSON(await fetch(request,{signal:audioAbort.signal}));
      }
      if(token!==audioRequest||generation!==playGeneration)return;
      if((nextPayload.activeLang||nextPayload.key)!==nextLang||!nextPayload.src)throw Error('Source mismatch');
      if(crossing){
       // This is a different episode list, not an equivalent track. The chosen
       // destination is episode 1, with no confirmation or false mapping.
       await switchWatchEpisode({type:'anime',id:x.id,season:1,episode:1},{historyMode:'replace',nextLang,resolvedPayload:nextPayload});
       return;
      }
      if(nextLang==='sub'||nextLang==='dub')animePlayCache.set(nextLang,clonePayload(nextPayload));
      const changed=await ui.switchAnimeSource(nextPayload,nextLang);
      if(token!==audioRequest||generation!==playGeneration)return;
      if(!changed){failed.push(nextLang);continue}
      const oldBucket=animeCatalogBucket(lang);lang=nextLang;
      animePlan={originLang:value,originEpisode:playingEpisode,order:requestedOrder,tried:[...failed,nextLang]};
      if(nextPayload.provider)container.dataset.provider=nextPayload.provider;
      if(nextPayload.server||nextPayload.label)container.dataset.server=nextPayload.server||nextPayload.label;
      history.replaceState({},'',watchUrl());syncAnimeEpisodeRowLang(lang);
      if(oldBucket!==animeCatalogBucket(lang)&&!x.isMovie)syncWatchEpisodePanel(true);
      return;
     }catch(error){
      if(token!==audioRequest||generation!==playGeneration||error?.name==='AbortError')return;
      failed.push(nextLang);
     }
    }
    // The previous source remains selected when all alternate tracks fail.
   },
   onServerChange:value=>{save(player.currentTime(),player.duration());provider=value;history.replaceState({},'',watchUrl());play(x)}
  });
  if(isAnime&&!regionalMap.size){
   get(`/api/anime-audio?id=${x.id}&episode=${playingEpisode}&anilistId=${x.anilistId||''}`).then(res=>{
    if(generation!==playGeneration||!res?.streams?.length)return;
    for(const r of res.streams){if(r?.key&&r?.src)regionalMap.set(r.key,r)}
    ui?.setAnimeRegionalStreams?.(res.streams);
   }).catch(()=>{});
  }
  player.one('dispose',()=>audioAbort?.abort());
  if(isAnime)player.one('loadedmetadata',()=>{if(generation===playGeneration)history.replaceState({},'',watchUrl())});
  const attempted=new Set([...(ctx.ott?.exclude||[]),requestedProvider,d.sourceKey].filter(value=>OTT_PROVIDERS.includes(value)));
  player.one('canplay',()=>{if(resumeAt>0&&player.duration()>resumeAt+10)player.currentTime(resumeAt)});
  let continuePlaying=autoplay;
  player.on('play',()=>{continuePlaying=true});
  player.on('pause',()=>{if(!player.error())continuePlaying=false});
  player.one('playing',()=>save(player.currentTime(),player.duration()));
  player.on('timeupdate',()=>{
   let current=player.currentTime(),duration=player.duration();
   if(readPreference('kozutv-autoskip','false')==='true')for(let range of [d.intro,d.outro]){let start=Number(range?.start),end=Number(range?.end);if(start>=0&&end>start&&current>=start&&current<end){player.currentTime(end);break}}
   if(Number.isFinite(duration)&&duration>0&&Date.now()-lastProgressSent>5000){lastProgressSent=Date.now();save(current,duration)}
  });
  player.on('ended',()=>{save(player.duration(),player.duration());if(readPreference('kozutv-autonext','true')!=='false')changeEpisode(1)});
  player.on('error',()=>{
   if(generation!==playGeneration||ui?.isSourceSwitching?.())return;
   const error=player.error();
   if(isAnime&&animePlan.order.some(value=>!animePlan.tried.includes(value))){play(x,state,{anime:animePlan,skipResume:ctx.skipResume});return}
   if(!isAnime){
    if(OTT_PROVIDERS.includes(d.sourceKey))attempted.add(d.sourceKey);
    const resumeTime=Math.max(0,Number(player.currentTime())||Number(ctx.resumeAt)||0);
    ottTried.add(d.src);
    if(ottSources.some(source=>!ottTried.has(source.src))){
     play(x,state,{ott:{exclude:ctx.ott?.exclude||[],payload:ottRaw,audioTried:[...ottTried]},resumeAt:resumeTime,resumePlaying:continuePlaying});return;
    }
    const next=OTT_PROVIDERS.find(value=>!attempted.has(value));
    if(next){provider=next;play(x,state,{ott:{exclude:[...attempted]},resumeAt:resumeTime,resumePlaying:continuePlaying});return}
   }
   disposeVideo();showPlayerError(Error(error?.message||'The stream could not be loaded.'));
  });
  if(autoplay)player.play().catch(()=>ui?.onAutoplayBlocked?.());
 }catch(error){
  if(generation!==playGeneration)return;
  disposeVideo();showPlayerError(error);
 }
}

function failure(e){app.innerHTML=`<div class="container content"><div class="empty"><h2>Something went wrong</h2><p class="error">${esc(e.message)}</p><button class="btn" data-retry>Try again</button></div></div>`}
function clock(v){let n=Math.max(0,Math.floor(Number(v)||0));return `${Math.floor(n/3600)?String(Math.floor(n/3600))+':':''}${String(Math.floor(n/60)%60).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`}
function continueGrid(data){return `<div class="continue-grid">${data.map(x=>`<article class="continue-card" data-open="/watch/${x.type}/${x.id}?episode=${x.episode}&season=${x.season}"><div class="continue-image">${x.poster?`<img loading="lazy" src="${safeImage(x.poster)}" alt="${esc(x.title)}">`:''}</div><div class="continue-foot"><div class="continue-progress" style="width:${x.duration?Math.min(100,100*x.currentTime/x.duration):0}%"></div><span>${isFeature(x)?'MOVIE':x.type==='tv'?`S${x.season} E${x.episode}`:`EP ${x.episode}`}</span><span>${x.duration?clock(x.currentTime):'00:00'}</span></div><h3>${esc(x.title)}</h3></article>`).join('')}</div>`}

async function watchlist(){
 const route=routeGeneration;
 app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let d=await get('/api/state'),convert=x=>({...x,year:'Saved',rating:null});if(route!==routeGeneration)return;savedKeys=new Set((d.watchlist||[]).map(x=>x.type+':'+x.id));document.title='Watchlist — kozuTV';
  app.innerHTML=`<div class="container content watchlist-page">${sectionTitle('Watchlist','bookmark','h1')}${grid(d.watchlist.map(convert))}<div class="continue-section">${sectionTitle('Continue Watching','history')}${d.history.length?continueGrid(d.history):grid([])}</div></div>`;
 }catch(e){if(route===routeGeneration)failure(e)}
}

async function schedulePage(){
 const route=routeGeneration;
 app.innerHTML='<div class="loading">Loading…</div>';document.title='Anime Schedule — kozuTV';
 try{let d=await get('/api/schedule'),groups=new Map();if(route!==routeGeneration)return;for(let entry of d.entries){let date=new Date(entry.airingAt*1000),key=date.toLocaleDateString('en',{weekday:'long',month:'long',day:'numeric'});if(!groups.has(key))groups.set(key,[]);groups.get(key).push(entry)}app.innerHTML=`<div class="container content">${sectionTitle('Anime Schedule','clock','h1')}${groups.size?[...groups].map(([day,entries])=>`<section class="schedule-day"><h2>${day}</h2>${entries.map(({item,episode,airingAt})=>`<article class="schedule-row" data-open="${url(item.type,item.id)}"><img src="${safeImage(item.poster)}" alt=""><div><strong>${esc(item.title)}</strong><span>Episode ${episode} · ${new Date(airingAt*1000).toLocaleTimeString('en',{hour:'numeric',minute:'2-digit'})}</span></div><b>${timeAgo(airingAt*1000)}</b></article>`).join('')}</section>`).join(''):'<div class="empty">No scheduled episodes.</div>'}</div>`}catch(e){if(route===routeGeneration)failure(e)}
}

const option=(value,label,current)=>`<option value="${value}" ${value===current?'selected':''}>${label}</option>`;
async function filtersPage(){
 const route=routeGeneration;
 app.innerHTML='<div class="loading">Loading advanced filters…</div>';document.title='Advanced Filters — kozuTV';
 let p=params(),values={type:p.get('type')||'all',genre:p.get('genre')||'',year:p.get('year')||'',sort:p.get('sort')||'popularity',status:p.get('status')||''};
 let baseQuery=new URLSearchParams();
 for(let [k,v] of Object.entries(values))if(v)baseQuery.set(k,v);
 let endpointBase='/api/filter'+(baseQuery.toString()?'?'+baseQuery.toString():'');
 try{
  let d=await get(endpointBase+(endpointBase.includes('?')?'&':'?')+'page=1');
  if(route!==routeGeneration)return;
  let list=d.items||[];
  pagedState={
   mode:'filters',
   endpointBase,
   page:1,
   hasMore:Boolean(d.hasMore),
   seen:new Set(list.map(x=>`${x.type}:${x.id}`)),
   total:Number(d.totalResults)||list.length
  };
  let countText=pagedState.total>list.length?`${pagedState.total.toLocaleString('en-US')}+ titles`:`${list.length} titles`;
  let moreResults=pagedState.hasMore?`<div class="category-more"><button class="category-more-button" data-more-results aria-label="Show more titles">${ico('plus')}<span>Show more</span></button></div>`:'';
  app.innerHTML=`<div class="container content">${sectionTitle('Advanced Filters','sliders','h1')}<form class="filters-form" data-filters><label>Type<select name="type">${option('all','Everything',values.type)}${option('anime','Anime',values.type)}${option('movie','Movies',values.type)}${option('tv','Web series',values.type)}</select></label><label>Genre<select name="genre">${option('','All genres',values.genre)}${catalogGenres.map(g=>option(g,g,values.genre)).join('')}</select></label><label>Year<input name="year" inputmode="numeric" pattern="[0-9]{4}" minlength="4" maxlength="4" value="${esc(values.year)}" placeholder="Any year"></label><label>Sort<select name="sort">${option('popularity','Popularity',values.sort)}${option('rating','Rating',values.sort)}${option('newest','Newest',values.sort)}</select></label><label>Anime status<select name="status">${option('','Any status',values.status)}${option('releasing','Ongoing',values.status)}${option('finished','Finished',values.status)}</select></label><button class="btn" type="submit">Apply filters</button></form><div class="filter-results-heading">${sectionTitle('Results','sliders')}<span id="filter-count-label">${esc(countText)}</span></div>${grid(list,'paged-grid')}${moreResults}</div>`;
 }catch(e){if(route===routeGeneration)failure(e)}
}

let tokenSubmitPending=false;
const SITE_PREF_DEFAULTS={'kozutv-autoplay':'true','kozutv-autonext':'true','kozutv-autoskip':'false','kozutv-resume-playback':'true','kozutv-seek-step':'10','kozutv-save-history':'true','kozutv-spotlight-autoplay':'true','kozutv-reduce-motion':'false','kozutv-ai-transcription':'true','kozutv-anime-lang':'auto','kozutv-ott-audio':'auto','kozutv-server-pref':'vidcore','kozutv-quality':'auto','kozutv-speed':'1'};
const SITE_PREF_KEYS=Object.keys(SITE_PREF_DEFAULTS);
const RESET_PREF_KEYS=[...SITE_PREF_KEYS,'kozutv-muted','kozutv-audio-pref',...['anime-sub','anime-dub','ott'].flatMap(mode=>[`kozutv-sub-pref-${mode}`,`kozutv-caption-style-${mode}`])];
// The player's caption menu no longer carries a disclosure line; this one-time
// Settings note keeps the external-transmission notice discoverable.
function aiNotice(){
 try{if(localStorage.getItem('kozutv-ai-notice-ack')==='true')return ''}catch{}
 return '<div class="setting-note" role="note"><span>AI captions send audio from the playing video to NVIDIA for transcription and may be inaccurate.</span><button type="button" class="setting-note-close" data-ai-notice-ack aria-label="Dismiss AI caption notice">Dismiss</button></div>';
}
function settingsPage(){
 document.title='Settings — kozuTV';
 const read=(key,def)=>{try{return localStorage.getItem(key)??def}catch{return def}};
 const toggle=(key,title,def)=>`<label class="setting-row"><strong>${title}</strong><span class="site-switch"><input type="checkbox" data-site-pref="${key}" ${read(key,def)==='true'?'checked':''}><span></span></span></label>`;
 const select=(key,title,def,choices)=>`<label class="setting-row"><strong>${title}</strong><select data-site-pref="${key}" aria-label="${title}">${choices.map(([v,l])=>option(v,l,read(key,def))).join('')}</select></label>`;
 const tokenState=window.KozuCacheToken?.state()||{ready:false,bound:false,token:''};
 app.innerHTML=`<div class="container content settings-page">${sectionTitle('Settings','settings','h1')}
  <section class="settings-card cache-token-card"><div class="settings-card-heading">${ico('key')}<h2>Cache Token</h2></div>
   <div class="cache-token-field"><input id="cache-token-input" type="text" aria-label="Cache token" placeholder="Enter token" value="${esc(tokenState.token||'')}" maxlength="6" pattern="[A-Za-z0-9]{6}" autocomplete="off" autocapitalize="characters" spellcheck="false"><span id="cache-token-icon" class="cache-token-icon"></span></div>
   <div class="cache-token-actions"><button class="btn" type="button" data-token-generate>Generate Token</button><button class="btn secondary" type="button" data-token-set>Set Token</button></div>
   <div class="cache-token-status" id="cache-token-status" role="status" aria-live="polite"></div>
  </section>
  <section class="settings-card"><div class="settings-card-heading">${ico('playback')}<h2>Playback</h2></div>
   ${toggle('kozutv-autoplay','Autoplay','true')}
   ${toggle('kozutv-autonext','Auto next','true')}
   ${toggle('kozutv-autoskip','Auto-skip','false')}
   ${toggle('kozutv-resume-playback','Resume playback','true')}
   ${select('kozutv-seek-step','Seek interval','10',[['5','5 seconds'],['10','10 seconds'],['15','15 seconds'],['30','30 seconds']])}
   ${select('kozutv-speed','Playback speed','1',[['0.25','0.25×'],['0.5','0.5×'],['0.75','0.75×'],['1','Normal'],['1.25','1.25×'],['1.5','1.5×'],['1.75','1.75×'],['2','2×']])}
   ${select('kozutv-quality','Preferred quality','auto',[['auto','Auto'],['2160','4K'],['1440','2K'],['1080','Full HD'],['720','HD'],['576','576p'],['480','SD'],['360','360p'],['240','240p']])}
  </section>
  <section class="settings-card"><div class="settings-card-heading">${ico('headphones')}<h2>Language & sources</h2></div>
   ${select('kozutv-anime-lang','Preferred anime audio','auto',[['auto','Series default'],['sub','Japanese'],['dub','English'],['hi','Hindi'],['ta','Tamil'],['te','Telugu'],['ml','Malayalam'],['kn','Kannada'],['bn','Bengali']])}
   ${select('kozutv-ott-audio','Preferred Movies/Series Audio','auto',[['auto','Original / default'],['en','English'],['ja','Japanese'],['hi','Hindi'],['ta','Tamil'],['te','Telugu'],['ml','Malayalam'],['kn','Kannada'],['bn','Bengali'],['ko','Korean'],['es','Spanish'],['fr','French'],['de','German'],['it','Italian'],['pt','Portuguese'],['ru','Russian'],['zh','Chinese'],['ar','Arabic'],['tr','Turkish'],['th','Thai'],['vi','Vietnamese'],['id','Indonesian'],['mr','Marathi'],['pa','Punjabi'],['gu','Gujarati'],['ur','Urdu'],['nl','Dutch'],['pl','Polish'],['sv','Swedish'],['da','Danish'],['fi','Finnish'],['cs','Czech'],['el','Greek'],['hu','Hungarian'],['ro','Romanian'],['uk','Ukrainian'],['he','Hebrew'],['fa','Persian'],['ms','Malay']])}
   ${toggle('kozutv-ai-transcription','AI Transcription','true')}${aiNotice()}
   ${select('kozutv-server-pref','Movie & series server','vidcore',[['vidcore','VidCore'],['embedwave','EmbedWave'],['cinesrc','CineSrc'],['vidlink','VidLink'],['vidsrc','VidSrc']])}
  </section>
  <section class="settings-card"><div class="settings-card-heading">${ico('sliders')}<h2>Viewing & browsing</h2></div>
   ${toggle('kozutv-save-history','Save watch history','true')}
   ${toggle('kozutv-spotlight-autoplay','Spotlight autoplay','true')}
   ${toggle('kozutv-reduce-motion','Reduce motion','false')}
  </section>
  <div class="settings-actions"><button class="btn secondary" type="button" data-reset-settings>Reset preferences</button><span id="settings-status" role="status" aria-live="polite"></span></div></div>`;
 updateCacheTokenUI();
}
function updateCacheTokenUI(){
 const s=window.KozuCacheToken?.state(),input=document.querySelector('#cache-token-input');if(!s||!input)return;
 if(s.bound)input.value=s.token||'';
 input.readOnly=Boolean(s.bound||s.busy||tokenSubmitPending||!s.ready||!s.storageAvailable);
 input.setAttribute('aria-readonly',String(input.readOnly));
 const icon=document.querySelector('#cache-token-icon');
 if(icon)icon.innerHTML=s.bound?(s.fresh?`<button type="button" data-token-copy title="Copy token" aria-label="Copy token">${ico('copy')}</button>`:`<span title="Token locked" aria-label="Token locked">${ico('lock')}</span>`):`<span aria-hidden="true">${ico('key')}</span>`;
 document.querySelectorAll('[data-token-generate],[data-token-set]').forEach(b=>b.disabled=Boolean(s.bound||s.busy||tokenSubmitPending||!s.ready||!s.storageAvailable));
 document.querySelectorAll('[data-site-pref]').forEach(el=>el.disabled=Boolean(s.busy));
 const status=document.querySelector('#cache-token-status');if(status){status.textContent=s.message||'';status.classList.toggle('is-error',Boolean(s.error))}
}
function refreshSettingsPreferences(){
 if(location.pathname!=='/settings')return;
 document.querySelectorAll('[data-site-pref]').forEach(el=>{
  const key=el.dataset.sitePref;let value=SITE_PREF_DEFAULTS[key];try{value=localStorage.getItem(key)??value}catch{}
  if(el.type==='checkbox')el.checked=value==='true';else el.value=value;
 });
}
window.addEventListener('kozutv-cache-token-change',updateCacheTokenUI);
window.addEventListener('kozutv-preferences-restored',()=>{refreshSettingsPreferences();applyDisplayPreferences()});
applyDisplayPreferences();

async function randomPage(){const route=routeGeneration;app.innerHTML='<div class="loading">Choosing a random title…</div>';try{let d=await get('/api/random');if(route!==routeGeneration)return;history.replaceState({},'',url(d.item.type,d.item.id));render()}catch(e){if(route===routeGeneration)failure(e)}}

function render(){
 routeGeneration++;clearTimeout(searchTimer);
 stopBrowseRows();stopGenrePages();
 episodeSwitchGeneration++;
 disposeVideo();closeMenu();let p=location.pathname;
 if(['/account','/login','/create-account','/profile','/community','/upcoming','/downloads','/rooms'].includes(p)||p.startsWith('/downloads/')||p.startsWith('/rooms/')){history.replaceState({},'','/browse');p='/browse'}
 if(p==='/settings')return settingsPage();
 if(p==='/schedule')return schedulePage();
 if(p==='/filters')return filtersPage();
 if(p==='/random')return randomPage();
 search.placeholder='Search anime, movies & series...';
 if(p==='/watchlist')return watchlist();
 let mw=p.match(/^\/(?:browse\/)?watch\/(anime|movie|tv)\/(\d+)/);
 if(mw)return watch(mw[1],mw[2]);
 let md=p.match(/^\/browse\/(anime|movie|tv)\/(\d+)/);
 if(md)return details(md[1],md[2]);
 return catalog(Boolean(params().get('q')));
}

document.addEventListener('click',async e=>{
 try{
  let tvMore=e.target.closest('[data-tv-more]');
  if(tvMore){
   let mode=tvMore.dataset.tvMode,dir=tvMore.dataset.tvMore,st=tvEpisodeLists[mode];
   if(st){
    if(dir==='prev')st.startIdx=Math.max(0,st.startIdx-TV_EP_CHUNK);
    else st.endIdx=Math.min(st.episodes.length,st.endIdx+TV_EP_CHUNK);
    renderTvEpisodes(mode);
   }
   return;
  }
  let description=e.target.closest('[data-description-toggle]');if(description){if(String(window.getSelection?.()||'').length)return;let expanded=description.classList.toggle('expanded');description.setAttribute('aria-expanded',String(expanded));return}
  let heroSave=e.target.closest('[data-hero-save]');if(heroSave){let [type,id]=heroSave.dataset.heroSave.split(':'),x=[...spotlightItems,...items,...suggestions,...Object.values(genreRows).flat()].find(i=>i.type===type&&String(i.id)===id);if(!x)return;let state=await get('/api/state'),saved=state.watchlist.some(i=>i.id===id&&i.type===type),next=await post('/api/watchlist',{...x,remove:saved});savedKeys=new Set(next.watchlist.map(i=>i.type+':'+i.id));document.querySelectorAll(`[data-hero-save="${type}:${id}"]`).forEach(b=>{b.classList.toggle('saved',!saved);b.setAttribute('aria-label',(!saved?'Remove from':'Add to')+' Watchlist')});return}

  let genreRetry=e.target.closest('[data-genre-retry]');if(genreRetry){genrePagesSession?.retry();return}
  let genrePageRetry=e.target.closest('[data-genre-page-retry]');if(genrePageRetry){genrePagesSession?.retryPage(genrePageRetry);return}
  let moreResultsBtn=e.target.closest('[data-more-results]');if(moreResultsBtn){
   if(moreResultsBtn.disabled||!pagedState.hasMore)return;
   moreResultsBtn.disabled=true;
   moreResultsBtn.innerHTML='<span class="button-loader" aria-label="Loading"></span>';
   moreResultsBtn.classList.add('is-loading');
   let anchor=moreResultsBtn.closest('.category-more');
   try{
    let nextPage=pagedState.page+1;
    let sep=pagedState.endpointBase.includes('?')?'&':'?';
    let d=await get(`${pagedState.endpointBase}${sep}page=${nextPage}`);
    pagedState.page=nextPage;
    pagedState.hasMore=Boolean(d.hasMore);
    let fresh=[];
    for(let it of d.items||[]){
     if(!it?.poster||!it?.title)continue;
     let k=`${it.type}:${it.id}`;
     if(!pagedState.seen.has(k)){pagedState.seen.add(k);fresh.push(it);items.push(it)}
    }
    let gridEl=document.querySelector('#paged-grid');
    if(fresh.length&&gridEl)gridEl.insertAdjacentHTML('beforeend',fresh.map(card).join(''));
    if(!anchor?.isConnected)return;
    moreResultsBtn.classList.remove('is-loading');
    if(pagedState.hasMore&&(d.items||[]).length){
     moreResultsBtn.disabled=false;
     moreResultsBtn.innerHTML=`${ico('plus')}<span>Show more</span>`;
    }else{
     anchor.remove();
    }
   }catch{
    if(anchor?.isConnected){
     moreResultsBtn.classList.remove('is-loading');
     moreResultsBtn.disabled=false;
     moreResultsBtn.innerHTML=`${ico('plus')}<span>Show more</span>`;
    }
   }
   return;
  }
  let copyToken=e.target.closest('[data-token-copy]');if(copyToken){await window.KozuCacheToken.copy();return}
  let generateToken=e.target.closest('[data-token-generate]');if(generateToken){await window.KozuCacheToken.generate();return}
  let setToken=e.target.closest('[data-token-set]');if(setToken){
   if(tokenSubmitPending)return;
   const token=document.querySelector('#cache-token-input')?.value||'';
   if(!/^[A-Z0-9]{6}$/.test(token)){await window.KozuCacheToken.set(token);return}
   tokenSubmitPending=true;updateCacheTokenUI();let checkError='';
   try{
    let current;try{current=await get('/api/state')}catch{checkError='Could not check current data. Please try again.';return}
    if((current.watchlist?.length||current.history?.length||Object.keys(window.KozuCacheToken.snapshot()).length)&&!window.confirm('Setting this token replaces this browser’s current kozuTV watchlist, history and preferences. Continue?'))return;
    await window.KozuCacheToken.set(token);return;
   }finally{tokenSubmitPending=false;updateCacheTokenUI();if(checkError){const status=document.querySelector('#cache-token-status');if(status){status.textContent=checkError;status.classList.add('is-error')}}}
  }
  let ack=e.target.closest('[data-ai-notice-ack]');if(ack){savePreference('kozutv-ai-notice-ack','true');ack.closest('.setting-note')?.remove();return}
  let reset=e.target.closest('[data-reset-settings]');if(reset){for(const key of RESET_PREF_KEYS)removePreference(key);applyDisplayPreferences();settingsPage();const status=document.querySelector('#settings-status');if(status)status.textContent='Preferences reset.';return}
  let genre=e.target.closest('[data-genre-filter]');if(genre){nav('/browse?genre='+encodeURIComponent(genre.dataset.genreFilter));return}
  let more=e.target.closest('[data-anime-page]');if(more&&detail){let mode=more.dataset.animeMode;await loadAnimeEpisodes(detail.item.id,mode,Number(more.dataset.animePage),mode==='watch'?episode:0,false);return}
  let dot=e.target.closest('[data-slide]');if(dot){const next=+dot.dataset.slide;showSlide(next,next<slide?-1:1);return}
  let open=e.target.closest('[data-open]');if(open){
   if(open.disabled)return;
   const u=new URL(open.dataset.open,location.origin),m=u.pathname.match(/^\/watch\/(anime|tv)\/(\d+)$/);
   if(m&&document.querySelector('#player')&&detail?.item?.type===m[1]&&String(detail.item.id)===m[2]){
    switchWatchEpisode({type:m[1],id:m[2],season:Number(u.searchParams.get('season')||1),episode:Number(u.searchParams.get('episode')||1)},{nextLang:u.searchParams.get('lang')||''});
   }else nav(open.dataset.open);
   return;
  }
  let link=e.target.closest('a[href^="/"]');if(link){e.preventDefault();nav(link.getAttribute('href'));return}
  let heroDetails=e.target.closest('[data-hero-details]');if(heroDetails){nav(heroDetails.dataset.heroDetails);return}
  if(e.target.closest('[data-retry]')){if(document.querySelector('#player')&&detail?.item)play(detail.item);else render();return}
  if(e.target.closest('[data-save]')&&detail){let x=detail.item,d=await get('/api/state'),saved=d.watchlist.some(i=>i.id===x.id&&i.type===x.type);let next=await post('/api/watchlist',{...x,remove:saved});savedKeys=new Set(next.watchlist.map(i=>i.type+':'+i.id));await updateSave();return}
 }catch(error){console.error(error)}
});

document.addEventListener('input',e=>{if(e.target.id==='cache-token-input'&&!e.target.readOnly)e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6)});

document.addEventListener('change',e=>{
 const pref=e.target.closest('[data-site-pref]');
 if(pref&&SITE_PREF_KEYS.includes(pref.dataset.sitePref)){savePreference(pref.dataset.sitePref,pref.type==='checkbox'?String(pref.checked):pref.value);applyDisplayPreferences();return}
 if(e.target.id==='season'&&detail)switchWatchEpisode({type:'tv',id:detail.item.id,season:+e.target.value,episode:1});
 if(e.target.id==='detail-tv-season'&&detail)loadDetailEpisodes(detail.item.id,e.target.value);
 if(e.target.id==='detail-regional-season'&&detail){let startEp=Math.max(1,+e.target.value||1);loadAnimeEpisodes(detail.item.id,'detail',Math.floor((startEp-1)/20)+1,0,true,startEp)}
 if(e.target.id==='watch-regional-season'&&detail)switchWatchEpisode({type:'anime',id:detail.item.id,season:1,episode:Math.max(1,+e.target.value||1)});
 if(['detail-pokemon-region','watch-pokemon-region'].includes(e.target.id)&&detail){
  const [id,start]=e.target.value.split(':'),first=Number(start)||1;
  if(e.target.id==='watch-pokemon-region')switchWatchEpisode({type:'anime',id,season:1,episode:first});
  else if(String(id)!==String(detail.item.id))nav(`/browse/anime/${id}?episode=${first}`);
  else {history.replaceState({},'',`/browse/anime/${id}?episode=${first}`);const r=pokemonRegion(detail,id,first);loadAnimeEpisodes(id,'detail',Math.floor((first-1)/20)+1,0,true,r?.startEp||first,r?.endEp||0);let b=document.querySelector('.detail .actions [data-open]');if(b)b.dataset.open=`/watch/anime/${id}?episode=${first}`}
 }
 if(['detail-anime-season','anime-season'].includes(e.target.id)&&detail){let id=e.target.value;if(String(id)===String(detail.item.id))return;if(e.target.id==='anime-season')switchWatchEpisode({type:'anime',id,season:1,episode:1});else nav(`/browse/anime/${id}`)}
});

const menuToggle=document.querySelector('.menu-toggle'),mainMenu=document.querySelector('#main-menu');
function closeMenu(){if(!menuToggle||!mainMenu)return;menuToggle.setAttribute('aria-expanded','false');menuToggle.setAttribute('aria-label','Open menu');mainMenu.hidden=true}
menuToggle?.addEventListener('click',()=>{let open=menuToggle.getAttribute('aria-expanded')!=='true';menuToggle.setAttribute('aria-expanded',String(open));menuToggle.setAttribute('aria-label',open?'Close menu':'Open menu');mainMenu.hidden=!open});
document.addEventListener('click',e=>{if(!e.target.closest('#main-menu,.menu-toggle'))closeMenu()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();if(!search.value.trim())closeSearchBox()}});
document.addEventListener('submit',e=>{
 let filters=e.target.closest('[data-filters]');if(!filters)return;
 e.preventDefault();let data=new FormData(filters),q=new URLSearchParams();
 for(let [key,value] of data)if(String(value).trim())q.set(key,String(value).trim());
 nav('/filters'+(q.toString()?'?'+q:''));
});

const searchbox=document.querySelector('.searchbox');
searchbox.addEventListener('click',()=>{closeMenu();searchbox.classList.add('open');headerEl?.classList.add('search-open');search.focus()});
search.addEventListener('focus',()=>{headerEl?.classList.add('search-open')});
search.addEventListener('blur',()=>{if(!search.value.trim())closeSearchBox()});
search.addEventListener('input',()=>{
 clearTimeout(searchTimer);routeGeneration++;episodeSwitchGeneration++;
 stopBrowseRows();disposeVideo();
 let term=search.value.trim();
 history.replaceState({},'',term?`/browse?q=${encodeURIComponent(term)}`:'/browse');
 searchTimer=setTimeout(()=>term?catalog(true):catalog(false),320);
});
document.addEventListener('keydown',e=>{
 if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-hero-details]')){e.preventDefault();nav(e.target.dataset.heroDetails);return}
 if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-description-toggle]')){e.preventDefault();e.target.click();return}
 if(e.key==='/'&&document.activeElement!==search&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)){e.preventDefault();searchbox.classList.add('open');headerEl?.classList.add('search-open');search.focus()}
});

const exploreIcons={'/browse':'home','/schedule':'clock','/upcoming':'calendar','/random':'shuffle','/filters':'sliders','/settings':'settings'};
document.querySelectorAll('.main-menu a[href]').forEach(a=>{let icon=exploreIcons[a.getAttribute('href')];if(icon)a.innerHTML=`${ico(icon)}<span>${esc(a.textContent)}</span>`});
document.querySelectorAll('[data-genre-filter]').forEach(b=>{b.innerHTML=`${ico(genreIcons[b.dataset.genreFilter]||'sparkles')}<span>${esc(b.textContent)}</span>`});
document.querySelectorAll('[data-menu-heading]').forEach(el=>{el.innerHTML=`${ico(el.dataset.menuHeading)}<span>${esc(el.textContent)}</span>${ico('chevron','menu-chevron')}`});
window.addEventListener('popstate',()=>{
 search.value=params().get('q')||'';
 const m=location.pathname.match(/^\/(?:browse\/)?watch\/(anime|tv)\/(\d+)$/),p=params();
 if(m&&document.querySelector('#player')&&detail?.item?.type===m[1]){
  switchWatchEpisode({type:m[1],id:m[2],season:Number(p.get('season')||1),episode:Number(p.get('episode')||p.get('ep')||1)},{historyMode:'none',nextLang:p.get('lang')||'',nextProvider:p.get('provider')||'vidcore'});
 }else render();
});
if(location.pathname==='/')history.replaceState({},'','/browse');
(window.KozuCacheToken?.ready||Promise.resolve()).finally(()=>{applyDisplayPreferences();render()});
