(() => {
'use strict';
const TOKEN_KEY='kozutv-cache-token', PENDING_KEY='kozutv-cache-pending-v1';
const CODE=/^[A-Z0-9]{6}$/;
const PREF_KEY=/^kozutv-(?!cache-)[a-z0-9-]{1,70}$/,LEGACY_PREFIX='moscowtv-',canonical=key=>!PREF_KEY.test(String(key||''))&&String(key||'').startsWith(LEGACY_PREFIX);
let storageAvailable=true;
try { const k='kozutv-cache-storage-test'; localStorage.setItem(k,'1'); localStorage.removeItem(k); } catch { storageAvailable=false; }
const read=(k,fallback='')=>{try{return localStorage.getItem(k)??fallback}catch{return fallback}};
const write=(k,v)=>{try{localStorage.setItem(k,String(v));return true}catch{return false}};
const remove=k=>{try{localStorage.removeItem(k)}catch{}};
const initialToken=String(read(TOKEN_KEY)).toUpperCase();
const state={ready:false,bound:false,token:CODE.test(initialToken)?initialToken:'',fresh:false,busy:false,message:'',error:false,revision:0};
let binding=false,flushPromise=null,pullPromise=null,flushTimer=null;
const emit=()=>window.dispatchEvent(new CustomEvent('kozutv-cache-token-change'));
const stateCopy=()=>({...state,storageAvailable});
function snapshot(){
 const result={};
 try{for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(PREF_KEY.test(key||'')||canonical(key)){const val=localStorage.getItem(key);if(typeof val==='string')result[key]=val}}}catch{}
 return result;
}
function pending(){
 try{const obj=JSON.parse(read(PENDING_KEY,'{}'));if(!obj||typeof obj!=='object'||Array.isArray(obj))return {};const clean={};for(const [k,v] of Object.entries(obj))if((PREF_KEY.test(k)||canonical(k))&&(typeof v==='string'||v===null))clean[k]=v;return clean}catch{return {}}
}
function savePending(obj){if(Object.keys(obj).length)write(PENDING_KEY,JSON.stringify(obj));else remove(PENDING_KEY)}
async function request(path,body){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),6000);
 try{
  const options={credentials:'same-origin',cache:'no-store',signal:controller.signal};
  if(body!==undefined){options.method='POST';options.headers={'Content-Type':'application/json'};options.body=JSON.stringify(body);options.keepalive=true}
  const response=await fetch(path,options),data=await response.json().catch(()=>({}));
  if(!response.ok){const err=Error(data.error||`Request failed (${response.status}).`);err.status=response.status;throw err}
  return data;
 }finally{clearTimeout(timer)}
}
function applyPreferences(remote){
 if(!remote||typeof remote!=='object'||Array.isArray(remote))return;
 const desired={};
 for(const [k,v] of Object.entries(remote))if((PREF_KEY.test(k)||canonical(k))&&typeof v==='string')desired[k]=v;
 // Unsynced local edits always win over an older server snapshot.
 for(const [k,v] of Object.entries(pending())){if(v===null)delete desired[k];else desired[k]=v}
 const current=snapshot();let changed=false;
 for(const key of Object.keys(current))if(!Object.hasOwn(desired,key)){remove(key);changed=true}
 for(const [key,value] of Object.entries(desired))if(current[key]!==value){write(key,value);changed=true}
 if(changed)window.dispatchEvent(new CustomEvent('kozutv-preferences-restored'));
}
function rememberBinding(d, fresh=false){
 state.bound=true;state.token=String(d.token||state.token);state.fresh=fresh;state.revision=Number(d.revision)||1;
 if(CODE.test(state.token))write(TOKEN_KEY,state.token);
}
async function flush(){
 if(!state.bound)return false;
 if(flushPromise)return flushPromise;
 clearTimeout(flushTimer);
 flushPromise=(async()=>{
  try{
   while(state.bound){
    const changes=pending();if(!Object.keys(changes).length)break;
    const d=await request('/api/cache-token/preferences',{changes});
    const rest=pending();for(const [k,v] of Object.entries(changes))if(Object.hasOwn(rest,k)&&rest[k]===v)delete rest[k];
    savePending(rest);state.revision=Number(d.revision)||state.revision;applyPreferences(d.preferences);
   }
   if(state.message==='Changes saved locally; token sync is pending.'){state.message='';state.error=false;emit()}
   return true;
  }catch{
   state.message='Changes saved locally; token sync is pending.';state.error=true;emit();return false;
  }
 })().finally(()=>{flushPromise=null});
 return flushPromise;
}
// Existing profiles still hold moscowtv-* keys; sends the same setting forward under kozutv-*.
const PREF_RENAME={...Object.fromEntries(['autoplay','autonext','autoskip','resume-playback','seek-step','save-history','spotlight-autoplay','reduce-motion','ai-transcription','anime-lang','ott-audio','server-pref','quality','speed','muted','audio-pref','brightness'].map(k=>['moscowtv-'+k,'kozutv-'+k])),'moscowtv-cache-storage-test':'kozutv-cache-storage-test'};
function changed(key,value){
 key=PREF_RENAME[key]||key;
 if(!PREF_KEY.test(key||'')||(!state.bound&&!binding))return;
 const changes=pending();changes[key]=value===null?null:String(value);savePending(changes);
 clearTimeout(flushTimer);flushTimer=setTimeout(()=>flush(),250);
}
function setPref(key,value){
 if(!write(key,value))return false;
 changed(key,String(value));return true;
}
function removePref(key){remove(key);changed(key,null)}
async function initialize(){
 if(!storageAvailable){state.ready=true;state.error=true;state.message='Browser storage is unavailable.';emit();return}
 try{
  let d=await request('/api/cache-token/status');
  if(!d.bound&&state.token){
   try{d=await request('/api/cache-token/set',{token:state.token})}
   catch(err){if(err.status===404){state.message='Saved token was not found on this server.';state.error=true;state.bound=false;state.ready=true;emit();return}throw err}
  }
  if(d.bound){
   rememberBinding(d,false);
   if(Object.keys(pending()).length){await flush();try{d=await request('/api/cache-token/status')}catch{}}
   applyPreferences(d.preferences);
  }else{state.bound=false;state.token=''}
 }catch{
  state.bound=CODE.test(state.token);
  state.message='Token service unavailable. Your local data is unchanged.';state.error=true;
 }
 state.ready=true;emit();
}
async function generate(){
 if(!state.ready||state.bound||state.busy||!storageAvailable)return;
 state.busy=true;binding=true;state.message='';state.error=false;emit();
 try{
  const d=await request('/api/cache-token/generate',{preferences:snapshot()});
  rememberBinding(d,true);state.message='';
  if(Object.keys(pending()).length)await flush();
 }catch(err){state.message=err.name==='AbortError'?'Token request timed out. Reload to check its status.':(err.message||'Could not generate a token.');state.error=true}
 finally{binding=false;state.busy=false;emit()}
}
async function set(code){
 if(!state.ready||state.bound||state.busy||!storageAvailable)return false;
 code=String(code||'').toUpperCase().trim();
 if(!CODE.test(code)){state.message='Enter a six-character token.';state.error=true;emit();return false}
 state.busy=true;state.message='';state.error=false;emit();
 try{
  const d=await request('/api/cache-token/set',{token:code});
  // A restore intentionally replaces this browser's previous kozuTV prefs.
  savePending({});rememberBinding(d,true);applyPreferences(d.preferences);
  state.message='Token set. Your kozuTV data has been restored.';return true;
 }catch(err){state.message=err.name==='AbortError'?'Token request timed out. Reload to check its status.':(err.message||'Could not set this token.');state.error=true;return false}
 finally{state.busy=false;emit()}
}
async function pull(){
 if(!state.ready||!state.bound||pullPromise||document.hidden)return;
 pullPromise=(async()=>{
  try{
   await flush();
   const d=await request('/api/cache-token/status');
   if(!d.bound)throw Error('Token connection lost');
   const oldToken=state.token,oldRevision=state.revision;
   rememberBinding(d,state.fresh&&oldToken===d.token);
   if(d.revision!==oldRevision||oldToken!==d.token)applyPreferences(d.preferences);
   if(state.message==='Token service unavailable. Your local data is unchanged.')state.message='';
   state.error=false;emit();
  }catch{if(Object.keys(pending()).length){state.message='Changes saved locally; token sync is pending.';state.error=true;emit()}}
 })().finally(()=>{pullPromise=null});
 return pullPromise;
}
async function copy(){
 if(!state.bound||!state.fresh||!state.token)return;
 try{
  let copied=false;
  if(navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(state.token);copied=true}catch{}}
  // Clipboard permissions can be denied in an embedded preview. Fall back to
  // the browser's user-gesture copy command before asking for manual copying.
  if(!copied){
   const input=document.querySelector('#cache-token-input');if(!input)throw Error();
   input.focus();input.select();copied=document.execCommand('copy');if(copied)input.setSelectionRange(0,0);
  }
  if(!copied)throw Error();
  state.message='Token copied.';state.error=false;
 }catch{
  const input=document.querySelector('#cache-token-input');input?.focus();input?.select();
  state.message='Select and copy the token manually.';state.error=true;
 }
 emit();
}
window.addEventListener('storage',event=>{
 if(event.key===TOKEN_KEY){
  const code=String(event.newValue||'').toUpperCase();
  if(CODE.test(code)&&code!==state.token){state.token=code;state.bound=true;state.fresh=false;pull()}
 }else if(PREF_KEY.test(event.key||''))window.dispatchEvent(new CustomEvent('kozutv-preferences-restored'));
});
window.addEventListener('focus',()=>pull());
document.addEventListener('visibilitychange',()=>{if(document.hidden)flush();else pull()});
window.addEventListener('pagehide',()=>{
 const changes=pending();
 if(state.bound&&Object.keys(changes).length&&navigator.sendBeacon){
  try{navigator.sendBeacon('/api/cache-token/preferences',new Blob([JSON.stringify({changes})],{type:'application/json'}))}catch{}
 }
});
setInterval(()=>{if(!document.hidden)pull()},30000);
const ready=initialize();
window.KozuCacheToken={ready,state:stateCopy,snapshot,setPref,removePref,changed,generate,set,copy,pull,flush};
})();
