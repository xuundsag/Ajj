// Test-only Node preload: simulate TMDB while recording actual upstream calls.
import fs from 'node:fs';
const originalFetch=globalThis.fetch;
let comedyFailures=0;
globalThis.fetch=async function(input,options){
  const raw=typeof input==='string'?input:input?.url||String(input),url=new URL(raw);
  if(url.hostname!=='api.themoviedb.org')return originalFetch(input,options);
  fs.appendFileSync(process.env.TMDB_FIXTURE_LOG,url.pathname+'?'+url.searchParams.toString()+'\n');
  await new Promise(resolve=>setTimeout(resolve,70));
  if(url.searchParams.get('with_genres')==='35'&&comedyFailures++===0)return new Response('unavailable',{status:503});
  const page=Number(url.searchParams.get('page')||1),isTv=url.pathname.includes('/tv');
  const results=page>2?[]:Array.from({length:20},(_,i)=>({id:(isTv?20000:10000)+page*100+i,title:isTv?undefined:`Movie ${page}-${i}`,name:isTv?`Series ${page}-${i}`:undefined,release_date:isTv?undefined:'2020-01-01',first_air_date:isTv?'2020-01-01':undefined,poster_path:'/fixture.jpg',backdrop_path:'/fixture-back.jpg',original_language:'en',popularity:30,vote_count:80,genre_ids:[]}));
  return new Response(JSON.stringify({page,total_pages:2,total_results:40,results}),{status:200,headers:{'content-type':'application/json'}});
};
