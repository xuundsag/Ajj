// Isolated V5.4.12 regression tests. No live visitor data or external providers.
import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import net from 'node:net';
import {spawn} from 'node:child_process';import {once} from 'node:events';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const work=fs.mkdtempSync(path.join(os.tmpdir(),'kozu-5412-browser-'));
const excluded=new Set(['states.json','user.json','cache-token.key','cache-tokens.json']);
fs.cpSync(path.join(root,'data'),path.join(work,'data'),{recursive:true,filter:src=>!excluded.has(path.basename(src))&&!src.endsWith('.tmp')});
fs.symlinkSync(path.join(root,'public'),path.join(work,'public'),'dir');
const allocator=net.createServer();await new Promise(r=>allocator.listen(0,'127.0.0.1',r));const port=allocator.address().port;await new Promise(r=>allocator.close(r));
const base=`http://127.0.0.1:${port}`,media=path.join(root,'scripts/fixtures/seek-test.webm');
let child,browser,logs='';const errors=[];const delay=ms=>new Promise(r=>setTimeout(r,ms));
const img='/images/spotlight/anime-21.jpg';
const anime={id:'424242',type:'anime',title:'Test Anime',description:'Description',poster:img,backdrop:img,genres:['Action'],episodes:3,sub:true,dub:true,differentDubOrder:true};
const movie={id:'55555',type:'movie',title:'Test Movie',description:'Description',poster:img,backdrop:img,genres:['Action'],isMovie:true};
const spot=[0,1,2].map((_,i)=>({...anime,id:String(424242+i),title:`Spotlight ${i+1}`}));
function json(route,body,status=200){return route.fulfill({status,contentType:'application/json',body:JSON.stringify(body)})}
const goodAnime=(lang,src='/__good.webm')=>({src,type:'video/webm',provider:'MegaPlay',sourceKey:'megaplay',server:lang,activeLang:lang,allowSub:true,allowDub:true,tracks:[],regionalStreams:[]});
const goodOtt=(sourceKey='vidcore',src='/__en.webm',streams=[])=>({src,type:'video/webm',provider:sourceKey,sourceKey,server:sourceKey,audioLang:'en',audioLabel:'English',tracks:[],audioStreams:streams,qualityStreams:[]});
async function installMocks(context,{animeItem=anime,play=null,genre=null,browse=true,mediaLog=null}={}){
 await context.route('**/api/**',async route=>{
  const u=new URL(route.request().url());
  if(u.pathname==='/api/browse'&&browse)return json(route,{items:spot,spotlight:spot,suggestions:[]});
  if(u.pathname==='/api/genre'&&genre)return genre(route,u);
  if(u.pathname==='/api/genre'||u.pathname==='/api/collection')return json(route,{items:spot,hasMore:false,totalResults:spot.length});
  if(u.pathname==='/api/detail'){
   const x=u.searchParams.get('type')==='movie'?movie:animeItem;
   return json(route,{item:x,seasons:x.type==='anime'?[{id:x.id,name:'Season 1',episodes:x.episodes}]:[],episodes:[]});
  }
  if(u.pathname==='/api/anime-episodes')return json(route,{episodes:[1,2,3].map(number=>({number,title:`Episode ${number}`})),hasNext:false});
  if(u.pathname==='/api/anime-audio')return json(route,{streams:[]});
  if(u.pathname==='/api/play')return play?play(route,u):json(route,goodAnime(u.searchParams.get('lang')||'sub'));
  return route.continue();
 });
 await context.route('**/__*.webm',route=>{
  const name=new URL(route.request().url()).pathname;if(mediaLog)mediaLog.push(name);
  return name.includes('__bad')?route.fulfill({status:404,body:'missing'}):route.fulfill({status:200,path:media,contentType:'video/webm',headers:{'Accept-Ranges':'bytes'}});
 });
}
async function context(opts={}){
 const c=await browser.newContext({viewport:{width:1200,height:850},...opts});
 // This suite verifies pre-AI V5.4.12 behavior. V5.4.13 tests AI separately.
 await c.addInitScript(()=>localStorage.setItem('kozutv-ai-transcription','false'));
 return c;
}
async function pageFor(c,route='/browse'){
 const p=await c.newPage();p.on('pageerror',e=>errors.push(String(e)));await p.goto(base+route,{waitUntil:'domcontentloaded'});
 await p.waitForSelector('#app > :not(.loading)',{timeout:15000});return p;
}
async function videoReady(p){await p.waitForFunction(()=>{const v=window.videojs?.getPlayer('kozutv-video');return v&&v.megaUI&&v.duration()>=170&&v.readyState()>=2},{timeout:25000})}
async function swipeMouse(p,left=true){const rect=await p.locator('.hero:not(.hero-leaving)').boundingBox(),y=rect.y+Math.min(180,rect.height*.35),start=rect.x+rect.width*(left?.68:.32),end=rect.x+rect.width*(left?.32:.68);await p.mouse.move(start,y);await p.mouse.down();await p.mouse.move(end,y,{steps:8});await p.mouse.up()}
async function swipeTouch(p,left=true){
 const r=await p.locator('.hero:not(.hero-leaving)').boundingBox(),y=Math.min(210,r.y+r.height*.3),start=Math.round(r.x+r.width*(left?.75:.25)),end=Math.round(r.x+r.width*(left?.25:.75));
 const cdp=await p.context().newCDPSession(p);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:start,y}]});
 for(let i=1;i<=6;i++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:Math.round(start+(end-start)*i/6),y}]});
 await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await cdp.detach();
}
try{
 child=spawn(process.execPath,[path.join(root,'server.js')],{cwd:work,env:{...process.env,PORT:String(port),NVIDIA_API_KEY:'',NVIDIA_API_KEY_FILE:path.join(work,'no-ai-key')},stdio:['ignore','pipe','pipe']});child.stdout.on('data',d=>logs+=d);child.stderr.on('data',d=>logs+=d);
 await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('server startup '+logs)),20000);child.once('exit',c=>{clearTimeout(t);reject(Error('server exit '+c+' '+logs))});child.stdout.on('data',()=>{if(logs.includes('listening on')){clearTimeout(t);resolve()}})});
 browser=await chromium.launch({headless:true,args:['--no-sandbox','--autoplay-policy=no-user-gesture-required']});
 // Desktop and actual emulated touch: left wraps to previous, right goes next.
 for(const mobile of [false,true]){
  const c=await context(mobile?{viewport:{width:390,height:844},isMobile:true,hasTouch:true}:{});await installMocks(c);await c.addInitScript(()=>localStorage.setItem('kozutv-spotlight-autoplay','false'));
  const p=await pageFor(c);await p.waitForSelector('.hero');const title=()=>p.locator('.hero:not(.hero-leaving) h1').innerText();
  assert.equal(await title(),'Spotlight 1');await (mobile?swipeTouch(p,true):swipeMouse(p,true));await p.waitForFunction(()=>document.querySelector('.hero:not(.hero-leaving) h1')?.textContent==='Spotlight 3');assert.equal(new URL(p.url()).pathname,'/browse','swipe did not navigate');
  assert.equal(await p.locator('.hero-leaving').count(),1,'animated outgoing slide');await p.waitForTimeout(500);
  await (mobile?swipeTouch(p,false):swipeMouse(p,false));await p.waitForFunction(()=>document.querySelector('.hero:not(.hero-leaving) h1')?.textContent==='Spotlight 1');await p.waitForTimeout(500);
  await p.locator('.hero:not(.hero-leaving) .dots [data-slide="1"]').click();await p.waitForFunction(()=>document.querySelector('.hero:not(.hero-leaving) h1')?.textContent==='Spotlight 2');await p.waitForTimeout(500);
  await p.locator('.hero:not(.hero-leaving) h1 a').click();await p.waitForURL(/\/browse\/anime\/424243/);await c.close();
 }
 const reduced=await context({reducedMotion:'reduce'});await installMocks(reduced);await reduced.addInitScript(()=>localStorage.setItem('kozutv-spotlight-autoplay','false'));const pr=await pageFor(reduced);await pr.waitForSelector('.hero');await swipeMouse(pr,true);assert.equal(await pr.locator('.hero-leaving').count(),0);assert.equal(await pr.locator('.hero h1').innerText(),'Spotlight 3');await reduced.close();
 // The row heading itself is a real navigable link; no separate See all label.
 const hc=await context();await installMocks(hc);await hc.addInitScript(()=>localStorage.setItem('kozutv-spotlight-autoplay','false'));const hp=await pageFor(hc);await hp.waitForSelector('.category-title-link');
 const link=hp.locator('.category-title-link').first(),href=await link.getAttribute('href'),text=await link.innerText();assert.equal(await hp.getByText('See all',{exact:false}).count(),0);await link.click();await hp.waitForURL(url=>url.pathname==='/browse'&&url.search===new URL(href,base).search);assert.equal(await hp.locator('h1.section-title').innerText(),text);await hc.close();
 console.log('PASS Spotlight left/right wrapping, desktop/touch, controls, title links, row navigation and reduced motion');

 // Pages are finite, unloaded well outside the viewport, reversible after LRU eviction.
 const requests=new Map();const c=await context();
 await c.addInitScript(()=>localStorage.setItem('kozutv-reduce-motion','true'));
 await installMocks(c,{genre:(route,u)=>{let n=Number(u.searchParams.get('page')||1);requests.set(n,(requests.get(n)||0)+1);return json(route,{items:Array.from({length:12},(_,i)=>({...anime,id:String(700000+n*100+i),title:`Page ${n} item ${i+1}`})),page:n,hasMore:n<25,totalResults:300})}});
 const p=await pageFor(c,'/browse?genre=Action');await p.waitForSelector('.genre-page[data-page="1"] .card');assert.equal(await p.locator('[data-more-results]').count(),0);
 for(let i=0;i<35;i++){
  const n=await p.locator('.genre-page').count();if(n>=25)break;
  await p.locator('#genre-sentinel').scrollIntoViewIfNeeded();await p.waitForFunction(n=>document.querySelectorAll('.genre-page').length>n,n,{timeout:12000});
 }
 assert.equal(await p.locator('.genre-page').count(),25);await p.waitForTimeout(800);
 const activeCards=await p.locator('.genre-page .card').count(),virtual=await p.locator('.genre-page.is-virtual').count();
 assert(activeCards<=96,`bounded nearby DOM: ${activeCards}`);assert(virtual>=18,`offscreen pages unloaded: ${virtual}`);
 const atEnd=[...requests.values()].reduce((a,b)=>a+b,0);await p.waitForTimeout(800);assert.equal([...requests.values()].reduce((a,b)=>a+b,0),atEnd,'no endless requests at exhaustion');
 assert((await p.locator('.genre-page[data-page="1"]').evaluate(e=>e.getBoundingClientRect().height))>100,'placeholder preserves height');
 await p.evaluate(()=>window.scrollTo(0,0));await p.waitForSelector('.genre-page[data-page="1"] .card',{timeout:12000});assert((requests.get(1)||0)>=2,'evicted page reloads');assert.equal(await p.locator('.genre-page[data-page="1"] .card h3').first().innerText(),'Page 1 item 1');
 await p.setViewportSize({width:390,height:844});await p.waitForTimeout(300);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth),390,'responsive placeholders');
 await p.evaluate(()=>window.scrollTo(0,document.documentElement.scrollHeight));await p.waitForSelector('.genre-page[data-page="25"] .card',{timeout:12000});await c.close();
 // Duplicate pages with dishonest hasMore stop after a small bounded number.
 let dup=0;const dc=await context();await installMocks(dc,{genre:(route)=>{dup++;return json(route,{items:[anime],hasMore:true})}});const dp=await pageFor(dc,'/browse?genre=Action');await dp.waitForTimeout(1700);assert(dup<=5&&dup>=4,'duplicate-only pages terminate');await dp.waitForTimeout(500);assert(dup<=5);await dc.close();
 // A transient failure stops auto-loading until the user retries.
 let failed=false;const rc=await context();await installMocks(rc,{genre:(route,u)=>{const n=Number(u.searchParams.get('page')||1);if(n===2&&!failed){failed=true;return json(route,{error:'temporary'},503)}return json(route,{items:[{...anime,id:String(900000+n),title:'Retry '+n}],hasMore:n<3})}});const rp=await pageFor(rc,'/browse?genre=Action');await rp.waitForSelector('[data-genre-retry]',{timeout:10000});await rp.locator('[data-genre-retry]').click();await rp.waitForSelector('.genre-page[data-page="3"] .card',{timeout:10000});await rc.close();
 // Delayed genre requests must not mutate the next route after navigation.
 let pendingGenre=false;const stale=await context();await installMocks(stale,{genre:async(route,u)=>{let n=Number(u.searchParams.get('page')||1);if(n>1){pendingGenre=true;await delay(700)}try{return await json(route,{items:[{...anime,id:String(960000+n)}],hasMore:n<4})}catch{return}}});
 const stp=await pageFor(stale,'/browse?genre=Action');for(let i=0;i<30&&!pendingGenre;i++)await stp.waitForTimeout(50);assert(pendingGenre,'next page requested');await stp.goto(base+'/settings',{waitUntil:'domcontentloaded'});await stp.waitForSelector('.settings-page');await stp.waitForTimeout(900);assert.equal(await stp.locator('.genre-page').count(),0);assert.equal(new URL(stp.url()).pathname,'/settings');await stale.close();
 console.log('PASS infinite genre scrolling, virtual unload/reload, resize, bounded exhaustion, duplicate guard, retry and stale-route cancellation');

 // Preference-first API failures with an incompatible episode-order catalog.
 for(const failures of [['hi'],['hi','dub']]){
  const attempts=[];const ac=await context();await ac.addInitScript(()=>{localStorage.setItem('kozutv-anime-lang','hi');localStorage.setItem('kozutv-autoplay','false')});
  await installMocks(ac,{animeItem:{...anime,dub:false},play:(route,u)=>{const lang=u.searchParams.get('lang'),ep=Number(u.searchParams.get('episode'));attempts.push([lang,ep]);return failures.includes(lang)?json(route,{error:'The selected language is not available for this episode.'},404):json(route,goodAnime(lang))}});
  const ap=await pageFor(ac,'/watch/anime/424242?episode=3');await videoReady(ap);
  const expected=failures.length===1?[['hi',3],['dub',1]]:[['hi',3],['dub',1],['sub',1]];assert.deepEqual(attempts,expected);
  const actual=failures.length===1?'dub':'sub';assert.match(ap.url(),new RegExp(`episode=1&lang=${actual}`));assert.equal(await ap.evaluate(()=>localStorage.getItem('kozutv-anime-lang')),'hi','fallback does not overwrite preferred audio');
  await ap.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('audio'));assert.equal(await ap.locator(`[data-audio-choice="${actual}"].selected`).count(),1,'actual language selected despite stale metadata');
  assert.equal(await ap.locator('.mp-notice:visible').count(),0);assert.equal(await ap.getByText(/language is not available|finding the selected audio|switching source/i).count(),0);await ac.close();
 }
 // A resolved URL can fail in the real Video.js tech; it must still fall back.
 const mediaAttempts=[];const mc=await context();await mc.addInitScript(()=>{localStorage.setItem('kozutv-anime-lang','hi');localStorage.setItem('kozutv-autoplay','false')});
 await installMocks(mc,{play:(route,u)=>{const l=u.searchParams.get('lang'),ep=Number(u.searchParams.get('episode'));mediaAttempts.push([l,ep]);return json(route,goodAnime(l,l==='hi'?'/__bad-hi.webm':'/__good.webm'))}});
 const mp=await pageFor(mc,'/watch/anime/424242?episode=3');await videoReady(mp);assert.deepEqual(mediaAttempts.slice(0,2),[['hi',3],['dub',1]]);assert.match(mp.url(),/episode=1&lang=dub/);assert.equal(await mp.locator('.mp-notice:visible').count(),0);await mc.close();
 // Same-order fallback retains the requested episode.
 const sameAttempts=[];const sc=await context();await sc.addInitScript(()=>{localStorage.setItem('kozutv-anime-lang','hi');localStorage.setItem('kozutv-autoplay','false')});
 await installMocks(sc,{animeItem:{...anime,differentDubOrder:false},play:(route,u)=>{const l=u.searchParams.get('lang');sameAttempts.push([l,Number(u.searchParams.get('episode'))]);return l==='hi'?json(route,{error:'unavailable'},404):json(route,goodAnime(l))}});
 const sp=await pageFor(sc,'/watch/anime/424242?episode=3');await videoReady(sp);assert.deepEqual(sameAttempts,[['hi',3],['dub',3]]);assert.match(sp.url(),/episode=3&lang=dub/);await sc.close();
 // Manual catalog crossing is silent and never resumes a differently ordered episode.
 const xc=await context();await xc.addInitScript(()=>localStorage.setItem('kozutv-autoplay','false'));await installMocks(xc);const xp=await pageFor(xc,'/settings');
 await xp.evaluate(async item=>fetch('/api/history',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...item,episode:1,season:1,currentTime:70,duration:180})}),anime);
 await xp.goto(base+'/watch/anime/424242?episode=3&lang=sub');await videoReady(xp);let dialogs=0;xp.on('dialog',d=>{dialogs++;d.dismiss()});await xp.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('audio'));await xp.locator('[data-audio-choice="dub"]').click();await xp.waitForURL(/episode=1&lang=dub/);await videoReady(xp);await xp.waitForTimeout(500);assert.equal(dialogs,0);assert((await xp.evaluate(()=>videojs.getPlayer('kozutv-video').currentTime()))<2,'cross-catalog episode 1 starts at the beginning');await xc.close();
 // Failed manual track switch rolls back without claiming the requested language.
 const manualLog=[];const fc=await context();await fc.addInitScript(()=>localStorage.setItem('kozutv-autoplay','false'));await installMocks(fc,{animeItem:{...anime,differentDubOrder:false},play:(route,u)=>{let l=u.searchParams.get('lang');manualLog.push(l);return json(route,goodAnime(l,l==='dub'?'/__bad-dub.webm':'/__good.webm'))}});
 const fp=await pageFor(fc,'/watch/anime/424242?episode=2&lang=sub');await videoReady(fp);await fp.evaluate(()=>{let v=videojs.getPlayer('kozutv-video');v.pause();v.currentTime(50)});await fp.waitForFunction(()=>Math.abs(videojs.getPlayer('kozutv-video').currentTime()-50)<1);
 await fp.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('audio'));await fp.locator('[data-audio-choice="dub"]').click();await fp.waitForFunction(()=>videojs.getPlayer('kozutv-video').megaUI.isSourceSwitching(),{timeout:5000});await fp.waitForFunction(()=>!videojs.getPlayer('kozutv-video').megaUI.isSourceSwitching(),{timeout:15000});await fp.waitForTimeout(250);
 assert.match(fp.url(),/episode=2&lang=sub/);assert(Math.abs(await fp.evaluate(()=>videojs.getPlayer('kozutv-video').currentTime())-50)<2,'failed switch restores position');assert.equal(await fp.locator('.mp-notice:visible').count(),0);await fc.close();
 // All failures produce one useful generic error, not availability popups.
 const all=[];const ec=await context();await ec.addInitScript(()=>localStorage.setItem('kozutv-anime-lang','hi'));await installMocks(ec,{play:(route,u)=>{all.push(u.searchParams.get('lang'));return json(route,{error:'The selected language is not available for this episode.'},404)}});const ep=await pageFor(ec,'/watch/anime/424242?episode=2');await ep.waitForSelector('.player-error');assert.deepEqual(all,['hi','dub','sub']);assert.equal(await ep.getByText(/selected language is not available/i).count(),0);assert.equal(await ep.locator('.player-error [data-retry]').count(),1);await ec.close();
 console.log('PASS anime preference-first API/media fallbacks, truthful labels, silent episode-one switching, rollback and terminal errors');

 // OTT direct streams: a broken preferred track falls through English then Japanese.
 const streams=[{language:'ja',label:'Japanese',src:'/__ja.webm',type:'video/webm'},{language:'hi',label:'Hindi',src:'/__bad-hi.webm',type:'video/webm'},{language:'en',label:'English',src:'/__en.webm',type:'video/webm'}];
 const ottMedia=[];const oc=await context();await oc.addInitScript(()=>{localStorage.setItem('kozutv-ott-audio','hi');localStorage.setItem('kozutv-autoplay','false')});await installMocks(oc,{mediaLog:ottMedia,play:route=>json(route,goodOtt('vidcore','/__ja.webm',streams))});
 const op=await pageFor(oc,'/watch/movie/55555');await videoReady(op);await op.waitForFunction(()=>videojs.getPlayer('kozutv-video').currentSrc().includes('__en.webm'),{timeout:25000});await op.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('audio'));assert.equal(await op.locator('[data-audio-stream="2"].selected').count(),1);assert.equal(await op.evaluate(()=>localStorage.getItem('kozutv-ott-audio')),'hi');assert.equal(await op.locator('.mp-notice:visible').count(),0);assert.equal(ottMedia[0],'/__bad-hi.webm','preference is tried before the default');assert.equal(ottMedia.filter(x=>x==='/__bad-hi.webm').length,1,'failed audio is not retried in a loop');await oc.close();
 // Cross-provider audio variants update the displayed server and URL, including manual changes.
 const vc=await context();await vc.addInitScript(()=>{localStorage.setItem('kozutv-ott-audio','hi');localStorage.setItem('kozutv-autoplay','false')});
 const cross=[{language:'en',label:'English',src:'/__en.webm',type:'video/webm',sourceKey:'vidcore',server:'VidCore',provider:'VidCore'},{language:'hi',label:'Hindi',src:'/__hi.webm',type:'video/webm',sourceKey:'embedwave',server:'EmbedWave',provider:'EmbedWave'}];
 await installMocks(vc,{play:route=>json(route,goodOtt('vidcore','/__en.webm',cross))});const vp=await pageFor(vc,'/watch/movie/55555');await videoReady(vp);assert.match(vp.url(),/provider=embedwave/);await vp.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('quality'));assert.equal(await vp.locator('[data-server-choice="embedwave"].selected').count(),1);
 await vp.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('audio'));await vp.locator('[data-audio-stream="0"]').click();await vp.waitForFunction(()=>videojs.getPlayer('kozutv-video').currentSrc().includes('__en.webm'));await vp.waitForFunction(()=>!location.search);await vp.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('quality'));assert.equal(await vp.locator('[data-server-choice="vidcore"].selected').count(),1);await vc.close();
 // Legacy player preference is respected only until the new selector explicitly chooses default.
 for(const explicitAuto of [false,true]){
  const lc=await context();await lc.addInitScript(auto=>{localStorage.setItem('kozutv-autoplay','false');localStorage.setItem('kozutv-audio-pref',JSON.stringify({language:'ja',label:'japanese'}));if(auto)localStorage.setItem('kozutv-ott-audio','auto')},explicitAuto);
  const variants=[{language:'en',label:'English',src:'/__en.webm',type:'video/webm'},{language:'ja',label:'Japanese',src:'/__ja.webm',type:'video/webm'}];await installMocks(lc,{play:route=>json(route,goodOtt('vidcore','/__en.webm',variants))});const lp=await pageFor(lc,'/watch/movie/55555');await videoReady(lp);
  if(!explicitAuto)await lp.waitForFunction(()=>videojs.getPlayer('kozutv-video').currentSrc().includes('__ja.webm'),{timeout:10000});else {await lp.waitForTimeout(500);assert((await lp.evaluate(()=>videojs.getPlayer('kozutv-video').currentSrc())).includes('__en.webm'))}
  await lc.close();
 }
 // Exercise the Video.js audio-track path as well as separate source files.
 const hls=await context();await hls.addInitScript(()=>{localStorage.setItem('kozutv-ott-audio','hi');localStorage.setItem('kozutv-autoplay','false')});await installMocks(hls,{play:route=>json(route,goodOtt('vidcore','/__good.webm',[]))});
 const hpage=await pageFor(hls,'/watch/movie/55555');await videoReady(hpage);
 await hpage.evaluate(()=>{const v=videojs.getPlayer('kozutv-video'),tracks=v.audioTracks();tracks.addTrack(new videojs.AudioTrack({id:'qa-ja',kind:'main',label:'Japanese',language:'ja',enabled:true}));tracks.addTrack(new videojs.AudioTrack({id:'qa-en',kind:'main',label:'English',language:'en',enabled:false}))});
 await hpage.waitForFunction(()=>Array.from(videojs.getPlayer('kozutv-video').audioTracks()).some(t=>t.language==='en'&&t.enabled),{timeout:10000});await hpage.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('audio'));assert.equal(await hpage.locator('.mp-audio-list .selected').innerText(),'English');await hls.close();
 // Actual source errors advance through distinct servers and report the resolver's real server.
 const serverCalls=[];const tc=await context();await tc.addInitScript(()=>localStorage.setItem('kozutv-autoplay','false'));
 await installMocks(tc,{play:(route,u)=>{const source=u.searchParams.get('provider'),exclude=u.searchParams.get('exclude')||'';serverCalls.push([source,exclude]);if(source==='vidcore')return json(route,goodOtt('vidcore','/__bad-server1.webm'));if(source==='embedwave')return json(route,goodOtt('cinesrc','/__bad-server2.webm'));return json(route,goodOtt('vidsrc','/__good.webm'))}});
 const tp=await pageFor(tc,'/watch/movie/55555');await videoReady(tp);assert.deepEqual(serverCalls.map(x=>x[0]),['vidcore','embedwave','vidlink']);assert(serverCalls[1][1].includes('vidcore'));for(const key of ['vidcore','embedwave','cinesrc'])assert(serverCalls[2][1].includes(key));
 assert.match(tp.url(),/provider=vidsrc/);await tp.evaluate(()=>videojs.getPlayer('kozutv-video').megaUI.openSettings('quality'));assert.equal(await tp.locator('[data-server-choice="vidsrc"].selected').count(),1);assert.equal(await tp.locator('.mp-notice:visible').count(),0);await tc.close();
 console.log('PASS movie audio preference, broken-track fallback, legacy/default behavior and real server failover');
 assert.deepEqual(errors,[],'no uncaught browser errors');console.log('ALL V5.4.12 FEATURE QA PASSED');
}finally{
 if(browser)await browser.close();
 if(child&&child.exitCode===null){const done=once(child,'exit').catch(()=>{});child.kill('SIGTERM');await Promise.race([done,delay(2000)]);if(child.exitCode===null)child.kill('SIGKILL')}
 fs.rmSync(work,{recursive:true,force:true});
}
