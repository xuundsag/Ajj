// End-to-end mirror test with an in-memory MongoDB adapter: the real
// persistence code runs, no live cluster is required.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createTokenPersistence } from '../cache-token-persistence.js';

const docs = new Map();
const collection = {
  async createIndex() {},
  async replaceOne(filter, doc) { docs.set(filter._id, structuredClone(doc)); return { acknowledged: true }; },
  async findOne(filter) { const d = docs.get(filter._id); return d ? structuredClone(d) : null; }
};
class FakeClient {
  async connect() {}
  db() { return { collection: () => collection }; }
  async close() {}
}
const clientFactory = async () => FakeClient;

const dirs = [];
const temp = () => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'kozu-mirror-')); dirs.push(d); return d; };
const quiet = { warn() {} };

const dir = temp();
const store = createTokenPersistence({ dataDir: dir, uri: 'mongodb://stub', log: quiet, clientFactory });
await store.init();
assert.equal(store.state.backend, 'mongodb');

const row = store.create('b'.repeat(32), { 'kozutv-speed': '1.25' });
await store.flush();
await new Promise(r => setTimeout(r, 400));
const doc = docs.get('cache-token-store');
assert(doc && doc.tokens && Object.keys(doc.tokens).length === 1, 'token mirrored to MongoDB');
assert.equal(Buffer.from(doc.key, 'base64').length, 32, 'encryption key mirrored');
assert.equal(store.patch('b'.repeat(32), { 'kozutv-quality': '720' }).preferences['kozutv-quality'], '720');
await store.flush();

// Simulate "files deleted": a new data directory must recover from MongoDB.
const fresh = temp();
const restored = createTokenPersistence({ dataDir: fresh, uri: 'mongodb://stub', log: quiet, clientFactory });
const state = await restored.init();
assert.equal(state.backend, 'mongodb');
assert.equal(restored.resolve(row.token).token, row.token, 'token recovered after the files were deleted');
assert.equal(restored.resolve(row.token).preferences['kozutv-quality'], '720', 'preferences recovered');
assert(fs.existsSync(path.join(fresh, 'cache-tokens.json')) && fs.existsSync(path.join(fresh, 'cache-token.key')), 'local files rebuilt from MongoDB');

// Newest copy wins: a local change is pushed, then pulled back into a lost copy.
restored.patch('b'.repeat(32), { 'kozutv-autoplay': 'false' });
await restored.flush();
const again = createTokenPersistence({ dataDir: temp(), uri: 'mongodb://stub', log: quiet, clientFactory });
await again.init();
assert.equal(again.status('b'.repeat(32)).preferences['kozutv-autoplay'], 'false', 'newest mirror wins');
await store.close(); await restored.close(); await again.close();
for (const d of dirs) fs.rmSync(d, { recursive: true, force: true });
console.log('PASS MongoDB mirror: write-through, file-loss recovery, preference recovery and newest-copy resolution');
