// Verifies Cache Token file fallback, delete-the-files recovery and the
// refusal to regenerate a missing key. The MongoDB mirror itself is covered by
// scripts/test-token-mirror.mjs with an in-memory adapter.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createTokenPersistence } from '../cache-token-persistence.js';

const quiet = { warn() {} };
const dirs = [];
const temp = () => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'kozu-persist-')); dirs.push(d); return d; };
const { createCacheTokenStore } = await import('../cache-tokens.js');

const base = temp();
const local = createCacheTokenStore(base);
const first = local.create('a'.repeat(32), { 'kozutv-autoplay': 'false' });
assert.match(first.token, /^[A-Z0-9]{6}$/);

// 1. File mode (no MongoDB configured) still works and reports its backend.
const filesOnly = createTokenPersistence({ dataDir: base, uri: '', log: quiet });
await filesOnly.init();
assert.equal(filesOnly.state.backend, 'files');
assert.equal(filesOnly.resolve(first.token).token, first.token, 'file-only mode resolves tokens');
assert.equal(filesOnly.state.mongo, 'disabled');
await filesOnly.close();

// 2. The document written by the persistence layer is exactly what the local
//    store produced, so a remote copy can rebuild the files.
const localDoc = JSON.parse(fs.readFileSync(path.join(base, 'cache-tokens.json'), 'utf8'));
assert.equal(localDoc.version, 1);
assert.equal(Object.keys(localDoc.tokens).length, 1);
const keyB64 = fs.readFileSync(path.join(base, 'cache-token.key')).toString('base64');
assert.equal(Buffer.from(keyB64, 'base64').length, 32);

// 3. Deleting both files and restoring the mirrored document recovers the token.
const recovered = temp();
fs.mkdirSync(recovered, { recursive: true });
fs.writeFileSync(path.join(recovered, 'cache-tokens.json'), JSON.stringify({ version: 1, tokens: localDoc.tokens, visitors: localDoc.visitors }));
fs.writeFileSync(path.join(recovered, 'cache-token.key'), Buffer.from(keyB64, 'base64'));
const rebuilt = createCacheTokenStore(recovered);
assert.equal(rebuilt.status('a'.repeat(32)).token, first.token, 'token survives deleting the data directory');
assert.equal(rebuilt.patch('a'.repeat(32), { 'kozutv-speed': '1.5' }).preferences['kozutv-speed'], '1.5');

// 4. A lost key with existing tokens must fail loudly instead of regenerating.
const nokey = temp();
fs.mkdirSync(nokey, { recursive: true });
fs.writeFileSync(path.join(nokey, 'cache-tokens.json'), JSON.stringify(localDoc));
assert.throws(() => createCacheTokenStore(nokey), /key is missing/);

// 5. Offline MongoDB: init must not throw and must keep the file backend usable.
const offline = createTokenPersistence({ dataDir: base, uri: 'mongodb://127.0.0.1:1/none?serverSelectionTimeoutMS=200', log: quiet });
const state = await offline.init();
assert.equal(state.mongo, 'unavailable');
assert.equal(offline.resolve(first.token).token, first.token, 'tokens still resolve while MongoDB is offline');
assert.equal(offline.state.backend, 'files');
await offline.close();


for (const d of dirs) fs.rmSync(d, { recursive: true, force: true });
console.log('PASS Cache Token MongoDB persistence: file fallback, mirror document, delete-files recovery, missing-key refusal, offline start');
