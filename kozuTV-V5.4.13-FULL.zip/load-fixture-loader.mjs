// Only loaded in the isolated load-test child; no external provider or AI calls.
import fs from 'node:fs';
const real=globalThis.fetch;
const seed=fs.readFileSync('/tmp/kozu-audio/seg.bin'), segment=Buffer.concat(Array(6).fill(seed));
globalThis.fetch=async(input,init)=>{
 const u=new URL(typeof input==='string'?input:input.url||input.href);
 if(u.hostname==='api.themoviedb.org'&&/^\/3\/movie\/\d+$/.test(u.pathname)){
  const id=Number(u.pathname.split('/').at(-1));const body={id,title:`Synthetic test title ${id}`,original_title:`Synthetic test title ${id}`,adult:false,release_date:'2024-01-01',status:'Released',original_language:'en',overview:'Load-test fixture',poster_path:'/not-loaded.jpg',backdrop_path:'/not-loaded.jpg',vote_average:7,vote_count:100,popularity:100,genres:[]};return new Response(JSON.stringify(body),{status:200,headers:{'content-type':'application/json'}});
 }
 if(u.hostname==='fixtures.kozu.test'){
  if(u.pathname.endsWith('/master.m3u8'))return new Response('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1300000,RESOLUTION=640x360\nmedia.m3u8\n',{status:200,headers:{'content-type':'application/vnd.apple.mpegurl'}});
  if(u.pathname.endsWith('/media.m3u8'))return new Response('#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:3\n'+Array.from({length:8},(_,i)=>`#EXTINF:3.0,\nsegment-${i}.ts\n`).join('')+'#EXT-X-ENDLIST\n',{status:200,headers:{'content-type':'application/vnd.apple.mpegurl'}});
  if(/\/segment-\d+\.ts$/.test(u.pathname))return new Response(segment,{status:200,headers:{'content-type':'video/mp2t','content-length':String(segment.length)}});
  return new Response('',{status:404});
 }
 return real(input,init);
};
