import fs from 'node:fs';
import path from 'node:path';
import { createCacheTokenStore } from './cache-tokens.js';

// Cache Token persistence.
//
// The local JSON files remain the working copy, but every change is mirrored to
// a single MongoDB document. If the data files are deleted (or the app is moved
// to another machine), startup pulls that document back and rebuilds both
// files, so existing tokens keep working. MongoDB is optional: when it is
// unreachable the server keeps using the files and retries in the background.

const DOC_ID = 'cache-token-store';
const MAX_TOKENS = 100000;

const isPlainObject = v => Boolean(v) && typeof v === 'object' && !Array.isArray(v);

function validDoc(doc) {
  if (!isPlainObject(doc)) return null;
  if (!isPlainObject(doc.tokens) || !isPlainObject(doc.visitors)) return null;
  const entries = Object.entries(doc.tokens);
  if (entries.length > MAX_TOKENS) return null;
  for (const [hash, entry] of entries) {
    if (!/^[a-f0-9]{64}$/.test(hash) || !isPlainObject(entry)) return null;
    if (typeof entry.sealed !== 'string' || typeof entry.visitorId !== 'string') return null;
    if (!isPlainObject(entry.preferences)) return null;
  }
  for (const [visitor, hash] of Object.entries(doc.visitors)) {
    if (typeof visitor !== 'string' || typeof hash !== 'string') return null;
  }
  return { tokens: doc.tokens, visitors: doc.visitors, updatedAt: Number(doc.updatedAt) || 0, key: typeof doc.key === 'string' ? doc.key : '' };
}

function atomicWrite(file, data, mode = 0o600) {
  const temp = `${file}.${process.pid}.${Date.now().toString(36)}.tmp`;
  try {
    fs.writeFileSync(temp, data, { flag: 'wx', mode });
    fs.renameSync(temp, file);
  } finally { try { fs.unlinkSync(temp); } catch {} }
}

export function createTokenPersistence({ dataDir, uri = '', dbName = 'kozutv', collectionName = 'cache_token_store', log = console, retryMs = 60000, clientFactory = null } = {}) {
  // clientFactory is injectable so tests can supply an in-memory adapter.
  const makeClient = clientFactory || (async () => { const { MongoClient } = await import('mongodb'); return MongoClient; });
  const dbPath = path.join(dataDir, 'cache-tokens.json');
  const keyPath = path.join(dataDir, 'cache-token.key');
  const state = { backend: 'files', mongo: 'disabled', lastPush: 0, lastError: '', store: null };
  let client = null, collection = null, pushTimer = null, retryTimer = null, pushing = false;

  const readLocalDoc = () => {
    try {
      const raw = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      const doc = validDoc(raw);
      if (!doc) return null;
      doc.updatedAt = Number(doc.updatedAt) || fs.statSync(dbPath).mtimeMs;
      return doc;
    } catch { return null; }
  };
  const readLocalKey = () => {
    try {
      const key = fs.readFileSync(keyPath);
      return key.length === 32 ? key.toString('base64') : '';
    } catch { return ''; }
  };

  function writeLocalDoc(doc) {
    fs.mkdirSync(dataDir, { recursive: true });
    if (doc.key) {
      const key = Buffer.from(doc.key, 'base64');
      if (key.length === 32) atomicWrite(keyPath, key);
    }
    atomicWrite(dbPath, JSON.stringify({ version: 1, tokens: doc.tokens, visitors: doc.visitors }));
    try { fs.utimesSync(dbPath, new Date(), new Date(doc.updatedAt || Date.now())); } catch {}
  }

  function snapshotLocal(updatedAt = Date.now()) {
    const doc = readLocalDoc();
    if (!doc) return null;
    return { tokens: doc.tokens, visitors: doc.visitors, updatedAt, key: readLocalKey() };
  }

  async function connect() {
    if (!uri) { state.mongo = 'disabled'; state.backend = 'files'; return false; }
    try {
      const MongoClient = await makeClient();
      if (!client) {
        client = new MongoClient(uri, { serverSelectionTimeoutMS: 8000, connectTimeoutMS: 8000, retryWrites: true, appName: 'kozuTV' });
        await client.connect();
      }
      collection = client.db(dbName).collection(collectionName);
      await collection.createIndex({ updatedAt: -1 });
      state.mongo = 'connected';
      return true;
    } catch (error) {
      state.mongo = 'unavailable';
      state.lastError = String(error?.message || error).slice(0, 200);
      try { await client?.close(); } catch {}
      client = null; collection = null;
      return false;
    }
  }

  async function push(reason = 'mutation') {
    if (!collection || pushing) return false;
    const doc = snapshotLocal();
    if (!doc) return false;
    pushing = true;
    state.lastPush = Date.now();
    try {
      const next = { _id: DOC_ID, version: 1, tokens: doc.tokens, visitors: doc.visitors, updatedAt: state.lastPush, key: doc.key };
      await collection.replaceOne({ _id: DOC_ID }, next, { upsert: true });
      // Keep the local copy's timestamp in step so "newest wins" comparisons
      // do not mistake a mirror push for a local edit.
      fs.utimesSync(dbPath, new Date(state.lastPush), new Date(state.lastPush));
      state.lastError = '';
      return true;
    } catch (error) {
      state.lastError = String(error?.message || error).slice(0, 200);
      state.mongo = 'unavailable';
      collection = null;
      try { await client?.close(); } catch {}
      client = null;
      return false;
    } finally { pushing = false; }
  }

  function schedulePush() {
    if (!collection) return;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(() => { push().catch(() => {}); }, 250);
    pushTimer.unref?.();
  }

  async function syncFromMongo() {
    if (!collection) return false;
    const raw = await collection.findOne({ _id: DOC_ID });
    const remote = validDoc(raw);
    if (!remote) return false;
    const local = readLocalDoc();
    const remoteHasData = Object.keys(remote.tokens).length > 0;
    const localMissing = !fs.existsSync(dbPath) || !fs.existsSync(keyPath);
    if (remoteHasData && (localMissing || !local || remote.updatedAt > local.updatedAt)) {
      writeLocalDoc(remote);
      state.backend = 'mongodb';
      return true;
    }
    if (local && Object.keys(local.tokens).length) await push('backfill');
    return false;
  }

  async function init() {
    fs.mkdirSync(dataDir, { recursive: true });
    const connected = await connect();
    if (connected) {
      try { await syncFromMongo(); } catch (error) { state.lastError = String(error?.message || error).slice(0, 200); }
    }
    // createCacheTokenStore repairs a missing key for an empty database; it
    // refuses to regenerate a key while tokens exist, so a lost key is an error.
    state.store = createCacheTokenStore(dataDir);
    if (state.mongo !== 'connected') {
      log.warn?.(`kozuTV: MongoDB token backup unavailable (${state.mongo}); using local files.`);
      scheduleRetry();
    } else if (!readLocalDoc()?.tokens || !Object.keys(readLocalDoc().tokens).length) {
      await push('startup');
    }
    return state;
  }

  function scheduleRetry() {
    if (retryTimer || !uri) return;
    retryTimer = setInterval(async () => {
      if (state.mongo === 'connected') return;
      const ok = await connect();
      if (!ok) return;
      clearInterval(retryTimer); retryTimer = null;
      try { await syncFromMongo(); } catch {}
      log.warn?.('kozuTV: MongoDB token backup reconnected.');
    }, retryMs);
    retryTimer.unref?.();
  }

  const withPush = fn => (...args) => {
    const result = fn(...args);
    schedulePush();
    return result;
  };

  return {
    init,
    get state() { return { backend: collection ? 'mongodb' : 'files', mongo: state.mongo, lastPush: state.lastPush, error: state.lastError }; },
    status: visitor => state.store.status(visitor),
    create: withPush((visitor, preferences) => state.store.create(visitor, preferences)),
    resolve: code => state.store.resolve(code),
    patch: withPush((visitor, changes) => state.store.patch(visitor, changes)),
    flush: () => push('flush'),
    async close() {
      clearTimeout(pushTimer); clearInterval(retryTimer);
      await push('shutdown').catch(() => {});
      try { await client?.close(); } catch {}
    }
  };
}
