import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

// A six-character code is deliberately only a convenience credential, not a
// strong password. Never log it; the persisted index is a keyed hash and the
// display value is encrypted with a key kept separately from the database.
const CODE = /^[A-Z0-9]{6}$/;
const PREF_KEY = /^kozutv-(?!cache-)[a-z0-9-]{1,70}$/;
const LEGACY_PREFIX = 'moscowtv-';
// Records written before the rename may still carry the old prefix. Accept them
// on read so existing profiles keep working; new writes must use kozutv-*.
const legacyKey = key => typeof key === 'string' && key.startsWith(LEGACY_PREFIX);
const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

export class CacheTokenError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}
const badPrefs = () => new CacheTokenError('INVALID_PREFS', 'Invalid preference data.');

function validatePreferences(value, allowDelete = false) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw badPrefs();
  const entries = Object.entries(value);
  if (entries.length > 80) throw badPrefs();
  const result = {};
  let size = 0;
  for (const [key, val] of entries) {
    if ((!PREF_KEY.test(key) && !legacyKey(key)) || (typeof val !== 'string' && !(allowDelete && val === null))) throw badPrefs();
    if (typeof val === 'string' && Buffer.byteLength(val) > 8192) throw badPrefs();
    size += Buffer.byteLength(key) + (typeof val === 'string' ? Buffer.byteLength(val) : 0);
    if (size > 32000) throw badPrefs();
    result[key] = val;
  }
  return result;
}

export function createCacheTokenStore(dataDir) {
  fs.mkdirSync(dataDir, { recursive: true });
  const dbPath = path.join(dataDir, 'cache-tokens.json');
  const keyPath = path.join(dataDir, 'cache-token.key');
  if (!fs.existsSync(keyPath)) {
    // Never silently replace the key for an existing token database.
    if (fs.existsSync(dbPath)) {
      const existing = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      if (Object.keys(existing.tokens || {}).length) throw new Error('Cache token key is missing; restore data/cache-token.key.');
    }
    try { fs.writeFileSync(keyPath, crypto.randomBytes(32), { flag: 'wx', mode: 0o600 }); }
    catch (error) { if (error.code !== 'EEXIST') throw error; }
  }
  const master = fs.readFileSync(keyPath);
  if (master.length !== 32) throw new Error('Cache token key is invalid.');
  const derive = purpose => crypto.createHmac('sha256', master).update(purpose).digest();
  const lookupKey = derive('kozutv-cache-token-lookup-v1');
  const encryptionKey = derive('kozutv-cache-token-encryption-v1');
  const digest = code => crypto.createHmac('sha256', lookupKey).update(code).digest('hex');
  function seal(code) {
    const iv = crypto.randomBytes(12), cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey, iv);
    const ciphertext = Buffer.concat([cipher.update(code, 'utf8'), cipher.final()]);
    return [iv, cipher.getAuthTag(), ciphertext].map(v => v.toString('base64url')).join('.');
  }
  function unseal(value) {
    const parts = String(value || '').split('.');
    if (parts.length !== 3) throw new Error('Cache token data is invalid.');
    const [iv, tag, ciphertext] = parts.map(v => Buffer.from(v, 'base64url'));
    const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey, iv);
    decipher.setAuthTag(tag);
    const result = Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
    if (!CODE.test(result)) throw new Error('Cache token data is invalid.');
    return result;
  }
  function read() {
    if (!fs.existsSync(dbPath)) return { version: 1, tokens: {}, visitors: {} };
    // A corrupt database must never be treated as empty and then overwritten.
    const d = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    if (!d || d.version !== 1 || !d.tokens || typeof d.tokens !== 'object' || Array.isArray(d.tokens) || !d.visitors || typeof d.visitors !== 'object' || Array.isArray(d.visitors)) throw new Error('Cache token database is invalid.');
    return d;
  }
  function write(data) {
    const temp = `${dbPath}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
    try {
      fs.writeFileSync(temp, JSON.stringify(data), { flag: 'wx', mode: 0o600 });
      fs.renameSync(temp, dbPath);
    } finally { try { fs.unlinkSync(temp); } catch {} }
  }
  function entryForVisitor(data, visitor) {
    const hash = data.visitors[visitor], entry = hash && data.tokens[hash];
    return entry && entry.visitorId === visitor ? entry : null;
  }
  function status(visitor) {
    const data = read(), entry = entryForVisitor(data, visitor);
    return entry ? { bound: true, token: unseal(entry.sealed), preferences: { ...(entry.preferences || {}) }, revision: Number(entry.revision) || 1 } : { bound: false };
  }
  function create(visitor, preferences) {
    const clean = validatePreferences(preferences);
    const data = read();
    if (entryForVisitor(data, visitor)) throw new CacheTokenError('BOUND', 'This browser already has a token.');
    let code, hash;
    for (let attempt = 0; attempt < 64; attempt++) {
      code = Array.from({ length: 6 }, () => ALPHABET[crypto.randomInt(ALPHABET.length)]).join('');
      if (!/[A-Z]/.test(code) || !/[0-9]/.test(code)) continue;
      hash = digest(code);
      if (!data.tokens[hash]) break;
      hash = '';
    }
    if (!hash) throw new Error('Could not generate a token.');
    data.tokens[hash] = { visitorId: visitor, sealed: seal(code), preferences: clean, revision: 1, createdAt: Date.now(), updatedAt: Date.now() };
    data.visitors[visitor] = hash;
    data.updatedAt = Date.now();
    write(data);
    return { bound: true, token: code, preferences: clean, revision: 1 };
  }
  function resolve(code) {
    if (!CODE.test(code)) return null;
    const data = read(), entry = data.tokens[digest(code)];
    if (!entry || data.visitors[entry.visitorId] !== digest(code)) return null;
    return { visitorId: entry.visitorId, token: code, preferences: { ...(entry.preferences || {}) }, revision: Number(entry.revision) || 1 };
  }
  function patch(visitor, changes) {
    const clean = validatePreferences(changes, true), data = read(), entry = entryForVisitor(data, visitor);
    if (!entry) throw new CacheTokenError('UNBOUND', 'This browser does not have a token.');
    const next = { ...(entry.preferences || {}) };
    for (const [key, val] of Object.entries(clean)) {
      if (val === null) delete next[key]; else next[key] = val;
    }
    validatePreferences(next);
    entry.preferences = next;
    entry.revision = (Number(entry.revision) || 1) + 1;
    entry.updatedAt = Date.now();
    data.updatedAt = entry.updatedAt;
    write(data);
    return { bound: true, preferences: { ...next }, revision: entry.revision };
  }
  return { status, create, resolve, patch };
}
