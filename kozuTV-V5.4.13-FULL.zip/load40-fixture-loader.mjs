// Test-only fetch fixture for isolated load tests. No NVIDIA instrumentation is installed.
import fs from 'node:fs';
const origFetch=globalThis.fetch;
globalThis.fetch=async(input,init)=>{const u=new URL(typeof input==='string'?input:input.url||input.href);if(u.hostname==='fixtures.kozu.test'){
 const n=u.pathname.split('/').at(-1),ok=/^media\.m3u8$|^seg-\d{3}\.ts$/.test(n);if(!ok)return new Response('',{status:404});const b=fs.readFileSync('/tmp/kozu-audio/sync-hls/'+n);return new Response(b,{status:200,headers:{'content-type':n.endsWith('.ts')?'video/mp2t':'application/vnd.apple.mpegurl','content-length':String(b.length)}});
 }return origFetch(input,init);};
