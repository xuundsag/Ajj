import freekeys from 'freekeys';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { resolveMegaPlayDirect, enrichAnimeQualityStreams } from './megaplay-resolver.js';
import { mediaUrl, dashUrl, handleMedia, handleDash } from './media-proxy.js';
import { OTT_SERVER_KEYS, DEFAULT_OTT_SERVER, resolveOttWithFallback, fetchVidsparkSubtitles } from './ott-resolvers.js';

const root = path.resolve('public');
const db = path.resolve('data/user.json');
const statesDb = path.resolve('data/states.json');
const initial = { watchlist: [], history: [] };
if (!fs.existsSync(db)) fs.writeFileSync(db, JSON.stringify(initial));
if (!fs.existsSync(statesDb)) fs.writeFileSync(statesDb, JSON.stringify({ visitors: {}, meta: {} }));

const json = (res, data, status = 200, req = null) => {
  let body = JSON.stringify(data), accept = String(req?.headers?.['accept-encoding'] || '');
  if (body.length > 1024 && accept.includes('gzip')) {
    let gz = zlib.gzipSync(body, { level: 4 });
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Encoding': 'gzip', 'Vary': 'Accept-Encoding', 'Cache-Control': 'no-store' });
    return res.end(gz);
  }
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
};

const cache = new Map();
async function remote(url, options = {}) {
  let ttl = options.ttl ?? 300000, c = cache.get(url);
  if (c && Date.now() - c.time < (c.ttl || ttl)) return c.data;
  let r = await fetch(url, {
    headers: { 'User-Agent': 'kozuTV/5.0 (catalog app)', ...(options.headers || {}) },
    signal: AbortSignal.timeout(options.timeout || 12000)
  });
  let text = await r.text();
  if (!r.ok) throw Error('Catalog unavailable (' + r.status + ')');
  let data;
  try { data = JSON.parse(text); } catch { throw Error('A catalog service returned an invalid response.'); }
  cache.set(url, { data, time: Date.now(), ttl });
  return data;
}

const genreNames = { 28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy', 80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family', 14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music', 9648: 'Mystery', 10749: 'Romance', 878: 'Science Fiction', 10770: 'TV Movie', 53: 'Thriller', 10752: 'War', 37: 'Western', 10759: 'Action & Adventure', 10765: 'Sci-Fi & Fantasy' };
const catalogGenres = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Horror', 'Mecha', 'Music', 'Mystery', 'Psychological', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller'];
const movieGenreIds = { Action: 28, Adventure: 12, Animation: 16, Comedy: 35, Crime: 80, Documentary: 99, Drama: 18, Family: 10751, Fantasy: 14, Horror: 27, Music: 10402, Mystery: 9648, Romance: 10749, 'Sci-Fi': 878, Thriller: 53 };
const tvGenreIds = { Action: 10759, Adventure: 10759, Animation: 16, Comedy: 35, Crime: 80, Documentary: 99, Drama: 18, Family: 10751, Fantasy: 10765, Mystery: 9648, 'Sci-Fi': 10765 };

const today = () => new Date().toISOString().slice(0, 10);
const releasedDate = value => Boolean(value) && /^\d{4}-\d{2}-\d{2}$/.test(String(value).slice(0, 10)) && String(value).slice(0, 10) <= today();

function decodeEntities(value) {
  return String(value || '')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&(amp|quot|apos|lt|gt|hellip|mdash|ndash);/g, (_, name) => ({ amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', hellip: '…', mdash: '—', ndash: '–' })[name]);
}
function normalizeTitle(value) {
  return String(value || '').replace(/['’‘`]/g, '').toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, ' ').trim();
}

const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
function parseAiredStartDate(aired, year) {
  const s = String(aired || '').split(/\s+to\s+/i)[0].trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  if (/^\d{4}-\d{2}$/.test(s)) return `${s}-01`;
  const m1 = s.match(/^([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})$/);
  if (m1) {
    const mo = MONTHS[m1[1].slice(0, 3).toLowerCase()];
    if (mo) return `${m1[3]}-${String(mo).padStart(2, '0')}-${String(m1[2]).padStart(2, '0')}`;
  }
  const m2 = s.match(/^([A-Za-z]{3,9})\s+(\d{4})$/);
  if (m2) {
    const mo = MONTHS[m2[1].slice(0, 3).toLowerCase()];
    if (mo) return `${m2[2]}-${String(mo).padStart(2, '0')}-01`;
  }
  if (/^\d{4}$/.test(s) && Number(s) > new Date().getFullYear()) return `${s}-01-01`;
  if (year && Number(year) > new Date().getFullYear()) return `${year}-01-01`;
  return '';
}

const megaCatalogPath = path.resolve('data/megaplay-catalog.json');
let megaEntries = [], megaAliases = [];
try {
  let d = JSON.parse(fs.readFileSync(megaCatalogPath));
  megaEntries = Array.isArray(d.entries) ? d.entries : [];
  megaAliases = Array.isArray(d.aliases) ? d.aliases : [];
} catch {}

// Build alias set across ALL anime entries (including unreleased) so unreleased/unavailable anime on TMDB never leaks into Movies/TV
const megaAliasSet = new Set(megaAliases.map(normalizeTitle).filter(Boolean));
for (let entry of megaEntries) {
  for (let raw of [entry.title, entry.english, entry.alternative, ...String(entry.titles || '').split(/[;,]/)]) {
    let norm = normalizeTitle(raw);
    if (norm && norm.length >= 3) megaAliasSet.add(norm);
  }
}

function animeAliasMatch(title) {
  let key = normalizeTitle(title);
  if (!key) return false;
  if (megaAliasSet.has(key)) return true;
  for (let alias of megaAliasSet) {
    if (alias.length > 4 && (key === alias || key.startsWith(alias + ' ') || key.endsWith(' ' + alias))) return true;
  }
  return false;
}

function validAnikotoEntry(entry) {
  let year = Number(entry?.year) || 0;
  if (!entry?.mal || !entry?.id || !entry?.poster) return false;
  if (!(Number(entry.episodes) > 0)) return false;
  if (year > new Date().getFullYear()) return false;
  if (/not yet|upcoming|unreleased/i.test(entry.status || '')) return false;
  let start = parseAiredStartDate(entry.aired, entry.year);
  if (start && start > today()) return false;
  return true;
}

// Strict MegaPlay playable maps ONLY contain released, streamable MegaPlay entries!
const megaByMal = new Map(), megaByAni = new Map();
const playableMegaEntries = megaEntries.filter(validAnikotoEntry);
for (let entry of playableMegaEntries) {
  if (entry.mal && !megaByMal.has(String(entry.mal))) megaByMal.set(String(entry.mal), entry);
  if (entry.ani && !megaByAni.has(String(entry.ani))) megaByAni.set(String(entry.ani), entry);
}
function megaForMedia(media) { return megaByAni.get(String(media?.id || '')) || megaByMal.get(String(media?.idMal || '')) || null; }
function megaForIds(mal, ani) { return megaByMal.get(String(mal || '')) || megaByAni.get(String(ani || '')) || null; }

const japaneseAnimation = x => {
  let animated = Boolean(x.genre_ids?.includes(16) || x.genres?.some(g => g.id === 16 || g.name === 'Animation'));
  if (!animated) return false;
  let origLang = String(x.original_language || '').toLowerCase();
  let countries = Array.isArray(x.origin_country) ? x.origin_country : [];
  if (['ja', 'zh', 'cn', 'ko'].includes(origLang) || countries.some(c => ['JP', 'CN', 'KR'].includes(c))) return true;
  if (origLang === 'en' && !countries.includes('JP')) return false;
  return animeAliasMatch(x.title || x.name) || animeAliasMatch(x.original_title || x.original_name);
};

const UNRELEASED_OTT_STATUSES = new Set(['rumored', 'planned', 'in production', 'post production', 'pilot', 'canceled']);
function releasedOtt(x, minVotes = 3) {
  if (!x || x.adult) return false;
  if (!x.poster_path) return false;
  if (!(x.title || x.name)) return false;
  if (!releasedDate(x.release_date || x.first_air_date)) return false;
  if (x.status && UNRELEASED_OTT_STATUSES.has(String(x.status).toLowerCase())) {
    if (!(String(x.status).toLowerCase() === 'canceled' && Number(x.number_of_episodes) > 0)) return false;
  }
  if ((x.media_type === 'tv' || (!x.media_type && x.first_air_date)) && x.number_of_episodes !== undefined && Number(x.number_of_episodes) <= 0) {
    return false;
  }
  let votes = Number(x.vote_count) || 0, pop = Number(x.popularity) || 0;
  if (minVotes > 0 && votes < minVotes && pop < 5) return false;
  if (japaneseAnimation(x)) return false;
  return true;
}

const ott = x => ({
  id: String(x.id),
  type: x.media_type === 'tv' || (!x.media_type && x.first_air_date) ? 'tv' : 'movie',
  title: x.title || x.name || '',
  originalTitle: x.original_title || x.original_name || '',
  poster: x.poster_path ? 'https://image.tmdb.org/t/p/w500' + x.poster_path : null,
  backdrop: x.backdrop_path ? 'https://image.tmdb.org/t/p/original' + x.backdrop_path : null,
  description: x.overview || '',
  rating: x.vote_average ? Number(x.vote_average.toFixed(1)) : null,
  popularity: Number(x.popularity) || 0,
  voteCount: Number(x.vote_count) || 0,
  year: (x.release_date || x.first_air_date || '').slice(0, 4),
  releaseDate: x.release_date || x.first_air_date || null,
  japaneseAnimation: japaneseAnimation(x),
  genres: x.genres?.map(g => g.name) || x.genre_ids?.map(id => genreNames[id]).filter(Boolean) || [],
  seasons: x.number_of_seasons
});

const aniCache = new Map();
async function anilist(query, variables = {}, timeout = 10000) {
  let key = JSON.stringify([query, variables]), cached = aniCache.get(key);
  if (cached && Date.now() - cached.time < 300000) return cached.data;
  let r = await fetch('https://graphql.anilist.co', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
    signal: AbortSignal.timeout(timeout)
  });
  if (!r.ok) throw Error('Anime catalog unavailable');
  let text = await r.text(), d;
  try { d = JSON.parse(text); } catch { throw Error('Anime catalog returned an invalid response.'); }
  if (d.errors) throw Error(d.errors[0].message);
  aniCache.set(key, { data: d.data, time: Date.now() });
  return d.data;
}

const fields = 'id idMal title{english romaji native} synonyms popularity coverImage{extraLarge large} bannerImage description(asHtml:false) averageScore format seasonYear startDate{year month day} episodes nextAiringEpisode{episode} genres status isAdult';
const positiveInt = value => Number.isInteger(Number(value)) && Number(value) > 0 ? Number(value) : null;
function animeEpisodeCount(media) {
  if (media.format === 'MOVIE' || media.status === 'NOT_YET_RELEASED') return null;
  let total = positiveInt(media.episodes);
  if (media.status === 'RELEASING') {
    let released = positiveInt((media.nextAiringEpisode?.episode || 1) - 1);
    if (released) return total ? Math.min(total, released) : released;
  }
  return total;
}

const spotlightCatalogPath = path.resolve('data/spotlight.json');
let spotlightCatalog = [];
try {
  let d = JSON.parse(fs.readFileSync(spotlightCatalogPath, 'utf8'));
  if (Array.isArray(d)) {
    spotlightCatalog = d.filter(x => x?.id && x?.type && x?.title && x?.backdrop && x?.spotlightBanner && (x.type !== 'anime' || megaByMal.has(String(x.id))));
  }
} catch {}

function cryptoShuffle(list) {
  let a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    let j = crypto.randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function buildRandomizedSpotlight() {
  if (!spotlightCatalog.length) return [];
  let isRomance = x => (x.genres || []).some(g => /romance/i.test(g));
  let romance = cryptoShuffle(spotlightCatalog.filter(isRomance));
  let others = cryptoShuffle(spotlightCatalog.filter(x => !isRomance(x)));
  let romCount = Math.min(romance.length, crypto.randomInt(2, 4));
  let lead = cryptoShuffle([...romance.slice(0, romCount), ...others.slice(0, Math.max(0, 6 - romCount))]);
  let tail = cryptoShuffle([...romance.slice(romCount), ...others.slice(Math.max(0, 6 - romCount))]);
  return [...lead, ...tail];
}

function releasedAnime(media) {
  if (!['FINISHED', 'RELEASING'].includes(media?.status)) return false;
  let d = media.startDate;
  if (!d?.year) return false;
  let date = `${d.year}-${String(d.month || 1).padStart(2, '0')}-${String(d.day || 1).padStart(2, '0')}`;
  if (date > today()) return false;
  if (media.status === 'RELEASING' && media.nextAiringEpisode?.episode === 1) return false;
  return true;
}

async function anikotoSeries(providerId) {
  if (!providerId || !/^\d+$/.test(String(providerId))) return null;
  let d = await remote(`https://anikotoapi.site/series/${encodeURIComponent(providerId)}`, { ttl: 21600000, timeout: 9000, headers: { Accept: 'application/json' } });
  if (!d.ok || !d.data?.anime || !Array.isArray(d.data.episodes)) throw Error('MegaPlay returned an invalid series response.');
  return d.data;
}

function cleanAnimeDisplayTitle(entry) {
  let primary = decodeEntities(entry.title || '').replace(/\s*\(TV\)\s*$/i, '').trim();
  let cjkIdx = primary.search(/[\u3040-\u30ff\u3400-\u9fff]/);
  if (cjkIdx > 6) primary = primary.slice(0, cjkIdx).trim();
  let engFirst = decodeEntities(String(entry.english || '').split(';')[0]).replace(/\s*\(TV\)\s*$/i, '').trim();
  if (primary && !/[\u3040-\u30ff\u3400-\u9fff]/.test(primary)) {
    if (
      engFirst.length > 4 &&
      !/^(Sorcery Fight|Blade of Demon Destruction|Na Honjaman|Naruto Hurricane|AoT$)/i.test(engFirst) &&
      /\b(Link Click|Bungo Stray Dogs|Kaguya-sama|My Dress-Up Darling|Frieren|Chainsaw Man|Spy x Family|My Hero Academia|Demon Slayer|Attack on Titan|Fullmetal Alchemist|Hunter x Hunter|Mob Psycho|Steins;Gate|Re:Zero|Konosuba|Mushoku Tensei|That Time I Got Reincarnated|Apothecary Diaries|Blue Box|Dandadan|Oshi no Ko|Haikyu|Vinland Saga| Rascal Does Not Dream|Fruits Basket|Violet Evergarden|Code Geass|Your Lie in April|Assassination Classroom|promised Neverland|Tokyo Ghoul|Black Clover|Fire Force|Dr\. Stone|Overlord|Classroom of the Elite|Horimiya|Toradora)\b/i.test(engFirst)
    ) {
      return engFirst;
    }
    return primary;
  }
  return engFirst.length > 2 ? engFirst : primary;
}

function anikotoItem(entry) {
  let format = String(entry.format || '').toUpperCase(), isMovie = format.includes('MOVIE');
  let score = Number.parseFloat(entry.score);
  let displayTitle = cleanAnimeDisplayTitle(entry);
  let status = /currently/i.test(entry.status) ? 'RELEASING' : 'FINISHED';
  let cleanDesc = decodeEntities(entry.description || '').replace(/\s*\[Written by MAL Rewrite\]\s*$/i, '').trim();
  return {
    id: String(entry.mal),
    anilistId: entry.ani ? String(entry.ani) : null,
    type: 'anime',
    title: displayTitle,
    poster: entry.poster || null,
    backdrop: entry.backdrop || null,
    description: cleanDesc,
    rating: Number.isFinite(score) && score > 0 ? score : null,
    popularity: Number(entry.popularity) || 0,
    year: entry.year || null,
    episodes: isMovie ? null : entry.episodes,
    episodeCountKind: 'available',
    genres: entry.genres || [],
    status,
    format,
    isMovie,
    playable: true,
    providerId: entry.id,
    dub: Boolean(entry.dub),
    updated: entry.updated || ''
  };
}

const anikotoItems = playableMegaEntries.map(anikotoItem);

const ani = x => {
  let isMovie = x.format === 'MOVIE', provider = megaForMedia(x);
  let episodes = animeEpisodeCount(x) || (isMovie ? null : positiveInt(provider?.episodes));
  return {
    id: String(x.idMal),
    anilistId: String(x.id),
    type: 'anime',
    title: x.title?.english || x.title?.romaji || provider?.english || provider?.title || '',
    poster: x.coverImage?.extraLarge || x.coverImage?.large || provider?.poster,
    backdrop: x.bannerImage || provider?.backdrop || x.coverImage?.extraLarge,
    description: (x.description || '').replace(/<[^>]*>/g, '') || provider?.description || '',
    rating: x.averageScore ? Number((x.averageScore / 10).toFixed(1)) : (provider?.score ? Number.parseFloat(provider.score) : null),
    popularity: Number(x.popularity) || 0,
    year: x.seasonYear || x.startDate?.year || provider?.year,
    episodes,
    episodeCountKind: x.status === 'RELEASING' ? 'released' : 'total',
    genres: x.genres?.length ? x.genres : (provider?.genres || []),
    status: x.status,
    format: x.format || provider?.format || null,
    isMovie,
    playable: Boolean(provider),
    providerId: provider?.id || null,
    dub: Boolean(provider?.dub)
  };
};

// ============================================================================
// V5.2.0 High-Precision Popularity-Driven Search Index & Ranking Engine
// ============================================================================
const STOP_WORDS = new Set(['the', 'a', 'an', 'of', 'in', 'on', 'at', 'to', 'for', 'and', 'no', 'ni', 'wa', 'ga', 'wo']);

// Curated real-world abbreviations & franchise aliases (prevents noisy random 3-letter acronyms like "end" -> "Egao no Daika")
const CURATED_OTT_ALIASES = new Map([
  ['tv:1399', ['got', 'song of ice and fire']],
  ['tv:94997', ['hotd']],
  ['tv:1396', ['brba']],
  ['tv:60059', ['bcs']],
  ['tv:2316', ['the office us']],
  ['movie:299534', ['endgame', 'end game', 'avengers 4', 'mcu']],
  ['movie:299536', ['infinity war', 'avengers 3', 'mcu']],
  ['movie:24428', ['avengers 1', 'mcu']],
  ['movie:99861', ['age of ultron', 'avengers 2', 'mcu']],
  ['movie:155', ['batman', 'batman dark knight', 'tdk']],
  ['movie:49026', ['batman', 'batman dark knight rises', 'tdkr']],
  ['movie:120', ['lotr', 'fellowship of the ring']],
  ['movie:121', ['lotr', 'two towers']],
  ['movie:122', ['lotr', 'return of the king', 'rotk']],
  ['movie:634649', ['nwh', 'spiderman no way home', 'spiderman 3']],
  ['movie:569094', ['atsv', 'spiderverse', 'spider verse']],
  ['movie:324857', ['itsv', 'spiderverse', 'spider verse']],
  ['movie:671', ['hp', 'philosophers stone', 'sorcerers stone']]
]);

const CURATED_ANIME_ACRONYMS = new Map([
  ['16498', ['aot']],
  ['40748', ['jjk']],
  ['31964', ['mha', 'bnha']],
  ['5114', ['fmab', 'fma brotherhood']],
  ['11061', ['hxh']],
  ['11757', ['sao']],
  ['30276', ['opm']],
  ['44511', ['csm']],
  ['1535', ['dn']],
  ['21', ['op']],
  ['38000', ['kny', 'ds']],
  ['52991', ['frieren', 'beyond journeys end']],
  ['52299', ['sl', 'ore dake level up na ken']],
  ['32281', ['kimi no na wa']]
]);

function extractSubtitleParts(rawTitle) {
  const s = String(rawTitle || '').trim();
  if (!s) return [];
  const parts = [];
  for (const piece of s.split(/\s*[:–—]\s*|\s+-\s+/)) {
    const n = normalizeTitle(piece);
    if (n && n.length >= 3) parts.push(n);
  }
  return parts;
}

// Unified 0..1000 Backend Popularity Meter across Movies, Web Series & Anime
function computePopularityMeter(item) {
  if (!item) return 20;
  if (item.type === 'anime') {
    const aniPop = Math.max(0, Number(item.popularity) || 250);
    const curve = 1000 * (1 - Math.exp(-aniPop / 210000)) * 0.72;
    const logPart = Math.min(280, Math.log10(1 + aniPop / 25) * 62);
    return Math.max(10, Math.min(1000, curve + logPart));
  }
  const votes = Math.max(0, Number(item.voteCount) || 0);
  const pop = Math.max(0, Number(item.popularity) || 0);
  const effectiveVotes = item.type === 'tv' ? votes * 1.75 : votes;
  const voteMeter = 1000 * (1 - Math.exp(-effectiveVotes / 8500)) * 0.72 + Math.min(280, Math.log10(1 + effectiveVotes) * 62);
  const trendMeter = votes >= 80 ? Math.min(860, Math.log10(1 + pop) * 305) : Math.min(220, Math.log10(1 + pop) * 95);
  return Math.max(8, Math.min(1000, Math.max(voteMeter, voteMeter * 0.65 + trendMeter * 0.45)));
}

function buildIndexedAnimeRecord(entry, item) {
  const primaryNorm = normalizeTitle(item.title);
  const rawNames = [
    item.title,
    entry.title,
    entry.english,
    entry.alternative,
    entry.native,
    ...String(entry.titles || '').split(/[;,]/),
  ];
  const candSet = new Set();
  const subtitleSet = new Set();
  for (const r of rawNames) {
    const n = normalizeTitle(r);
    if (n) candSet.add(n);
    for (const sub of extractSubtitleParts(r)) {
      if (sub !== n) subtitleSet.add(sub);
    }
  }
  for (const ac of CURATED_ANIME_ACRONYMS.get(String(entry.mal)) || []) {
    candSet.add(ac);
  }
  // Only add >=4-char acronyms for genuinely popular anime (prevents obscure 3-letter collisions like "end" or "bat")
  if ((Number(entry.popularity) || 0) >= 120000) {
    for (const n of [...candSet]) {
      const words = n.split(' ').filter(w => w.length > 0 && !/^\d+$/.test(w));
      if (words.length >= 4 && words.length <= 7) {
        const ac = words.map(w => w[0]).join('');
        if (ac.length >= 4) subtitleSet.add(ac);
      }
    }
  }
  const candidates = [...candSet];
  const subtitles = [...subtitleSet];
  const compacts = candidates.map(c => c.replace(/\s+/g, '')).filter(Boolean);
  const subCompacts = subtitles.map(c => c.replace(/\s+/g, '')).filter(Boolean);
  const wordSet = new Set();
  for (const c of [...candidates, ...subtitles]) {
    for (const w of c.split(' ')) if (w) wordSet.add(w);
  }
  const popMeter = computePopularityMeter(item);
  return {
    entry,
    item,
    primaryNorm,
    primaryCompact: primaryNorm.replace(/\s+/g, ''),
    candidates,
    compacts,
    subtitles,
    subCompacts,
    words: [...wordSet],
    popMeter
  };
}

const indexedAnime = playableMegaEntries.map((entry, rankIdx) => buildIndexedAnimeRecord(entry, anikotoItems[rankIdx]));

// Load Top ~2,630 Popular TMDB Movies & Web Series Index for instant 0ms blockbuster recall (e.g. "end" -> "Avengers: Endgame")
const popularOttCatalogPath = path.resolve('data/ott-popular-catalog.json');
const indexedPopularOtt = [];
try {
  const rawPop = JSON.parse(fs.readFileSync(popularOttCatalogPath, 'utf8'));
  for (const row of rawPop?.entries || []) {
    if (!row?.id || !row?.title) continue;
    const item = {
      id: String(row.id),
      type: row.type === 'tv' ? 'tv' : 'movie',
      title: row.title,
      originalTitle: row.originalTitle || '',
      poster: row.poster || null,
      backdrop: row.backdrop || null,
      description: row.description || '',
      rating: row.rating ?? null,
      popularity: Number(row.popularity) || 0,
      voteCount: Number(row.voteCount) || 0,
      year: row.year || '',
      releaseDate: row.releaseDate || null,
      japaneseAnimation: false,
      genres: (row.genreIds || []).map(id => genreNames[id]).filter(Boolean)
    };
    const primaryNorm = normalizeTitle(item.title);
    const oNorm = normalizeTitle(item.originalTitle);
    const candSet = new Set([primaryNorm, oNorm].filter(Boolean));
    const subSet = new Set();
    for (const rawName of [item.title, item.originalTitle]) {
      for (const sub of extractSubtitleParts(rawName)) {
        if (!candSet.has(sub)) subSet.add(sub);
      }
    }
    for (const alias of CURATED_OTT_ALIASES.get(`${item.type}:${item.id}`) || []) {
      const n = normalizeTitle(alias);
      if (n) subSet.add(n);
    }
    const candidates = [...candSet];
    const subtitles = [...subSet];
    const compacts = candidates.map(c => c.replace(/\s+/g, '')).filter(Boolean);
    const subCompacts = subtitles.map(c => c.replace(/\s+/g, '')).filter(Boolean);
    const wordSet = new Set();
    for (const c of [...candidates, ...subtitles]) {
      for (const w of c.split(' ')) if (w) wordSet.add(w);
    }
    indexedPopularOtt.push({
      key: `${item.type}:${item.id}`,
      item,
      primaryNorm,
      primaryCompact: primaryNorm.replace(/\s+/g, ''),
      candidates,
      compacts,
      subtitles,
      subCompacts,
      words: [...wordSet],
      popMeter: computePopularityMeter(item)
    });
  }
} catch {}

const megaMissCache = new Map();
async function probeMegaPlayEmbedUrl(url) {
  try {
    let r = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        Referer: 'https://megaplay.buzz/'
      },
      signal: AbortSignal.timeout(4200)
    });
    if (!r.ok) return false;
    let html = await r.text();
    return Boolean(html.match(/data-id=["']?(\d+)/)?.[1] || html.match(/File\s+(\d+)\s+-/)?.[1]);
  } catch {
    return false;
  }
}

async function ensureDynamicMegaEntry(malId, mediaOpt = null) {
  const malStr = String(malId || '');
  if (!/^\d+$/.test(malStr)) return null;
  if (megaByMal.has(malStr)) return megaByMal.get(malStr);
  const missTs = megaMissCache.get(malStr);
  if (missTs && Date.now() - missTs < 900_000) return null;

  const media = mediaOpt || await animeRecord(malStr, false).catch(() => null);
  if (!media || media.isAdult || !releasedAnime(media)) {
    megaMissCache.set(malStr, Date.now());
    return null;
  }
  const aniStr = String(media.id || '');
  const [subMal, dubMal] = await Promise.all([
    probeMegaPlayEmbedUrl(`https://megaplay.buzz/stream/mal/${malStr}/1/sub`),
    probeMegaPlayEmbedUrl(`https://megaplay.buzz/stream/mal/${malStr}/1/dub`)
  ]);
  let subOk = subMal, dubOk = dubMal;
  if (!subOk && !dubOk && aniStr) {
    const [subAni, dubAni] = await Promise.all([
      probeMegaPlayEmbedUrl(`https://megaplay.buzz/stream/ani/${aniStr}/1/sub`),
      probeMegaPlayEmbedUrl(`https://megaplay.buzz/stream/ani/${aniStr}/1/dub`)
    ]);
    subOk = subAni;
    dubOk = dubAni;
  }
  if (!subOk && !dubOk) {
    megaMissCache.set(malStr, Date.now());
    return null;
  }

  const isMovie = media.format === 'MOVIE';
  const fmtMap = { MOVIE: 'Movie', TV: 'TV', TV_SHORT: 'TV_SHORT', ONA: 'ONA', OVA: 'OVA', SPECIAL: 'Special' };
  const eng = String(media.title?.english || '').trim();
  const rom = String(media.title?.romaji || '').trim();
  const nat = String(media.title?.native || '').trim();
  const syns = Array.isArray(media.synonyms) ? media.synonyms.filter(Boolean) : [];
  const allTitles = [...new Set([eng, rom, nat, ...syns].filter(Boolean))].join('; ');
  const sd = media.startDate || {};
  const entry = {
    id: `mp-${malStr}`,
    mal: malStr,
    ani: aniStr,
    title: eng || rom || nat,
    english: eng || rom,
    alternative: rom || eng,
    titles: allTitles,
    native: nat,
    poster: media.coverImage?.extraLarge || media.coverImage?.large || '',
    backdrop: media.bannerImage || media.coverImage?.extraLarge || '',
    description: String(media.description || '').replace(/<[^>]*>/g, '').trim(),
    year: sd.year || media.seasonYear || null,
    status: media.status === 'RELEASING' ? 'Currently Airing' : 'Finished Airing',
    score: media.averageScore ? (media.averageScore / 10).toFixed(2) : '',
    popularity: Number(media.popularity) || 0,
    genres: Array.isArray(media.genres) ? media.genres : [],
    format: fmtMap[media.format] || 'TV',
    aired: sd.year ? `${sd.year}-${String(sd.month || 1).padStart(2, '0')}-${String(sd.day || 1).padStart(2, '0')}` : '',
    episodes: isMovie ? 1 : (animeEpisodeCount(media) || 1),
    dub: Boolean(dubOk),
    updated: `${sd.year || media.seasonYear || 2024}-01-01 00:00:00`
  };
  if (!megaByMal.has(malStr)) {
    megaByMal.set(malStr, entry);
    if (aniStr && !megaByAni.has(aniStr)) megaByAni.set(aniStr, entry);
    const item = anikotoItem(entry);
    anikotoItems.push(item);
    indexedAnime.push(buildIndexedAnimeRecord(entry, item));
    for (const raw of [entry.title, entry.english, entry.alternative, ...syns]) {
      const n = normalizeTitle(raw);
      if (n && n.length >= 3) megaAliasSet.add(n);
    }
  }
  return megaByMal.get(malStr);
}

function editDistanceAtMost(a, b, maxDist) {
  const la = a.length, lb = b.length;
  if (Math.abs(la - lb) > maxDist) return maxDist + 1;
  if (a === b) return 0;
  let prev = new Uint16Array(lb + 1);
  let curr = new Uint16Array(lb + 1);
  for (let j = 0; j <= lb; j++) prev[j] = j;
  for (let i = 1; i <= la; i++) {
    curr[0] = i;
    let rowMin = curr[0];
    const ca = a.charCodeAt(i - 1);
    for (let j = 1; j <= lb; j++) {
      const cost = ca === b.charCodeAt(j - 1) ? 0 : 1;
      const v = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
      curr[j] = v;
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > maxDist) return maxDist + 1;
    [prev, curr] = [curr, prev];
  }
  return prev[lb];
}

function scoreCandidateMatch(qNorm, qCompact, qWords, primaryNorm, primaryCompact, candidates, compacts, allWords, subtitles = [], subCompacts = []) {
  if (!qNorm) return 0;
  let best = 0;

  // 1. Primary & full-alias matching
  if (primaryNorm === qNorm || (qCompact.length >= 2 && primaryCompact === qCompact)) {
    best = Math.max(best, 1620);
  }
  for (let i = 0; i < candidates.length; i++) {
    const c = candidates[i], cc = compacts[i];
    const noArt = c.replace(/^(?:the|a|an)\s+/, '');
    if (c === qNorm || (qCompact.length >= 3 && cc === qCompact)) {
      best = Math.max(best, 1580);
    } else if (noArt && noArt !== c && noArt === qNorm) {
      best = Math.max(best, c === primaryNorm ? 1560 : 1510);
    } else if (c.startsWith(qNorm + ' ') || c.startsWith(qNorm)) {
      const penalty = Math.min(180, Math.max(0, c.length - qNorm.length) * 2.5);
      best = Math.max(best, (c === primaryNorm ? 1360 : 1240) - penalty);
    } else if (noArt && (noArt.startsWith(qNorm + ' ') || noArt.startsWith(qNorm))) {
      const penalty = Math.min(180, Math.max(0, noArt.length - qNorm.length) * 2.5);
      best = Math.max(best, (c === primaryNorm ? 1330 : 1210) - penalty);
    } else if (qCompact.length >= 3 && cc.startsWith(qCompact)) {
      const penalty = Math.min(180, Math.max(0, cc.length - qCompact.length) * 2.5);
      best = Math.max(best, 1220 - penalty);
    } else if ((' ' + c + ' ').includes(' ' + qNorm + ' ')) {
      best = Math.max(best, c === primaryNorm ? 1140 : 1040);
    } else if (qCompact.length >= 4 && cc.includes(qCompact)) {
      best = Math.max(best, 940);
    }
  }

  // 2. Subtitle / post-colon & curated franchise alias matching (e.g. "Avengers: Endgame" -> "endgame" matches "end" & "end game"!)
  for (let i = 0; i < subtitles.length; i++) {
    const sub = subtitles[i], sc = subCompacts[i] || sub.replace(/\s+/g, '');
    const noArt = sub.replace(/^(?:the|a|an)\s+/, '');
    if (sub === qNorm || (qCompact.length >= 2 && sc === qCompact) || (noArt && noArt === qNorm)) {
      best = Math.max(best, 1520);
    } else if (sub.startsWith(qNorm + ' ') || sub.startsWith(qNorm) || (noArt && noArt.startsWith(qNorm))) {
      const penalty = Math.min(150, Math.max(0, sub.length - qNorm.length) * 2.5);
      best = Math.max(best, 1260 - penalty);
    } else if (qCompact.length >= 3 && sc.startsWith(qCompact)) {
      const penalty = Math.min(150, Math.max(0, sc.length - qCompact.length) * 2.5);
      best = Math.max(best, 1200 - penalty);
    } else if ((' ' + sub + ' ').includes(' ' + qNorm + ' ')) {
      best = Math.max(best, 1080);
    }
  }

  if (best >= 1200) return best;

  // 3. Multi-word / prefix token match within a single candidate or subtitle
  if (qWords.length >= 1) {
    for (const c of [...candidates, ...subtitles]) {
      const cWords = c.split(' ');
      if (qWords.every(qw => cWords.some(cw => cw.startsWith(qw)))) {
        const lenDiff = Math.min(160, Math.max(0, cWords.length - qWords.length) * 18);
        best = Math.max(best, (c === primaryNorm ? 1120 : 1020) - lenDiff);
      }
    }
  }
  if (best >= 980) return best;

  // 4. Cross-alias prefix + fuzzy typo tolerance (handles "frieran", "interstelar", "jujtsu", "spider verse", etc.)
  const sigWords = qWords.filter(w => !STOP_WORDS.has(w));
  const checkWords = sigWords.length ? sigWords : qWords;
  let exactOrPrefixHits = 0;
  let fuzzyHits = 0;
  for (const qw of checkWords) {
    if (allWords.some(cw => cw === qw || (qw.length >= 3 && cw.startsWith(qw)))) {
      exactOrPrefixHits++;
      continue;
    }
    if (qw.length >= 4) {
      const maxEd = qw.length >= 7 ? 2 : 1;
      if (allWords.some(cw => cw.length >= 3 && editDistanceAtMost(qw, cw.slice(0, Math.max(cw.length, qw.length)), maxEd) <= maxEd)) {
        fuzzyHits++;
      }
    }
  }
  const totalMatched = exactOrPrefixHits + fuzzyHits;
  if (totalMatched === checkWords.length && checkWords.length > 0) {
    best = Math.max(best, fuzzyHits === 0 ? 860 : 640 - fuzzyHits * 35);
  } else if (checkWords.length >= 2 && totalMatched / checkWords.length >= 0.66 && exactOrPrefixHits >= 1) {
    best = Math.max(best, Math.round(420 * (totalMatched / checkWords.length)));
  }

  return best;
}

// Combines text relevance with the 0..1000 Backend Popularity Meter so popular titles always rise to the top
function finalizeSearchScore(baseMatchScore, item, qNorm, popMeterOpt = null) {
  if (baseMatchScore <= 0) return 0;
  const popMeter = popMeterOpt !== null ? popMeterOpt : computePopularityMeter(item);

  // Dampen exact-name monopoly of obscure micro-titles (< 220 popMeter) so global hits aren't buried under 3-vote films
  const credibility = Math.min(1, 0.36 + popMeter / 280);
  let score = baseMatchScore * credibility;

  // Strong backend popularity meter weight (0 .. 1900 pts) + subtle rating tie-breaker
  score += popMeter * 1.9;
  score += (Number(item.rating) || 0) * 9;

  // Subtle boost to root/main series over specials/recaps unless user explicitly searched for season/movie/ova/special
  const lowerTitle = String(item.title || '').toLowerCase();
  const wantsSubEntry = /\b(season|part|cour|ova|special|movie|film|recap)\b|\b[2-9]\b/.test(qNorm);
  if (!wantsSubEntry) {
    if (item.type === 'anime') {
      const fmt = String(item.format || '').toUpperCase();
      if (fmt === 'TV') score += 35;
      else if (fmt === 'MOVIE') score += 20;
      else if (fmt === 'SPECIAL' || fmt === 'OVA') score -= 55;
      if (/\b(season\s*[2-9]|2nd\s*season|3rd\s*season|4th\s*season|part\s*[2-9]|ova|special)\b/i.test(lowerTitle)) {
        score -= 40;
      }
    } else {
      score += 20;
    }
  }
  return score;
}

function searchLocalMegaPlay(term, extraAniMap = null) {
  const qNorm = normalizeTitle(term);
  if (!qNorm) return [];
  const qCompact = qNorm.replace(/\s+/g, '');
  const qWords = qNorm.split(' ').filter(Boolean);
  const results = [];

  for (const rec of indexedAnime) {
    let extraBoost = 0;
    const aniExtra = extraAniMap?.get(rec.item.id);
    let candidates = rec.candidates, compacts = rec.compacts, words = rec.words;
    if (aniExtra) {
      extraBoost = 80;
      if (aniExtra.extraCands.length) {
        const merged = new Set([...rec.candidates, ...aniExtra.extraCands]);
        candidates = [...merged];
        compacts = candidates.map(c => c.replace(/\s+/g, ''));
        const ws = new Set(rec.words);
        for (const c of aniExtra.extraCands) for (const w of c.split(' ')) if (w) ws.add(w);
        words = [...ws];
      }
    }
    let mScore = scoreCandidateMatch(qNorm, qCompact, qWords, rec.primaryNorm, rec.primaryCompact, candidates, compacts, words, rec.subtitles, rec.subCompacts);
    if (mScore <= 0 && aniExtra) mScore = 760;
    if (mScore <= 0) continue;
    const enrichedItem = aniExtra?.mediaItem ? {
      ...rec.item,
      popularity: Math.max(Number(rec.item.popularity) || 0, Number(aniExtra.popularity) || 0),
      backdrop: rec.item.backdrop || aniExtra.mediaItem.backdrop,
      rating: rec.item.rating || aniExtra.mediaItem.rating
    } : rec.item;
    const popMeter = aniExtra?.popularity ? computePopularityMeter(enrichedItem) : rec.popMeter;
    const total = finalizeSearchScore(mScore + extraBoost, enrichedItem, qNorm, popMeter);
    results.push({ item: enrichedItem, score: total, popMeter });
  }
  results.sort((a, b) => b.score - a.score);
  return results.slice(0, 36);
}

function scoreOttSearchItem(rawTmdb, qNorm, qCompact, qWords) {
  const item = ott(rawTmdb);
  const pNorm = normalizeTitle(item.title);
  const oNorm = normalizeTitle(item.originalTitle);
  const candidates = [pNorm, oNorm].filter(Boolean);
  const compacts = candidates.map(c => c.replace(/\s+/g, ''));
  const subSet = new Set();
  for (const r of [item.title, item.originalTitle]) {
    for (const sub of extractSubtitleParts(r)) {
      if (!candidates.includes(sub)) subSet.add(sub);
    }
  }
  for (const al of CURATED_OTT_ALIASES.get(`${item.type}:${item.id}`) || []) {
    const n = normalizeTitle(al);
    if (n) subSet.add(n);
  }
  const subtitles = [...subSet];
  const subCompacts = subtitles.map(c => c.replace(/\s+/g, ''));
  const wordSet = new Set();
  for (const c of [...candidates, ...subtitles]) for (const w of c.split(' ')) if (w) wordSet.add(w);
  let mScore = scoreCandidateMatch(qNorm, qCompact, qWords, pNorm, pNorm.replace(/\s+/g, ''), candidates, compacts, [...wordSet], subtitles, subCompacts);
  if (mScore <= 0) {
    if ((item.voteCount >= 120 || item.popularity >= 25) && qNorm.length >= 3) mScore = 500;
    else return null;
  }
  const popMeter = computePopularityMeter(item);
  return { item, score: finalizeSearchScore(mScore, item, qNorm, popMeter), popMeter };
}

function animePopRank(item) {
  const aniPop = Number(item.popularity) || 0;
  if (aniPop > 0) return aniPop + (item.rating || 7) * 4000;
  return ((item.rating || 6) ** 4) * (item.dub ? 1.35 : 1) * ((Number(item.year) || 0) >= 2015 ? 1.2 : 1);
}

function sortAnikoto(items, sort) {
  let copy = [...items];
  if (sort === 'rating') copy.sort((a, b) => (b.rating || 0) - (a.rating || 0) || animePopRank(b) - animePopRank(a));
  else if (sort === 'newest') copy.sort((a, b) => (b.year || 0) - (a.year || 0) || String(b.updated).localeCompare(String(a.updated)));
  else copy.sort((a, b) => animePopRank(b) - animePopRank(a));
  return copy;
}

const EPISODIC_ANIME_FORMATS = new Set(['TV', 'TV_SHORT', 'ONA']);
const EXPLICIT_SEASON_SUFFIX_RE = /(?:\s*[:\-–—]\s*|\s+)(?:season\s*\d+|\d+(?:st|nd|rd|th)\s+season|part\s*\d+|cour\s*\d+|the\s+final\s+season.*|final\s+season.*|(?:ii|iii|iv|v|vi))(?:\s+part\s*\d+)?\s*$/i;

function isEpisodicCatalogAnime(item) {
  if (!item || item.type !== 'anime' || item.isMovie) return false;
  const fmt = String(item.format || '').toUpperCase();
  if (/MOVIE|OVA|SPECIAL|MUSIC/.test(fmt)) return false;
  return true;
}

function stripAnimeSeasonSuffix(rawTitle) {
  let clean = String(rawTitle || '').replace(/\s*\(TV\)\s*$/i, '').trim();
  let prev = '';
  while (clean && clean !== prev) {
    prev = clean;
    clean = clean.replace(EXPLICIT_SEASON_SUFFIX_RE, '').trim();
  }
  return clean;
}

const localSeasonFamilyByMal = new Map();
const localRootItemByMal = new Map();
(() => {
  const byRootKey = new Map();
  const baseExactKeys = new Set();
  for (const it of anikotoItems) {
    if (!isEpisodicCatalogAnime(it)) continue;
    const exactKey = normalizeTitle(it.title);
    if (exactKey && stripAnimeSeasonSuffix(it.title) === it.title.replace(/\s*\(TV\)\s*$/i, '').trim()) {
      baseExactKeys.add(exactKey);
    }
  }
  for (const it of anikotoItems) {
    if (!isEpisodicCatalogAnime(it)) continue;
    const exactKey = normalizeTitle(it.title);
    const stripped = normalizeTitle(stripAnimeSeasonSuffix(it.title));
    if (!stripped || stripped.length < 3) continue;
    if (stripped !== exactKey && !baseExactKeys.has(stripped)) {
      // Also allow grouping multiple explicit seasons even when S1 had "Season 1" in title
      const list = byRootKey.get(stripped) || [];
      list.push(it);
      byRootKey.set(stripped, list);
      continue;
    }
    const list = byRootKey.get(stripped) || [];
    list.push(it);
    byRootKey.set(stripped, list);
  }
  for (const [, group] of byRootKey) {
    if (group.length < 2) continue;
    const sorted = [...group].sort((a, b) => {
      const aBase = stripAnimeSeasonSuffix(a.title) === a.title.replace(/\s*\(TV\)\s*$/i, '').trim() ? 0 : 1;
      const bBase = stripAnimeSeasonSuffix(b.title) === b.title.replace(/\s*\(TV\)\s*$/i, '').trim() ? 0 : 1;
      return (Number(a.year) || 9999) - (Number(b.year) || 9999) || aBase - bBase || Number(a.id) - Number(b.id);
    });
    const root = sorted[0];
    const entries = sorted.map(s => ({
      id: String(s.id),
      anilistId: s.anilistId ? String(s.anilistId) : '',
      name: s.title,
      episodes: s.episodes,
      format: s.format || 'TV',
      year: Number(s.year) || 9999
    }));
    for (const s of sorted) {
      localSeasonFamilyByMal.set(String(s.id), entries);
      if (String(s.id) !== String(root.id)) localRootItemByMal.set(String(s.id), root);
    }
  }
})();

function dedupeCatalog(list, preserveSequels = false) {
  let output = [], positions = new Map();
  for (let rawItem of list) {
    if (!rawItem?.id || !rawItem?.title || !rawItem?.poster) continue;
    let item = rawItem;
    if (item.type === 'anime' && !preserveSequels && localRootItemByMal.has(String(item.id))) {
      item = localRootItemByMal.get(String(item.id));
    }
    if (item.type === 'anime' && !megaByMal.has(String(item.id))) continue;
    if (item.type !== 'anime' && item.japaneseAnimation) continue;
    let kind = item.type === 'movie' || item.isMovie ? 'movie' : 'series';
    let key = item.year ? `${normalizeTitle(item.title)}|${item.year}|${kind}` : `${item.type}:${item.id}`;
    let idKey = `${item.type}:${item.id}`;
    if (positions.has(idKey)) continue;
    if (!positions.has(key)) {
      positions.set(key, output.length);
      positions.set(idKey, output.length);
      output.push(item);
      continue;
    }
    let at = positions.get(key), old = output[at];
    if (old.type === 'anime' && item.type !== 'anime') output[at] = { ...old, backdrop: item.backdrop || old.backdrop };
    else if (item.type === 'anime' && old.type !== 'anime') output[at] = { ...item, backdrop: old.backdrop || item.backdrop };
  }
  return output;
}

async function animeRecord(id, withRelations = false) {
  let d = await anilist(`query($id:Int){Media(idMal:$id,type:ANIME){${fields}${withRelations ? ' relations{edges{relationType node{idMal type format}}}' : ''}}}`, { id: Number(id) });
  return d.Media;
}
async function animeRecordsBatch(malIds) {
  const nums = [...new Set(malIds.map(Number).filter(n => Number.isInteger(n) && n > 0))].slice(0, 25);
  if (!nums.length) return [];
  const d = await anilist(
    `query($ids:[Int]){Page(page:1,perPage:25){media(idMal_in:$ids,type:ANIME){${fields} relations{edges{relationType node{idMal type format}}}}}}`,
    { ids: nums }
  );
  return d?.Page?.media || [];
}
function animeSeasonEntry(media) {
  const malStr = String(media.idMal);
  const provider = megaByMal.get(malStr);
  const item = ani(media);
  const catalogName = provider ? cleanAnimeDisplayTitle(provider) : '';
  return {
    id: malStr,
    anilistId: String(media.id),
    name: catalogName || item.title,
    episodes: positiveInt(provider?.episodes) || item.episodes,
    format: item.format
  };
}

const seasonFamilyCache = new Map();

async function animeSeasonFamily(media, fallbackMalId = '') {
  const rootMal = String(media?.idMal || fallbackMalId || '');
  if (!rootMal) return [];
  const cached = seasonFamilyCache.get(rootMal);
  if (cached && Date.now() - cached.time < 1800_000) return cached.seasons;

  const localFallback = (localSeasonFamilyByMal.get(rootMal) || []).map(({ year, ...rest }) => rest);
  if (!media || media.format === 'MOVIE' || !EPISODIC_ANIME_FORMATS.has(media.format)) {
    return localFallback.length >= 2 ? localFallback : [];
  }

  const entries = new Map([[rootMal, media]]);
  const seen = new Set([rootMal]);
  let frontier = [media];

  // Traverse PREQUEL/SEQUEL graph across all episodic anime formats (TV, TV_SHORT, ONA) in batched GraphQL hops
  for (let depth = 0; depth < 6 && frontier.length && seen.size < 24; depth++) {
    const nextIds = [];
    for (const cur of frontier) {
      for (const edge of cur.relations?.edges || []) {
        const node = edge.node;
        const nId = String(node?.idMal || '');
        if (
          !['PREQUEL', 'SEQUEL'].includes(edge.relationType) ||
          node?.type !== 'ANIME' ||
          !EPISODIC_ANIME_FORMATS.has(node?.format) ||
          !nId ||
          seen.has(nId)
        ) continue;
        seen.add(nId);
        nextIds.push(nId);
      }
    }
    if (!nextIds.length) break;
    try {
      const fetched = await animeRecordsBatch(nextIds);
      frontier = [];
      for (const linked of fetched) {
        if (linked?.idMal && EPISODIC_ANIME_FORMATS.has(linked.format)) {
          entries.set(String(linked.idMal), linked);
          frontier.push(linked);
        }
      }
    } catch {
      break;
    }
  }

  const aniListSeasons = [...entries.values()]
    .filter(m => releasedAnime(m) && megaForMedia(m))
    .sort((a, b) =>
      (a.startDate?.year || 9999) - (b.startDate?.year || 9999) ||
      (a.startDate?.month || 1) - (b.startDate?.month || 1) ||
      (a.startDate?.day || 1) - (b.startDate?.day || 1) ||
      Number(a.id) - Number(b.id)
    )
    .map(animeSeasonEntry);

  // Merge any local catalog seasons not yet linked on AniList
  const mergedById = new Map();
  for (const s of aniListSeasons) mergedById.set(s.id, s);
  for (const s of localFallback) {
    if (!mergedById.has(s.id)) mergedById.set(s.id, s);
  }
  const finalSeasons = mergedById.size >= 2 ? [...mergedById.values()] : [];

  if (finalSeasons.length >= 2) {
    const now = Date.now();
    for (const s of finalSeasons) {
      seasonFamilyCache.set(s.id, { seasons: finalSeasons, time: now });
    }
  }
  return finalSeasons;
}

let sharedKey = null;
async function tmdbKey() {
  if (process.env.TMDB_API_KEY) return process.env.TMDB_API_KEY;
  if (!sharedKey) sharedKey = (await freekeys()).tmdb_key;
  return sharedKey;
}
async function tmdb(route, params = {}, timeout = 10000) {
  let key = await tmdbKey();
  let q = new URLSearchParams({ ...params, api_key: key, language: 'en-US' });
  try {
    return await remote('https://api.themoviedb.org/3/' + route + '?' + q, { timeout });
  } catch (e) {
    if (process.env.TMDB_API_KEY) throw e;
    sharedKey = (await freekeys()).tmdb_key;
    q.set('api_key', sharedKey);
    return remote('https://api.themoviedb.org/3/' + route + '?' + q, { timeout });
  }
}

async function getTmdbMetaForResolver(input) {
  let [d, seasonData] = await Promise.all([
    tmdb(`${input.type}/${input.id}`, { append_to_response: 'external_ids' }),
    input.type === 'tv' ? tmdb(`tv/${input.id}/season/${input.season}`).catch(() => null) : Promise.resolve(null)
  ]);
  let epObj = input.type === 'tv' && Array.isArray(seasonData?.episodes)
    ? seasonData.episodes.find(e => Number(e.episode_number) === Number(input.episode))
    : null;
  return {
    title: d.title || d.name || d.original_title || d.original_name || '',
    year: String(d.release_date || d.first_air_date || '').slice(0, 4),
    imdbId: d.imdb_id || d.external_ids?.imdb_id || '',
    originalLanguage: String(d.original_language || '').toLowerCase(),
    episodeRuntimeMinutes: Number(epObj?.runtime) || 0
  };
}

const readStates = () => {
  try { let d = JSON.parse(fs.readFileSync(statesDb)); return { visitors: d.visitors || {}, meta: d.meta || {} }; }
  catch { return { visitors: {}, meta: {} }; }
};
const cleanState = state => ({
  watchlist: Array.isArray(state?.watchlist) ? state.watchlist.slice(0, 100) : [],
  history: Array.isArray(state?.history) ? state.history.slice(0, 100) : []
});
function readState(owner) {
  let states = readStates(), existing = states.visitors[owner.id];
  if (!existing && !states.meta.legacyMigrated) {
    let legacy = null;
    try { legacy = JSON.parse(fs.readFileSync(db)); } catch {}
    states.meta.legacyMigrated = true;
    if (legacy && (legacy.watchlist?.length || legacy.history?.length)) states.visitors[owner.id] = cleanState(legacy);
    fs.writeFileSync(statesDb, JSON.stringify(states));
    return cleanState(states.visitors[owner.id]);
  }
  return cleanState(existing);
}
function writeState(owner, state) {
  let states = readStates();
  states.visitors[owner.id] = cleanState(state);
  fs.writeFileSync(statesDb, JSON.stringify(states));
  return states.visitors[owner.id];
}
const parseCookies = req => Object.fromEntries(String(req.headers.cookie || '').split(';').map(x => x.trim().split('=').map(decodeURIComponent)).filter(x => x.length === 2));
function appendCookie(res, value) {
  let old = res.getHeader('Set-Cookie'), all = old ? (Array.isArray(old) ? old : [old]) : [];
  res.setHeader('Set-Cookie', [...all, value]);
}
function visitorId(req, res) {
  let cookies = parseCookies(req), id = cookies.kozutv_visitor || cookies.moscowtv_visitor;
  if (!/^[a-f0-9]{32}$/.test(id || '')) {
    id = crypto.randomBytes(16).toString('hex');
  }
  if (cookies.kozutv_visitor !== id) {
    appendCookie(res, `kozutv_visitor=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=315360000`);
  }
  return id;
}
function stateOwner(req, res) { return { scope: 'visitors', id: visitorId(req, res) }; }
async function requestBody(req) {
  let chunks = [];
  for await (let chunk of req) {
    chunks.push(chunk);
    if (Buffer.concat(chunks).length > 50000) throw Error('Payload too large');
  }
  return JSON.parse(Buffer.concat(chunks).toString() || '{}');
}
function num(s) { return /^\d{1,10}$/.test(s || '') ? s : null; }

async function api(req, res, url) {
  let p = url.pathname, q = url.searchParams;
  try {
    if (p === '/api/state') return json(res, readState(stateOwner(req, res)), 200, req);

    if ((p === '/api/watchlist' && req.method === 'POST') || (p === '/api/history' && req.method === 'POST')) {
      let item = await requestBody(req);
      if (!['anime', 'movie', 'tv'].includes(item.type) || !num(String(item.id))) return json(res, { error: 'Invalid item' }, 400);
      let owner = stateOwner(req, res), state = readState(owner), field = p.endsWith('watchlist') ? 'watchlist' : 'history';
      let record = {
        id: String(item.id),
        type: item.type,
        title: String(item.title || '').slice(0, 200),
        poster: String(item.poster || '').slice(0, 500),
        episode: Math.max(1, Number(item.episode) || 1),
        season: Math.max(1, Number(item.season) || 1),
        updated: Date.now(),
        genres: Array.isArray(item.genres) ? item.genres.map(String).slice(0, 10) : [],
        format: typeof item.format === 'string' ? item.format.slice(0, 20) : null,
        isMovie: Boolean(item.isMovie),
        currentTime: Math.max(0, Number(item.currentTime) || 0),
        duration: Math.max(0, Number(item.duration) || 0)
      };
      let found = state[field].findIndex(x => x.id === record.id && x.type === record.type);
      let old = found >= 0 ? state[field].splice(found, 1)[0] : null;
      if (field === 'history' && old && old.episode === record.episode && old.season === record.season) {
        record.currentTime = item.currentTime == null ? old.currentTime || 0 : record.currentTime;
        record.duration = item.duration == null ? old.duration || 0 : record.duration;
      }
      if (!record.genres.length && old) record.genres = old.genres || [];
      if (field === 'history' || !item.remove) state[field].unshift(record);
      writeState(owner, state);
      return json(res, state, 200, req);
    }

    if (p === '/api/browse') {
      let [o] = await Promise.allSettled([tmdb('trending/all/week')]);
      let freshAnime = anikotoItems.filter(x => !x.isMovie).slice(0, 12);
      let popularAnimeSeries = sortAnikoto(anikotoItems.filter(x => !x.isMovie), 'popularity').slice(0, 10);
      let popularAnimeMovies = sortAnikoto(anikotoItems.filter(x => x.isMovie), 'popularity').slice(0, 10);
      let animeItems = [];
      for (let i = 0; i < 12; i++) {
        if (freshAnime[i]) animeItems.push(freshAnime[i]);
        if (popularAnimeMovies[i]) animeItems.push(popularAnimeMovies[i]);
        if (popularAnimeSeries[i]) animeItems.push(popularAnimeSeries[i]);
      }
      let ottItems = o.status === 'fulfilled'
        ? o.value.results.filter(x => ['tv', 'movie'].includes(x.media_type) && releasedOtt(x, 5)).map(ott)
        : [];
      if (!animeItems.length && !ottItems.length) throw Error('Catalogs are unavailable');
      let movies = ottItems.filter(x => x.type === 'movie'), shows = ottItems.filter(x => x.type === 'tv'), mixed = [];
      for (let i = 0; i < Math.max(animeItems.length, movies.length, shows.length); i++) {
        if (animeItems[i]) mixed.push(animeItems[i]);
        if (movies[i]) mixed.push(movies[i]);
        if (shows[i]) mixed.push(shows[i]);
      }
      mixed = dedupeCatalog(mixed);
      let history = readState(stateOwner(req, res)).history, watchedGenres = new Map();
      for (let [index, h] of history.entries()) {
        for (let g of h.genres || []) watchedGenres.set(g.toLowerCase(), (watchedGenres.get(g.toLowerCase()) || 0) + Math.max(1, 8 - index));
      }
      let watched = new Set(history.map(h => h.type + ':' + h.id));
      let suggestions = mixed
        .filter(x => !watched.has(x.type + ':' + x.id))
        .map(x => ({ ...x, match: (x.genres || []).reduce((n, g) => n + (watchedGenres.get(g.toLowerCase()) || 0), 0) }))
        .filter(x => x.match > 0)
        .sort((a, b) => b.match - a.match)
        .slice(0, 12);
      return json(res, { items: mixed, spotlight: buildRandomizedSpotlight(), suggestions, hasPreferences: watchedGenres.size > 0 }, 200, req);
    }

    if (p === '/api/search-all') {
      let term = (q.get('q') || '').trim().slice(0, 100);
      if (!term) return json(res, { items: [] }, 200, req);
      let qNorm = normalizeTitle(term), qCompact = qNorm.replace(/\s+/g, ''), qWords = qNorm.split(' ').filter(Boolean);

      const [aniRes, multiRes, movieRes, tvRes] = await Promise.allSettled([
        anilist(
          `query($q:String){Page(page:1,perPage:24){media(search:$q,type:ANIME,isAdult:false,status_in:[FINISHED,RELEASING],sort:[SEARCH_MATCH,POPULARITY_DESC]){${fields}}}}`,
          { q: term },
          2800
        ),
        tmdb('search/multi', { query: term, include_adult: 'false', page: '1' }, 3200),
        tmdb('search/movie', { query: term, include_adult: 'false', page: '1' }, 3200),
        tmdb('search/tv', { query: term, include_adult: 'false', page: '1' }, 3200)
      ]);

      // Map AniList search hits to released MegaPlay-available anime (probing MegaPlay live for unindexed titles!)
      const extraAniMap = new Map();
      if (aniRes.status === 'fulfilled') {
        const aniMediaList = (aniRes.value?.Page?.media || []).filter(m => m?.idMal && releasedAnime(m));
        const unindexed = aniMediaList.filter(m => !megaForMedia(m)).slice(0, 6);
        if (unindexed.length) {
          await Promise.allSettled(unindexed.map(m => ensureDynamicMegaEntry(m.idMal, m)));
        }
        for (const m of aniMediaList) {
          if (!megaForMedia(m)) continue;
          const extraCands = [
            m.title?.english,
            m.title?.romaji,
            m.title?.native,
            ...(Array.isArray(m.synonyms) ? m.synonyms : [])
          ].map(normalizeTitle).filter(Boolean);
          extraAniMap.set(String(m.idMal), {
            popularity: Number(m.popularity) || 0,
            extraCands,
            mediaItem: ani(m)
          });
        }
      }

      const scoredAnime = searchLocalMegaPlay(term, extraAniMap);

      // Merge & score released, streamable TMDB movies & web series
      const rawOttMap = new Map();
      for (const [srcRes, forcedType] of [[multiRes, null], [movieRes, 'movie'], [tvRes, 'tv']]) {
        if (srcRes.status !== 'fulfilled') continue;
        for (const raw of srcRes.value?.results || []) {
          const mediaType = forcedType || raw.media_type;
          if (!['movie', 'tv'].includes(mediaType)) continue;
          const enriched = { ...raw, media_type: mediaType };
          if (!releasedOtt(enriched, 2)) continue;
          const k = `${mediaType}:${raw.id}`;
          if (!rawOttMap.has(k)) rawOttMap.set(k, enriched);
        }
      }

      const scoredOttMap = new Map();
      for (const raw of rawOttMap.values()) {
        const scored = scoreOttSearchItem(raw, qNorm, qCompact, qWords);
        if (scored) scoredOttMap.set(`${scored.item.type}:${scored.item.id}`, scored);
      }

      // Scan the in-memory Popular Blockbusters Index (2,630 top Movies & TV Series) so short/prefix/compound queries
      // like "end" -> "Avengers: Endgame" or "bat" -> "The Batman" ALWAYS surface the world's most popular hits first!
      for (const rec of indexedPopularOtt) {
        const mScore = scoreCandidateMatch(qNorm, qCompact, qWords, rec.primaryNorm, rec.primaryCompact, rec.candidates, rec.compacts, rec.words, rec.subtitles, rec.subCompacts);
        if (mScore <= 0) continue;
        const total = finalizeSearchScore(mScore, rec.item, qNorm, rec.popMeter);
        const prev = scoredOttMap.get(rec.key);
        if (!prev || total > prev.score) {
          scoredOttMap.set(rec.key, { item: prev?.item || rec.item, score: total, popMeter: rec.popMeter });
        }
      }

      // Also fuzzy-match curated OTT Spotlight titles
      for (const sp of spotlightCatalog) {
        const k = `${sp.type}:${sp.id}`;
        if (sp.type === 'anime' || scoredOttMap.has(k)) continue;
        const pNorm = normalizeTitle(sp.title);
        const pComp = pNorm.replace(/\s+/g, '');
        const subs = extractSubtitleParts(sp.title).filter(s => s !== pNorm);
        const subComps = subs.map(s => s.replace(/\s+/g, ''));
        const pWords = [...new Set([pNorm, ...subs].flatMap(s => s.split(' ')).filter(Boolean))];
        const mScore = scoreCandidateMatch(qNorm, qCompact, qWords, pNorm, pComp, [pNorm], [pComp], pWords, subs, subComps);
        if (mScore > 0) {
          scoredOttMap.set(k, { item: sp, score: finalizeSearchScore(mScore, sp, qNorm, 780), popMeter: 780 });
        }
      }

      // If TMDB missed due to a space-split compound word (e.g. "end game" vs "endgame") or mid-word typo, run a fallback query
      if (scoredOttMap.size < 3 && ((qWords.length >= 2 && qCompact.length >= 5) || (qWords.length === 1 && qWords[0].length >= 6))) {
        const altQuery = qWords.length >= 2 ? qCompact : qWords[0].slice(0, 5);
        const stemRes = await tmdb('search/multi', { query: altQuery, include_adult: 'false', page: '1' }, 2200).catch(() => null);
        for (const raw of stemRes?.results || []) {
          if (!['movie', 'tv'].includes(raw.media_type)) continue;
          if (!releasedOtt(raw, 5)) continue;
          const k = `${raw.media_type}:${raw.id}`;
          if (scoredOttMap.has(k)) continue;
          const scored = scoreOttSearchItem(raw, qNorm, qCompact, qWords);
          if (scored) scoredOttMap.set(k, scored);
        }
      }

      const scoredOtt = [...scoredOttMap.values()];
      const combinedRanked = [...scoredAnime, ...scoredOtt]
        .sort((a, b) => b.score - a.score)
        .map(x => x.item);

      const queryMentionsSeason = /\b(?:season|part|cour|s\d+)\b/i.test(term);
      return json(res, { items: dedupeCatalog(combinedRanked, queryMentionsSeason).slice(0, 48) }, 200, req);
    }

    if (p === '/api/genre') {
      let g = q.get('name');
      if (!catalogGenres.includes(g)) return json(res, { error: 'Unknown genre' }, 400);
      let mId = movieGenreIds[g], tId = tvGenreIds[g];
      let [mRes, tRes] = await Promise.allSettled([
        mId ? tmdb('discover/movie', { with_genres: String(mId), sort_by: 'popularity.desc', page: '1', 'primary_release_date.lte': today(), 'vote_count.gte': '8', include_adult: 'false' }) : Promise.resolve(null),
        tId ? tmdb('discover/tv', { with_genres: String(tId), sort_by: 'popularity.desc', page: '1', 'first_air_date.lte': today(), 'vote_count.gte': '8', include_adult: 'false' }) : Promise.resolve(null)
      ]);
      let animeItems = sortAnikoto(anikotoItems.filter(x => x.genres.includes(g)), 'popularity').slice(0, 16);
      let movieItems = mRes.status === 'fulfilled' && mRes.value ? mRes.value.results.filter(x => releasedOtt({ ...x, media_type: 'movie' }, 5)).slice(0, 10).map(x => ott({ ...x, media_type: 'movie' })) : [];
      let tvItems = tRes.status === 'fulfilled' && tRes.value ? tRes.value.results.filter(x => releasedOtt({ ...x, media_type: 'tv' }, 5)).slice(0, 10).map(x => ott({ ...x, media_type: 'tv' })) : [];
      let mixed = [];
      for (let i = 0; i < 16; i++) {
        if (animeItems[i]) mixed.push(animeItems[i]);
        if (movieItems[i]) mixed.push(movieItems[i]);
        if (tvItems[i]) mixed.push(tvItems[i]);
      }
      return json(res, { items: dedupeCatalog(mixed).slice(0, 24) }, 200, req);
    }

    if (p === '/api/random') {
      let [o] = await Promise.allSettled([tmdb('trending/all/week')]);
      let ottItems = o.status === 'fulfilled' ? o.value.results.filter(x => ['movie', 'tv'].includes(x.media_type) && releasedOtt(x, 5)).map(ott) : [];
      let topAnime = sortAnikoto(anikotoItems, 'popularity').slice(0, 250);
      let all = dedupeCatalog([...spotlightCatalog, ...topAnime, ...anikotoItems.slice(0, 150), ...ottItems]);
      if (!all.length) throw Error('Catalogs are unavailable');
      return json(res, { item: all[crypto.randomInt(all.length)] }, 200, req);
    }

    if (p === '/api/schedule') {
      let now = Math.floor(Date.now() / 1000), start = now - 24 * 3600, week = now + 8 * 86400;
      let pageBlock = n => `p${n}:Page(page:${n},perPage:50){airingSchedules(airingAt_greater:$start,airingAt_lesser:$week,sort:TIME){id airingAt episode media{${fields}}}}`;
      let d = await anilist(
        `query($start:Int,$week:Int){${[1, 2, 3, 4, 5, 6].map(pageBlock).join(' ')}}`,
        { start, week },
        14000
      );
      let rawSchedules = [1, 2, 3, 4, 5, 6].flatMap(n => d?.[`p${n}`]?.airingSchedules || []);
      let seenSlot = new Set();
      let entries = [];
      for (let x of rawSchedules) {
        if (!x?.media?.idMal || x.media.isAdult || !megaForMedia(x.media)) continue;
        let slotKey = `${x.media.idMal}:${x.episode}`;
        if (seenSlot.has(slotKey)) continue;
        seenSlot.add(slotKey);
        let item = ani(x.media);
        let provider = megaByMal.get(String(x.media.idMal));
        if (provider) item.title = cleanAnimeDisplayTitle(provider) || item.title;
        entries.push({ id: x.id, airingAt: x.airingAt, episode: x.episode, item });
      }
      return json(res, { entries }, 200, req);
    }

    if (p === '/api/filter') {
      let type = ['anime', 'movie', 'tv', 'all'].includes(q.get('type')) ? q.get('type') : 'all';
      let genre = catalogGenres.includes(q.get('genre')) ? q.get('genre') : '';
      let year = /^\d{4}$/.test(q.get('year') || '') && Number(q.get('year')) <= new Date().getFullYear() ? q.get('year') : '';
      let sort = ['popularity', 'rating', 'newest'].includes(q.get('sort')) ? q.get('sort') : 'popularity';
      let status = ['releasing', 'finished'].includes(q.get('status')) ? q.get('status') : '';
      if (q.get('year') && Number(q.get('year')) > new Date().getFullYear()) return json(res, { items: [] }, 200, req);

      let tasks = [];
      if (type === 'all' || type === 'anime') {
        let animeItems = anikotoItems.filter(x => (!genre || x.genres.includes(genre)) && (!year || String(x.year) === year) && (!status || x.status === status.toUpperCase()));
        tasks.push(Promise.resolve(sortAnikoto(animeItems, sort).slice(0, 40)));
      } else if (type === 'movie') {
        let animeMovies = anikotoItems.filter(x => x.isMovie && (!genre || x.genres.includes(genre)) && (!year || String(x.year) === year) && (!status || x.status === status.toUpperCase()));
        tasks.push(Promise.resolve(sortAnikoto(animeMovies, sort).slice(0, 30)));
      }
      for (let mediaType of type === 'all' ? ['movie', 'tv'] : type === 'anime' ? [] : [type]) {
        tasks.push((async () => {
          let genreMap = mediaType === 'movie' ? movieGenreIds : tvGenreIds;
          if (genre && !genreMap[genre]) return [];
          let params = {
            sort_by: { popularity: 'popularity.desc', rating: 'vote_average.desc', newest: mediaType === 'movie' ? 'primary_release_date.desc' : 'first_air_date.desc' }[sort],
            include_adult: 'false',
            'vote_count.gte': sort === 'rating' ? '25' : '6'
          };
          if (genre) params.with_genres = String(genreMap[genre]);
          if (year) params[mediaType === 'movie' ? 'primary_release_year' : 'first_air_date_year'] = year;
          params[mediaType === 'movie' ? 'primary_release_date.lte' : 'first_air_date.lte'] = today();
          let d = await tmdb('discover/' + mediaType, params);
          return d.results.filter(x => releasedOtt({ ...x, media_type: mediaType }, 4)).map(x => ott({ ...x, media_type: mediaType }));
        })());
      }
      let settled = await Promise.allSettled(tasks), groups = settled.filter(x => x.status === 'fulfilled').map(x => x.value), items = [];
      for (let i = 0; i < 50; i++) for (let group of groups) if (group[i]) items.push(group[i]);
      if (!items.length && settled.every(x => x.status === 'rejected')) throw Error('Catalogs are unavailable');
      return json(res, { items: dedupeCatalog(items).slice(0, 60) }, 200, req);
    }

    if (p === '/api/detail') {
      let id = num(q.get('id')), type = q.get('type');
      if (!id || !['anime', 'tv', 'movie'].includes(type)) return json(res, { error: 'Invalid title' }, 400);

      if (type === 'anime') {
        let provider = megaByMal.get(id) || await ensureDynamicMegaEntry(id);
        if (!provider) {
          return json(res, { error: 'This anime is not available on MegaPlay.' }, 404, req);
        }
        let [providerData, media] = await Promise.all([
          anikotoSeries(provider.id).catch(() => null),
          animeRecord(id, true).catch(() => null)
        ]);
        let item = anikotoItem(provider);
        let count = providerData?.episodes?.length || 0;
        if (count > 0) {
          if (!item.isMovie) item.episodes = count;
          item.playable = true;
          item.dub = providerData.episodes.some(x => x.embed_url?.dub) || Boolean(provider.dub);
        } else {
          let directOk = await resolveMegaPlayDirect({ malId: id, aniId: provider.ani || media?.id, episode: 1, lang: 'sub' }).then(() => true).catch(() => false)
            || await resolveMegaPlayDirect({ malId: id, aniId: provider.ani || media?.id, episode: 1, lang: 'dub' }).then(() => true).catch(() => false);
          if (!directOk) {
            return json(res, { error: 'This anime has no released episodes available yet.' }, 404, req);
          }
          item.playable = true;
        }
        if (media) {
          let fallback = ani(media);
          item.poster = item.poster || fallback.poster;
          item.backdrop = item.backdrop || fallback.backdrop;
          item.description = item.description || fallback.description;
          if (!item.genres.length) item.genres = fallback.genres;
        }
        item.upcoming = false;
        let seasons = await animeSeasonFamily(media, id);
        return json(res, { item, episodes: [], seasons }, 200, req);
      }

      let d = await tmdb(type + '/' + id);
      if (!releasedOtt({ ...d, media_type: type }, 0)) {
        return json(res, { error: 'This title is unreleased or unavailable for streaming.' }, 404, req);
      }
      let item = ott({ ...d, media_type: type });
      item.upcoming = false;
      item.playable = true;
      let seasons = type === 'tv'
        ? (d.seasons || [])
            .filter(x => x.season_number >= 1 && Number(x.episode_count) > 0 && (!x.air_date || String(x.air_date).slice(0, 10) <= today()))
            .map(x => ({ number: x.season_number, name: x.name, episodes: x.episode_count }))
        : [];
      return json(res, { item, seasons }, 200, req);
    }

    if (p === '/api/anime-episodes') {
      let id = num(q.get('id')), page = Math.max(1, Math.min(10000, Math.floor(Number(q.get('page')) || 1))), limit = 20;
      if (!id) return json(res, { error: 'Invalid anime' }, 400);
      let provider = megaByMal.get(id) || await ensureDynamicMegaEntry(id);
      if (!provider) return json(res, { error: 'Episodes are not available for this title.' }, 404);
      let base = [];
      let data = await anikotoSeries(provider.id).catch(() => null);
      base = (data?.episodes || []).filter(x => Number.isInteger(Number(x.number)) && Number(x.number) > 0).sort((a, b) => Number(a.number) - Number(b.number));
      if (!base.length) {
        let media = await animeRecord(id, false).catch(() => null);
        let fallbackTotal = positiveInt(provider.episodes) || animeEpisodeCount(media) || 0;
        if (fallbackTotal > 0) {
          base = Array.from({ length: fallbackTotal }, (_, i) => ({
            number: i + 1,
            title: `Episode ${i + 1}`,
            episode_embed_id: '',
            embed_url: {
              sub: `https://megaplay.buzz/stream/mal/${id}/${i + 1}/sub`,
              dub: provider.dub ? `https://megaplay.buzz/stream/mal/${id}/${i + 1}/dub` : null
            }
          }));
        } else {
          return json(res, { error: 'Episodes are not available for this title.' }, 404);
        }
      }
      let offset = (page - 1) * limit, pageRows = base.slice(offset, offset + limit);
      let [jikanMap, anizipMap] = await Promise.all([jikanAnimeEpisodeMeta(id, pageRows.map(x => Number(x.number))), anizipEpisodeMeta(id)]);
      let sources = ['megaplay'];
      if (jikanMap?.size) sources.unshift('jikan');
      if (anizipMap?.size && !sources.includes('jikan')) sources.unshift('jikan-mal');
      let episodes = pageRows.map(x => {
        let n = Number(x.number), jk = jikanMap?.get(n), az = anizipMap?.get(n), fallbackTitle = decodeEntities(x.title);
        let cleanFallback = fallbackTitle && !/^episode\s*\d+$/i.test(fallbackTitle.trim()) ? fallbackTitle : '';
        let title = (jk?.title || az?.title || cleanFallback || `Episode ${n}`).replace(/`/g, "'").trim();
        let description = (jk?.description || az?.description || '').trim();
        let still = jk?.still || az?.still || null;
        return { number: n, title, description, still, embedId: String(x.episode_embed_id || ''), sub: Boolean(x.embed_url?.sub ?? true), dub: Boolean(x.embed_url?.dub) };
      });
      return json(res, { episodes, page, perPage: limit, total: base.length, hasNext: offset + limit < base.length, sources }, 200, req);
    }

    if (p === '/api/season') {
      let id = num(q.get('id')), season = q.get('season') === '0' ? '0' : num(q.get('season'));
      if (!id || season === null) return json(res, { error: 'Invalid season' }, 400);
      let d = await tmdb(`tv/${id}/season/${season}`);
      let rawEps = Array.isArray(d.episodes) ? d.episodes : [];
      let hasAnyDated = rawEps.some(e => Boolean(e.air_date));
      let airedEps = rawEps.filter(e => {
        if (!e.episode_number || e.episode_number <= 0) return false;
        if (e.air_date) return String(e.air_date).slice(0, 10) <= today();
        return !hasAnyDated;
      });
      return json(res, {
        episodes: airedEps.map(e => ({
          number: e.episode_number,
          title: e.name || `Episode ${e.episode_number}`,
          description: e.overview || '',
          still: e.still_path ? 'https://image.tmdb.org/t/p/w300' + e.still_path : null
        }))
      }, 200, req);
    }

    if (p === '/api/play') {
      let id = num(q.get('id')), type = q.get('type'), ep = num(q.get('episode') || '1'), season = q.get('season') === '0' ? '0' : num(q.get('season') || '1');
      let lang = q.get('lang') === 'dub' ? 'dub' : 'sub';
      let requestedProvider = q.get('provider'), provider = OTT_SERVER_KEYS.has(requestedProvider) ? requestedProvider : DEFAULT_OTT_SERVER;
      let aniId = num(q.get('anilistId'));
      if (!id || !ep || !season || !['anime', 'movie', 'tv'].includes(type)) return json(res, { error: 'Invalid playback request' }, 400);

      if (type === 'anime') {
        let available = megaForIds(id, aniId) || await ensureDynamicMegaEntry(id), effectiveAni = aniId || available?.ani || null, fallbackEmbed = null, subFallbackEmbed = null;
        if (!available) return json(res, { error: 'This anime is not available on MegaPlay.' }, 404, req);
        let isAnimeMovie = String(available.format || '').toUpperCase().includes('MOVIE');
        if (available.id) {
          let seriesData = await anikotoSeries(available.id).catch(() => null);
          let row = seriesData?.episodes?.find(x => Number(x.number) === Number(ep));
          fallbackEmbed = row?.embed_url?.[lang] || null;
          subFallbackEmbed = row?.embed_url?.sub || null;
        }
        let azPromise = remote(`https://api.ani.zip/mappings?mal_id=${encodeURIComponent(id)}`, { ttl: 21600000, timeout: 2200, headers: { Accept: 'application/json' } }).catch(() => null);
        let subCompanionPromise = lang === 'dub'
          ? resolveMegaPlayDirect({ malId: id, aniId: effectiveAni, episode: ep, lang: 'sub', fallbackEmbed: subFallbackEmbed }).catch(() => null)
          : Promise.resolve(null);
        try {
          let resolved = await resolveMegaPlayDirect({ malId: id, aniId: effectiveAni, episode: ep, lang, fallbackEmbed });
          let [az, subCompanion] = await Promise.all([azPromise, subCompanionPromise]);
          let tmdbId = az?.mappings?.themoviedb_id || null;
          let azEp = az?.episodes?.[String(ep)] || null;
          let tmdbMapping = tmdbId ? { tmdbId, type: isAnimeMovie || az?.mappings?.type === 'MOVIE' ? 'movie' : 'tv', season: Number(azEp?.seasonNumber) || 1, episode: Number(azEp?.episodeNumber) || Number(ep) || 1 } : null;
          let rawQualityStreams = await enrichAnimeQualityStreams({ primaryUrl: resolved.url, lang, tmdbMapping }).catch(() => []);
          let qualityStreams = rawQualityStreams.map(qs => {
            try { return { tier: qs.tier, height: qs.height, codec: qs.codec || 'h264', type: qs.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', src: mediaUrl(qs.url, qs.proxyProvider || 'megaplay', qs.headers || {}) }; }
            catch { return null; }
          }).filter(Boolean);

          let mergedMegaTracks = Array.isArray(resolved.tracks) ? resolved.tracks.map(x => ({ ...x })) : [];
          if (lang === 'dub' && Array.isArray(subCompanion?.tracks) && subCompanion.tracks.length) {
            const isEng = t => /^en/i.test(t?.language || '') || /^english\b/i.test(String(t?.label || '').trim());
            const dubEn = mergedMegaTracks.find(isEng);
            const subEn = subCompanion.tracks.find(isEng);
            if (dubEn && subEn && dubEn.src !== subEn.src) {
              // Check if MegaPlay's dub English VTT is a short Signs & Songs track (<90 cues) vs full dialogue CC
              let dubCueCount = 999;
              try {
                const vttRes = await fetch(dubEn.src, { headers: { 'User-Agent': 'Mozilla/5.0', Referer: 'https://megaplay.buzz/' }, signal: AbortSignal.timeout(1800) });
                if (vttRes.ok) {
                  const vttTxt = await vttRes.text();
                  dubCueCount = (vttTxt.match(/-->/g) || []).length;
                }
              } catch {}
              if (dubCueCount < 90) {
                dubEn.label = 'English (Signs & Songs)';
                mergedMegaTracks = [
                  { ...subEn },
                  dubEn,
                  ...mergedMegaTracks.filter(t => t !== dubEn),
                  ...subCompanion.tracks.filter(t => t !== subEn && !mergedMegaTracks.some(m => m.label.toLowerCase() === t.label.toLowerCase()))
                ];
              } else {
                for (const st of subCompanion.tracks) {
                  if (!mergedMegaTracks.some(m => m.label.toLowerCase() === st.label.toLowerCase())) {
                    mergedMegaTracks.push({ ...st });
                  }
                }
              }
            } else {
              for (const st of subCompanion.tracks) {
                if (!mergedMegaTracks.some(m => m.label.toLowerCase() === st.label.toLowerCase())) {
                  mergedMegaTracks.push({ ...st });
                }
              }
            }
          }

          let tracks = mergedMegaTracks.map(x => ({ ...x, src: mediaUrl(x.src, 'megaplay') }));
          if (!tracks.length && tmdbMapping) {
            const vsSubs = await fetchVidsparkSubtitles({
              type: tmdbMapping.type,
              id: String(tmdbMapping.tmdbId),
              season: String(tmdbMapping.season || 1),
              episode: String(tmdbMapping.episode || 1)
            }).catch(() => []);
            tracks = vsSubs.map(x => {
              try { return { kind: x.kind || 'subtitles', language: x.language || 'und', label: x.label || 'Subtitle', src: mediaUrl(x.src, x.proxyProvider || 'vidcore', x.headers || {}) }; }
              catch { return null; }
            }).filter(Boolean);
          }

          return json(res, { src: mediaUrl(resolved.url, 'megaplay'), type: /\.mp4(?:\?|$)/i.test(resolved.url) ? 'video/mp4' : 'application/x-mpegURL', kind: 'videojs', provider: 'MegaPlay', server: lang === 'dub' ? 'Dub' : 'Sub', tracks, qualityStreams, intro: resolved.intro, outro: resolved.outro }, 200, req);
        } catch {
          let otherLang = lang === 'dub' ? 'sub' : 'dub', otherFallback = null;
          if (available.id) {
            let seriesData = await anikotoSeries(available.id).catch(() => null);
            let row = seriesData?.episodes?.find(x => Number(x.number) === Number(ep));
            otherFallback = row?.embed_url?.[otherLang] || null;
          }
          let hasOpposite = await resolveMegaPlayDirect({ malId: id, aniId: effectiveAni, episode: ep, lang: otherLang, fallbackEmbed: otherFallback }).then(() => true).catch(() => false);
          if (hasOpposite) {
            return json(res, { error: lang === 'dub' ? 'Dub is not available for this episode.' : 'Sub is not available for this episode.', availableLang: otherLang }, 404, req);
          }
          return json(res, { error: 'This episode is not available on MegaPlay right now.' }, 404, req);
        }
      }

      let input = { type, id, season, episode: ep };
      let resolved = await resolveOttWithFallback(input, provider, getTmdbMetaForResolver);
      let proxyProvider = resolved.proxyProvider || resolved.sourceKey || DEFAULT_OTT_SERVER;
      let src = resolved.kind === 'dash' ? dashUrl(resolved.url, proxyProvider, resolved.headers) : mediaUrl(resolved.url, proxyProvider, resolved.headers);
      let tracks = (resolved.tracks || []).map(x => {
        try { return { kind: x.kind || 'subtitles', language: x.language || 'und', label: x.label || 'Subtitle', src: mediaUrl(x.src, x.proxyProvider || proxyProvider, x.headers || resolved.headers) }; }
        catch { return null; }
      }).filter(Boolean);
      let audioStreams = (resolved.audioStreams || []).map(a => {
        try { return { language: a.language, label: a.label, src: mediaUrl(a.url, a.proxyProvider || proxyProvider, a.headers || resolved.headers) }; }
        catch { return null; }
      }).filter(Boolean);
      let qualityStreams = (resolved.qualityStreams || []).map(qs => {
        try { return { tier: qs.tier, height: qs.height, codec: qs.codec || 'h264', type: qs.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', src: mediaUrl(qs.url, qs.proxyProvider || proxyProvider, qs.headers || resolved.headers || {}) }; }
        catch { return null; }
      }).filter(Boolean);
      return json(res, { src, type: resolved.kind === 'mp4' ? 'video/mp4' : 'application/x-mpegURL', codec: resolved.codec || 'h264', kind: 'videojs', provider: resolved.provider, sourceKey: resolved.sourceKey, server: resolved.server, tracks, audioStreams, qualityStreams }, 200, req);
    }

    return json(res, { error: 'Not found' }, 404);
  } catch (e) {
    return json(res, { error: e.message || 'Request failed' }, e.message?.includes('configured') ? 503 : 502);
  }
}

let jikanUnreachableUntil = 0;
async function jikanAnimeEpisodeMeta(malId, sliceNums) {
  if (Date.now() < jikanUnreachableUntil) return null;
  try {
    let jikanPage = Math.max(1, Math.ceil((sliceNums[0] || 1) / 100));
    let [epRes, vidRes] = await Promise.all([
      remote(`https://api.jikan.moe/v4/anime/${encodeURIComponent(malId)}/episodes?page=${jikanPage}`, { ttl: 21600000, timeout: 1800, headers: { Accept: 'application/json' } }).catch(err => {
        if (/timeout|abort|fetch/i.test(err.message)) jikanUnreachableUntil = Date.now() + 600000;
        return null;
      }),
      remote(`https://api.jikan.moe/v4/anime/${encodeURIComponent(malId)}/videos/episodes?page=1`, { ttl: 21600000, timeout: 1800, headers: { Accept: 'application/json' } }).catch(() => null)
    ]);
    if (!epRes?.data && !vidRes?.data) return null;
    let byNum = new Map();
    for (let row of epRes?.data || []) {
      let n = Number(row.mal_id);
      if (n > 0) byNum.set(n, { title: row.title || row.title_romanji || '', still: null, description: '' });
    }
    for (let row of vidRes?.data || []) {
      let n = Number(row.mal_id), img = row.images?.jpg?.image_url || null;
      if (n > 0) {
        let prev = byNum.get(n) || { title: '', still: null, description: '' };
        byNum.set(n, { title: prev.title || row.title || '', still: img || prev.still, description: prev.description });
      }
    }
    return byNum;
  } catch { return null; }
}

async function anizipEpisodeMeta(malId) {
  try {
    let d = await remote(`https://api.ani.zip/mappings?mal_id=${encodeURIComponent(malId)}`, { ttl: 21600000, timeout: 4500, headers: { Accept: 'application/json' } });
    let eps = d?.episodes || {};
    let byNum = new Map();
    for (let [k, ep] of Object.entries(eps)) {
      if (!/^\d+$/.test(k)) continue;
      let n = Number(k);
      if (!Number.isInteger(n) || n <= 0) continue;
      let rawTitle = typeof ep.title === 'string' ? ep.title : (ep.title?.en || ep.title?.['x-jat'] || ep.title?.ja || '');
      let rawDesc = String(ep.overview || ep.summary || '').replace(/\s*\(?\bSource:\s*[^)\n]+\)?\s*$/i, '').trim();
      let img = /^https:\/\//.test(ep.image || '') ? ep.image : null;
      byNum.set(n, { title: rawTitle, still: img, description: rawDesc });
    }
    return byNum;
  } catch { return null; }
}

const staticCache = new Map();
const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ttf': 'font/ttf',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2'
};
const CSP = "default-src 'self' https: data: blob:; frame-src 'none'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' https: data:; connect-src 'self' https: data: blob:; media-src 'self' https: data: blob:; worker-src 'self' blob:";

http.createServer((req, res) => {
  let u = new URL(req.url, 'http://localhost');
  if (u.pathname.startsWith('/browse/watch/')) {
    let dest = u.pathname.replace(/^\/browse\/watch\//, '/watch/');
    res.writeHead(301, { Location: dest + u.search });
    return res.end();
  }
  if (u.pathname === '/upcoming') {
    res.writeHead(302, { Location: '/browse' });
    return res.end();
  }
  if (/^\/(anime|ott)(\/|$)/.test(u.pathname)) {
    let dest = u.pathname.replace(/^\/(anime|ott)/, '/browse');
    res.writeHead(302, { Location: dest + u.search });
    return res.end();
  }
  if (u.pathname.startsWith('/api/dash/')) return handleDash(req, res, u);
  if (u.pathname === '/api/media') return handleMedia(req, res, u);
  if (u.pathname.startsWith('/api/')) return api(req, res, u);

  let pathname = u.pathname === '/' ? '/index.html' : u.pathname;
  let target = path.resolve(root, '.' + pathname);
  if (!target.startsWith(root + path.sep) || !fs.existsSync(target) || !fs.statSync(target).isFile()) {
    target = path.join(root, 'index.html');
  }
  let ext = path.extname(target), stat = fs.statSync(target), cached = staticCache.get(target);
  if (!cached || cached.mtime !== stat.mtimeMs) {
    let raw = fs.readFileSync(target), compressible = /^\.(?:html|js|css|svg|webmanifest)$/.test(ext);
    cached = { mtime: stat.mtimeMs, raw, gz: compressible ? zlib.gzipSync(raw, { level: 6 }) : null };
    staticCache.set(target, cached);
  }
  let immutable = u.pathname.startsWith('/vendor/') || u.pathname.startsWith('/fonts/') || u.pathname.startsWith('/images/') || u.searchParams.has('v');
  let headers = {
    'Content-Type': mimeTypes[ext] || 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-cache' : (immutable ? 'public, max-age=86400' : 'public, max-age=300'),
    'Content-Security-Policy': CSP
  };
  if (cached.gz && String(req.headers['accept-encoding'] || '').includes('gzip')) {
    headers['Content-Encoding'] = 'gzip';
    headers['Vary'] = 'Accept-Encoding';
    res.writeHead(200, headers);
    return res.end(cached.gz);
  }
  res.writeHead(200, headers);
  res.end(cached.raw);
}).listen(process.env.PORT || 3000, '0.0.0.0', () => {
  console.log('kozuTV V5.2.0 listening on ' + (process.env.PORT || 3000));
});
