# kozuTV V5.0.0

**kozuTV** is a fast, modern, ad-free streaming web application for **HD Anime (English Sub & Dub)**, **Movies**, and **Web Series** powered by a custom **Video.js 8.23.4** player and same-origin signed media proxy.

## Quick Start

```bash
npm install
npm start
```

By default, the server listens on `http://0.0.0.0:3000` (override with `PORT=8080 npm start` or edit `start.js`).

## Highlights in V5.0.0

- **kozuTV Rebrand & Assets**: Transparent high-DPI geometric `kozuTV` wordmark, simplistic `k` multi-size favicon (`favicon.ico`, `favicon-32.png`, `favicon-192.png`, `apple-touch-icon.png`), `site.webmanifest`, OpenGraph/Twitter `1200×630` social banner (`/images/kozutv-banner.jpg`), and Anikoto-inspired metadata & titles.
- **Clean `/watch` Routes**: Direct `/watch/:type/:id` URLs across the app (with automatic `301` redirect from legacy `/browse/watch/:type/:id` links).
- **3 Dedicated OTT Servers (Movies & Web Series)**:
  1. `vidcore.org` (`vidcore` — Default, multi-audio Original + English Dub, multi-language WebVTT subtitles)
  2. `vidlink.pro` (`vidlink` — multi-tier 4K / 2K / Full HD / HD / SD + WebVTT captions)
  3. `vidsrc.to` (`vidsrc` — multi-audio HLS + multi-language subtitles)
- **Instant Multi-Tier Quality Switcher**: Descriptive resolution tiers (`4K · 2160p`, `2K · 1440p`, `Full HD · 1080p`, `HD · 720p`, `SD · 480p`, `SD · 360p`, `Auto`) with high-bitrate default startup and immediate switching across both Anime and OTT streams.
- **Upgraded Relevance & Typo-Tolerant Search**: Multi-source search across MegaPlay, AniList, and TMDB (`multi` + `movie` + `tv`) with prefix, acronym, compact-word, and fuzzy edit-distance ranking.
- **Strict Catalog Purity**: Only released, streamable titles appear in the catalog and search — unreleased titles and anime unavailable on MegaPlay are excluded everywhere.
