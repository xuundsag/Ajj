import freekeys from 'freekeys';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('public'), db=path.resolve('data/user.json'), usersDb=path.resolve('data/users.json'), statesDb=path.resolve('data/states.json');
const initial={watchlist:[],history:[]};
if(!fs.existsSync(db))fs.writeFileSync(db,JSON.stringify(initial));
if(!fs.existsSync(usersDb))fs.writeFileSync(usersDb,'[]');
if(!fs.existsSync(statesDb))fs.writeFileSync(statesDb,JSON.stringify({visitors:{},accounts:{}}));
const json=(res,data,status=200)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data))};
const cache=new Map();
async function remote(url,options={}){let ttl=options.ttl??300000,c=cache.get(url);if(c&&Date.now()-c.time<(c.ttl||ttl))return c.data;let r=await fetch(url,{headers:{'User-Agent':'MoscowTV/1.0 (catalog app)',...(options.headers||{})},signal:AbortSignal.timeout(options.timeout||9000)});if(!r.ok)throw Error('Catalog unavailable ('+r.status+')');let data=await r.json();cache.set(url,{data,time:Date.now(),ttl});return data}
const genreNames={28:'Action',12:'Adventure',16:'Animation',35:'Comedy',80:'Crime',99:'Documentary',18:'Drama',10751:'Family',14:'Fantasy',36:'History',27:'Horror',10402:'Music',9648:'Mystery',10749:'Romance',878:'Science Fiction',10770:'TV Movie',53:'Thriller',10752:'War',37:'Western',10759:'Action & Adventure',10765:'Sci-Fi & Fantasy'};
const ott=x=>({id:String(x.id),type:x.media_type==='tv'||(!x.media_type&&x.first_air_date)?'tv':'movie',title:x.title||x.name||'',poster:x.poster_path?'https://image.tmdb.org/t/p/w500'+x.poster_path:null,backdrop:x.backdrop_path?'https://image.tmdb.org/t/p/original'+x.backdrop_path:null,description:x.overview||'',rating:x.vote_average?Number(x.vote_average.toFixed(1)):null,year:(x.release_date||x.first_air_date||'').slice(0,4),genres:x.genres?.map(g=>g.name)||x.genre_ids?.map(id=>genreNames[id]).filter(Boolean)||[],seasons:x.number_of_seasons});
const aniCache=new Map();async function anilist(query,variables={}){let key=JSON.stringify([query,variables]),cached=aniCache.get(key);if(cached&&Date.now()-cached.time<300000)return cached.data;let r=await fetch('https://graphql.anilist.co',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query,variables}),signal:AbortSignal.timeout(9000)});if(!r.ok)throw Error('Anime catalog unavailable');let d=await r.json();if(d.errors)throw Error(d.errors[0].message);aniCache.set(key,{data:d.data,time:Date.now()});return d.data}
const fields='id idMal title{english romaji} coverImage{extraLarge large} bannerImage description(asHtml:false) averageScore format seasonYear startDate{year month day} episodes nextAiringEpisode{episode} genres status isAdult';
const positiveInt=value=>Number.isInteger(Number(value))&&Number(value)>0?Number(value):null;
function animeEpisodeCount(media){
 if(media.format==='MOVIE'||media.status==='NOT_YET_RELEASED')return null;
 let total=positiveInt(media.episodes);
 if(media.status==='RELEASING'){
  let released=positiveInt((media.nextAiringEpisode?.episode||1)-1);
  if(released)return total?Math.min(total,released):released;
 }
 return total;
}
const ani=x=>{
 let isMovie=x.format==='MOVIE',episodes=animeEpisodeCount(x);
 return {id:String(x.idMal),anilistId:String(x.id),type:'anime',title:x.title?.english||x.title?.romaji||'',poster:x.coverImage?.extraLarge||x.coverImage?.large,backdrop:x.bannerImage||x.coverImage?.extraLarge,description:(x.description||'').replace(/<[^>]*>/g,''),rating:x.averageScore?Number((x.averageScore/10).toFixed(1)):null,year:x.seasonYear||x.startDate?.year,episodes,episodeCountKind:x.status==='RELEASING'?'released':'total',genres:x.genres||[],status:x.status,format:x.format||null,isMovie};
};
async function animeRecord(id,withRelations=false){
 let d=await anilist(`query($id:Int){Media(idMal:$id,type:ANIME){${fields}${withRelations?' relations{edges{relationType node{idMal type format}}}':''}}}`,{id:Number(id)});
 return d.Media;
}
function animeTitleKey(media){
 let title=(media.title?.english||media.title?.romaji||'').toLowerCase().split(':')[0];
 return title.replace(/\bfinal season\b.*$/,'').replace(/\b(?:season|part|cour)\s*\d+\b.*$/,'').replace(/\s+(?:ii|iii|iv|v|vi|vii|viii|ix|x)$/,'').replace(/[^a-z0-9]+/g,' ').trim();
}
function explicitAnimeSeason(media){return /\b(?:season|part|cour)\s*\d+\b|\bfinal season\b|\s(?:ii|iii|iv|v|vi|vii|viii|ix|x)$/i.test(media.title?.english||media.title?.romaji||'')}
function compatibleAnimeFormat(root,candidate){return ['TV','TV_SHORT'].includes(root)?['TV','TV_SHORT'].includes(candidate):root===candidate}
function animeSeasonEntry(media){let item=ani(media);return {id:String(media.idMal),anilistId:String(media.id),name:item.title,episodes:item.episodes,format:item.format}}
async function animeSeasonFamily(media){
 if(!media||media.format==='MOVIE'||!['TV','TV_SHORT','ONA'].includes(media.format))return [];
 let entries=new Map([[String(media.idMal),media]]),seen=new Set([String(media.idMal)]),queue=[media],key=animeTitleKey(media);
 while(queue.length&&seen.size<24){
  let current=queue.shift();
  for(let edge of current.relations?.edges||[]){
   let node=edge.node,id=String(node.idMal||'');
   if(!['PREQUEL','SEQUEL'].includes(edge.relationType)||node.type!=='ANIME'||!compatibleAnimeFormat(media.format,node.format)||!node.idMal||seen.has(id))continue;
   seen.add(id);
   try{let linked=await animeRecord(id,true);if(linked&&animeTitleKey(linked)===key){entries.set(id,linked);queue.push(linked)}}catch{}
  }
 }
 let all=[...entries.values()];
 // Group only explicit season/part families. Naruto Shippuden, Boruto and
 // other differently titled successors remain completely standalone.
 if(all.length<2||!all.some(explicitAnimeSeason))return [];
 return all.sort((a,b)=>(a.startDate?.year||9999)-(b.startDate?.year||9999)||(a.startDate?.month||1)-(b.startDate?.month||1)||(a.startDate?.day||1)-(b.startDate?.day||1)||Number(a.id)-Number(b.id)).map(animeSeasonEntry);
}
let jikanRetryAfter=0;
async function jikan(path){
 if(Date.now()<jikanRetryAfter)throw Error('Jikan is temporarily unavailable');
 try{return await remote('https://api.jikan.moe/v4/'+path,{timeout:4000,ttl:86400000,headers:{Accept:'application/json'}})}
 catch(error){jikanRetryAfter=Date.now()+60000;throw error}
}
const kitsuOptions={ttl:86400000,headers:{Accept:'application/vnd.api+json'}};
async function kitsuEpisodes(malId,offset,limit){
 let mapping=await remote(`https://kitsu.io/api/edge/mappings?filter%5BexternalSite%5D=myanimelist%2Fanime&filter%5BexternalId%5D=${malId}`,kitsuOptions);
 let link=mapping.data?.find(x=>x.attributes?.externalSite==='myanimelist/anime'&&String(x.attributes?.externalId)===String(malId))?.relationships?.item?.links?.related;
 if(!link)return null;
 let anime=await remote(link,kitsuOptions),kitsuId=anime.data?.id;
 if(!kitsuId)return null;
 let response=await remote(`https://kitsu.io/api/edge/anime/${kitsuId}/episodes?page%5Blimit%5D=${limit}&page%5Boffset%5D=${offset}&sort=number`,kitsuOptions);
 return {kitsuId,response};
}
function kitsuEpisode(row){
 let a=row.attributes||{},number=Number(a.number);
 return {number,title:a.titles?.en_us||a.titles?.en||a.titles?.en_jp||a.canonicalTitle||null,description:a.synopsis||a.description||'',still:a.thumbnail?.original||null,aired:a.airdate||null,duration:Number(a.length)||null,filler:false,recap:false};
}
function jikanEpisode(row){
 return {number:Number(row.mal_id),title:row.title||row.title_romanji||row.title_japanese||null,description:row.synopsis||'',still:row.images?.jpg?.image_url||row.images?.webp?.image_url||null,aired:row.aired||null,duration:Number(row.duration)||null,score:Number(row.score)||null,filler:Boolean(row.filler),recap:Boolean(row.recap)};
}
function mergeEpisode(fallback,primary){
 if(!fallback)return primary;
 return {...fallback,...Object.fromEntries(Object.entries(primary).filter(([,value])=>value!==null&&value!==''&&value!==undefined)),still:primary.still||fallback.still,description:primary.description||fallback.description,title:primary.title||fallback.title};
}
let sharedKey=null;
async function tmdbKey(){if(process.env.TMDB_API_KEY)return process.env.TMDB_API_KEY;if(!sharedKey)sharedKey=(await freekeys()).tmdb_key;return sharedKey}
async function tmdb(route,params={}){let key=await tmdbKey();let q=new URLSearchParams({...params,api_key:key,language:'en-US'});try{return await remote('https://api.themoviedb.org/3/'+route+'?'+q)}catch(e){if(process.env.TMDB_API_KEY)throw e;sharedKey=(await freekeys()).tmdb_key;q.set('api_key',sharedKey);return remote('https://api.themoviedb.org/3/'+route+'?'+q)}}
const sessions=new Map();
const readUsers=()=>{try{return JSON.parse(fs.readFileSync(usersDb))}catch{return []}};
const writeUsers=users=>fs.writeFileSync(usersDb,JSON.stringify(users));
const readStates=()=>{try{let d=JSON.parse(fs.readFileSync(statesDb));return {visitors:d.visitors||{},accounts:d.accounts||{},meta:d.meta||{}}}catch{return {visitors:{},accounts:{},meta:{}}}};
const cleanState=state=>({watchlist:Array.isArray(state?.watchlist)?state.watchlist.slice(0,100):[],history:Array.isArray(state?.history)?state.history.slice(0,100):[]});
function readState(owner){let states=readStates(),existing=states[owner.scope]?.[owner.id];if(owner.scope==='visitors'&&!existing&&!states.meta.legacyMigrated){let legacy=null;try{legacy=JSON.parse(fs.readFileSync(db))}catch{}states.meta.legacyMigrated=true;if(legacy&&(legacy.watchlist?.length||legacy.history?.length))states.visitors[owner.id]=cleanState(legacy);fs.writeFileSync(statesDb,JSON.stringify(states));return cleanState(states.visitors[owner.id])}return cleanState(existing)}
function writeState(owner,state){let states=readStates();states[owner.scope][owner.id]=cleanState(state);fs.writeFileSync(statesDb,JSON.stringify(states));return states[owner.scope][owner.id]}
function mergeStates(a,b){let result={};for(let field of ['watchlist','history']){let seen=new Map();for(let x of [...(a?.[field]||[]),...(b?.[field]||[])].sort((a,b)=>(b.updated||0)-(a.updated||0))){let key=x.type+':'+x.id;if(!seen.has(key))seen.set(key,x)}result[field]=[...seen.values()].slice(0,100)}return result}
const parseCookies=req=>Object.fromEntries(String(req.headers.cookie||'').split(';').map(x=>x.trim().split('=').map(decodeURIComponent)).filter(x=>x.length===2));
function appendCookie(res,value){let old=res.getHeader('Set-Cookie'),all=old?(Array.isArray(old)?old:[old]):[];res.setHeader('Set-Cookie',[...all,value])}
function visitorId(req,res){let cookies=parseCookies(req),id=cookies.moscowtv_visitor;if(!/^[a-f0-9]{32}$/.test(id||'')){id=crypto.randomBytes(16).toString('hex');appendCookie(res,`moscowtv_visitor=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=315360000`)}return id}
function publicAccount(username){let u=readUsers().find(x=>x.username.toLowerCase()===String(username).toLowerCase());return u?{username:u.username,avatar:u.avatar||'orange',bio:u.bio||'',created:u.created}:null}
function currentAccount(req){let token=parseCookies(req).moscowtv_session,session=token&&sessions.get(token);if(!session||session.expires<Date.now())return null;return publicAccount(session.username)}
function stateOwner(req,res){let account=currentAccount(req);return account?{scope:'accounts',id:account.username.toLowerCase()}:{scope:'visitors',id:visitorId(req,res)}}
function createSession(res,username){let token=crypto.randomBytes(32).toString('hex');sessions.set(token,{username,expires:Date.now()+30*86400000});appendCookie(res,`moscowtv_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000`);return publicAccount(username)}
async function requestBody(req){let chunks=[];for await(let chunk of req){chunks.push(chunk);if(Buffer.concat(chunks).length>50000)throw Error('Payload too large')}return JSON.parse(Buffer.concat(chunks).toString()||'{}')}
async function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){let derived=await new Promise((resolve,reject)=>crypto.scrypt(password,salt,64,(error,key)=>error?reject(error):resolve(key)));return salt+':'+derived.toString('hex')}
async function verifyPassword(password,stored){let [salt,expected]=String(stored).split(':');if(!salt||!expected)return false;let hashed=await hashPassword(password,salt),a=Buffer.from(hashed.split(':')[1],'hex'),b=Buffer.from(expected,'hex');return a.length===b.length&&crypto.timingSafeEqual(a,b)}
function backupVisitorToAccount(req,res,username){let visitor={scope:'visitors',id:visitorId(req,res)},account={scope:'accounts',id:username.toLowerCase()};return writeState(account,mergeStates(readState(visitor),readState(account)))}
function num(s){return /^\d{1,10}$/.test(s||'')?s:null}
async function api(req,res,url){let p=url.pathname, q=url.searchParams;try{
if(p==='/api/auth/me')return json(res,{user:currentAccount(req)});
if(p==='/api/auth/register'&&req.method==='POST'){
 let body=await requestBody(req),username=String(body.username||'').trim(),password=String(body.password||'');
 if(!/^[A-Za-z0-9_.]{3,20}$/.test(username)||password.length<6||password.length>72)return json(res,{error:'Use a 3–20 character username and a password of 6–72 characters.'},400);
 let users=readUsers();if(users.some(x=>x.username.toLowerCase()===username.toLowerCase()))return json(res,{error:'That username already has an account.'},409);
 users.push({username,hash:await hashPassword(password),avatar:'orange',bio:'',created:Date.now()});writeUsers(users);backupVisitorToAccount(req,res,username);return json(res,{user:createSession(res,username)});
}
if(p==='/api/auth/login'&&req.method==='POST'){
 let body=await requestBody(req),username=String(body.username||'').trim(),password=String(body.password||''),account=readUsers().find(x=>x.username.toLowerCase()===username.toLowerCase());
 if(!account||!await verifyPassword(password,account.hash))return json(res,{error:'Incorrect username or password.'},401);
 backupVisitorToAccount(req,res,account.username);return json(res,{user:createSession(res,account.username)});
}
if(p==='/api/auth/logout'&&req.method==='POST'){
 let account=currentAccount(req),token=parseCookies(req).moscowtv_session;if(account){let visitor={scope:'visitors',id:visitorId(req,res)},owner={scope:'accounts',id:account.username.toLowerCase()};writeState(visitor,mergeStates(readState(owner),readState(visitor)))}if(token)sessions.delete(token);appendCookie(res,'moscowtv_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');return json(res,{user:null})
}
if(p==='/api/state'){return json(res,readState(stateOwner(req,res)))}
if((p==='/api/watchlist'&&req.method==='POST')||(p==='/api/history'&&req.method==='POST')){
 let item=await requestBody(req);if(!['anime','movie','tv'].includes(item.type)||!num(String(item.id)))return json(res,{error:'Invalid item'},400);
 let owner=stateOwner(req,res),state=readState(owner),field=p.endsWith('watchlist')?'watchlist':'history';
 let record={id:String(item.id),type:item.type,title:String(item.title||'').slice(0,200),poster:String(item.poster||'').slice(0,500),episode:Math.max(1,Number(item.episode)||1),season:Math.max(1,Number(item.season)||1),updated:Date.now()};
 record.genres=Array.isArray(item.genres)?item.genres.map(String).slice(0,10):[];record.format=typeof item.format==='string'?item.format.slice(0,20):null;record.isMovie=Boolean(item.isMovie);record.currentTime=Math.max(0,Number(item.currentTime)||0);record.duration=Math.max(0,Number(item.duration)||0);
 let found=state[field].findIndex(x=>x.id===record.id&&x.type===record.type),old=found>=0?state[field].splice(found,1)[0]:null;
 if(field==='history'&&old&&old.episode===record.episode&&old.season===record.season){record.currentTime=item.currentTime==null?old.currentTime||0:record.currentTime;record.duration=item.duration==null?old.duration||0:record.duration}if(!record.genres.length&&old)record.genres=old.genres||[];
 if(field==='history'||!item.remove)state[field].unshift(record);writeState(owner,state);return json(res,state)
}
if(p==='/api/profile'&&req.method==='GET'){let owner=stateOwner(req,res),state=readState(owner);return json(res,{user:currentAccount(req),stats:{watchlist:state.watchlist.length,history:state.history.length}})}
if(p==='/api/profile'&&req.method==='POST'){let account=currentAccount(req);if(!account)return json(res,{error:'Sign in to edit your profile.'},401);let body=await requestBody(req),avatar=String(body.avatar||'orange'),bio=String(body.bio||'').trim();if(!['orange','violet','blue','green','red','gold'].includes(avatar)||bio.length>160)return json(res,{error:'Invalid profile.'},400);let users=readUsers(),u=users.find(x=>x.username.toLowerCase()===account.username.toLowerCase());u.avatar=avatar;u.bio=bio;writeUsers(users);return json(res,{user:publicAccount(u.username)})}
if(p==='/api/browse'){let [a,o]=await Promise.allSettled([anilist(`query {Page(page:1,perPage:18){media(type:ANIME,sort:TRENDING_DESC,isAdult:false){${fields}}}}`),tmdb('trending/all/week')]);let animeItems=a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal).map(ani):[];let ottItems=o.status==='fulfilled'?o.value.results.filter(x=>x.media_type==='tv'||x.media_type==='movie').map(ott):[];if(!animeItems.length&&!ottItems.length)throw Error('Catalogs are unavailable');let movies=ottItems.filter(x=>x.type==='movie'),shows=ottItems.filter(x=>x.type==='tv'),mixed=[];for(let i=0;i<Math.max(animeItems.length,movies.length,shows.length);i++){if(animeItems[i])mixed.push(animeItems[i]);if(movies[i])mixed.push(movies[i]);if(shows[i])mixed.push(shows[i])}let history=readState(stateOwner(req,res)).history,watchedGenres=new Map();for(let [index,h] of history.entries())for(let g of h.genres||[])watchedGenres.set(g.toLowerCase(),(watchedGenres.get(g.toLowerCase())||0)+Math.max(1,8-index));let watched=new Set(history.map(h=>h.type+':'+h.id));let suggestions=mixed.filter(x=>!watched.has(x.type+':'+x.id)).map(x=>({...x,match:(x.genres||[]).reduce((n,g)=>n+(watchedGenres.get(g.toLowerCase())||0),0)})).filter(x=>x.match>0).sort((a,b)=>b.match-a.match).slice(0,12);return json(res,{items:mixed,suggestions,hasPreferences:watchedGenres.size>0})}
if(p==='/api/search-all'){let term=(q.get('q')||'').trim().slice(0,100);if(!term)return json(res,{items:[]});let [a,o]=await Promise.allSettled([anilist(`query($search:String){Page(page:1,perPage:15){media(type:ANIME,search:$search,isAdult:false){${fields}}}}`,{search:term}),tmdb('search/multi',{query:term,include_adult:'false'})]);return json(res,{items:[...(a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal).map(ani):[]),...(o.status==='fulfilled'?o.value.results.filter(x=>['tv','movie'].includes(x.media_type)).map(ott):[])]})}
if(p==='/api/genre'){let g=q.get('name');if(!['Action','Adventure','Animation','Comedy','Drama','Fantasy','Horror','Romance','Thriller'].includes(g))return json(res,{error:'Unknown genre'},400);let id={Action:28,Adventure:12,Animation:16,Comedy:35,Drama:18,Fantasy:14,Horror:27,Romance:10749,Thriller:53}[g];let [a,o]=await Promise.allSettled([anilist(`query($genre:String){Page(page:1,perPage:8){media(type:ANIME,genre:$genre,sort:POPULARITY_DESC,isAdult:false){${fields}}}}`,{genre:g}),tmdb('discover/movie',{with_genres:String(id),sort_by:'popularity.desc',page:'1'})]);let animeItems=a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal).map(ani):[];let movieItems=o.status==='fulfilled'?o.value.results.slice(0,8).map(ott):[];let mixed=[];for(let i=0;i<8;i++){if(animeItems[i])mixed.push(animeItems[i]);if(movieItems[i])mixed.push(movieItems[i])}return json(res,{items:mixed.slice(0,12)})}
if(p==='/api/random'){let [a,o]=await Promise.allSettled([anilist(`query {Page(page:1,perPage:50){media(type:ANIME,sort:POPULARITY_DESC,isAdult:false){${fields}}}}`),tmdb('trending/all/week')]);let all=[...(a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal).map(ani):[]),...(o.status==='fulfilled'?o.value.results.filter(x=>['movie','tv'].includes(x.media_type)).map(ott):[])];if(!all.length)throw Error('Catalogs are unavailable');return json(res,{item:all[crypto.randomInt(all.length)]})}
if(p==='/api/schedule'){let now=Math.floor(Date.now()/1000),week=now+7*86400,d=await anilist(`query($now:Int,$week:Int){Page(page:1,perPage:50){airingSchedules(airingAt_greater:$now,airingAt_lesser:$week,sort:TIME){id airingAt episode media{${fields}}}}}`,{now,week});return json(res,{entries:d.Page.airingSchedules.filter(x=>x.media?.idMal&&!x.media.isAdult).map(x=>({id:x.id,airingAt:x.airingAt,episode:x.episode,item:ani(x.media)}))})}
if(p==='/api/upcoming'){let [a,o]=await Promise.allSettled([anilist(`query {Page(page:1,perPage:24){media(type:ANIME,status:NOT_YET_RELEASED,sort:POPULARITY_DESC,isAdult:false){${fields}}}}`),tmdb('movie/upcoming',{region:'IN'})]);return json(res,{anime:a.status==='fulfilled'?a.value.Page.media.filter(x=>x.idMal).map(ani):[],movies:o.status==='fulfilled'?o.value.results.map(ott):[]})}
if(p==='/api/filter'){
 let type=['anime','movie','tv','all'].includes(q.get('type'))?q.get('type'):'all',genre=['Action','Adventure','Animation','Comedy','Drama','Fantasy','Horror','Romance','Thriller'].includes(q.get('genre'))?q.get('genre'):'',year=/^\d{4}$/.test(q.get('year')||'')?q.get('year'):'',sort=['popularity','rating','newest'].includes(q.get('sort'))?q.get('sort'):'popularity',status=['releasing','finished'].includes(q.get('status'))?q.get('status'):'',tasks=[];
 if(type==='all'||type==='anime')tasks.push((async()=>{let vars={genre:genre||null,sort:[{popularity:'POPULARITY_DESC',rating:'SCORE_DESC',newest:'START_DATE_DESC'}[sort]],status:status?status.toUpperCase():null,start:year?Number(year+'0101'):null,end:year?Number(year+'1231'):null},d=await anilist(`query($genre:String,$sort:[MediaSort],$status:MediaStatus,$start:FuzzyDateInt,$end:FuzzyDateInt){Page(page:1,perPage:24){media(type:ANIME,isAdult:false,genre:$genre,sort:$sort,status:$status,startDate_greater:$start,startDate_lesser:$end){${fields}}}}`,vars);return d.Page.media.filter(x=>x.idMal).map(ani)})());
 let movieGenres={Action:28,Adventure:12,Animation:16,Comedy:35,Drama:18,Fantasy:14,Horror:27,Romance:10749,Thriller:53},tvGenres={Action:10759,Adventure:10759,Animation:16,Comedy:35,Drama:18,Fantasy:10765,Horror:27,Romance:10749};
 for(let mediaType of type==='all'?['movie','tv']:type==='anime'?[]:[type])tasks.push((async()=>{let genreMap=mediaType==='movie'?movieGenres:tvGenres;if(genre&&!genreMap[genre])return [];let params={sort_by:{popularity:'popularity.desc',rating:'vote_average.desc',newest:mediaType==='movie'?'primary_release_date.desc':'first_air_date.desc'}[sort],include_adult:'false','vote_count.gte':sort==='rating'?'20':'0'};if(genre)params.with_genres=String(genreMap[genre]);if(year)params[mediaType==='movie'?'primary_release_year':'first_air_date_year']=year;let d=await tmdb('discover/'+mediaType,params);return d.results.map(ott)})());
 let settled=await Promise.allSettled(tasks),groups=settled.filter(x=>x.status==='fulfilled').map(x=>x.value),items=[];for(let i=0;i<50;i++)for(let group of groups)if(group[i])items.push(group[i]);if(!items.length&&settled.every(x=>x.status==='rejected'))throw Error('Catalogs are unavailable');return json(res,{items:items.slice(0,60)})
}
if(p==='/api/detail'){let id=num(q.get('id')),type=q.get('type');if(!id||!['anime','tv','movie'].includes(type))return json(res,{error:'Invalid title'},400);if(type==='anime'){
 let media=await animeRecord(id,true);
 if(!media)return json(res,{error:'Anime not found'},404);
 let seasons=await animeSeasonFamily(media);
 return json(res,{item:ani(media),episodes:[],seasons});
 }let d=await tmdb(type+'/'+id);return json(res,{item:ott({...d,media_type:type}),seasons:d.seasons?.filter(x=>x.season_number>=0).map(x=>({number:x.season_number,name:x.name,episodes:x.episode_count}))||[]})}
if(p==='/api/anime-episodes'){
 let id=num(q.get('id')),page=Math.max(1,Math.min(10000,Math.floor(Number(q.get('page'))||1))),limit=20,offset=(page-1)*limit;
 if(!id)return json(res,{error:'Invalid anime'},400);
 let jikanPage=Math.floor(offset/100)+1,jikanOffset=offset%100;
 let [media,jikanResult,kitsuResult]=await Promise.all([
  animeRecord(id).catch(()=>null),
  jikan(`anime/${id}/episodes?page=${jikanPage}`).catch(error=>({error:error.message})),
  kitsuEpisodes(id,offset,limit).catch(error=>({error:error.message}))
 ]);
 let jd=jikanResult?.pagination?jikanResult:null,kd=kitsuResult?.response||null;
 if(!jd&&!kd&&(jikanResult?.error||kitsuResult?.error))return json(res,{error:'Jikan and the episode metadata fallback are temporarily unavailable.'},502);
 let known=media?animeEpisodeCount(media):null,rows=new Map();
 for(let row of kd?.data||[]){let episode=kitsuEpisode(row);if(Number.isInteger(episode.number)&&episode.number>0&&(!known||episode.number<=known))rows.set(episode.number,episode)}
 for(let row of (jd?.data||[]).slice(jikanOffset,jikanOffset+limit)){
  let episode=jikanEpisode(row);if(!Number.isInteger(episode.number)||episode.number<1||(known&&episode.number>known))continue;
  rows.set(episode.number,mergeEpisode(rows.get(episode.number),episode));
 }
 let episodes=[...rows.values()].sort((a,b)=>a.number-b.number),jikanTotal=Number(jd?.pagination?.items?.total)||0,kitsuTotal=Number(kd?.meta?.count)||0,total=Math.max(jikanTotal,kitsuTotal);
 if(known)total=total?Math.min(total,known):known;
 let hasNext=total?offset+limit<total:Boolean(jd?.pagination?.has_next_page||kd?.links?.next);
 return json(res,{episodes,page,perPage:limit,total:total||null,hasNext,sources:[...(jd?['jikan']:[]),...(kd?['kitsu']:[])]});
}
if(p==='/api/season'){let id=num(q.get('id')),season=q.get('season')==='0'?'0':num(q.get('season'));if(!id||season===null)return json(res,{error:'Invalid season'},400);let d=await tmdb(`tv/${id}/season/${season}`);return json(res,{episodes:(d.episodes||[]).map(e=>({number:e.episode_number,title:e.name,description:e.overview,still:e.still_path?'https://image.tmdb.org/t/p/w300'+e.still_path:null}))})}
if(p==='/api/play'){let id=num(q.get('id')),type=q.get('type'),ep=num(q.get('episode')||'1'),season=q.get('season')==='0'?'0':num(q.get('season')||'1'),lang=q.get('lang')==='dub'?'dub':'sub',provider=q.get('provider')==='second'?'second':'default',aniId=num(q.get('anilistId'));if(!id||!ep||!season||!['anime','movie','tv'].includes(type))return json(res,{error:'Invalid playback request'},400);let src=type==='anime'?`https://megaplay.buzz/stream/ani/${aniId||id}/${ep}/${provider==='second'?'dub':'sub'}`:type==='movie'?(provider==='second'?`https://embedwave.cc/embed/movie/${id}`:`https://cinesrc.st/embed/movie/${id}`):(provider==='second'?`https://embedwave.cc/embed/tv/${id}/${season}/${ep}`:`https://cinesrc.st/embed/tv/${id}?s=${season}&e=${ep}`);return json(res,{src,provider:type==='anime'?'MegaPlay':provider==='second'?'EmbedWave':'CineSrc'})}
return json(res,{error:'Not found'},404)
}catch(e){return json(res,{error:e.message||'Request failed'},e.message?.includes('configured')?503:502)}}
http.createServer((req,res)=>{let u=new URL(req.url,'http://localhost');if(/^\/(anime|ott)(\/|$)/.test(u.pathname)){let dest=u.pathname.replace(/^\/(anime|ott)/,'/browse');res.writeHead(302,{Location:dest+u.search});return res.end()}if(u.pathname.startsWith('/api/'))return api(req,res,u);let pathname=u.pathname==='/'?'/index.html':u.pathname;let target=path.resolve(root,'.'+pathname);if(!target.startsWith(root+path.sep)||!fs.existsSync(target)||!fs.statSync(target).isFile())target=path.join(root,'index.html');let ext=path.extname(target);res.writeHead(200,{'Content-Type':({'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.ttf':'font/ttf'}[ext]||'application/octet-stream'),'Content-Security-Policy':"default-src 'self' https: data: blob:; frame-src https://megaplay.buzz https://cinesrc.st https://embedwave.cc; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' https: data:; connect-src 'self'"});fs.createReadStream(target).pipe(res)}).listen(process.env.PORT||3000,'0.0.0.0',()=>console.log('MoscowTV listening on '+(process.env.PORT||3000)));
