# MoscowTV V2

A dark, orange-accented anime, movie and web-series catalog with a simple Watchlist, Continue Watching, optional account backup, and third-party iframe playback. Node 20+ is recommended.

**V2 intentionally omits Comments and Community for a later revision. Watchlist status types are also removed: saving is a single Add/Remove action.**

## Start

```sh
node start.js
```

The launcher installs production dependencies if needed and starts on port `3000`. Edit `PORT` in `start.js` to change it. There is no frontend build step. Set `TMDB_API_KEY` for a reliable movie/TV catalog; otherwise the server tries publicly shared keys from `freekeys`, which can fail or be rate-limited.

## Saving without an account

**Sign-in is not required.** Watching, Watchlist, progress, and all browsing features work as a guest.

- A persistent, HttpOnly visitor cookie associates the browser with its state in `data/states.json`.
- Watchlist and history save automatically. A one-time migration can import the previous shared `data/user.json` state.
- Registering or logging in merges the current device state into that account. Later changes are backed up automatically.
- Logging in after clearing browser data restores the account's Watchlist and history. Logging out copies the current state back to the device.
- Accounts use salted scrypt password hashes in `data/users.json`. Sessions use an HttpOnly, SameSite=Lax cookie and last 30 days, but the in-memory session map is cleared by a server restart.
- This is a small local JSON-backed app, not a production multi-tenant database.

## Simple Watchlist and Profile

- Details and player controls use a single **Add to Watchlist / In Watchlist** action. There are no Watchlist status labels, dropdowns, or status filters.
- The Watchlist page shows the saved-title grid and Continue Watching with vertical posters, orange progress, media labels, and elapsed time.
- Guest Profiles show real Watchlist/history counts and explain automatic guest saving.
- Signed-in Profiles add avatar colors, a bio, account-backup status, and logout.

## Discovery features

- The logo dropdown links Home, Schedule, Upcoming, Random, Advanced Filters, Profile, and genres.
- **Random** selects from real AniList/TMDB catalog results.
- **Schedule** uses real AniList airing schedules for the next seven days.
- **Upcoming** combines announced anime with TMDB upcoming movies.
- **Advanced Filters** supports media type, genre, year, sort, and anime status through real discovery queries.
- Browse retains its mixed catalog, three random genre shelves, rotating spotlights, search, and suggestions.

## Anime metadata and seasons

- Anime metadata comes from AniList by MyAnimeList ID; AniList IDs are retained for MegaPlay.
- Jikan is primary for episode metadata. Kitsu fills gaps or serves as fallback through exact `myanimelist/anime` mappings. Responses contain 20 real title/image/description rows per request with compact **Show more** pagination. Missing descriptions render nothing.
- Only genuine explicit season/part families are grouped. Attack on Titan's compatible TV entries share a selector; movies, OVAs, and specials are not pulled in.
- Naruto, Naruto: Shippuden, and Boruto are never merged into one another. Relations alone never trigger grouping.
- Anime films have no episode count badge, episode list, Previous/Next episode controls, or Auto Next. Episode `1` is used internally only because the MegaPlay URL requires it.
- Anime details use actual history for **Continue**, open the saved episode, and begin the visible episode list there.

## Playback and controls

- **Anime:** MegaPlay iframes with Sub/Dub selectors.
- **Movies/web series:** CineSrc is Stream 1; EmbedWave is Stream 2.
- The player retains the reference's two control rows: Auto Play/Auto Next/Auto Skip where applicable, report and Watchlist icons, then Light/Previous/Next. Community and comments are not present.
- MegaPlay progress events are accepted only from the expected origin and recognized payloads. CineSrc/EmbedWave have no verified title-wide progress integration here. History never invents elapsed time.
- MoscowTV does not proxy or extract direct streams and cannot reliably change provider-owned controls inside cross-origin iframes.

## Provider availability limitation

MegaPlay, CineSrc, and EmbedWave do not expose a reliable, documented catalog-wide API for checking whether every title is currently streamable. MoscowTV does not claim a streamable-only catalog filter or treat an iframe HTTP 200 response as proof of playback. Availability and provider controls vary by title/provider. Verify content rights and provider terms before deployment.

## Attribution

The interface and feature design take inspiration from Anipaca; its GPL-3.0 license is retained in `ANIPACA-LICENSE.txt`. MoscowTV uses a separate text-only wordmark and bundled Manrope fonts. Lucide's ISC/Feather MIT notices are retained in `LUCIDE-LICENSE.txt`.
