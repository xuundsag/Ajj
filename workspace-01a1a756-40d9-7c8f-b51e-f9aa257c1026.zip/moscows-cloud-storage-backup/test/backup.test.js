import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { backupFixture } from '../src/backup.js';

test('standby backup contains source, env, and meg.json', async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-backup-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const source = path.join(directory, 'primary');
  const destination = path.join(directory, 'standby');
  await mkdir(path.join(source, 'src'), { recursive: true });
  await writeFile(path.join(source, 'src', 'server.js'), 'latest source\n');
  await writeFile(path.join(source, '.env'), 'BOT_TOKEN=secret\n');
  await writeFile(path.join(source, 'package.json'), '{}\n');
  await writeFile(path.join(source, 'meg.json'), '{"version":1,"files":{}}\n');

  const saved = await backupFixture(source, destination, path.join(source, 'meg.json'));
  assert.deepEqual(saved, { version: 1, files: {} });
  assert.equal(await readFile(path.join(destination, 'src', 'server.js'), 'utf8'), 'latest source\n');
  assert.equal(await readFile(path.join(destination, '.env'), 'utf8'), 'BOT_TOKEN=secret\n');
  assert.equal(await readFile(path.join(destination, 'meg.json'), 'utf8'), '{"version":1,"files":{}}\n');
});
