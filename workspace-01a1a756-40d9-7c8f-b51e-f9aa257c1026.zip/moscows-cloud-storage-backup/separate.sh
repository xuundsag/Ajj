#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_SOURCE_DIR="${BACKUP_SOURCE_DIR:-$(cd "$SCRIPT_DIR/.." && pwd)/moscows-cloud-storage-backup}"
RESTORE_DIR="${RESTORE_DIR:-$BACKUP_SOURCE_DIR}"

for required in src/server.js package.json package-lock.json meg.json .env; do
  if [[ ! -f "$BACKUP_SOURCE_DIR/$required" ]]; then
    echo "Backup is missing $required: $BACKUP_SOURCE_DIR" >&2
    exit 1
  fi
done

# Optional: set RESTORE_DIR to fetch the standby files into another folder.
if [[ "$RESTORE_DIR" != "$BACKUP_SOURCE_DIR" ]]; then
  mkdir -p "$RESTORE_DIR"
  cp -a "$BACKUP_SOURCE_DIR/src" "$BACKUP_SOURCE_DIR/public" "$BACKUP_SOURCE_DIR/scripts" \
    "$BACKUP_SOURCE_DIR/test" "$RESTORE_DIR/"
  cp -a "$BACKUP_SOURCE_DIR/package.json" "$BACKUP_SOURCE_DIR/package-lock.json" \
    "$BACKUP_SOURCE_DIR/meg.json" "$BACKUP_SOURCE_DIR/.env" "$RESTORE_DIR/"
  cp -a "$BACKUP_SOURCE_DIR/README.md" "$BACKUP_SOURCE_DIR/BOT_SETUP.md" \
    "$BACKUP_SOURCE_DIR/.env.example" "$BACKUP_SOURCE_DIR/separate.sh" "$RESTORE_DIR/"
fi

cd "$RESTORE_DIR"
export BACKUP_ENABLED=false
if [[ ! -d node_modules || package-lock.json -nt node_modules/.package-lock.json ]]; then
  npm ci --no-audit --no-fund
fi

echo "Starting Moscow's Cloud Storage from $RESTORE_DIR"
exec npm start
