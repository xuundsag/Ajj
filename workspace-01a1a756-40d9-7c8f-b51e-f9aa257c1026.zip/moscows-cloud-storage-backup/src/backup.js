import { cp, copyFile, chmod, mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { config } from './config.js';

const directories = ['src', 'public', 'scripts', 'test'];
const files = ['package.json', 'package-lock.json', 'README.md', 'BOT_SETUP.md', '.env.example', '.env', 'separate.sh'];
let timer = null;
let active = null;

async function copyIfPresent(source, destination, recursive = false) {
  try {
    if (recursive) await cp(source, destination, { recursive: true, force: true });
    else await copyFile(source, destination);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

async function performBackup() {
  if (config.backupDir === config.root) throw new Error('BACKUP_DIR must be different from the project folder');
  await mkdir(config.backupDir, { recursive: true, mode: 0o700 });
  await Promise.all([
    ...directories.map((directory) => copyIfPresent(
      path.join(config.root, directory), path.join(config.backupDir, directory), true,
    )),
    ...files.map((file) => copyIfPresent(path.join(config.root, file), path.join(config.backupDir, file))),
    copyIfPresent(config.dataFile, path.join(config.backupDir, 'meg.json')),
  ]);
  await chmod(path.join(config.backupDir, '.env'), 0o600).catch((error) => {
    if (error.code !== 'ENOENT') throw error;
  });
  await writeFile(path.join(config.backupDir, '.backup-info.json'), JSON.stringify({
    updatedAt: new Date().toISOString(),
    source: config.root,
  }, null, 2) + '\n', { mode: 0o600 });
  console.log(`Backup updated: ${config.backupDir}`);
}

export function backupNow() {
  if (!config.backupEnabled) return Promise.resolve();
  if (active) return active;
  active = performBackup().finally(() => { active = null; });
  return active;
}

export async function startBackups() {
  if (!config.backupEnabled) return;
  try {
    await backupNow();
  } catch (error) {
    console.error(`Backup failed: ${error.message}`);
  }
  timer = setInterval(() => {
    backupNow().catch((error) => console.error(`Backup failed: ${error.message}`));
  }, config.backupInterval);
  timer.unref();
}

export async function stopBackups() {
  if (timer) clearInterval(timer);
  timer = null;
  if (active) await active;
}

// Exported for focused backup tests without changing process configuration.
export async function backupFixture(sourceRoot, destination, dataFile) {
  await mkdir(destination, { recursive: true });
  for (const file of ['.env', 'package.json']) {
    await copyIfPresent(path.join(sourceRoot, file), path.join(destination, file));
  }
  await copyIfPresent(path.join(sourceRoot, 'src'), path.join(destination, 'src'), true);
  await copyIfPresent(dataFile, path.join(destination, 'meg.json'));
  const saved = JSON.parse(await readFile(path.join(destination, 'meg.json'), 'utf8'));
  return saved;
}
