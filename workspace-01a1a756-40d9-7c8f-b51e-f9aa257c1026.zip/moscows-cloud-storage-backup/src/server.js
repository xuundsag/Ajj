import express from 'express';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { config, assertConfig } from './config.js';
import { JsonStore } from './store.js';
import { TelegramStorage } from './telegram.js';
import { UploadManager } from './uploads.js';
import { receiveFile } from './multipart.js';
import { FILE_KEY_PATTERN, isEncryptionKey } from './keys.js';
import { decryptStream } from './crypto.js';
import { ensureTelegramServer, stopTelegramServer } from './telegram-process.js';
import { backupNow, startBackups, stopBackups } from './backup.js';

assertConfig();
await ensureTelegramServer();
const store = new JsonStore(config.dataFile);
await store.init();
const telegram = new TelegramStorage();
const uploads = new UploadManager(store, telegram);
const app = express();
const asyncRoute = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

app.disable('x-powered-by');
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'X-Frame-Options': 'DENY',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  });
  next();
});
app.use(express.json({ limit: '32kb' }));

function recordForKey(value) {
  const fileKey = String(value || '').toUpperCase();
  if (!FILE_KEY_PATTERN.test(fileKey)) throw Object.assign(new Error('Invalid FILE_KEY'), { status: 400 });
  const record = store.get(fileKey);
  if (!record) throw Object.assign(new Error('File not found'), { status: 404 });
  return record;
}

async function* prepend(first, rest) {
  yield first;
  yield* rest;
}

app.get('/', (req, res) => res.redirect('/upload'));
app.get('/upload', (req, res) => res.sendFile(path.join(config.root, 'public', 'upload.html')));
app.get('/download', (req, res) => res.sendFile(path.join(config.root, 'public', 'download.html')));

app.get('/api', (req, res) => res.json({
  name: "Moscow's Cloud Storage",
  endpoints: { upload: '/api/upload', download: '/api/download' },
  maxFileSize: config.maxFileSize,
  downloadMode: 'server-decrypted-stream',
}));

app.post('/api/upload', asyncRoute(async (req, res) => {
  const file = await receiveFile(req, config.maxFileSize);
  res.json(await uploads.single(file));
}));

app.post('/api/download', asyncRoute(async (req, res) => {
  const record = recordForKey(req.body?.fileKey);
  const encKey = req.body?.encKey;
  if (record.encrypted && !isEncryptionKey(encKey)) {
    throw Object.assign(new Error('A valid ENC_KEY is required'), { status: 400 });
  }

  if (req.body?.metadata === true) {
    res.json({
      name: record.name,
      size: record.size,
      mimeType: record.mimeType,
      encrypted: record.encrypted,
      downloadUrl: '/api/download',
    });
    return;
  }

  const response = await telegram.openDownload(record.chunks[0]);
  let stream = Readable.fromWeb(response.body);
  if (record.encrypted) {
    const decrypted = decryptStream(stream, record.size, record.encryption, encKey);
    const first = await decrypted.next();
    if (first.done) throw new Error('Encrypted file is empty');
    stream = Readable.from(prepend(first.value, decrypted));
  }

  res.status(200);
  res.set({
    'Content-Type': record.mimeType,
    'Content-Length': String(record.size),
    'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(record.name)}`,
    'Cache-Control': 'private, no-store',
  });
  await pipeline(stream, res);
}));

app.get('/api/download', (req, res) => {
  res.set('Allow', 'POST');
  res.status(405).json({ error: 'Use POST with JSON fileKey and encKey' });
});

app.use(express.static(path.join(config.root, 'public'), { maxAge: '1h', index: false }));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((req, res) => res.status(404).sendFile(path.join(config.root, 'public', 'upload.html')));

app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  const status = error.status || (error instanceof SyntaxError ? 400 : 500);
  if (status >= 500) console.error(error);
  res.status(status).json({ error: status >= 500 ? 'Storage request failed' : error.message });
});

const server = app.listen(config.port, '0.0.0.0', () => {
  console.log(`Moscow's Cloud Storage listening on http://0.0.0.0:${config.port}`);
});
server.requestTimeout = 0;
server.headersTimeout = 60_000;
await startBackups();

let shuttingDown = false;
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    if (shuttingDown) return;
    shuttingDown = true;
    server.close(async () => {
      await stopBackups();
      await backupNow().catch((error) => console.error(`Final backup failed: ${error.message}`));
      await stopTelegramServer();
      process.exit(0);
    });
  });
}
