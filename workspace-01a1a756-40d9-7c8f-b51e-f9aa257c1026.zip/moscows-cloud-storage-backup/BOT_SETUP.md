# Telegram Bot and Local Bot API Setup Guide

## 1. What handles the traffic?

Your current project uses this upload path:

```text
Browser
  → Moscow's Cloud Storage Node app
  → temporary file on the Node server
  → local Telegram Bot API server
  → Telegram cloud
  → document appears in your storage channel
```

Therefore, **uploads do not go directly to Telegram**. Both your Node server and the local Bot API server handle the upload.

Every download now follows this path:

```text
Browser ← Node app (decrypts when required) ← local Bot API file server ← Telegram cloud/local file cache
```

| Operation | Node app load | Local Bot API load | Telegram's role |
|---|---|---|---|
| Upload | Full incoming bandwidth, temporary disk writes, optional encryption CPU, then outgoing bandwidth to Bot API | Receives the document and uploads it to Telegram | Stores the document in the channel |
| Unencrypted download | Streams the entire file to the browser | Serves the file bytes to Node | Provides the file if it is not already available locally |
| Encrypted download | Streams the entire file, verifies authentication tags, and decrypts 16 MiB segments | Serves encrypted bytes to Node | Provides the file if needed |

If Node and the local Bot API run on the same VPS, all of that load belongs to the same VPS even though they are separate processes. There are no browser redirects to Telegram and no CORS proxy setting.

## 2. Where are files stored?

### Telegram cloud

The uploaded document is sent to your channel and stored by Telegram. This is the persistent cloud copy represented by the Telegram `file_id`.

### Local Bot API server

The local Bot API is not just a configuration setting; it is a server process that handles Telegram traffic. It has working and temporary directories and can use local disk for its database and file cache, particularly for downloaded files. Do not assume that it uses zero disk.

Telegram documents that local mode supports uploads up to 2000 MB and downloads without a size limit. See the official [Telegram Bot API server documentation](https://github.com/tdlib/telegram-bot-api#usage).

### Moscow's Cloud Storage server

- `tmp/` contains temporary upload files, not permanent cloud storage.
- An unencrypted upload temporarily needs up to one file's worth of disk space.
- An encrypted upload temporarily has both the incoming and encrypted file, so it can need approximately **two times the file size**. Allow more than 4 GB of free temporary space for one maximum-size encrypted upload.
- Temporary files are removed when the Telegram request finishes. Concurrent uploads multiply disk requirements.
- `meg.json` stores metadata, Telegram paths, file IDs, and authentication tags. It does not contain the file contents or ENC_KEY.

**Practical answer:** Telegram provides the persistent cloud document, but your local API server still handles traffic and can consume disk. Your Node server also uses temporary disk during uploads.

## 3. Create the Telegram bot

1. Open [@BotFather](https://t.me/BotFather) in Telegram.
2. Send `/newbot`.
3. Enter a display name and a unique username ending in `bot`.
4. Copy the token. It looks like:

   ```text
   123456789:AAExampleTokenDoNotShare
   ```

5. Keep this token secret. Anyone with it can control the bot.

## 4. Prepare the storage channel

1. Create a private Telegram channel. A supergroup also works.
2. Add your new bot as an administrator.
3. Give it permission to **Post Messages**. Document posting is required.
4. Post a message in the channel.
5. Request bot updates using the hosted API:

   ```bash
   export BOT_TOKEN='123456789:YOUR_REAL_TOKEN'
   curl -s "https://api.telegram.org/bot${BOT_TOKEN}/getUpdates"
   ```

6. Find the channel in the JSON response and copy its `chat.id`. It can appear under `channel_post.chat.id` or `my_chat_member.chat.id`.

A channel ID normally looks like:

```text
-1001234567890
```

If the update list is empty, add/post again and repeat the request. If a webhook is configured, it can prevent updates from appearing in `getUpdates`.

## 5. Obtain API_ID and API_HASH

The local Bot API server requires Telegram application credentials in addition to the bot token.

1. Sign in at [my.telegram.org](https://my.telegram.org).
2. Open **API development tools**.
3. Create an application.
4. Copy its numeric `api_id` and its `api_hash`.

These are different credentials:

| Credential | Where it comes from | Used by |
|---|---|---|
| `BOT_TOKEN` | BotFather | Authenticating your bot |
| `TELEGRAM_API_ID` | my.telegram.org | Running the local Bot API server |
| `TELEGRAM_API_HASH` | my.telegram.org | Running the local Bot API server |

## 6. Build the local Bot API server on Ubuntu/Debian

The official project also provides a [build-instruction generator](https://tdlib.github.io/telegram-bot-api/build.html) for other operating systems.

```bash
sudo apt update
sudo apt install -y build-essential cmake git gperf libssl-dev zlib1g-dev

git clone --recursive https://github.com/tdlib/telegram-bot-api.git
cd telegram-bot-api
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_FLAGS_RELEASE="-O2 -DNDEBUG" ..
cmake --build . --parallel 2
```

**RAM control:** never use bare `--parallel` on a memory-limited machine. Use `--parallel 2` for roughly 16 GB RAM or `--parallel 1` when targeting roughly 8 GB. The automatic builder reads `TELEGRAM_BUILD_JOBS` and applies the same limit plus the GNU linker option `--no-keep-memory`. Job control is not a hard RAM quota.

Create writable data directories:

```bash
sudo mkdir -p /var/lib/telegram-bot-api /var/tmp/telegram-bot-api
sudo chown -R "$USER":"$USER" /var/lib/telegram-bot-api /var/tmp/telegram-bot-api
```

Start the server from the `build` directory:

```bash
export TELEGRAM_API_ID='123456'
export TELEGRAM_API_HASH='your_api_hash'

./telegram-bot-api \
  --local \
  --http-ip-address=127.0.0.1 \
  --http-port=8081 \
  --dir=/var/lib/telegram-bot-api \
  --temp-dir=/var/tmp/telegram-bot-api \
  --log=/var/lib/telegram-bot-api/server.log
```

For production, run this as a restricted system user with `systemd` so it restarts automatically. The official documentation lists additional command-line options.

## 7. Move the bot to the local server

Telegram recommends logging the bot out of the hosted Bot API before moving it to a local server:

```bash
curl -s "https://api.telegram.org/bot${BOT_TOKEN}/logOut"
```

Then verify the local server:

```bash
curl -s "http://127.0.0.1:8081/bot${BOT_TOKEN}/getMe"
```

A successful response contains `"ok":true` and your bot's information.

## 8. Configure Moscow's Cloud Storage

In the project directory:

```bash
cp .env.example .env
```

Edit `.env`:

```env
BOT_TOKEN=123456789:YOUR_REAL_TOKEN
TELEGRAM_CHAT_ID=-1001234567890
TELEGRAM_API_ID=123456
TELEGRAM_API_HASH=your_api_hash
TELEGRAM_API_BASE_URL=http://127.0.0.1:8081
TELEGRAM_AUTO_START=true
TELEGRAM_BUILD_JOBS=2
PORT=3000
BACKUP_ENABLED=true
BACKUP_DIR=../moscows-cloud-storage-backup
BACKUP_INTERVAL_MS=300000
```

Start the application:

```bash
npm install
npm start
```

If the local Bot API is unavailable, `npm start` automatically builds a missing binary and starts the server using the API ID/hash in `.env`. Set `TELEGRAM_AUTO_START=false` to disable this behavior. Set `TELEGRAM_BUILD_JOBS=1` before the first build on lower-RAM machines.

Open:

```text
http://localhost:3000/upload
```

Test with a small file first. The document should appear in your private Telegram channel, and `meg.json` should gain a FILE_KEY record.

## 9. Production network configuration

### Keep the Bot API private when possible

If Node and Bot API are on the same machine, keep Bot API bound to `127.0.0.1`. Do not expose port `8081` publicly without a TLS/authentication plan.

The Node server now downloads and decrypts files itself, so browsers never receive Bot API URLs. The Bot API can remain bound to `127.0.0.1` even for public website users. Only the Node website needs public HTTPS access; port `8081` should remain private.

### Reverse proxy upload settings

For Nginx in front of the Node app, allow the full upload and disable an unnecessary extra buffering layer:

```nginx
client_max_body_size 2g;
client_body_timeout 3600s;
proxy_request_buffering off;
proxy_read_timeout 3600s;
proxy_send_timeout 3600s;
```

### Capacity planning

- One maximum encrypted upload can require over 4 GB across the app's two temporary files, before Bot API disk/cache usage.
- Multiple simultaneous uploads multiply temporary disk and bandwidth usage.
- Downloads consume bandwidth twice on the same host's network path: Bot API to Node and Node to the browser. Loopback traffic is fast, but the public outbound bandwidth is still consumed.
- Server-side decryption adds CPU work; it is processed in 16 MiB segments rather than loading the entire file into RAM.
- Encryption adds CPU work, but the app processes only 16 MiB at a time rather than loading 2 GB into RAM.
- Add a queue or concurrency limit before offering large uploads to many users.

## 10. Standby backup and restore

While the primary app runs, it copies the latest source, `.env`, `meg.json`, scripts, package files, and documentation to `../moscows-cloud-storage-backup` immediately and every five minutes. Build directories, dependencies, caches, logs, and temporary uploads are excluded.

Stop the primary server, then start the standby with:

```bash
bash separate.sh
```

The script installs missing dependencies and runs `npm start`. Automatic Bot API startup also applies to the standby. To restore into a separate target folder:

```bash
RESTORE_DIR=/path/to/restored-server bash separate.sh
```

The backup includes plaintext `.env` credentials. Restrict access to both primary and backup folders.

The app limit is set to **2,000,000,000 bytes** to match Telegram's documented 2000 MB limit.
