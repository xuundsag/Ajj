const app=document.querySelector('#app'),search=document.querySelector('#search'),headerEl=document.querySelector('.header');
let items=[],spotlightItems=[],suggestions=[],genreRows={},activeGenres=[],genreQueue=[],continueItems=[],slide=0,detail=null,season=1,episode=1,provider='vidcore',searchTimer,lastProgressSent=0,savedKeys=new Set(),animeEpisodeLists={detail:null,watch:null},videoPlayer=null,playGeneration=0,lang='sub';
let pagedState={mode:'',endpointBase:'',page:1,hasMore:false,seen:new Set(),total:0};

const siteFooter=document.querySelector('footer');
function syncFooter(){let loading=app.firstElementChild?.classList.contains('loading');document.body.classList.toggle('route-ready',app.childElementCount>0&&!loading)}
new MutationObserver(syncFooter).observe(app,{childList:true});syncFooter();

let playerAssetsPromise=null;
function loadPlayerAssets(){
 if(window.videojs&&window.MegaPlayUI)return Promise.resolve();
 if(!playerAssetsPromise)playerAssetsPromise=(async()=>{
  for(let src of ['/vendor/video.min.js','/megaplay-controls.js?v=5.4.4'])await new Promise((resolve,reject)=>{
   let script=document.createElement('script');script.src=src;script.async=true;script.onload=resolve;
   script.onerror=()=>{script.remove();reject(Error('The player assets could not be loaded.'))};
   document.head.append(script);
  });
 })().catch(error=>{playerAssetsPromise=null;throw error});
 return playerAssetsPromise;
}

const DEFAULT_DOC_TITLE='kozuTV - Watch Free Anime, Movies & Series Online in HD Sub & Dub';
const OTT_PROVIDERS=['vidcore','embedwave','cinesrc','vidlink','vidsrc'];
const isFeature=x=>x?.type==='movie'||x?.isMovie||x?.format==='MOVIE';
const short=(s,n)=>{let t=String(s||'').replace(/\s+/g,' ').trim();return t.length>n?t.slice(0,n).replace(/\s+\S*$/,'')+'…':t};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const url=(type,id)=>`/browse/${type}/${id}`;
const responseJSON=async r=>{let text=await r.text(),d;try{d=JSON.parse(text)}catch{throw Error(r.ok?'The service returned an invalid response.':`Request failed (${r.status}).`)}if(!r.ok){let err=Error(d.error||'Request failed');if(d.availableLang)err.availableLang=d.availableLang;throw err}return d};
const get=async p=>responseJSON(await fetch(p));
const post=async(p,body)=>responseJSON(await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}));
const params=()=>new URLSearchParams(location.search);
const safeImage=s=>/^(?:https:\/\/|\/images\/|data:image\/svg\+xml)/i.test(s||'')?esc(s):'';

const catalogGenres=['Action','Adventure','Animation','Comedy','Crime','Documentary','Drama','Family','Fantasy','Horror','Mecha','Music','Mystery','Psychological','Romance','Sci-Fi','Slice of Life','Sports','Supernatural','Thriller'];
const spotlightPortraits={'anime:21':'/images/spotlight/anime-21.jpg','movie:1263337':'/images/spotlight/movie-1263337.jpg','anime:61607':'/images/spotlight/anime-61607.jpg','movie:1423191':'/images/spotlight/movie-1423191.jpg','tv:289517':'/images/spotlight/tv-289517.jpg','movie:1294189':'/images/spotlight/movie-1294189.jpg'};

function disposeVideo(){playGeneration++;if(videoPlayer){try{videoPlayer.dispose()}catch{}videoPlayer=null}}

function closeSearchBox(){
 document.querySelector('.searchbox')?.classList.remove('open');
 headerEl?.classList.remove('search-open');
}

function nav(path){
 disposeVideo();
 history.pushState({},'',path);
 let nextQ=new URLSearchParams(location.search).get('q')||'';
 search.value=nextQ;
 if(!nextQ)closeSearchBox();
 render();
 window.scrollTo(0,0);
}

function card(x){
 return `<article class="card" data-open="${esc(url(x.type,x.id))}"><div class="poster">${x.poster?`<img loading="lazy" src="${safeImage(x.poster)}" alt="${esc(x.title)}">`:''}${x.rating?`<span class="rating">${ico('star')}${esc(x.rating)}</span>`:''}</div><h3 title="${esc(x.title)}">${esc(x.title)}</h3><p>${esc(x.year||'New')} &nbsp;·&nbsp; ${x.type==='anime'?(x.isMovie?'Anime Movie':'Anime Series'):x.type==='tv'?'TV Series':'Movie'}</p></article>`;
}
function grid(data,idAttr=''){return data.length?`<div class="grid"${idAttr?` id="${idAttr}"`:''}>${data.map(card).join('')}</div>`:'<div class="empty">No titles found.</div>'}

function hero(data){
 let x=data[slide%data.length];if(!x)return '';
 let feature=isFeature(x),key=x.type+':'+x.id,saved=savedKeys.has(key);
 let watch=`/watch/${x.type}/${x.id}${feature?'':'?season=1&episode=1'}`;
 let art=safeImage(x.backdrop||x.poster);
 let mobileArt=safeImage(x.spotlightBanner||spotlightPortraits[key]||x.poster||x.backdrop);
 let genreSummary=Array.isArray(x.genres)&&x.genres.length?`<span>${esc(x.genres.slice(0,2).join(' · '))}</span>`:'';
 return `<section class="hero" data-hero-details="${url(x.type,x.id)}" role="link" tabindex="0" aria-label="View ${esc(x.title)} details"><div class="hero-image" style="background-image:url('${art}')"></div><img class="hero-image-mobile" src="${mobileArt}" alt="" fetchpriority="high" decoding="async"><div class="container hero-content"><div class="hero-copy"><h1>${esc(x.title)}</h1><div class="meta hero-meta"><span>${ico(x.type==='anime'?(feature?'film':'tv'):x.type==='tv'?'tv':'film')}${x.type==='anime'?(feature?'Anime Movie':'Anime'):x.type==='tv'?'Web Series':'Movie'}</span>${genreSummary}${x.year?`<span>${ico('calendar')}${esc(x.year)}</span>`:''}<span class="quality">HD</span>${x.rating?`<span>${ico('star')}${esc(x.rating)}</span>`:''}</div><p class="description">${esc(short(x.description||'',220))}</p><div class="hero-actions"><button class="btn hero-watch" data-open="${watch}">${ico('play')}<span>Start Watching${feature?'':' E1'}</span></button><button class="hero-save ${saved?'saved':''}" data-hero-save="${key}" aria-label="${saved?'Remove from':'Add to'} Watchlist" title="Watchlist">${ico('bookmark')}</button></div></div><div class="dots">${data.slice(0,6).map((_,i)=>`<button data-slide="${i}" class="${i===slide?'active':''}" aria-label="Spotlight ${i+1}"></button>`).join('')}</div></div></section>`;
}

async function catalog(isSearch=false){
 let p=params(),urlQ=(p.get('q')||'').trim();
 if(urlQ&&!search.value.trim())search.value=urlQ;
 let term=search.value.trim();
 if(term)isSearch=true;
 let genre=isSearch?null:p.get('genre');
 document.title=isSearch?`Search “${term}” — kozuTV`:genre?`${genre} — kozuTV`:DEFAULT_DOC_TITLE;
 app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let endpoint=isSearch?`/api/search-all?q=${encodeURIComponent(term)}&page=1`:genre?`/api/genre?name=${encodeURIComponent(genre)}&page=1`:'/api/browse';
  let [d,state]=await Promise.all([get(endpoint),get('/api/state')]);
  items=d.items||[];
  spotlightItems=!isSearch&&!genre?(d.spotlight?.length?d.spotlight.slice(0,6):items.filter(x=>x.poster&&x.title&&x.backdrop).slice(0,6)):[];
  suggestions=isSearch||genre?[]:d.suggestions||[];
  savedKeys=new Set((state.watchlist||[]).map(x=>x.type+':'+x.id));
  continueItems=isSearch||genre?[]:(state.history||[]).slice(0,8);
  genreRows={};
  genreQueue=[...catalogGenres].sort(()=>Math.random()-.5);
  activeGenres=genreQueue.splice(0,3);
  slide=0;
  let filtered=isSearch||Boolean(genre);
  if(filtered){
   pagedState={
    mode:isSearch?'search':'genre',
    endpointBase:isSearch?`/api/search-all?q=${encodeURIComponent(term)}`:`/api/genre?name=${encodeURIComponent(genre)}`,
    page:1,
    hasMore:Boolean(d.hasMore),
    seen:new Set(items.map(x=>`${x.type}:${x.id}`)),
    total:Number(d.totalResults)||items.length
   };
  }else{
   pagedState={mode:'',endpointBase:'',page:1,hasMore:false,seen:new Set(),total:0};
  }
  drawCatalog(filtered,genre?genre:term,Boolean(genre));
  if(!filtered)loadGenreRows();
 }catch(e){
  app.innerHTML=`<div class="container content"><div class="empty"><h2>Catalog unavailable</h2><p class="error">${esc(e.message)}</p><button class="btn" data-retry>Try again</button></div></div>`;
 }
}

const genreIcons={Action:'swords',Adventure:'compass',Animation:'sparkles',Comedy:'laugh',Crime:'shield',Documentary:'film',Drama:'theater',Family:'users',Fantasy:'wand',Horror:'ghost',Mecha:'cpu',Music:'music',Mystery:'search',Psychological:'brain',Romance:'heart','Sci-Fi':'rocket','Slice of Life':'coffee',Sports:'trophy',Supernatural:'sparkles',Thriller:'zap'};
function sectionTitle(title,icon='sparkles',tag='h2'){return `<${tag} class="section-title"><span class="section-icon">${ico(icon)}</span><span>${esc(title)}</span></${tag}>`}

async function loadGenreRows(names=activeGenres){
 names=[...names];
 await Promise.all(names.map(async name=>{
  try{
   let d=await get('/api/genre?home=1&name='+encodeURIComponent(name));
   if(location.pathname!=='/browse'||params().has('genre')||params().has('q')||search.value.trim())return;
   genreRows[name]=d.items||[];
   let slot=document.querySelector('[data-genre="'+name+'"]');
   if(slot)slot.innerHTML=genreRows[name].length?sectionTitle(name,genreIcons[name])+grid(genreRows[name]):'';
  }catch{}
 }));
}

const carousel=setInterval(()=>{
 if(location.pathname!=='/browse'||params().has('genre')||params().has('q')||search.value.trim()||document.hidden||!spotlightItems.length)return;
 slide=(slide+1)%spotlightItems.length;
 let current=document.querySelector('.hero');
 if(current)current.outerHTML=hero(spotlightItems);
},6500);

function drawCatalog(filtered=false,term='',isGenre=false){
 let data=items.filter(x=>x.poster&&x.title);
 let continueSection=!filtered&&continueItems.length?`<section class="continue-section home-continue">${sectionTitle('Continue Watching','history')}${continueGrid(continueItems)}</section>`:'';
 let moreCategories=!filtered&&genreQueue.length?`<div class="category-more"><button class="category-more-button" data-more-categories aria-label="Show more categories">${ico('plus')}<span>Show more</span></button></div>`:'';
 let moreResults=filtered&&pagedState.hasMore?`<div class="category-more"><button class="category-more-button" data-more-results aria-label="Show more titles">${ico('plus')}<span>Show more</span></button></div>`:'';
 let headingIcon=filtered?(isGenre?(genreIcons[term]||'sparkles'):'search'):'flame';
 let headingText=filtered?(isGenre?term:`Results for “${term}”`):'Trending Now';
 let headingTag=filtered?'h1':'h2';
 app.innerHTML=`${!filtered&&spotlightItems.length?hero(spotlightItems):''}<div class="container content">${continueSection}${sectionTitle(headingText,headingIcon,headingTag)}${grid(data,filtered?'paged-grid':'')}${!filtered&&suggestions.length?`<section class="suggestions">${sectionTitle('Suggested for you','sparkles')}${grid(suggestions)}</section>`:''}${!filtered?activeGenres.map(name=>`<section class="genre-section" data-genre="${name}"></section>`).join(''):''}${moreCategories}${moreResults}</div>`;
}

const icons={
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
 bookmark:'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
 autoplay:'<path d="M21 12a9 9 0 1 1-2.64-6.36L21 8"/><path d="M21 3v5h-5"/>',
 autonext:'<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
 autoskip:'<path d="m3 5 8 7-8 7z"/><path d="m13 5 8 7-8 7z"/>',
 light:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.66 6.34l1.41-1.41"/>',
 prev:'<path d="M19 20 9 12l10-8z"/><path d="M5 19V5"/>',
 next:'<path d="m5 4 10 8-10 8z"/><path d="M19 5v14"/>',
 expand:'<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 check:'<path d="m5 12 4 4L19 6"/>',
 'bookmark-plus':'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/><path d="M12 7v6M9 10h6"/>',
 'bookmark-check':'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/><path d="m9 10 2 2 4-4"/>',
 star:'<path d="m12 2 3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01z"/>',
 calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
 tv:'<rect x="2" y="7" width="20" height="13" rx="2"/><path d="m17 2-5 5-5-5"/>',
 film:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4"/>',
 play:'<path d="m8 5 11 7-11 7z"/>',
 flame:'<path d="M12 22c4.4 0 8-3.2 8-7.5 0-2.2-1.1-4.2-3-6.5.1 2-1 3.5-2.2 4.2.3-3.8-1.7-7.2-5.3-10.2.2 3.5-1.8 5.7-3.3 7.6C5.1 11.1 4 12.8 4 14.5 4 18.8 7.6 22 12 22Z"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>',
 compass:'<circle cx="12" cy="12" r="9"/><path d="m16 8-2.5 5.5L8 16l2.5-5.5Z"/>',
 sparkles:'<path d="m12 3 1.3 3.7L17 8l-3.7 1.3L12 13l-1.3-3.7L7 8l3.7-1.3ZM5 14l.9 2.1L8 17l-2.1.9L5 20l-.9-2.1L2 17l2.1-.9ZM18 14l.9 2.1L21 17l-2.1.9L18 20l-.9-2.1L15 17l2.1-.9Z"/>',
 laugh:'<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 3 4 3 4-3 4-3ZM9 9h.01M15 9h.01"/>',
 theater:'<path d="M4 4h16v6a8 8 0 0 1-16 0ZM8 9h.01M16 9h.01M8 13c2 1.5 6 1.5 8 0M12 18v3M8 21h8"/>',
 wand:'<path d="m15 4 5 5L8 21H3v-5ZM14 6l4 4M6 3v3M4.5 4.5h3M20 15v4M18 17h4"/>',
 ghost:'<path d="M5 21V10a7 7 0 0 1 14 0v11l-2.5-2-2.3 2-2.2-2-2.2 2-2.3-2ZM9 10h.01M15 10h.01"/>',
 zap:'<path d="M13 2 4 14h7l-1 8 9-12h-7Z"/>',
 swords:'<path d="m14.5 4.5 5-1-1 5L8 19l-3 1 1-3ZM14 9l3 3M4 4l16 16M4 9l-1-5 5 1 11 11"/>',
 shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
 users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
 cpu:'<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
 music:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
 brain:'<path d="M12 5a3 3 0 1 0-6 .1 4 4 0 0 0-2.5 5.8 4 4 0 0 0 .5 6.6A4 4 0 1 0 12 18ZM12 5a3 3 0 1 1 6 .1 4 4 0 0 1 2.5 5.8 4 4 0 0 1-.5 6.6A4 4 0 1 1 12 18ZM12 5v13"/>',
 rocket:'<path d="M14 4c3-3 7-2 7-2s1 4-2 7l-7 7-5-5Z"/><path d="m7 11-4 1 3 3M12 16l-1 4 3-3"/><circle cx="16" cy="8" r="1"/><path d="M7 17c-2 1-3 3-3 5 2 0 4-1 5-3"/>',
 coffee:'<path d="M17 8h1a4 4 0 1 1 0 8h-1M3 8h14v7a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4ZM6 2v2M10 2v2M14 2v2"/>',
 trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0ZM7 6H4v2a4 4 0 0 0 4 4M17 6h3v2a4 4 0 0 1-4 4"/>',
 history:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l3 2"/>',
 sliders:'<path d="M4 6h10M18 6h2M4 12h3M11 12h9M4 18h8M16 18h4"/><circle cx="16" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="14" cy="18" r="2"/>',
 shuffle:'<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 episodes:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 9h8M8 13h5"/>',
 home:'<path d="m3 11 9-8 9 8v9a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>'
};
function ico(n,extra=''){return `<svg class="ui-icon ${extra}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${icons[n]||''}</svg>`}

function animeSeasonSelect(d,x,mode){if(!d.seasons||d.seasons.length<2)return '';let id=mode==='detail'?'detail-anime-season':'anime-season';return `<select class="season-select" id="${id}" aria-label="Anime season">${d.seasons.map(s=>`<option value="${s.id}" ${s.id===x.id?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`}
function animeEpisodeRow(x,id,active){
 let art=x.still||detail?.item.backdrop||detail?.item.poster;
 return `<button class="episode-row ${x.number===active?'selected':''}" data-open="/watch/anime/${id}?episode=${x.number}&lang=${lang}">${art?`<img loading="lazy" src="${safeImage(art)}" alt="">`:''}<span><strong>${x.number}. ${esc(x.title||`Episode ${x.number}`)}</strong>${x.description?`<small>${esc(short(x.description,190))}</small>`:''}</span></button>`;
}
function renderAnimeEpisodes(mode){
 let state=animeEpisodeLists[mode],container=document.querySelector(`#${mode}-anime-episodes`);if(!state||!container)return;
 let pages=[...state.pages.keys()].sort((a,b)=>a-b),episodes=new Map();
 for(let page of pages)for(let x of state.pages.get(page).episodes||[])if(!state.startFrom||x.number>=state.startFrom)episodes.set(x.number,x);
 let last=pages.at(-1)||1,more=state.pages.get(last)?.hasNext,button=(page,label)=>`<div class="anime-pagination"><button class="btn secondary" data-anime-page="${page}" data-anime-mode="${mode}">${label}</button></div>`;
 container.innerHTML=state.error?'<div class="empty">Episodes are unavailable right now.</div>':`<div class="episode-detail-list anime-episode-list">${[...episodes.values()].sort((a,b)=>a.number-b.number).map(x=>animeEpisodeRow(x,state.id,state.active)).join('')||'<div class="empty">No episodes listed.</div>'}</div>${more?button(last+1,'Show more'):''}`;
}
async function loadAnimeEpisodes(id,mode,page=1,active=0,reset=false,startFrom=0){
 let container=document.querySelector(`#${mode}-anime-episodes`);if(!container)return;let state=animeEpisodeLists[mode];
 if(reset||!state||state.id!==id){state={id,pages:new Map(),active,error:'',loading:false,startFrom};animeEpisodeLists[mode]=state;container.innerHTML='<div class="loading">Loading episodes…</div>'}
 if(state.loading)return;state.loading=true;state.error='';let clicked=container.querySelector(`[data-anime-page="${page}"]`);if(clicked){clicked.disabled=true;clicked.innerHTML='<span class="button-loader" aria-label="Loading"></span>';clicked.classList.add('is-loading')}
 try{let d=await get(`/api/anime-episodes?id=${id}&page=${page}`);if(animeEpisodeLists[mode]!==state)return;state.pages.set(page,d);state.active=active||state.active}
 catch(e){state.error=e.message;if(reset)state.pages.clear()}
 finally{state.loading=false;if(animeEpisodeLists[mode]===state)renderAnimeEpisodes(mode)}
}

function watchlistButton(){return `<button class="btn secondary" data-save>${ico('plus')}<span class="desktop-action">Add to Watchlist</span><span class="mobile-action">Add</span></button>`}

function episodeTargets(){
 if(!detail||isFeature(detail.item))return {prev:null,next:null};let x=detail.item;
 if(x.type==='anime'){
  let seasons=Array.isArray(detail.seasons)?detail.seasons:[],index=seasons.findIndex(s=>String(s.id)===String(x.id)),count=Math.max(1,Number(x.episodes)||1),own=n=>({type:'anime',id:x.id,season:1,episode:n});
  return {prev:episode>1?own(episode-1):index>0?{type:'anime',id:seasons[index-1].id,season:1,episode:Math.max(1,Number(seasons[index-1].episodes)||1)}:null,next:episode<count?own(episode+1):index>=0&&seasons[index+1]?{type:'anime',id:seasons[index+1].id,season:1,episode:1}:null};
 }
 let seasons=(detail.seasons||[]).filter(s=>Number(s.episodes)>0).sort((a,b)=>a.number-b.number),index=seasons.findIndex(s=>Number(s.number)===Number(season)),current=seasons[index],count=Math.max(1,Number(current?.episodes)||1),own=n=>({type:'tv',id:x.id,season,episode:n});
 return {prev:episode>1?own(episode-1):index>0?{type:'tv',id:x.id,season:seasons[index-1].number,episode:Number(seasons[index-1].episodes)}:null,next:episode<count?own(episode+1):index>=0&&seasons[index+1]?{type:'tv',id:x.id,season:seasons[index+1].number,episode:1}:null};
}

function timeAgo(timestamp){let seconds=Math.round((Number(timestamp)-Date.now())/1000),abs=Math.abs(seconds),unit=abs>=86400?'day':abs>=3600?'hour':abs>=60?'minute':'second',value=Math.round(seconds/(unit==='day'?86400:unit==='hour'?3600:unit==='minute'?60:1)),r=new Intl.RelativeTimeFormat('en',{numeric:'auto'});return r.format(value,unit)}

async function details(type,id){
 app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let d=await get(`/api/detail?type=${type}&id=${id}`);detail=d;let x=d.item,resumeEpisode=0,resumeSeason=1,state=await get('/api/state');savedKeys=new Set((state.watchlist||[]).map(i=>i.type+':'+i.id));
  if(type==='anime'&&!x.upcoming){let seen=state.history.find(h=>h.type==='anime'&&h.id===x.id);if(seen){resumeEpisode=Math.max(1,Number(seen.episode)||1);if(x.episodes)resumeEpisode=Math.min(resumeEpisode,x.episodes)}}
  else if(type==='tv'&&!x.upcoming){let seen=state.history.find(h=>h.type==='tv'&&h.id===x.id);if(seen){resumeEpisode=Math.max(1,Number(seen.episode)||1);resumeSeason=Math.max(1,Number(seen.season)||1)}}
  document.title=`${x.title} — kozuTV`;
  let watch=type==='tv'&&resumeEpisode?`/watch/tv/${id}?season=${resumeSeason}&episode=${resumeEpisode}`:`/watch/${type}/${id}${resumeEpisode?`?episode=${resumeEpisode}`:''}`;
  let watchLabel=resumeEpisode?'Continue':'Watch Now';
  let showEpisodes=!x.upcoming&&!isFeature(x),actions=`<div class="actions">${!x.upcoming?`<button class="btn" data-open="${watch}">${ico('play')}<span>${watchLabel}</span></button>`:''}${watchlistButton()}</div>`;
  app.innerHTML=`<div class="container content detail"><div class="detail-layout"><img class="detail-poster" src="${safeImage(x.poster)}" alt="${esc(x.title)}"><div class="detail-heading"><h1>${esc(x.title)}</h1><div class="meta"><span>${ico('star')}${esc(x.rating||'N/A')}</span><span class="quality">HD</span>${x.upcoming?'<span class="upcoming-badge">Upcoming</span>':showEpisodes&&x.episodes?`<span>${x.episodes} episodes</span>`:''}</div></div><div class="detail-body"><div class="description detail-description" data-description-toggle role="button" tabindex="0" aria-expanded="false">${esc(x.description||'No description available.')}</div><div class="chips">${(x.genres||[]).map(g=>`<span class="chip">${esc(g)}</span>`).join('')}</div>${actions}</div></div>${type==='anime'&&showEpisodes?`<section class="season-section">${sectionTitle(d.seasons.length>1?'Seasons & Episodes':'Episodes','episodes')}${animeSeasonSelect(d,x,'detail')}<div id="detail-anime-episodes" class="anime-episodes"><div class="loading">Loading…</div></div></section>`:''}${type==='tv'&&!x.upcoming?`<section class="season-section">${sectionTitle('Seasons & Episodes','episodes')}<select class="season-select" id="detail-tv-season">${d.seasons.map(s=>`<option value="${s.number}">${esc(s.name)}</option>`).join('')}</select><div id="detail-episodes" class="episode-detail-list">Loading…</div></section>`:''}</div>`;
  updateSave(state);if(type==='tv'&&!x.upcoming&&d.seasons?.length)loadDetailEpisodes(id,d.seasons[0].number);if(type==='anime'&&showEpisodes)loadAnimeEpisodes(id,'detail',resumeEpisode?Math.floor((resumeEpisode-1)/20)+1:1,resumeEpisode,true,resumeEpisode);
 }catch(e){failure(e)}
}

async function loadDetailEpisodes(id,num){let box=document.querySelector('#detail-episodes');if(!box)return;box.innerHTML='<div class="loading">Loading episodes…</div>';try{let d=await get(`/api/season?id=${id}&season=${num}`);box.innerHTML=d.episodes.map(e=>`<button class="episode-row" data-open="/watch/tv/${id}?season=${num}&episode=${e.number}">${e.still?`<img loading="lazy" src="${safeImage(e.still)}" alt="">`:''}<span><strong>${e.number}. ${esc(e.title)}</strong><small>${esc((e.description||'').slice(0,160))}</small></span></button>`).join('')||'No episode information available.'}catch{box.textContent='Episodes unavailable right now.'}}
async function loadWatchEpisodes(id,number,active){let box=document.querySelector('#watch-episodes');if(!box)return;try{let d=await get(`/api/season?id=${id}&season=${number}`);box.innerHTML=d.episodes.map(e=>`<button class="episode-row ${e.number===active?'selected':''}" data-open="/watch/tv/${id}?season=${number}&episode=${e.number}">${e.still?`<img loading="lazy" src="${safeImage(e.still)}" alt="">`:''}<span><strong>${e.number}. ${esc(e.title)}</strong><small>${esc((e.description||'').slice(0,160))}</small></span></button>`).join('')||'No episodes available.'}catch{box.textContent='Episodes unavailable right now.'}}

async function updateSave(state=null){
 if(!detail)return;let d=state||await get('/api/state'),saved=d.watchlist.some(i=>i.id===detail.item.id&&i.type===detail.item.type),button=document.querySelector('.detail [data-save]');
 if(button)button.innerHTML=saved?`${ico('check')}<span class="desktop-action">In Watchlist</span><span class="mobile-action">Added</span>`:`${ico('plus')}<span class="desktop-action">Add to Watchlist</span><span class="mobile-action">Add</span>`;
}

function watchUrl(){
 let x=detail?.item;
 if(x.type==='anime')return `/watch/anime/${x.id}?episode=${episode}&lang=${lang}`;
 if(x.type==='movie')return `/watch/movie/${x.id}${provider&&provider!=='vidcore'?`?provider=${provider}`:''}`;
 return `/watch/tv/${x.id}?season=${season}&episode=${episode}${provider&&provider!=='vidcore'?`&provider=${provider}`:''}`;
}

function changeEpisode(step){
 let target=episodeTargets()[step>0?'next':'prev'];if(!target)return;
 if(String(target.id)!==String(detail.item.id)){
  nav(target.type==='anime'?`/watch/anime/${target.id}?episode=${target.episode}&lang=${lang}`:`/watch/${target.type}/${target.id}?season=${target.season}&episode=${target.episode}`);
  return;
 }
 season=target.season;episode=target.episode;nav(watchUrl());
}

async function watch(type,id){
 app.innerHTML='<div class="loading">Preparing your player…</div>';
 try{
  let d=await get(`/api/detail?type=${type}&id=${id}`);detail=d;let x=d.item;if(x.upcoming)throw Error('This title has not been released yet.');
  let p=params();
  season=p.has('season')?Math.max(0,Number(p.get('season'))||0):1;
  episode=Math.max(1,Number(p.get('episode')||p.get('ep'))||1);
  if(type==='anime'){if(x.isMovie)episode=1;else if(x.episodes)episode=Math.min(episode,x.episodes)}
  else if(type==='tv'){let current=d.seasons.find(s=>Number(s.number)===Number(season));if(current?.episodes)episode=Math.min(episode,Number(current.episodes))}
  let savedAnimeLang=localStorage.getItem('moscowtv-anime-lang');
  lang=p.has('lang')?(p.get('lang')==='dub'?'dub':'sub'):(savedAnimeLang==='dub'&&x.dub!==false?'dub':'sub');
  let requestedProvider=p.get('provider')||localStorage.getItem('moscowtv-server-pref')||'vidcore';
  provider=type==='anime'?'megaplay':(OTT_PROVIDERS.includes(requestedProvider)?requestedProvider:'vidcore');
  document.title=`Watch ${x.title} — kozuTV`;
  app.innerHTML=`<div class="container content"><div class="player-wrap"><h1 class="watch-title" id="watch-title">${esc(x.title)}</h1><div class="player" id="player"><div class="loading">Loading player…</div></div>${!isFeature(x)?`${sectionTitle('Episodes','episodes')}${type==='tv'?`<select class="season-select" id="season">${d.seasons.map(s=>`<option value="${s.number}" ${s.number===season?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`:''}${type==='anime'?animeSeasonSelect(d,x,'watch'):''}${type==='tv'?`<div id="watch-episodes" class="episode-detail-list"><div class="loading">Loading episodes…</div></div>`:`<div id="watch-anime-episodes" class="anime-episodes"><div class="loading">Loading episodes…</div></div>`}`:''}</div></div>`;
  let state=await get('/api/state');await updateSave(state);
  if(type==='tv')loadWatchEpisodes(id,season,episode);
  else if(type==='anime'&&!x.isMovie)loadAnimeEpisodes(id,'watch',Math.floor((episode-1)/20)+1,episode,true);
  await play(x,state);
 }catch(e){failure(e)}
}

function showPlayerError(error){let container=document.querySelector('#player');if(!container)return failure(error);container.innerHTML=`<div class="empty player-error"><strong>Playback unavailable</strong><span>${esc(error.message||'The stream could not be loaded.')}</span><button class="btn" data-retry>Try again</button></div>`}

async function play(x,state=null,tried=[],retriedLang=false){
 disposeVideo();let generation=playGeneration;
 try{
  let statePromise=state?Promise.resolve(state):get('/api/state');
  let mediaPromise=get(`/api/play?type=${x.type}&id=${x.id}&episode=${episode}&season=${season}&lang=${lang}&provider=${provider}&anilistId=${x.anilistId||''}`);
  let [,resolvedState,d]=await Promise.all([loadPlayerAssets(),statePromise,mediaPromise]);
  state=resolvedState;if(generation!==playGeneration)return;
  let saved=state.history.find(h=>h.type===x.type&&h.id===x.id&&h.episode===episode&&h.season===season);
  let resumeAt=saved?.currentTime>15&&saved?.duration-saved?.currentTime>20?Math.max(0,Number(saved.currentTime)+.25):0;
  let saveData=Boolean(navigator.connection?.saveData),autoplay=!saveData&&localStorage.getItem('moscowtv-autoplay')!=='false';
  let container=document.querySelector('#player');if(!container)return;
  container.dataset.provider=d.provider;container.dataset.server=d.server||'';
  container.innerHTML='<video id="moscowtv-video" class="video-js vjs-default-skin vjs-big-play-centered" playsinline webkit-playsinline disableremoteplayback></video>';
  let player=videojs('moscowtv-video',{controls:false,preload:saveData?'none':'auto',playbackRates:[.5,.75,1,1.25,1.5,2],html5:{vhs:{overrideNative:true,useBandwidthFromLocalStorage:false,useNetworkInformationApi:true,limitRenditionByPlayerDimensions:false,useDevicePixelRatio:false,bandwidth:saveData?500000:16000000,enableLowInitialPlaylist:false,smoothQualityChange:true,goalBufferLength:20,maxGoalBufferLength:30,backBufferLength:15,maxBufferLowWaterLine:16,bufferHighWaterLine:20},nativeAudioTracks:false,nativeTextTracks:false}});
  videoPlayer=player;
  try{player.tech({}).el().setAttribute('disableremoteplayback','')}catch{}
  player.src({src:d.src,type:d.type||'application/x-mpegURL'});
  let save=(current=0,duration=0)=>post('/api/history',{...x,episode,season,currentTime:current,duration}).catch(()=>{});
  let targets=episodeTargets();
  let ui=MegaPlayUI.create(player,{
   item:x,
   data:d,
   lang,
   server:d.sourceKey||provider,
   autoplay,
   hasPrevEpisode:Boolean(targets.prev),
   hasNextEpisode:Boolean(targets.next),
   onPrevEpisode:()=>changeEpisode(-1),
   onNextEpisode:()=>changeEpisode(1),
   onAudioChange:value=>{if(value===lang)return;save(player.currentTime(),player.duration());lang=value;nav(watchUrl())},
   onServerChange:value=>{save(player.currentTime(),player.duration());provider=value;nav(watchUrl())}
  });
  let attempted=new Set([...tried,provider,d.sourceKey].filter(Boolean));
  player.one('canplay',()=>{if(resumeAt>0&&player.duration()>resumeAt+10)player.currentTime(resumeAt)});
  player.one('playing',()=>save(player.currentTime(),player.duration()));
  player.on('timeupdate',()=>{
   let current=player.currentTime(),duration=player.duration();
   if(localStorage.getItem('moscowtv-autoskip')==='true')for(let range of [d.intro,d.outro]){let start=Number(range?.start),end=Number(range?.end);if(start>=0&&end>start&&current>=start&&current<end){player.currentTime(end);break}}
   if(Number.isFinite(duration)&&duration>0&&Date.now()-lastProgressSent>5000){lastProgressSent=Date.now();save(current,duration)}
  });
  player.on('ended',()=>{save(player.duration(),player.duration());if(localStorage.getItem('moscowtv-autonext')!=='false')changeEpisode(1)});
  player.on('error',()=>{
   if(generation!==playGeneration)return;
   let error=player.error(),next=x.type!=='anime'?OTT_PROVIDERS.find(value=>!attempted.has(value)):null;
   if(next){provider=next;play(x,state,[...attempted]);return}
   disposeVideo();showPlayerError(Error(error?.message||'The stream could not be loaded.'));
  });
  if(autoplay)player.play().catch(()=>ui?.onAutoplayBlocked?.());
 }catch(e){
  if(generation!==playGeneration)return;
  if(x.type==='anime'&&!retriedLang&&e.availableLang){
   lang=e.availableLang;
   try{localStorage.setItem('moscowtv-anime-lang',lang)}catch{}
   return play(x,state,tried,true);
  }
  disposeVideo();showPlayerError(e);
 }
}

function failure(e){app.innerHTML=`<div class="container content"><div class="empty"><h2>Something went wrong</h2><p class="error">${esc(e.message)}</p><button class="btn" data-retry>Try again</button></div></div>`}
function clock(v){let n=Math.max(0,Math.floor(Number(v)||0));return `${Math.floor(n/3600)?String(Math.floor(n/3600))+':':''}${String(Math.floor(n/60)%60).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`}
function continueGrid(data){return `<div class="continue-grid">${data.map(x=>`<article class="continue-card" data-open="/watch/${x.type}/${x.id}?episode=${x.episode}&season=${x.season}"><div class="continue-image">${x.poster?`<img loading="lazy" src="${safeImage(x.poster)}" alt="${esc(x.title)}">`:''}</div><div class="continue-foot"><div class="continue-progress" style="width:${x.duration?Math.min(100,100*x.currentTime/x.duration):0}%"></div><span>${isFeature(x)?'MOVIE':x.type==='tv'?`S${x.season} E${x.episode}`:`EP ${x.episode}`}</span><span>${x.duration?clock(x.currentTime):'00:00'}</span></div><h3>${esc(x.title)}</h3></article>`).join('')}</div>`}

async function watchlist(){
 app.innerHTML='<div class="loading">Loading…</div>';
 try{
  let d=await get('/api/state'),convert=x=>({...x,year:'Saved',rating:null});savedKeys=new Set((d.watchlist||[]).map(x=>x.type+':'+x.id));document.title='Watchlist — kozuTV';
  app.innerHTML=`<div class="container content watchlist-page">${sectionTitle('Watchlist','bookmark','h1')}${grid(d.watchlist.map(convert))}<div class="continue-section">${sectionTitle('Continue Watching','history')}${d.history.length?continueGrid(d.history):grid([])}</div></div>`;
 }catch(e){failure(e)}
}

async function schedulePage(){
 app.innerHTML='<div class="loading">Loading…</div>';document.title='Anime Schedule — kozuTV';
 try{let d=await get('/api/schedule'),groups=new Map();for(let entry of d.entries){let date=new Date(entry.airingAt*1000),key=date.toLocaleDateString('en',{weekday:'long',month:'long',day:'numeric'});if(!groups.has(key))groups.set(key,[]);groups.get(key).push(entry)}app.innerHTML=`<div class="container content">${sectionTitle('Anime Schedule','clock','h1')}${groups.size?[...groups].map(([day,entries])=>`<section class="schedule-day"><h2>${day}</h2>${entries.map(({item,episode,airingAt})=>`<article class="schedule-row" data-open="${url(item.type,item.id)}"><img src="${safeImage(item.poster)}" alt=""><div><strong>${esc(item.title)}</strong><span>Episode ${episode} · ${new Date(airingAt*1000).toLocaleTimeString('en',{hour:'numeric',minute:'2-digit'})}</span></div><b>${timeAgo(airingAt*1000)}</b></article>`).join('')}</section>`).join(''):'<div class="empty">No scheduled episodes.</div>'}</div>`}catch(e){failure(e)}
}

const option=(value,label,current)=>`<option value="${value}" ${value===current?'selected':''}>${label}</option>`;
async function filtersPage(){
 app.innerHTML='<div class="loading">Loading advanced filters…</div>';document.title='Advanced Filters — kozuTV';
 let p=params(),values={type:p.get('type')||'all',genre:p.get('genre')||'',year:p.get('year')||'',sort:p.get('sort')||'popularity',status:p.get('status')||''};
 let baseQuery=new URLSearchParams();
 for(let [k,v] of Object.entries(values))if(v)baseQuery.set(k,v);
 let endpointBase='/api/filter'+(baseQuery.toString()?'?'+baseQuery.toString():'');
 try{
  let d=await get(endpointBase+(endpointBase.includes('?')?'&':'?')+'page=1');
  let list=d.items||[];
  pagedState={
   mode:'filters',
   endpointBase,
   page:1,
   hasMore:Boolean(d.hasMore),
   seen:new Set(list.map(x=>`${x.type}:${x.id}`)),
   total:Number(d.totalResults)||list.length
  };
  let countText=pagedState.total>list.length?`${pagedState.total.toLocaleString('en-US')}+ titles`:`${list.length} titles`;
  let moreResults=pagedState.hasMore?`<div class="category-more"><button class="category-more-button" data-more-results aria-label="Show more titles">${ico('plus')}<span>Show more</span></button></div>`:'';
  app.innerHTML=`<div class="container content">${sectionTitle('Advanced Filters','sliders','h1')}<form class="filters-form" data-filters><label>Type<select name="type">${option('all','Everything',values.type)}${option('anime','Anime',values.type)}${option('movie','Movies',values.type)}${option('tv','Web series',values.type)}</select></label><label>Genre<select name="genre">${option('','All genres',values.genre)}${catalogGenres.map(g=>option(g,g,values.genre)).join('')}</select></label><label>Year<input name="year" inputmode="numeric" pattern="[0-9]{4}" minlength="4" maxlength="4" value="${esc(values.year)}" placeholder="Any year"></label><label>Sort<select name="sort">${option('popularity','Popularity',values.sort)}${option('rating','Rating',values.sort)}${option('newest','Newest',values.sort)}</select></label><label>Anime status<select name="status">${option('','Any status',values.status)}${option('releasing','Ongoing',values.status)}${option('finished','Finished',values.status)}</select></label><button class="btn" type="submit">Apply filters</button></form><div class="filter-results-heading">${sectionTitle('Results','sliders')}<span id="filter-count-label">${esc(countText)}</span></div>${grid(list,'paged-grid')}${moreResults}</div>`;
 }catch(e){failure(e)}
}

async function randomPage(){app.innerHTML='<div class="loading">Choosing a random title…</div>';try{let d=await get('/api/random');history.replaceState({},'',url(d.item.type,d.item.id));render()}catch(e){failure(e)}}

function render(){
 disposeVideo();closeMenu();let p=location.pathname;
 if(['/account','/login','/create-account','/profile','/community','/upcoming'].includes(p)){history.replaceState({},'','/browse');p='/browse'}
 if(p==='/schedule')return schedulePage();
 if(p==='/filters')return filtersPage();
 if(p==='/random')return randomPage();
 search.placeholder='Search anime, movies & series...';
 if(p==='/watchlist')return watchlist();
 let mw=p.match(/^\/(?:browse\/)?watch\/(anime|movie|tv)\/(\d+)/);
 if(mw)return watch(mw[1],mw[2]);
 let md=p.match(/^\/browse\/(anime|movie|tv)\/(\d+)/);
 if(md)return details(md[1],md[2]);
 return catalog(Boolean(params().get('q')));
}

document.addEventListener('click',async e=>{
 try{
  let description=e.target.closest('[data-description-toggle]');if(description){if(String(window.getSelection?.()||'').length)return;let expanded=description.classList.toggle('expanded');description.setAttribute('aria-expanded',String(expanded));return}
  let heroSave=e.target.closest('[data-hero-save]');if(heroSave){let [type,id]=heroSave.dataset.heroSave.split(':'),x=[...spotlightItems,...items,...suggestions,...Object.values(genreRows).flat()].find(i=>i.type===type&&String(i.id)===id);if(!x)return;let state=await get('/api/state'),saved=state.watchlist.some(i=>i.id===id&&i.type===type),next=await post('/api/watchlist',{...x,remove:saved});savedKeys=new Set(next.watchlist.map(i=>i.type+':'+i.id));document.querySelectorAll(`[data-hero-save="${type}:${id}"]`).forEach(b=>{b.classList.toggle('saved',!saved);b.setAttribute('aria-label',(!saved?'Remove from':'Add to')+' Watchlist')});return}
  let categoryButton=e.target.closest('[data-more-categories]');if(categoryButton){if(categoryButton.disabled)return;categoryButton.disabled=true;categoryButton.innerHTML='<span class="button-loader" aria-label="Loading"></span>';categoryButton.classList.add('is-loading');let next=genreQueue.splice(0,3),anchor=categoryButton.closest('.category-more');activeGenres.push(...next);for(let name of next)anchor.insertAdjacentHTML('beforebegin',`<section class="genre-section" data-genre="${name}"></section>`);await loadGenreRows(next);if(!anchor.isConnected)return;categoryButton.classList.remove('is-loading');if(genreQueue.length){categoryButton.disabled=false;categoryButton.innerHTML=`${ico('plus')}<span>Show more</span>`}else anchor.remove();return}
  let moreResultsBtn=e.target.closest('[data-more-results]');if(moreResultsBtn){
   if(moreResultsBtn.disabled||!pagedState.hasMore)return;
   moreResultsBtn.disabled=true;
   moreResultsBtn.innerHTML='<span class="button-loader" aria-label="Loading"></span>';
   moreResultsBtn.classList.add('is-loading');
   let anchor=moreResultsBtn.closest('.category-more');
   try{
    let nextPage=pagedState.page+1;
    let sep=pagedState.endpointBase.includes('?')?'&':'?';
    let d=await get(`${pagedState.endpointBase}${sep}page=${nextPage}`);
    pagedState.page=nextPage;
    pagedState.hasMore=Boolean(d.hasMore);
    let fresh=[];
    for(let it of d.items||[]){
     if(!it?.poster||!it?.title)continue;
     let k=`${it.type}:${it.id}`;
     if(!pagedState.seen.has(k)){pagedState.seen.add(k);fresh.push(it);items.push(it)}
    }
    let gridEl=document.querySelector('#paged-grid');
    if(fresh.length&&gridEl)gridEl.insertAdjacentHTML('beforeend',fresh.map(card).join(''));
    if(!anchor?.isConnected)return;
    moreResultsBtn.classList.remove('is-loading');
    if(pagedState.hasMore&&(d.items||[]).length){
     moreResultsBtn.disabled=false;
     moreResultsBtn.innerHTML=`${ico('plus')}<span>Show more</span>`;
    }else{
     anchor.remove();
    }
   }catch{
    if(anchor?.isConnected){
     moreResultsBtn.classList.remove('is-loading');
     moreResultsBtn.disabled=false;
     moreResultsBtn.innerHTML=`${ico('plus')}<span>Show more</span>`;
    }
   }
   return;
  }
  let genre=e.target.closest('[data-genre-filter]');if(genre){nav('/browse?genre='+encodeURIComponent(genre.dataset.genreFilter));return}
  let more=e.target.closest('[data-anime-page]');if(more&&detail){let mode=more.dataset.animeMode;await loadAnimeEpisodes(detail.item.id,mode,Number(more.dataset.animePage),mode==='watch'?episode:0,false);return}
  let dot=e.target.closest('[data-slide]');if(dot){slide=+dot.dataset.slide;let current=document.querySelector('.hero');if(current&&spotlightItems.length)current.outerHTML=hero(spotlightItems);return}
  let open=e.target.closest('[data-open]');if(open){nav(open.dataset.open);return}
  let link=e.target.closest('a[href^="/"]');if(link){e.preventDefault();nav(link.getAttribute('href'));return}
  let heroDetails=e.target.closest('[data-hero-details]');if(heroDetails){nav(heroDetails.dataset.heroDetails);return}
  if(e.target.closest('[data-retry]')){render();return}
  if(e.target.closest('[data-save]')&&detail){let x=detail.item,d=await get('/api/state'),saved=d.watchlist.some(i=>i.id===x.id&&i.type===x.type);let next=await post('/api/watchlist',{...x,remove:saved});savedKeys=new Set(next.watchlist.map(i=>i.type+':'+i.id));await updateSave();return}
 }catch(error){console.error(error)}
});

document.addEventListener('change',e=>{
 if(e.target.id==='season'&&detail){season=+e.target.value;episode=1;nav(`/watch/tv/${detail.item.id}?season=${season}&episode=1`)}
 if(e.target.id==='detail-tv-season'&&detail)loadDetailEpisodes(detail.item.id,e.target.value);
 if(['detail-anime-season','anime-season'].includes(e.target.id)&&detail){let id=e.target.value;nav(e.target.id==='anime-season'?`/watch/anime/${id}?episode=1&lang=${lang}`:`/browse/anime/${id}`)}
});

const menuToggle=document.querySelector('.menu-toggle'),mainMenu=document.querySelector('#main-menu');
function closeMenu(){if(!menuToggle||!mainMenu)return;menuToggle.setAttribute('aria-expanded','false');menuToggle.setAttribute('aria-label','Open menu');mainMenu.hidden=true}
menuToggle?.addEventListener('click',()=>{let open=menuToggle.getAttribute('aria-expanded')!=='true';menuToggle.setAttribute('aria-expanded',String(open));menuToggle.setAttribute('aria-label',open?'Close menu':'Open menu');mainMenu.hidden=!open});
document.addEventListener('click',e=>{if(!e.target.closest('#main-menu,.menu-toggle'))closeMenu()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();if(!search.value.trim())closeSearchBox()}});
document.addEventListener('submit',async e=>{
 let filters=e.target.closest('[data-filters]');if(filters){e.preventDefault();let data=new FormData(filters),q=new URLSearchParams();for(let [key,value] of data)if(String(value).trim())q.set(key,String(value).trim());nav('/filters'+(q.toString()?'?'+q:''));return}
});

const searchbox=document.querySelector('.searchbox');
searchbox.addEventListener('click',()=>{closeMenu();searchbox.classList.add('open');headerEl?.classList.add('search-open');search.focus()});
search.addEventListener('focus',()=>{headerEl?.classList.add('search-open')});
search.addEventListener('blur',()=>{if(!search.value.trim())closeSearchBox()});
search.addEventListener('input',()=>{
 clearTimeout(searchTimer);
 let term=search.value.trim();
 history.replaceState({},'',term?`/browse?q=${encodeURIComponent(term)}`:'/browse');
 searchTimer=setTimeout(()=>term?catalog(true):catalog(false),320);
});
document.addEventListener('keydown',e=>{
 if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-hero-details]')){e.preventDefault();nav(e.target.dataset.heroDetails);return}
 if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-description-toggle]')){e.preventDefault();e.target.click();return}
 if(e.key==='/'&&document.activeElement!==search&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)){e.preventDefault();searchbox.classList.add('open');headerEl?.classList.add('search-open');search.focus()}
});

const genreMenu=document.querySelector('#genre-menu');
if(genreMenu)genreMenu.innerHTML=catalogGenres.map(name=>`<button type="button" data-genre-filter="${esc(name)}">${esc(name)}</button>`).join('');
const exploreIcons={'/browse':'home','/schedule':'clock','/upcoming':'calendar','/random':'shuffle','/filters':'sliders'};
document.querySelectorAll('.main-menu a[href]').forEach(a=>{let icon=exploreIcons[a.getAttribute('href')];if(icon)a.innerHTML=`${ico(icon)}<span>${esc(a.textContent)}</span>`});
document.querySelectorAll('[data-genre-filter]').forEach(b=>{b.innerHTML=`${ico(genreIcons[b.dataset.genreFilter])}<span>${esc(b.textContent)}</span>`});
window.addEventListener('popstate',()=>{search.value=params().get('q')||'';render()});
if(location.pathname==='/')history.replaceState({},'','/browse');
render();
