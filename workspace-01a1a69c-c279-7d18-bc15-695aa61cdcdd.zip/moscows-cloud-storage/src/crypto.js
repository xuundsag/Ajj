import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { open } from 'node:fs/promises';
import { config } from './config.js';

export const IV_BYTES = 12;
export const TAG_BYTES = 16;
export const SEGMENT_SIZE = config.encryptionSegmentSize;

export function deriveSegmentIv(baseIv, index) {
  const iv = Buffer.from(baseIv);
  iv[8] ^= (index >>> 24) & 0xff;
  iv[9] ^= (index >>> 16) & 0xff;
  iv[10] ^= (index >>> 8) & 0xff;
  iv[11] ^= index & 0xff;
  return iv;
}

export function decryptSegment(ciphertext, keyBase64Url, baseIv, index, tagBase64Url) {
  const decipher = createDecipheriv('aes-256-gcm', Buffer.from(keyBase64Url, 'base64url'), deriveSegmentIv(baseIv, index));
  decipher.setAuthTag(Buffer.from(tagBase64Url, 'base64url'));
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

async function writeAll(handle, buffer) {
  let offset = 0;
  while (offset < buffer.length) {
    const { bytesWritten } = await handle.write(buffer, offset, buffer.length - offset, null);
    offset += bytesWritten;
  }
}

export async function encryptFile(inputPath, outputPath, keyBase64Url) {
  const key = Buffer.from(keyBase64Url, 'base64url');
  const baseIv = randomBytes(IV_BYTES);
  const tags = [];
  const input = await open(inputPath, 'r');
  const output = await open(outputPath, 'wx', 0o600);
  try {
    const { size } = await input.stat();
    let position = 0;
    let index = 0;
    while (position < size) {
      const length = Math.min(SEGMENT_SIZE, size - position);
      const plain = Buffer.allocUnsafe(length);
      let offset = 0;
      while (offset < length) {
        const { bytesRead } = await input.read(plain, offset, length - offset, position + offset);
        if (!bytesRead) throw new Error('Unexpected end of file');
        offset += bytesRead;
      }

      const cipher = createCipheriv('aes-256-gcm', key, deriveSegmentIv(baseIv, index));
      const ciphertext = Buffer.concat([cipher.update(plain), cipher.final()]);
      await writeAll(output, ciphertext);
      tags.push(cipher.getAuthTag().toString('base64url'));
      position += length;
      index += 1;
    }
  } finally {
    await Promise.all([input.close(), output.close()]);
  }

  return {
    algorithm: 'AES-256-GCM',
    segmentSize: SEGMENT_SIZE,
    iv: baseIv.toString('base64url'),
    tags,
  };
}
