import express from 'express';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { config, assertConfig } from './config.js';
import { JsonStore } from './store.js';
import { TelegramStorage } from './telegram.js';
import { UploadManager } from './uploads.js';
import { receiveFile } from './multipart.js';
import { FILE_KEY_PATTERN, isEncryptionKey } from './keys.js';

assertConfig();
const store = new JsonStore(config.dataFile);
await store.init();
const telegram = new TelegramStorage();
const uploads = new UploadManager(store, telegram);
const app = express();
const asyncRoute = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

app.disable('x-powered-by');
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'X-Frame-Options': 'DENY',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  });
  next();
});
app.use(express.json({ limit: '32kb' }));

function recordForKey(value) {
  const fileKey = String(value || '').toUpperCase();
  if (!FILE_KEY_PATTERN.test(fileKey)) throw Object.assign(new Error('Invalid FILE_KEY'), { status: 400 });
  const record = store.get(fileKey);
  if (!record) throw Object.assign(new Error('File not found'), { status: 404 });
  return { fileKey, record };
}

function downloadPayload(fileKey, record) {
  return {
    fileKey,
    name: record.name,
    size: record.size,
    mimeType: record.mimeType,
    encrypted: record.encrypted,
    encryption: record.encryption || null,
    chunks: record.chunks.map((chunk, index) => ({
      index,
      size: chunk.storedSize,
      url: `/api/download?fileKey=${fileKey}&chunk=${index}`,
    })),
  };
}

app.get('/', (req, res) => res.redirect('/upload'));
app.get('/upload', (req, res) => res.sendFile(path.join(config.root, 'public', 'upload.html')));
app.get('/download', (req, res) => res.sendFile(path.join(config.root, 'public', 'download.html')));

app.get('/api', (req, res) => res.json({
  name: "Moscow's Cloud Storage",
  endpoints: { upload: '/api/upload', download: '/api/download' },
  maxFileSize: config.maxFileSize,
}));

app.post('/api/upload', asyncRoute(async (req, res) => {
  const file = await receiveFile(req, config.maxFileSize);
  res.json(await uploads.single(file));
}));

app.post('/api/download', (req, res) => {
  const { fileKey, record } = recordForKey(req.body?.fileKey);
  if (record.encrypted && !isEncryptionKey(req.body?.encKey)) {
    throw Object.assign(new Error('A valid ENC_KEY is required'), { status: 400 });
  }
  res.json(downloadPayload(fileKey, record));
});

app.get('/api/download', asyncRoute(async (req, res) => {
  const { record } = recordForKey(req.query.fileKey);
  const index = req.query.chunk === undefined && record.chunks.length === 1 ? 0 : Number(req.query.chunk);
  if (!Number.isInteger(index) || !record.chunks[index]) {
    throw Object.assign(new Error('A valid chunk index is required'), { status: 400 });
  }
  const chunk = record.chunks[index];

  if (String(req.query.proxy || '') === '1') {
    if (!config.allowProxyFallback) throw Object.assign(new Error('Proxy fallback is disabled'), { status: 403 });
    const response = await telegram.openDownload(chunk);
    res.status(200);
    res.set('Content-Type', 'application/octet-stream');
    res.set('Cache-Control', 'private, no-store');
    if (response.headers.get('content-length')) res.set('Content-Length', response.headers.get('content-length'));
    if (record.chunks.length === 1) res.set('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(record.name)}`);
    await pipeline(Readable.fromWeb(response.body), res);
    return;
  }

  res.redirect(302, await telegram.getFileUrl(chunk));
}));

app.use(express.static(path.join(config.root, 'public'), { maxAge: '1h', index: false }));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((req, res) => res.status(404).sendFile(path.join(config.root, 'public', 'upload.html')));

app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  const status = error.status || (error instanceof SyntaxError ? 400 : 500);
  if (status >= 500) console.error(error);
  res.status(status).json({ error: status >= 500 ? 'Storage request failed' : error.message });
});

const server = app.listen(config.port, '0.0.0.0', () => {
  console.log(`Moscow's Cloud Storage listening on http://0.0.0.0:${config.port}`);
});
server.requestTimeout = 0;
server.headersTimeout = 60_000;

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
