import { createReadStream } from 'node:fs';
import http from 'node:http';
import https from 'node:https';
import FormData from 'form-data';
import { config } from './config.js';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export class TelegramStorage {
  constructor() {
    this.pathCache = new Map();
  }

  async request(method, { query, timeout = 30_000 } = {}) {
    if (!config.botToken || !config.chatId) throw new Error('Telegram is not configured');
    const url = new URL(`${config.telegramApiBase}/bot${config.botToken}/${method}`);
    for (const [key, value] of Object.entries(query || {})) url.searchParams.set(key, String(value));

    let lastError;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeout);
      try {
        const response = await fetch(url, { method: 'POST', signal: controller.signal });
        const payload = await response.json().catch(() => null);
        if (response.ok && payload?.ok) return payload.result;
        const error = new Error(payload?.description || `Telegram request failed (${response.status})`);
        error.status = response.status;
        error.retryAfter = Number(payload?.parameters?.retry_after || 0);
        throw error;
      } catch (error) {
        if ((error.status && error.status !== 429 && error.status < 500) || attempt === 3) throw error;
        lastError = error;
        await sleep(Math.max(Number(error.retryAfter || 0) * 1000, 500 * 2 ** attempt));
      } finally {
        clearTimeout(timer);
      }
    }
    throw lastError;
  }

  postDocument(url, filePath, fileSize, fileName) {
    return new Promise((resolve, reject) => {
      const form = new FormData();
      form.append('chat_id', config.chatId);
      form.append('disable_content_type_detection', 'true');
      form.append('document', createReadStream(filePath), {
        filename: fileName,
        contentType: 'application/octet-stream',
        knownLength: fileSize,
      });
      form.getLength((lengthError, length) => {
        if (lengthError) return reject(lengthError);
        const request = (url.protocol === 'https:' ? https : http).request(url, {
          method: 'POST',
          headers: { ...form.getHeaders(), 'Content-Length': length },
        }, (response) => {
          let body = '';
          response.on('data', (chunk) => { body += chunk; });
          response.on('end', () => {
            let payload = null;
            try { payload = JSON.parse(body); } catch { /* handled by caller */ }
            resolve({ status: response.statusCode, payload });
          });
          response.on('error', reject);
        });
        request.on('error', reject);
        request.setTimeout(0);
        form.on('error', (error) => request.destroy(error));
        form.pipe(request);
        return null;
      });
    });
  }

  async sendDocumentFile(filePath, fileSize, fileName) {
    if (!config.botToken || !config.chatId) throw new Error('Telegram is not configured');
    const url = new URL(`${config.telegramApiBase}/bot${config.botToken}/sendDocument`);
    let document;
    let lastError;

    for (let attempt = 0; attempt < 4; attempt += 1) {
      try {
        const { status, payload } = await this.postDocument(url, filePath, fileSize, fileName);
        if (status >= 200 && status < 300 && payload?.ok) {
          document = payload.result;
          break;
        }
        const error = new Error(payload?.description || `Telegram request failed (${status})`);
        error.status = status;
        error.retryAfter = Number(payload?.parameters?.retry_after || 0);
        throw error;
      } catch (error) {
        if ((error.status && error.status !== 429 && error.status < 500) || attempt === 3) throw error;
        lastError = error;
        await sleep(Math.max(Number(error.retryAfter || 0) * 1000, 500 * 2 ** attempt));
      }
    }
    if (!document?.file_id) throw lastError || new Error('Telegram returned no file_id');

    const file = await this.request('getFile', { query: { file_id: document.file_id } });
    if (!file?.file_path) throw new Error('Telegram returned no file_path');
    const obtainedAt = Date.now();
    this.pathCache.set(document.file_id, { path: file.file_path, obtainedAt });
    return { fileId: document.file_id, filePath: file.file_path, pathObtainedAt: obtainedAt };
  }

  fileUrl(filePath) {
    const encodedPath = String(filePath).replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/');
    return `${config.telegramApiBase}/file/bot${config.botToken}/${encodedPath}`;
  }

  async getFileUrl(chunk, refresh = false) {
    const cached = this.pathCache.get(chunk.fileId);
    const fresh = cached && Date.now() - cached.obtainedAt < 45 * 60 * 1000;
    if (!refresh && fresh) return this.fileUrl(cached.path);
    if (!refresh && chunk.filePath && Date.now() - Number(chunk.pathObtainedAt || 0) < 45 * 60 * 1000) {
      return this.fileUrl(chunk.filePath);
    }
    const file = await this.request('getFile', { query: { file_id: chunk.fileId } });
    if (!file?.file_path) throw new Error('Telegram returned no file_path');
    this.pathCache.set(chunk.fileId, { path: file.file_path, obtainedAt: Date.now() });
    return this.fileUrl(file.file_path);
  }

  async openDownload(chunk) {
    let response = await fetch(await this.getFileUrl(chunk));
    if ([401, 403, 404].includes(response.status)) {
      response.body?.cancel();
      response = await fetch(await this.getFileUrl(chunk, true));
    }
    if (!response.ok || !response.body) {
      response.body?.cancel();
      throw new Error(`Telegram download failed (${response.status})`);
    }
    return response;
  }
}
