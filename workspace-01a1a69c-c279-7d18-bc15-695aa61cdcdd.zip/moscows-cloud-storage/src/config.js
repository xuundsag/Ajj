import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
dotenv.config({ path: path.join(root, '.env'), quiet: true });

function boolean(value, fallback) {
  if (value === undefined) return fallback;
  return value.toLowerCase() === 'true';
}

export const config = {
  root,
  port: Number(process.env.PORT || 3000),
  botToken: process.env.BOT_TOKEN || '',
  chatId: process.env.TELEGRAM_CHAT_ID || '',
  telegramApiBase: (process.env.TELEGRAM_API_BASE_URL || 'http://localhost:8081').replace(/\/$/, ''),
  dataFile: process.env.DATA_FILE || path.join(root, 'meg.json'),
  tempDir: process.env.TEMP_DIR || path.join(root, 'tmp'),
  maxFileSize: 2_000_000_000,
  encryptionSegmentSize: 16 * 1024 ** 2,
  allowProxyFallback: boolean(process.env.ALLOW_PROXY_FALLBACK, true),
};

export function assertConfig() {
  if (!config.botToken) throw new Error('BOT_TOKEN is required. See README.md.');
  if (!config.chatId) throw new Error('TELEGRAM_CHAT_ID is required. See README.md.');
}
