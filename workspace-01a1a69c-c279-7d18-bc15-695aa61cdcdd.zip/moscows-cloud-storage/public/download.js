const form = document.querySelector('#download-form');
const fileKeyInput = document.querySelector('#file-key-input');
const encKeyInput = document.querySelector('#enc-key-input');
const button = document.querySelector('#download-button');
const progress = document.querySelector('#progress');
const progressBar = document.querySelector('#progress-bar');
const progressValue = document.querySelector('#progress-value');
const status = document.querySelector('#status');

fileKeyInput.addEventListener('input', () => {
  const end = fileKeyInput.selectionEnd;
  fileKeyInput.value = fileKeyInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
  fileKeyInput.setSelectionRange(end, end);
});

function base64UrlBytes(value) {
  const base64 = value.replace(/-/g, '+').replace(/_/g, '/');
  const binary = atob(base64 + '='.repeat((4 - base64.length % 4) % 4));
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function segmentIv(base, index) {
  const iv = new Uint8Array(base);
  iv[8] ^= (index >>> 24) & 0xff;
  iv[9] ^= (index >>> 16) & 0xff;
  iv[10] ^= (index >>> 8) & 0xff;
  iv[11] ^= index & 0xff;
  return iv;
}

function setProgress(bytes, total) {
  const percent = Math.min(100, Math.floor(bytes / total * 100));
  progressBar.style.width = `${percent}%`;
  progressValue.textContent = `${percent}%`;
}

async function fetchChunk(chunk) {
  try {
    const response = await fetch(chunk.url, { cache: 'no-store' });
    if (!response.ok) throw new Error('Telegram download failed');
    return response;
  } catch (error) {
    if (error.message !== 'Telegram download failed' && error.name !== 'TypeError') throw error;
    const response = await fetch(`${chunk.url}&proxy=1`, { cache: 'no-store' });
    if (!response.ok) throw new Error('Telegram download failed');
    return response;
  }
}

class ExactReader {
  constructor(stream) {
    this.reader = stream.getReader();
    this.pending = null;
  }

  async read(length) {
    const output = new Uint8Array(length);
    let offset = 0;
    while (offset < length) {
      if (!this.pending) {
        const { done, value } = await this.reader.read();
        if (done) throw new Error('Unexpected end of download');
        this.pending = value;
      }
      const count = Math.min(length - offset, this.pending.length);
      output.set(this.pending.subarray(0, count), offset);
      this.pending = count === this.pending.length ? null : this.pending.subarray(count);
      offset += count;
    }
    return output;
  }

  cancel() {
    return this.reader.cancel().catch(() => {});
  }
}

function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  status.textContent = '';
  button.disabled = true;
  progress.hidden = true;
  let writable = null;
  let reader = null;

  try {
    const metadataResponse = await fetch('/api/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fileKey: fileKeyInput.value, encKey: encKeyInput.value.trim() }),
    });
    const metadata = await metadataResponse.json().catch(() => ({}));
    if (!metadataResponse.ok) throw new Error(metadata.error || 'Download failed');

    if (!metadata.encrypted) {
      const anchor = document.createElement('a');
      anchor.href = metadata.chunks[0].url;
      anchor.download = metadata.name;
      document.body.append(anchor);
      anchor.click();
      anchor.remove();
      return;
    }

    const encryption = metadata.encryption;
    if (!encryption || encryption.algorithm !== 'AES-256-GCM') throw new Error('Unsupported encryption');
    const key = await crypto.subtle.importKey(
      'raw', base64UrlBytes(encKeyInput.value.trim()), { name: 'AES-GCM' }, false, ['decrypt'],
    );
    const baseIv = base64UrlBytes(encryption.iv);
    const memoryOnly = !window.showSaveFilePicker;
    if (memoryOnly && metadata.size > 256 * 1024 ** 2) throw new Error('Use a Chromium browser to download this file');
    const parts = [];
    if (!memoryOnly) {
      const handle = await window.showSaveFilePicker({ suggestedName: metadata.name });
      writable = await handle.createWritable();
    }

    const response = await fetchChunk(metadata.chunks[0]);
    reader = new ExactReader(response.body);
    progress.hidden = false;
    let completed = 0;
    let index = 0;
    setProgress(0, metadata.size);

    while (completed < metadata.size) {
      const length = Math.min(encryption.segmentSize, metadata.size - completed);
      const ciphertext = await reader.read(length);
      const tag = base64UrlBytes(encryption.tags[index]);
      const sealed = new Uint8Array(length + tag.length);
      sealed.set(ciphertext);
      sealed.set(tag, length);
      const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: segmentIv(baseIv, index) }, key, sealed);
      if (writable) await writable.write(plain);
      else parts.push(plain);
      completed += plain.byteLength;
      index += 1;
      setProgress(completed, metadata.size);
    }

    await reader.cancel();
    reader = null;
    if (writable) {
      await writable.close();
      writable = null;
    } else {
      saveBlob(new Blob(parts, { type: metadata.mimeType }), metadata.name);
    }
    progress.hidden = true;
  } catch (error) {
    if (reader) await reader.cancel();
    if (writable) await writable.abort().catch(() => {});
    status.textContent = error.name === 'AbortError' ? '' : (error.message || 'Download failed');
    progress.hidden = true;
  } finally {
    button.disabled = false;
  }
});
