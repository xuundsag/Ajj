# Moscow's Cloud Storage

A minimal two-page cloud storage app backed by a **local Telegram Bot API server**. Each upload is sent to Telegram as one document, with a maximum source file size of **2 GB (2,000,000,000 bytes)**. Optional AES-256-GCM encryption is processed in memory-bounded segments without splitting the Telegram document.

Metadata and Telegram file paths are stored in `meg.json`; encryption keys are never stored.

See [BOT_SETUP.md](BOT_SETUP.md) for the complete bot creation, local Bot API installation, storage, bandwidth, and production setup guide.

## Requirements

- Node.js 20 or newer
- A running [local Telegram Bot API server](https://github.com/tdlib/telegram-bot-api), normally listening on port `8081`
- A Telegram bot and a channel or group where it can post documents

## Setup

1. Start your Telegram Bot API server in local mode.
2. Create a bot with [@BotFather](https://t.me/BotFather) and copy its token.
3. Create a private Telegram channel or group, add the bot, and allow it to post messages.
4. Copy the chat ID. For a channel it normally starts with `-100`.
5. Configure and start:

```bash
cp .env.example .env
# Edit .env and set BOT_TOKEN, TELEGRAM_CHAT_ID and TELEGRAM_API_BASE_URL
npm install
npm start
```

The default local Bot API address is `http://localhost:8081`. Open `http://localhost:3000/upload`.

For development:

```bash
npm run dev
```

## Pages

- `/upload` — choose one file up to 2 GB, optionally enable encryption, and upload. FILE_KEY and the optional ENC_KEY appear only in the completed upload view. Reloading removes that view.
- `/download` — enter FILE_KEY and, for encrypted files, ENC_KEY.
- `/api` — API information.

## API

### Upload

Send one multipart request with `file` and optional `encrypted=true`:

```bash
curl -X POST http://localhost:3000/api/upload \
  -F 'file=@example.zip' \
  -F 'encrypted=true'
```

```json
{
  "fileKey": "A1B2C3D4",
  "encKey": "base64url-encoded-32-byte-key"
}
```

`encKey` is `null` when encryption is disabled. The source file can be up to `2000000000` bytes, matching Telegram's documented 2000 MB local-server limit. The app streams the incoming request to a temporary file and then streams one document to the local Bot API; it never loads the whole file into memory.

### Download metadata

```bash
curl -X POST http://localhost:3000/api/download \
  -H 'Content-Type: application/json' \
  -d '{"fileKey":"A1B2C3D4","encKey":"ENC_KEY_IF_REQUIRED"}'
```

Example response:

```json
{
  "fileKey": "A1B2C3D4",
  "name": "example.zip",
  "size": 123456789,
  "mimeType": "application/zip",
  "encrypted": true,
  "encryption": {
    "algorithm": "AES-256-GCM",
    "segmentSize": 16777216,
    "iv": "base64url-base-iv",
    "tags": ["base64url-authentication-tag"]
  },
  "chunks": [
    {
      "index": 0,
      "size": 123456789,
      "url": "/api/download?fileKey=A1B2C3D4&chunk=0"
    }
  ]
}
```

There is always one Telegram document for a new upload. Request its URL with redirects enabled:

```bash
curl -L 'http://localhost:3000/api/download?fileKey=A1B2C3D4&chunk=0' -o encrypted-file
```

A normal GET returns an HTTP `302` redirect to the configured Bot API file server.

### Encryption format

Encryption uses independent 16 MiB AES-256-GCM segments inside the single stored document:

- Decode `encKey` from base64url to obtain the 32-byte key.
- Decode `encryption.iv` to obtain the 12-byte base IV.
- For segment index `n`, derive its IV by XORing the final four IV bytes with `n` as an unsigned 32-bit big-endian integer.
- Read up to `segmentSize` ciphertext bytes, append the decoded authentication tag at `encryption.tags[n]`, then decrypt with AES-256-GCM.
- Concatenate the plaintext segments.

Authentication tags and the non-secret base IV are stored in `meg.json`. The ciphertext has exactly the same size as the source file, so encryption does not push a 2 GB upload over Telegram's document limit.

## Storage and operation

- `meg.json` contains original metadata, Telegram `fileId`/`filePath` values, and encryption authentication metadata. Writes use a temporary file and atomic rename. Back up this file.
- `tmp/` holds only transient upload files. Both incoming and encrypted temporary files are deleted after the Telegram request finishes.
- FILE_KEY is a cryptographically random eight-character uppercase alphanumeric key.
- ENC_KEY is a random 256-bit base64url key returned by the upload response and never written to `meg.json`.
- A reverse proxy must allow multipart request bodies of at least 2 GB and permit long upload timeouts. The Node server itself has no request timeout.

## Browser and network notes

- Unencrypted downloads redirect to the configured Bot API file server.
- Encrypted downloads stream and decrypt one 16 MiB segment at a time. Large encrypted downloads use the File System Access API in Chromium-based browsers; other browsers can reconstruct files up to 256 MiB in memory.
- If cross-origin browser reads are blocked, `ALLOW_PROXY_FALLBACK=true` streams the response through the app without saving it. Set it to `false` to require redirects only.
- Direct Bot API file URLs contain the bot token. Use a dedicated storage bot and protect the local Bot API endpoint.
- Use HTTPS in production. Web Crypto, clipboard, and file-picker features require a secure context except on localhost.

## Tests

```bash
npm test
```
