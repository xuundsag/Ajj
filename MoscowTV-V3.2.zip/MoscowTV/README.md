# MoscowTV V3.2

A responsive anime, movie and web-series catalog with an Anikoto-powered anime catalog, MegaPlay episode playback, CineSrc/EmbedWave OTT playback, a simple Watchlist, Continue Watching, and a bold mobile/desktop Spotlight.

## Start

```sh
node start.js
```

The launcher installs production dependencies when needed and starts on port `3000`. Edit `PORT` in `start.js` to change it. Node 20+ is recommended. Set `TMDB_API_KEY` for reliable TMDB access; otherwise the server tries publicly shared keys from `freekeys`, which can fail or be rate-limited.

## V3.2 discovery and color refinements

- **Continue Watching** now appears above Trending on the home page whenever real watch history exists. It uses the same saved episode, season, progress, and resume links as the Watchlist history view.
- Home starts with three genre shelves. A compact **Show more** button below the shelves loads three more at a time and disappears after all genres are shown.
- The menu, home shelves, and Advanced Filters share **20 genre choices**: Action, Adventure, Animation, Comedy, Crime, Documentary, Drama, Family, Fantasy, Horror, Mecha, Music, Mystery, Psychological, Romance, Sci-Fi, Slice of Life, Sports, Supernatural, and Thriller.
- Accent colors use the Spotlight orange (`#ff731c`) consistently for primary buttons, badges, icons, active states, and progress. Secondary surfaces remain dark.
- The player’s “You are now watching” notice is reduced to 12px on desktop and 11px on mobile.

## V3.1 refinements

- Adds the supplied transparent **MoscowTV Crown Wordmark** in the header and footer, cropped and sized for desktop/mobile.
- Keeps the bold **Archivo/Atyp Display** heading stack and switches body copy to **Manrope/Atyp Text**.
- Mobile Spotlight artwork now covers the full Spotlight height and fades smoothly into the page instead of ending in the middle.
- Spotlight indicators sit directly below the actions with consistent spacing. Clicking anywhere on the Spotlight outside its action controls opens the details page.
- Details descriptions remain click-to-expand but no longer have a boxed background or border.
- The desktop Watchlist header icon is borderless like mobile. Expanded mobile Search stays aligned between the menu and Watchlist icons.

## Anikoto anime catalog

**Anikoto is now the primary anime catalog**, rather than only an availability check.

- `data/megaplay-catalog.json` contains Anikoto titles, English/alternate titles, posters, wide artwork, descriptions, genres, years, formats, ratings, status, MAL/AniList IDs, episode counts, and provider series IDs.
- Browse, Search, genre shelves, Random, Advanced Filters, and released anime details use this catalog directly.
- Only entries with a poster and at least one listed episode enter the normal anime catalog.
- AniList remains in use for real airing schedules, upcoming anime, and season-relationship metadata. TMDB remains the OTT catalog and can supply a matching wide backdrop.
- Cross-catalog duplicates and localized anime duplicates are removed. Unreleased titles remain separate from normal discovery.

To refresh the Anikoto snapshot, run the following command and restart the server. The importer respects the published 60-requests-per-120-seconds limit and takes a few minutes.

```sh
python3 scripts/update-megaplay-catalog.py
```

## Playback and episode data

- Anime details and episode lists use the selected Anikoto series.
- MegaPlay playback uses the exact `embed_url.sub` or `embed_url.dub` returned for the requested provider episode. Missing episodes/language tracks produce a short error rather than a fabricated player URL.
- Selective AniList season relationships remain available; unrelated successors are not merged.
- Anime movies do not show episode counts, episode lists, Previous/Next, or Auto Next.
- Upcoming detail pages have no Watch button, episode counts, episode lists, or episode controls.
- Movies/web series retain CineSrc and EmbedWave selectors.

Provider entries can change. V3.2 uses actual catalog and episode data rather than treating an iframe HTTP 200 response as proof of availability.

## Interface and saving

- Accounts, Profiles, login, registration, Comments, Community, Watchlist statuses, and account-backup notices are removed.
- Watchlist/history save automatically to the current browser through a persistent HttpOnly visitor cookie and `data/states.json`.
- The Watchlist icon sits beside Search on desktop and mobile.
- The Spotlight includes wide artwork, a Start Watching button, a circular Watchlist action, and segmented indicators.
- Bold inline SVG icons are used for headings and menu categories; there are no emoji icons or external icon scripts.
- Details descriptions expand/collapse when anywhere in the description text area is clicked. Enter/Space also works when focused.
- Two-row orange player controls, Light mode, report control, watching notice, actual-history Continue, search, Schedule, Upcoming, Random, and Advanced Filters remain.

## Typography and logo

Headings request **Atyp Display** and fall back to bundled **Archivo**. Body copy requests **Atyp Text** and falls back to bundled **Manrope**. Atyp is a commercial Suitcase Type Foundry family and is not bundled without a license. Archivo and Manrope licenses are included in `public/fonts/`.

The crown wordmark is the user-supplied `MoscowTV Crown Wordmark.png`, preserved with transparency and stored as `public/images/moscowtv-crown-wordmark.png`.

## Attribution

The interface takes inspiration from Anipaca and the supplied Crunchyroll Spotlight screenshot. Anipaca's GPL-3.0 license is retained in `ANIPACA-LICENSE.txt`. Lucide-style inline SVG notices are retained in `LUCIDE-LICENSE.txt`. Catalog data comes from Anikoto, AniList, and TMDB. Review content rights and provider terms before deployment.
