# kozuTV V5.4.19

kozuTV is a responsive anime, movie and series browser with a custom Video.js player and a
same-origin media proxy. No account is needed: every page works signed out.

## Quick start

Requires Node.js 20 or newer.

```bash
npm install
npm start
```

Open `http://localhost:3000`. To use another port, run `PORT=8080 npm start`.
Some optional provider fallbacks use Playwright; if prompted, install Chromium with
`npx playwright install chromium`.

## What this build contains

- **Flat sidebar:** Home, Watchlist, Schedule, Random title, Advanced filters, Upcoming anime,
  Settings. Explore and its sub-lists are gone.
- **Regional audio.** Every anime title is probed for the dubs its own sources carry, so the
  player's Audio menu lists the real languages — Japanese, English, Hindi, Tamil, Telugu,
  Malayalam, Kannada, Bengali — and never a language the source cannot play. Special
  catalogues (Shin-chan, Doraemon, the Pokémon film, the Indian-broadcast titles) use the
  same menu with their verified feeds. Sources publish dubs as either HLS or MP4; both play
  through the same proxy.
- **AI Transcription trigger in Settings.** The switch is the last row of *Viewing & browsing*
  and turns the transcription pipeline (NVIDIA Riva via `NVIDIA_API_KEY`) on or off. No AI
  notice, disclosure or "(AI)" wording is printed anywhere in the interface.
- **Settings** saves immediately and has three cards: *Playback*, *Language & sources*,
  *Viewing & browsing* (14 preferences, ending with the AI Transcription switch).
  Reset preferences restores every default.
- **Player:** subtitle controls, playback speed, picture-in-picture, seek previews, quality and
  server choices when the source provides them, keyboard and double-tap seeking, resume.
- **No footer** anywhere in the interface.

## Removed since V5.4.13

Cache Token, the Discord card and Rich Presence helper, accounts, public profiles, the
Statistics page and the watch ledger are **not** part of this build: no `/api/cache-token/*`,
`/api/discord/*` or `/api/app/activity` route exists, Settings has no Cache Token or Discord
card, and no runtime credential files ship in the archive.

## Configuration

`.env` in the project root is loaded at startup and is **not** overridden by variables already
set in the environment:

```
PORT=3000
MONGODB_URI=mongodb+srv://user:password@cluster0.example.mongodb.net/?retryWrites=true&w=majority
MONGODB_DB=kozutv
MONGODB_COLLECTION=cache_token_store
NVIDIA_API_KEY=...
```

Quote values that contain `#`. This release ZIP is built with the real `.env` **inside it**: it
holds the NVIDIA key and the database password, so treat the archive as a secret, do not
publish it, and rotate both credentials if it is shared. `.env.example` shows the same keys
with placeholders, and `.env` is listed in `.gitignore`. MongoDB is optional — without a
reachable database the app keeps running; the AI Transcription switch still works from the
NVIDIA key alone.

## AI transcription

When AI Transcription is on, caption choices follow the selected spoken audio: Hindi offers
Hindi and Hinglish, Bengali offers Bengali and Benglish. The Latin options are automatic
transliterations, not translations. Transcribed HLS audio is sent to NVIDIA's hosted speech
service; MP4, encrypted, low-latency and byte-range HLS are not supported by this path.
Parakeet returns word timestamps; NVIDIA Whisper is used for several other languages and
returns approximate timings. Captioning prefetches the next 12-second window, follows seeking
and source changes, cancels stale work, and falls back to matching existing captions when
available. Existing subtitle files stay available when the switch is off.

Node.js 20+ and outbound access to `grpc.nvcf.nvidia.com:443` are required. The default key
location is `~/.config/kozutv/nvidia-nim.key`; `NVIDIA_API_KEY` and `NVIDIA_API_KEY_FILE`
override it. Restrict the secret file to the server account (`chmod 600`). Default request
caps are **1,800 per socket IP per hour** and **6,000 globally per hour**; adjust them with
`AI_MAX_PER_IP_HOUR` and `AI_MAX_GLOBAL_HOUR`. These limits are not authentication: put an
authenticated reverse proxy and a spending budget in front of any public deployment. Riva
protocol files and licence notices are in `riva/proto` and `THIRD-PARTY/`.

## Tests

```bash
npm install
npx playwright install chromium      # browser suites
npm test
```

`npm test` runs the regional-dub, viewer-settings, genre-cache, V5.4.12 feature and V5.4.13
AI-caption suites (isolated servers, mocked catalogues, no NVIDIA key, temporary data — saved
data is untouched). Individual commands: `npm run test:dubs`, `npm run test:viewer`,
`npm run test:genre`, `npm run test:feature`, `npm run test:ai`.

## Notes

- Providers, subtitle catalogues and dubs are external and may change or fail. Language labels
  describe provider metadata, not verified provenance; a curated dub collection is not a
  guarantee for every episode.
- Watchlist and history are stored per visitor in `data/states.json`; a fresh installation
  starts empty. Device preferences live in the browser.
- See [data/ATTRIBUTION.md](data/ATTRIBUTION.md) for episode-data and artwork sources and the
  licence files for third-party software and fonts.
