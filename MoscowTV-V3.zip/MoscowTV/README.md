# MoscowTV V3

A responsive anime, movie and web-series catalog with MegaPlay anime playback, CineSrc/EmbedWave OTT playback, a simple Watchlist, Continue Watching, discovery tools, and a bold mobile/desktop Spotlight.

## Start

```sh
node start.js
```

The launcher installs production dependencies when needed and starts on port `3000`. Edit `PORT` in `start.js` to change it. Node 20+ is recommended. Set `TMDB_API_KEY` for reliable TMDB access; otherwise the server tries publicly shared keys from `freekeys`, which can fail or be rate-limited.

## V3 changes

- Accounts, Profiles, login, registration, and account-backup messaging are removed. Watchlist/history still save automatically to the current browser through a persistent visitor cookie.
- The top text navigation is removed. A Watchlist icon sits directly beside Search on desktop and mobile.
- The Spotlight uses wide artwork, bold display typography, a Start Watching button, a circular Watchlist button, and segmented slide indicators.
- Details descriptions expand when anywhere in the description area is clicked and collapse when clicked again. Enter/Space also works when the area is keyboard-focused.
- Bold inline SVG icons are used for category headings; there are no emoji icons or external icon scripts.
- General Browse, Search, Genre, Random, Schedule, and Advanced Filter results exclude unreleased titles. Cross-catalog duplicates are merged by normalized title, year, and series/movie kind, with anime preferred and wide OTT backdrop art retained when available.
- Upcoming remains a separate browse-only page. Upcoming detail pages do not show Watch buttons, episode counts, episode lists, or episode controls.

## Verifiable MegaPlay availability

MegaPlay's own documentation recommends the Anikoto API for its series catalog and episode IDs. V3 therefore uses a local snapshot of that catalog instead of assuming that an iframe HTTP response proves availability.

- Normal anime discovery includes only released AniList titles with a matching Anikoto/MegaPlay catalog entry and at least one listed episode.
- Provider title aliases also catch localized TMDB anime duplicates, preventing unavailable shows from re-entering as separate OTT entries.
- Anime playback uses the exact `embed_url.sub` or `embed_url.dub` returned for the requested provider episode. Missing episodes or language tracks produce a short error instead of a fabricated player URL.
- Anime episode lists come from the same provider catalog, so the episode controls correspond to listed episodes.
- Upcoming titles are not treated as playable merely because they exist in AniList.
- The snapshot is stored at `data/megaplay-catalog.json`. To refresh it, run the command below and restart the server. The importer respects the provider's published 60-requests-per-120-seconds limit and takes a few minutes.

```sh
python3 scripts/update-megaplay-catalog.py
```

No system can guarantee that every third-party video remains playable forever. Provider entries and embeds can change; the important difference is that V3 uses actual catalog/episode data rather than inferring availability from iframe status codes.

## Watchlist and history

- Details, Spotlight, and player controls use a single Add/Remove Watchlist action.
- There are no Watchlist statuses, accounts, backup notices, Comments, or Community pages.
- History and Watchlist are stored in `data/states.json` under a random visitor ID in an HttpOnly, SameSite=Lax cookie.
- This is a small JSON-backed local app, not a multi-tenant production database.

## Other retained behavior

- Selective anime season grouping; unrelated successors are not merged.
- Actual-history Continue behavior.
- Anime movies do not show episode counts, episode lists, Previous/Next, or Auto Next.
- MegaPlay Sub/Dub selectors; CineSrc and EmbedWave selectors for OTT titles.
- Two-row orange player controls, Light mode, report control, watching notice, and responsive episode lists.
- Random, Schedule, Upcoming, Advanced Filters, genre shelves, search, and suggestions.

## Typography

The design requests **Atyp Display** for headings and **Atyp Text** for body copy. Atyp is a commercial Suitcase Type Foundry family and is not bundled without a license. The ZIP includes licensed open **Archivo** and **Space Grotesk** WOFF2 fallbacks, so the design works offline and in the preview. If you own Atyp webfont licenses, add the licensed files and corresponding `@font-face` rules using those family names.

Archivo and Space Grotesk licenses are included in `public/fonts/`.

## Attribution

The interface takes inspiration from Anipaca and the supplied Crunchyroll Spotlight screenshot. Anipaca's GPL-3.0 license is retained in `ANIPACA-LICENSE.txt`. Lucide-style inline SVG notices are retained in `LUCIDE-LICENSE.txt`. Catalog metadata comes from AniList and TMDB; provider availability/episode mappings come from the documented Anikoto API. Review content rights and provider terms before deployment.
