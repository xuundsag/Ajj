# Moscow's Cloud Storage

A minimal two-page cloud storage app backed by a **local Telegram Bot API server**. Each upload is sent to Telegram as one document up to **2 GB (2,000,000,000 bytes)**. AES-256-GCM encryption and decryption are performed on the server in memory-bounded 16 MiB segments.

Metadata and Telegram file paths are stored in `meg.json`; ENC_KEY values are never stored.

## Requirements

- Node.js 20 or newer
- Telegram bot token and storage chat ID
- Telegram `api_id` and `api_hash` from [my.telegram.org](https://my.telegram.org)
- Build tools for automatic Bot API compilation: Git, CMake, a C++ compiler, OpenSSL, zlib, and gperf

See [BOT_SETUP.md](BOT_SETUP.md) for the complete Telegram and server guide.

## Configuration

Both `.env.example` and `.env` are provided. Edit `.env`:

```env
BOT_TOKEN=123456789:replace_me
TELEGRAM_CHAT_ID=-1001234567890
TELEGRAM_API_ID=123456
TELEGRAM_API_HASH=replace_me
TELEGRAM_API_BASE_URL=http://127.0.0.1:8081
TELEGRAM_AUTO_START=true
TELEGRAM_LOCAL_FILE_UPLOAD=true
TELEGRAM_BUILD_JOBS=2
PORT=3000
```

Then run:

```bash
npm install
npm start
```

Open `http://localhost:3000/upload`.

### Automatic Bot API server

At startup, the app checks `TELEGRAM_API_BASE_URL`. If the Bot API is unavailable and `TELEGRAM_AUTO_START=true`, it:

1. Builds the official Bot API binary when it is missing.
2. Creates its data and temporary directories.
3. Starts it with `--local` using `TELEGRAM_API_ID` and `TELEGRAM_API_HASH`.
4. Waits for `getMe` to succeed before starting the website.
5. Stops the managed Bot API process during graceful shutdown.

Set `TELEGRAM_AUTO_START=false` to use an independently managed server.

### Build RAM control

Do not use an unbounded `cmake --build . --parallel` on this project.

- `TELEGRAM_BUILD_JOBS=2` is the default, intended for approximately 16 GB RAM systems.
- `TELEGRAM_BUILD_JOBS=1` is recommended when targeting approximately 8 GB RAM.
- The build also uses `-O2` and the GNU linker's `--no-keep-memory` option.

Job control limits concurrent compiler processes; it is not a hard RAM quota. Compiler memory usage varies by version and platform.

## Pages

- `/upload` — choose one file up to 2 GB, optionally enable encryption, and upload. FILE_KEY and optional ENC_KEY appear only in the completed view.
- `/download` — enter FILE_KEY and, for encrypted files, ENC_KEY.
- `/api` — API information.

## API

### Upload

```bash
curl -X POST http://localhost:3000/api/upload \
  -F 'file=@example.zip' \
  -F 'encrypted=true'
```

```json
{
  "fileKey": "A1B2C3D4",
  "encKey": "base64url-encoded-32-byte-key"
}
```

`encKey` is `null` when encryption is disabled. The incoming file is streamed to temporary disk. When Node and the Bot API share a filesystem, `TELEGRAM_LOCAL_FILE_UPLOAD=true` hands the Bot API a `file://` path so it reads the file directly without a second large HTTP upload. Set it to `false` for remote servers or containers without a shared volume to use multipart streaming instead.

### Download metadata

```bash
curl -X POST http://localhost:3000/api/download \
  -H 'Content-Type: application/json' \
  -d '{"fileKey":"A1B2C3D4","encKey":"ENC_KEY_IF_REQUIRED","metadata":true}'
```

```json
{
  "name": "example.zip",
  "size": 123456789,
  "mimeType": "application/zip",
  "encrypted": true,
  "downloadUrl": "/api/download"
}
```

### Download the file

Use the same endpoint without `metadata`:

```bash
curl -X POST http://localhost:3000/api/download \
  -H 'Content-Type: application/json' \
  -d '{"fileKey":"A1B2C3D4","encKey":"ENC_KEY_IF_REQUIRED"}' \
  -o example.zip
```

The Node server downloads the Telegram document, verifies and decrypts encrypted segments when required, and streams the plaintext response to the client. **There are no Telegram redirects and no browser decryption.** Telegram file URLs and bot tokens are not exposed to the browser.

## Storage and operation

- `meg.json` contains original metadata, Telegram file IDs/paths, and non-secret authentication tags. Writes use atomic rename.
- `tmp/` holds transient incoming and encrypted upload files. They are deleted after the Telegram request finishes.
- FILE_KEY is a cryptographically random eight-character uppercase alphanumeric key.
- ENC_KEY is a random 256-bit base64url key returned once by the upload response and never written to `meg.json`.
- One maximum-size encrypted upload can temporarily require over 4 GB across its incoming and encrypted files.
- Uploads and downloads pass through the Node server and local Bot API, so both bandwidth and server capacity must be sized accordingly.
- A reverse proxy must allow multipart request bodies of at least 2 GB and permit long upload/download timeouts.
- Large downloads use the File System Access API in Chromium browsers to avoid holding the file in memory. Other browsers can download up to 256 MiB through the memory fallback.
- Use HTTPS in production, especially because ENC_KEY is sent to the server for decryption.

## Tests

```bash
npm test
```
