import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { config } from '../src/config.js';
import { TelegramStorage } from '../src/telegram.js';

async function fixture(t, handler) {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-telegram-error-'));
  const filePath = path.join(directory, 'upload.bin');
  await writeFile(filePath, Buffer.alloc(64 * 1024, 1));
  const server = createServer(handler);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const original = {
    botToken: config.botToken,
    chatId: config.chatId,
    telegramApiBase: config.telegramApiBase,
    telegramLocalFileUpload: config.telegramLocalFileUpload,
  };
  Object.assign(config, {
    botToken: 'TEST_TOKEN',
    chatId: '-100123',
    telegramApiBase: `http://127.0.0.1:${server.address().port}`,
    telegramLocalFileUpload: true,
  });
  t.after(async () => {
    Object.assign(config, original);
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
    await rm(directory, { recursive: true, force: true });
  });
  return { filePath, server };
}

test('Telegram 500 description is preserved and sendDocument is not retried', async (t) => {
  let requests = 0;
  const { filePath } = await fixture(t, (req, res) => {
    requests += 1;
    req.resume();
    req.on('end', () => {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error_code: 500, description: 'test storage failure' }));
    });
  });
  const storage = new TelegramStorage();
  await assert.rejects(storage.sendDocumentFile(filePath, 64 * 1024, 'test.bin'), (error) => {
    assert.match(error.message, /test storage failure/);
    assert.equal(error.telegramStatus, 500);
    assert.equal(error.clientStatus, 502);
    return true;
  });
  assert.equal(requests, 1);
});

test('early socket close stops multipart upload without EPIPE retries', async (t) => {
  let requests = 0;
  const { filePath } = await fixture(t, (req) => {
    requests += 1;
    req.once('data', () => req.socket.destroy());
  });
  config.telegramLocalFileUpload = false;
  const storage = new TelegramStorage();
  await assert.rejects(storage.sendDocumentFile(filePath, 64 * 1024, 'test.bin'), (error) => {
    assert.match(error.message, /connection failed/);
    assert.equal(error.clientStatus, 502);
    return true;
  });
  assert.equal(requests, 1);
});
