import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';
import path from 'node:path';
import Busboy from 'busboy';

const root = path.resolve(import.meta.dirname, '..');

async function freePort() {
  const server = createServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  await new Promise((resolve) => server.close(resolve));
  return port;
}

function json(res, value) {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(value));
}

test('HTTP upload and server-side decrypted download round-trip', { timeout: 20_000 }, async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'mcs-api-'));
  const documents = new Map();
  const telegram = createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname === '/botTEST_TOKEN/getMe') {
      json(res, { ok: true, result: { id: 1, is_bot: true } });
      return;
    }
    if (url.pathname === '/botTEST_TOKEN/sendDocument') {
      const saveDocument = (buffer) => {
        const id = `id-${documents.size}`;
        documents.set(id, buffer);
        json(res, {
          ok: true,
          result: {
            message_id: 1000 + documents.size,
            chat: { id: -100123 },
            document: { file_id: id, file_size: buffer.length },
          },
        });
      };
      if (req.headers['content-type']?.includes('application/json')) {
        let body = '';
        req.on('data', (chunk) => { body += chunk; });
        req.on('end', async () => {
          const input = JSON.parse(body);
          saveDocument(await readFile(fileURLToPath(input.document)));
        });
        return;
      }
      const busboy = Busboy({ headers: req.headers });
      let buffer = null;
      busboy.on('file', (name, stream) => {
        const chunks = [];
        stream.on('data', (chunk) => chunks.push(chunk));
        stream.on('end', () => { buffer = Buffer.concat(chunks); });
      });
      busboy.on('close', () => saveDocument(buffer));
      req.pipe(busboy);
      return;
    }
    if (url.pathname === '/botTEST_TOKEN/getFile') {
      const id = url.searchParams.get('file_id');
      json(res, { ok: true, result: { file_id: id, file_path: `documents/${id}` } });
      return;
    }
    if (url.pathname.startsWith('/file/botTEST_TOKEN/documents/')) {
      const id = url.pathname.split('/').pop();
      const body = documents.get(id);
      res.writeHead(200, { 'Content-Length': body.length, 'Content-Type': 'application/octet-stream' });
      res.end(body);
      return;
    }
    res.writeHead(404).end();
  });
  await new Promise((resolve) => telegram.listen(0, '127.0.0.1', resolve));
  const telegramPort = telegram.address().port;
  const appPort = await freePort();
  const base = `http://127.0.0.1:${appPort}`;
  const child = spawn(process.execPath, ['src/server.js'], {
    cwd: root,
    env: {
      ...process.env,
      BOT_TOKEN: 'TEST_TOKEN',
      TELEGRAM_CHAT_ID: '-100123',
      TELEGRAM_API_BASE_URL: `http://127.0.0.1:${telegramPort}`,
      TELEGRAM_API_ID: '12345',
      TELEGRAM_API_HASH: 'test-hash',
      PORT: String(appPort),
      DATA_FILE: path.join(directory, 'meg.json'),
      TEMP_DIR: path.join(directory, 'tmp'),
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  t.after(async () => {
    child.kill('SIGTERM');
    telegram.closeAllConnections();
    await new Promise((resolve) => telegram.close(resolve));
    await rm(directory, { recursive: true, force: true });
  });

  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('App startup timed out')), 8_000);
    child.stdout.on('data', (chunk) => {
      if (chunk.toString().includes('listening')) { clearTimeout(timer); resolve(); }
    });
    child.stderr.on('data', (chunk) => process.stderr.write(chunk));
    child.once('exit', (code) => { clearTimeout(timer); reject(new Error(`App exited: ${code}`)); });
  });

  const form = new FormData();
  form.append('encrypted', 'true');
  form.append('file', new Blob(['hello cloud storage']), 'hello.txt');
  const uploadResponse = await fetch(`${base}/api/upload`, { method: 'POST', body: form });
  assert.equal(uploadResponse.status, 200);
  const uploaded = await uploadResponse.json();
  assert.match(uploaded.fileKey, /^[A-Z0-9]{8}$/);
  assert.ok(uploaded.encKey);
  assert.notEqual(documents.get('id-0').toString(), 'hello cloud storage');

  const missingKey = await fetch(`${base}/api/download`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fileKey: uploaded.fileKey }),
  });
  assert.equal(missingKey.status, 400);

  const metadataResponse = await fetch(`${base}/api/download`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...uploaded, metadata: true }),
  });
  assert.equal(metadataResponse.status, 200);
  const metadata = await metadataResponse.json();
  assert.equal(metadata.name, 'hello.txt');
  assert.equal(metadata.size, Buffer.byteLength('hello cloud storage'));
  assert.equal(metadata.downloadUrl, '/api/download');
  assert.equal(metadata.encryption, undefined);

  const wrongKey = await fetch(`${base}/api/download`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fileKey: uploaded.fileKey, encKey: 'A'.repeat(43) }),
  });
  assert.equal(wrongKey.status, 400);

  const download = await fetch(`${base}/api/download`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(uploaded),
  });
  assert.equal(download.status, 200);
  assert.equal(download.headers.get('content-length'), String(metadata.size));
  assert.match(download.headers.get('content-disposition'), /hello\.txt/);
  assert.equal(await download.text(), 'hello cloud storage');

  const getDownload = await fetch(`${base}/api/download`);
  assert.equal(getDownload.status, 405);

  const stored = await readFile(path.join(directory, 'meg.json'), 'utf8');
  assert.equal(stored.includes(uploaded.encKey), false);
  assert.equal(stored.includes('documents/id-0'), true);
  assert.equal(stored.includes('"messageId": 1001'), true);

  const apiInfo = await (await fetch(`${base}/api`)).json();
  assert.equal(apiInfo.maxFileSize, 2_000_000_000);
  assert.equal(apiInfo.downloadMode, 'server-decrypted-stream');

  const page = await fetch(`${base}/upload`);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /Moscow's Cloud Storage/);
});
