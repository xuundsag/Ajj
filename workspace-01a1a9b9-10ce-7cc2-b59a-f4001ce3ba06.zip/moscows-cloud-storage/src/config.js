import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
dotenv.config({ path: path.join(root, '.env'), quiet: true });

function boolean(value, fallback) {
  if (value === undefined) return fallback;
  return value.toLowerCase() === 'true';
}

export const config = {
  root,
  port: Number(process.env.PORT || 3000),
  botToken: process.env.BOT_TOKEN || '',
  chatId: process.env.TELEGRAM_CHAT_ID || '',
  telegramApiId: process.env.TELEGRAM_API_ID || '',
  telegramApiHash: process.env.TELEGRAM_API_HASH || '',
  telegramApiBase: (process.env.TELEGRAM_API_BASE_URL || 'http://127.0.0.1:8081').replace(/\/$/, ''),
  telegramAutoStart: boolean(process.env.TELEGRAM_AUTO_START, true),
  telegramLocalFileUpload: boolean(process.env.TELEGRAM_LOCAL_FILE_UPLOAD, true),
  telegramBinary: path.resolve(root, process.env.TELEGRAM_API_BINARY || 'vendor/telegram-bot-api/build/telegram-bot-api'),
  telegramDataDir: path.resolve(root, process.env.TELEGRAM_API_DATA_DIR || 'data/telegram-bot-api'),
  telegramTempDir: path.resolve(root, process.env.TELEGRAM_API_TEMP_DIR || 'data/telegram-bot-api-tmp'),
  telegramBuildJobs: Number(process.env.TELEGRAM_BUILD_JOBS || 2),
  dataFile: process.env.DATA_FILE || path.join(root, 'meg.json'),
  tempDir: process.env.TEMP_DIR || path.join(root, 'tmp'),
  maxFileSize: 2_000_000_000,
  encryptionSegmentSize: 16 * 1024 ** 2,
};

export function assertConfig() {
  if (!config.botToken) throw new Error('BOT_TOKEN is required. See README.md.');
  if (!config.chatId) throw new Error('TELEGRAM_CHAT_ID is required. See README.md.');
  if (config.telegramAutoStart && (!config.telegramApiId || !config.telegramApiHash)) {
    throw new Error('TELEGRAM_API_ID and TELEGRAM_API_HASH are required for automatic Bot API startup.');
  }
}
