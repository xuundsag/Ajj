(() => {
const icons = {
 play:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-play" viewBox="0 0 240 240" focusable="false"><path d="M62.8,199.5c-1,0.8-2.4,0.6-3.3-0.4c-0.4-0.5-0.6-1.1-0.5-1.8V42.6c-0.2-1.3,0.7-2.4,1.9-2.6c0.7-0.1,1.3,0.1,1.9,0.4l154.7,77.7c2.1,1.1,2.1,2.8,0,3.8L62.8,199.5z"/></svg>',
 pause:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-pause" viewBox="0 0 240 240" focusable="false"><path d="M100,194.9c0.2,2.6-1.8,4.8-4.4,5c-0.2,0-0.4,0-0.6,0H65c-2.6,0.2-4.8-1.8-5-4.4c0-0.2,0-0.4,0-0.6V45c-0.2-2.6,1.8-4.8,4.4-5c0.2,0,0.4,0,0.6,0h30c2.6-0.2,4.8,1.8,5,4.4c0,0.2,0,0.4,0,0.6V194.9z M180,45.1c0.2-2.6-1.8-4.8-4.4-5c-0.2,0-0.4,0-0.6,0h-30c-2.6-0.2-4.8,1.8-5,4.4c0,0.2,0,0.4,0,0.6V195c-0.2,2.6,1.8,4.8,4.4,5c0.2,0,0.4,0,0.6,0h30c2.6,0.2,4.8-1.8,5-4.4c0-0.2,0-0.4,0-0.6V45.1z"/></svg>',
 rewind:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-rewind" viewBox="0 0 240 240" focusable="false"><path d="M113.2,131.078a21.589,21.589,0,0,0-17.7-10.6,21.589,21.589,0,0,0-17.7,10.6,44.769,44.769,0,0,0,0,46.3,21.589,21.589,0,0,0,17.7,10.6,21.589,21.589,0,0,0,17.7-10.6,44.769,44.769,0,0,0,0-46.3Zm-17.7,47.2c-7.8,0-14.4-11-14.4-24.1s6.6-24.1,14.4-24.1,14.4,11,14.4,24.1S103.4,178.278,95.5,178.278Zm-43.4,9.7v-51l-4.8,4.8-6.8-6.8,13-13a4.8,4.8,0,0,1,8.2,3.4v62.7l-9.6-.1Zm162-130.2v125.3a4.867,4.867,0,0,1-4.8,4.8H146.6v-19.3h48.2v-96.4H79.1v19.3c0,5.3-3.6,7.2-8,4.3l-41.8-27.9a6.013,6.013,0,0,1-2.7-8,5.887,5.887,0,0,1,2.7-2.7l41.8-27.9c4.4-2.9,8-1,8,4.3v19.3H209.2A4.974,4.974,0,0,1,214.1,57.778Z"/></svg>',
 forward:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-forward" viewBox="0 0 240 240" focusable="false"><path d="M185,131.078a21.589,21.589,0,0,0-17.7-10.6,21.589,21.589,0,0,0-17.7,10.6,44.769,44.769,0,0,0,0,46.3,21.589,21.589,0,0,0,17.7,10.6,21.589,21.589,0,0,0,17.7-10.6,44.769,44.769,0,0,0,0-46.3Zm-17.7,47.2c-7.8,0-14.4-11-14.4-24.1s6.6-24.1,14.4-24.1,14.4,11,14.4,24.1S175.2,178.278,167.3,178.278Zm-43.4,9.7v-51l-4.8,4.8-6.8-6.8,13-13a4.8,4.8,0,0,1,8.2,3.4v62.7l-9.6-.1Zm-98-130.2v125.3a4.867,4.867,0,0,0,4.8,4.8H93.4v-19.3H45.2v-96.4H160.9v19.3c0,5.3,3.6,7.2,8,4.3l41.8-27.9a6.013,6.013,0,0,0,2.7-8,5.887,5.887,0,0,0-2.7-2.7l-41.8-27.9c-4.4-2.9-8-1-8,4.3v19.3H30.8A4.974,4.974,0,0,0,25.9,57.778Z"/></svg>',
 volume:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-volume-100" viewBox="0 0 240 240" focusable="false"><path d="M116.4,42.8v154.5c0,2.8-1.7,3.6-3.8,1.7l-54.1-48.1H29c-2.8,0-5.2-2.3-5.2-5.2V94.2c0-2.8,2.3-5.2,5.2-5.2h29.5l54.1-48.1C114.6,39.1,116.4,39.9,116.4,42.8z M192.3,120c0-31.3-18.6-59.6-47.5-71.8l-7.6,19.2c20.9,9.1,34.4,29.8,34.4,52.6s-13.5,43.5-34.4,52.6l7.6,19.2C173.7,179.6,192.3,151.3,192.3,120z M161.4,120c0-18.8-11.7-35.6-29.3-42.2l-7.6,19.3c13,5.9,18.7,21.2,12.8,34.2c-2.6,5.7-7.1,10.2-12.8,12.8l7.6,19.3C149.7,155.8,161.4,138.9,161.4,120z M144.8,27.2l-7.6,19.3c39.6,14.8,59.7,59,44.9,98.6c-7.8,20.9-24.2,37.4-45.2,45.2l7.6,19.3c50.2-17.5,76.7-72.4,59.2-122.6C194.2,59.4,172.5,37.6,144.8,27.2z"/></svg>',
 mute:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-volume-0" viewBox="0 0 240 240" focusable="false"><path d="M116.6,42.9v154.6c0,2.8-1.7,3.6-3.8,1.7l-54.1-48H29c-2.8,0-5.2-2.3-5.2-5.2V94.4c0-2.8,2.3-5.2,5.2-5.2h29.6l54.1-48C114.8,39.2,116.6,40,116.6,42.9z M198.2,120.1l26-26l-14.6-14.6l-26,26l-26-26L143,94.1l26,26l-26,26l14.6,14.6l26-26l26,26l14.6-14.6L198.2,120.1z"/></svg>',
 ccOff:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-cc-off" viewBox="0 0 240 240" focusable="false"><path d="M215,40H25c-2.7,0-5,2.2-5,5v150c0,2.7,2.2,5,5,5h190c2.7,0,5-2.2,5-5V45C220,42.2,217.8,40,215,40z M208.1,188.1H31.9V51.9h176.2V188.1z M77.7,108.9h-1.1c-0.1,1.6-0.2,3.4-0.2,5.4v11.6c0,2,0,3.8,0.1,5.4h1.1c0.3,4.2,3,6.5,8,6.7c3.6,0,6.6-1.9,7.6-5.4c0.2-0.7,0.9-1,1.6-0.8c0,0,0,0,0,0l9.8,2.9c0.6,0.2,1,0.8,0.8,1.5c0,0,0,0.1,0,0.1c-2.2,8.4-9,13.1-19.8,13.1c-14.2-0.2-21.5-8.4-21.8-24.6v-9.6c0.3-16.2,7.5-24.4,21.8-24.6c10.9,0,17.7,4.9,19.8,13.2c0.2,0.7-0.1,1.4-0.8,1.6l-9.9,2.8c-0.6,0.2-1.3-0.2-1.5-0.8c0,0,0,0,0-0.1c-1-3.5-4.1-5.4-7.6-5.4C80.7,102.4,78.1,104.6,77.7,108.9L77.7,108.9z M147.8,108.9h-1.1c-0.1,1.6-0.2,3.4-0.2,5.4v11.6c0,2,0,3.8,0.1,5.4h1.1c0.3,4.2,3,6.5,8,6.7c3.6,0,6.6-1.9,7.6-5.4c0.2-0.7,0.9-1,1.6-0.8c0,0,0,0,0,0l9.8,2.9c0.6,0.2,1,0.8,0.8,1.5c0,0,0,0.1,0,0.1c-2.2,8.4-9,13.1-19.8,13.1c-14.2-0.2-21.5-8.4-21.8-24.6v-9.6c0.3-16.2,7.5-24.4,21.8-24.6c10.9,0,17.7,4.9,19.8,13.2c0.2,0.7-0.1,1.4-0.8,1.6l-9.8,2.9c-0.6,0.2-1.3-0.2-1.5-0.8c0,0,0,0,0-0.1c-1-3.5-4.1-5.4-7.6-5.4C150.8,102.4,148.2,104.6,147.8,108.9L147.8,108.9z"/></svg>',
 ccOn:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-cc-on" viewBox="0 0 240 240" focusable="false"><path d="M215,40H25c-2.7,0-5,2.2-5,5v150c0,2.7,2.2,5,5,5h190c2.7,0,5-2.2,5-5V45C220,42.2,217.8,40,215,40z M108.1,137.7c0.7-0.7,1.5-1.5,2.4-2.3c-2.4,8.9-9.4,14-20.6,14c-14.2-0.2-21.5-8.4-21.8-24.6v-9.6c0.3-16.2,7.5-24.4,21.8-24.6c10.9,0,17.7,4.9,19.8,13.2c0.2,0.7-0.1,1.4-0.8,1.6l-9.9,2.8c-0.6,0.2-1.3-0.2-1.5-0.8c0,0,0,0,0-0.1c-1-3.5-4.1-5.4-7.6-5.4c-5,0.2-7.7,2.4-8,6.7h-1.1c-0.1,1.6-0.2,3.4-0.2,5.4v11.6c0,2,0,3.8,0.1,5.4h1.1c0.3,4.2,3,6.5,8,6.7c3.6,0,6.6-1.9,7.6-5.4c0.2-0.7,0.9-1,1.6-0.8c0,0,0,0,0,0l9.8,2.9c0.6,0.2,1,0.8,0.8,1.5c0,0,0,0.1,0,0.1C109.2,136.7,108.7,137.2,108.1,137.7z M178.2,137.7c0.7-0.7,1.5-1.5,2.4-2.3c-2.4,8.9-9.4,14-20.6,14c-14.2-0.2-21.5-8.4-21.8-24.6v-9.6c0.3-16.2,7.5-24.4,21.8-24.6c10.9,0,17.7,4.9,19.8,13.2c0.2,0.7-0.1,1.4-0.8,1.6l-9.8,2.9c-0.6,0.2-1.3-0.2-1.5-0.8c0,0,0,0,0-0.1c-1-3.5-4.1-5.4-7.6-5.4c-5,0.2-7.7,2.4-8,6.7h-1.1c-0.1,1.6-0.2,3.4-0.2,5.4v11.6c0,2,0,3.8,0.1,5.4h1.1c0.3,4.2,3,6.5,8,6.7c3.6,0,6.6-1.9,7.6-5.4c0.2-0.7,0.9-1,1.6-0.8c0,0,0,0,0,0l9.8,2.9c0.6,0.2,1,0.8,0.8,1.5c0,0,0,0.1,0,0.1C179.3,136.7,178.8,137.2,178.2,137.7z"/></svg>',
 settings:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-settings" viewBox="0 0 240 240" focusable="false"><path d="M204,145l-25-14c0.8-3.6,1.2-7.3,1-11c0.2-3.7-0.2-7.4-1-11l25-14c2.2-1.6,2.9-4.5,1.6-6.9l-16-28c-1.4-2.1-4.1-2.9-6.4-1.9l-25,14c-6-4.2-12.3-7.9-19-11v-28c0.2-2.6-1.8-4.8-4.4-5c-0.2,0-0.4,0-0.6,0h-31c-2.6,0.2-4.6,2.4-4.4,5c0,0.2,0,0.4,0,0.6v28c-6.7,3.1-13,6.7-19,11L56,63c-2.4-0.8-5.1,0.1-6.4,2.2l-16,28c-1.1,2.3-0.4,5.1,1.6,6.7l25,14c-0.8,3.6-1.2,7.3-1,11c-0.2,3.7,0.2,7.4,1,11l-25,14c-2.2,1.6-2.9,4.5-1.6,6.9l16,28c1.4,2.1,4.1,2.9,6.4,1.9l25-14c6,4.2,12.3,7.9,19,11v28c-0.2,2.6,1.8,4.8,4.4,5c0.2,0,0.4,0,0.6,0h31c2.6-0.2,4.6-2.4,4.4-5c0-0.2,0-0.4,0-0.6v-28c7-3.4,13.7-7.1,20-11l23.7,14c2.4,0.8,5.1-0.1,6.4-2.2l16-28C207.2,149.3,206.4,146.5,204,145z M119.7,149.7c-16.6,0-30-13.4-30-30s13.4-30,30-30s30,13.4,30,30c0.2,16.4-12.9,29.8-29.3,30C120.2,149.7,120,149.7,119.7,149.7z"/></svg>',
 pip:'<svg class="jw-svg-icon jw-svg-icon-pip-off" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M21 3C22.1 3 23 3.9 23 5V12H21V5H3V19H12V21H3C1.9 21 1 20.1 1 19V5C1 3.9 1.9 3 3 3H21ZM22 14C22.55 14 23 14.45 23 15V20C23 20.55 22.55 21 22 21H15C14.45 21 14 20.55 14 20V15C14 14.45 14.45 14 15 14H22Z"/><path d="M5.79289 7.20711C5.40237 6.81658 5.40237 6.18342 5.79289 5.79289C6.18342 5.40237 6.81658 5.40237 7.20711 5.79289L10 8.58579V7C10 6.44772 10.4477 6 11 6C11.5523 6 12 6.44772 12 7V11C12 11.5523 11.5523 12 11 12H7C6.44772 12 6 11.5523 6 11C6 10.4477 6.44772 10 7 10H8.58579L5.79289 7.20711Z"/></svg>',
 fullscreen:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-fullscreen-on" viewBox="0 0 240 240" focusable="false"><path d="M96.3,186.1c1.9,1.9,1.3,4-1.4,4.4l-50.6,8.4c-1.8,0.5-3.7-0.6-4.2-2.4c-0.2-0.6-0.2-1.2,0-1.7l8.4-50.6c0.4-2.7,2.4-3.4,4.4-1.4l14.5,14.5l28.2-28.2l14.3,14.3l-28.2,28.2L96.3,186.1z M195.8,39.1l-50.6,8.4c-2.7,0.4-3.4,2.4-1.4,4.4l14.5,14.5l-28.2,28.2l14.3,14.3l28.2-28.2l14.5,14.5c1.9,1.9,4,1.3,4.4-1.4l8.4-50.6c0.5-1.8-0.6-3.6-2.4-4.2C197,39,196.4,39,195.8,39.1L195.8,39.1z"/></svg>',
 exitFullscreen:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-fullscreen-off" viewBox="0 0 240 240" focusable="false"><path d="M109.2,134.9l-8.4,50.1c-0.4,2.7-2.4,3.3-4.4,1.4L82,172l-27.9,27.9l-14.2-14.2l27.9-27.9l-14.4-14.4c-1.9-1.9-1.3-3.9,1.4-4.4l50.1-8.4c1.8-0.5,3.6,0.6,4.1,2.4C109.4,133.7,109.4,134.3,109.2,134.9L109.2,134.9z M172.1,82.1L200,54.2L185.8,40l-27.9,27.9l-14.4-14.4c-1.9-1.9-3.9-1.3-4.4,1.4l-8.4,50.1c-0.5,1.8,0.6,3.6,2.4,4.1c0.5,0.2,1.2,0.2,1.7,0l50.1-8.4c2.7-0.4,3.3-2.4,1.4-4.4L172.1,82.1z"/></svg>',
 audioTracks:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-audiotracks" viewBox="0 0 24 24" fill="currentColor"><path d="M12 1a9 9 0 0 0-9 9v7a3 3 0 0 0 3 3h2v-8H5v-2a7 7 0 0 1 14 0v2h-3v8h2a3 3 0 0 0 3-3v-7a9 9 0 0 0-9-9Z"/><path d="M10 15h4v2h-4v-2Zm0-4h6v2h-6v-2Zm0 8h3v2h-3v-2Z"/></svg>',
 quality:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-quality-100" viewBox="0 0 240 240" focusable="false"><path d="M55,200H35c-3,0-5-2-5-4c0,0,0,0,0,0v-21c0-3,2-5,4-5c0,0,0,0,0,0h21c3,0,5,2,5,4c0,0,0,0,0,0v21C60,198,58,200,55,200z M110,144c0-2-2-4-4-4c0,0,0,0,0,0H85c-3,0-5,2-5,5v50c0,3,2,5,4,5c0,0,0,0,0,0h21c3,0,5-2,5-4c0,0,0,0,0,0V144z M160,94c0-2-2-4-4-4c0,0,0,0,0,0h-21c-3,0-5,2-5,5v100c0,3,2,5,4,5c0,0,0,0,0,0h21c3,0,5-2,5-4c0,0,0,0,0,0V94z M210,44c0-2-2-4-4-4c0,0,0,0,0,0h-21c-3,0-5,2-5,5v150c0,3,2,5,4,5c0,0,0,0,0,0h21c3,0,5-2,5-4c0,0,0,0,0,0V44z"/></svg>',
 speed:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-playback-rates" viewBox="0 0 240 240" focusable="false"><path d="M159.9,99.9c0-5.5-4.5-10-10-10s-10,4.5-10,10v11.8L120,100V45c0-2.7-2.2-5-5-5c-52.5,0-95,42.5-95,95s42.5,95,95,95s95-42.5,95-95c0-2.7-2.2-5-5-5h-55l19.9-11.8V99.9z M120,200c-35.8,0-65-29.2-65-65c0-32.5,24-59.4,55.2-64.2V115c0,8.3,6.7,15,15,15h44.2C164.4,169.9,144.3,200,120,200z"/></svg>',
 close:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon jw-svg-icon-close" viewBox="0 0 240 240" focusable="false"><path d="M134.8,120l48.6-48.6c2-1.9,2.1-5.1,0.2-7.1c-0.1-0.1-0.1-0.1-0.2-0.2l-7.7-7.7c-1.9-2-5.1-2.1-7.1-0.2c-0.1,0.1-0.1,0.1-0.2,0.2L120,105.2L71.4,56.6c-1.9-2-5.1-2.1-7.1-0.2c-0.1,0.1-0.1,0.1-0.2,0.2l-7.9,7.8c-2,1.9-2.1,5.1-0.2,7.1c0.1,0.1,0.1,0.1,0.2,0.2L105.2,120l-48.6,48.6c-2,1.9-2.1,5.1-0.2,7.1c0.1,0.1,0.1,0.1,0.2,0.2l7.7,7.7c1.9,2,5.1,2.1,7.1,0.2c0.1-0.1,0.1-0.1,0.2-0.2l48.6-48.6l48.6,48.6c1.9,2,5.1,2.1,7.1,0.2c0.1-0.1,0.1-0.1,0.2-0.2l7.7-7.7c2-1.9,2.1-5.1,0.2-7.1c-0.1-0.1-0.1-0.1-0.2-0.2L134.8,120z"/></svg>',
 back:'<svg xmlns="http://www.w3.org/2000/svg" class="jw-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>'
};

const defaultCaptionStyle={size:'100',color:'white',background:'black',backgroundOpacity:'65',textOpacity:'100',font:'sans',edge:'shadow',position:'bottom'};
const captionColors={white:[255,255,255],yellow:[255,235,59],cyan:[77,238,234],green:[129,255,138],magenta:[255,121,214],orange:[255,154,85],black:[0,0,0],navy:[14,24,44]};
const captionFonts={sans:'Arial, Helvetica, sans-serif',system:'system-ui, -apple-system, Segoe UI, Roboto, sans-serif',serif:'Georgia, "Times New Roman", serif',mono:'"Courier New", monospace'};
const captionEdges={none:'none',shadow:'0 2px 4px rgba(0,0,0,.95), 0 0 2px rgba(0,0,0,.9)',outline:'-1.5px -1.5px 0 #000, 1.5px -1.5px 0 #000, -1.5px 1.5px 0 #000, 1.5px 1.5px 0 #000, 0 2px 4px rgba(0,0,0,.9)',raised:'0 1px 0 #222, 0 2px 0 #111, 0 3px 5px rgba(0,0,0,.9)',depressed:'0 -1px 0 #000, 0 1px 1px rgba(255,255,255,.35)'};
const captionOptions=[
 ['size','Font size',[['75','75%'],['100','100%'],['125','125%'],['150','150%'],['175','175%'],['200','200%']]],
 ['color','Text color',[['white','White'],['yellow','Yellow'],['cyan','Cyan'],['green','Green'],['orange','Orange'],['magenta','Magenta']]],
 ['background','Background',[['black','Black'],['navy','Dark blue'],['white','White']]],
 ['backgroundOpacity','Window opacity',[['0','0%'],['25','25%'],['50','50%'],['65','65%'],['75','75%'],['100','100%']]],
 ['textOpacity','Text opacity',[['100','100%'],['85','85%'],['75','75%'],['50','50%']]],
 ['font','Font family',[['sans','Sans-serif'],['system','Clean UI'],['serif','Serif'],['mono','Monospace']]],
 ['edge','Edge style',[['shadow','Drop shadow'],['outline','Uniform outline'],['raised','Raised'],['depressed','Depressed'],['none','None']]],
 ['position','Position',[['bottom','Bottom'],['middle','Middle'],['top','Top']]]
];
const servers=[
 ['default','Primary Stream','Best available HLS stream'],
 ['second','Streams 2','Alternate server Pool'],
 ['vidlink','Vidlink','Direct backup server'],
 ['vidsrc','Vidsrc','Secondary backup server']
];
const esc=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const rgba=(rgb,opacity)=>`rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${Math.max(0,Math.min(1,Number(opacity)/100))})`;
function formatClock(seconds){
 if(!Number.isFinite(seconds)||seconds<0)seconds=0;
 let total=Math.floor(seconds),h=Math.floor(total/3600),m=Math.floor(total/60)%60,s=String(total%60).padStart(2,'0');
 return h?`${h}:${String(m).padStart(2,'0')}:${s}`:`${m}:${s}`;
}
function loadCaptionStyle(){
 try{return {...defaultCaptionStyle,...JSON.parse(localStorage.getItem('moscowtv-caption-style')||'{}')}}
 catch{return {...defaultCaptionStyle}}
}
function saveCaptionStyle(style){try{localStorage.setItem('moscowtv-caption-style',JSON.stringify(style))}catch{}}

function create(player,options={}){
 const host=player.el(),data=options.data||{},item=options.item||{},isAnime=item.type==='anime';
 host.classList.add('mp-host');
 let hideTimer=null,loaderTimer=null,tapSeekTimer=null,singleTapTimer=null,captionStyle=loadCaptionStyle(),activeTrack=null,captionCueHandler=null,selectedTrackKey=-1;
 let previewPlayer=null,previewReady=false,previewBusy=false,queuedPreviewTime=null,lastPreviewTime=-99,previewTimer=null,scrubPointerId=null,scrubStartX=0,scrubHoldReady=false,scrubPendingPercent=0;
 let audioContext=null,gainNode=null,boostPercent=100,orientationLocked=false,disposed=false;
 let pointerStart=null,lastPointerUpAt=0,lastSideTap={side:'',time:0},activeSkipSide='',lastSkipAt=0,skipAccum=0;

 // Lazy remote subtitle catalog: 0 HTTP requests on load; fetched on-demand when selected!
 const remoteCatalog=(Array.isArray(data.tracks)?data.tracks:[]).filter(t=>t?.src).map((t,i)=>({...t,id:'remote-'+i,loadedTrack:null,loading:false}));
 const remoteTrackObjects=new WeakSet();

 const ui=document.createElement('div');
 ui.className='mp-ui';
 ui.dataset.active='true';
 ui.dataset.paused=options.autoplay===false?'true':'false';
 ui.dataset.autoplay=options.autoplay===false?'false':'true';
 ui.dataset.loading=options.autoplay===false?'false':'true';
 ui.dataset.seeking='false';
 ui.dataset.scrubbing='false';
 ui.innerHTML=`
  <div class="mp-loader" aria-hidden="true"></div>
  <div class="mp-tap-seek" data-side="left" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg><span data-seek-text>10s</span></div>
  <div class="mp-tap-seek" data-side="right" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg><span data-seek-text>10s</span></div>
  <div class="mp-captions" aria-live="off"></div>
  <button type="button" class="mp-center-play" aria-label="Play">${icons.play}</button>
  <button type="button" class="mp-skip mp-skip-intro" hidden>Skip Intro</button>
  <button type="button" class="mp-skip mp-skip-outro" hidden>Skip Outro</button>
  <div class="mp-bottom">
   <div class="mp-seek-area">
    <div class="mp-seek-preview" hidden><canvas width="192" height="108"></canvas><span class="mp-preview-time">0:00</span></div>
    <div class="mp-seek-rail">
     <div class="mp-seek-buffer"></div>
     <div class="mp-seek-marker mp-intro-marker" hidden></div>
     <div class="mp-seek-marker mp-outro-marker" hidden></div>
     <div class="mp-seek-progress"></div>
    </div>
    <span class="mp-seek-dot" aria-hidden="true"></span>
    <input class="mp-seek-input" type="range" min="0" max="1000" step="1" value="0" aria-label="Seek">
   </div>
   <div class="mp-control-row">
    <button type="button" class="mp-button mp-play-control" aria-label="Play">${icons.play}</button>
    <button type="button" class="mp-button mp-rewind" aria-label="Rewind 10 seconds">${icons.rewind}</button>
    <button type="button" class="mp-button mp-forward" aria-label="Forward 10 seconds">${icons.forward}</button>
    <button type="button" class="mp-button mp-mute" aria-label="Mute">${icons.volume}</button>
    <div class="mp-time"><span data-mp-current>0:00</span><span class="mp-time-separator"> / </span><span data-mp-duration>0:00</span></div>
    <div class="mp-spacer"></div>
    <button type="button" class="mp-button mp-cc-button" aria-label="Subtitles">${icons.ccOff}</button>
    <button type="button" class="mp-button mp-settings-button" aria-label="Settings">${icons.settings}</button>
    <button type="button" class="mp-button mp-pip" aria-label="Picture in Picture">${icons.pip}</button>
    <button type="button" class="mp-button mp-fullscreen" aria-label="Fullscreen">${icons.fullscreen}</button>
   </div>
  </div>
  <div class="mp-settings" role="dialog" aria-label="Player settings" hidden>
   <div class="mp-settings-tabs" role="tablist">
    <button type="button" class="mp-button mp-tab active" data-tab="cc" aria-label="Subtitles">${icons.ccOff}</button>
    <button type="button" class="mp-button mp-tab" data-tab="audio" aria-label="Audio">${icons.audioTracks}</button>
    <button type="button" class="mp-button mp-tab" data-tab="quality" aria-label="Quality and servers">${icons.quality}</button>
    <button type="button" class="mp-button mp-tab" data-tab="speed" aria-label="Playback">${icons.speed}</button>
    <button type="button" class="mp-button mp-tab" data-tab="boost" aria-label="Audio boost">${icons.volume}</button>
    <button type="button" class="mp-button mp-settings-close" aria-label="Close settings">${icons.close}</button>
   </div>
   <div class="mp-panel" data-panel="cc">
    <div class="mp-track-list"></div>
    <button type="button" class="mp-subtitle-settings-link" data-open-caption-style>Settings</button>
   </div>
   <div class="mp-panel" data-panel="caption-style" hidden>
    <div class="mp-style-header"><button type="button" class="mp-button" data-back-cc aria-label="Back to subtitles">${icons.back}</button><strong>Subtitle Style</strong></div>
    <div class="mp-caption-preview"><span class="mp-caption-sample">Captions look like this</span></div>
    <div class="mp-style-controls">${captionOptions.map(([key,label,choices])=>`<label class="mp-style-row"><span>${esc(label)}</span><select data-caption-style="${key}">${choices.map(([v,text])=>`<option value="${v}">${esc(text)}</option>`).join('')}</select></label>`).join('')}</div>
    <button type="button" class="mp-reset-style" data-reset-caption-style>Reset</button>
   </div>
   <div class="mp-panel" data-panel="audio" hidden><div class="mp-audio-list"></div></div>
   <div class="mp-panel" data-panel="quality" hidden>
    <div class="mp-quality-list"></div>
    <div class="mp-server-section"><h3>Stream Server</h3><div class="mp-server-list"></div></div>
   </div>
   <div class="mp-panel" data-panel="speed" hidden><div class="mp-speed-list"></div></div>
   <div class="mp-panel" data-panel="boost" hidden>
    <div class="mp-boost-wrap">
     <div class="mp-boost-heading"><span>Volume Boost</span><strong data-boost-label>100%</strong></div>
     <input type="range" min="100" max="400" step="10" value="100" data-boost-input aria-label="Volume boost">
     <div class="mp-boost-labels"><span>1x</span><span>2x</span><span>3x</span><span>4x</span></div>
    </div>
   </div>
  </div>`;
 host.appendChild(ui);

 const $=sel=>ui.querySelector(sel),$$=sel=>[...ui.querySelectorAll(sel)];
 const centerPlay=$('.mp-center-play'),playButton=$('.mp-play-control'),muteButton=$('.mp-mute'),ccButton=$('.mp-cc-button'),fullscreenButton=$('.mp-fullscreen'),pipButton=$('.mp-pip');
 const seekArea=$('.mp-seek-area'),seekInput=$('.mp-seek-input'),seekProgress=$('.mp-seek-progress'),seekBuffer=$('.mp-seek-buffer'),seekPreview=$('.mp-seek-preview'),previewCanvas=$('.mp-seek-preview canvas'),previewTime=$('.mp-preview-time');
 const currentEl=$('[data-mp-current]'),durationEl=$('[data-mp-duration]'),captionsEl=$('.mp-captions'),settings=$('.mp-settings');
 const skipIntro=$('.mp-skip-intro'),skipOutro=$('.mp-skip-outro'),introMarker=$('.mp-intro-marker'),outroMarker=$('.mp-outro-marker');
 const tapLeft=$('.mp-tap-seek[data-side="left"]'),tapRight=$('.mp-tap-seek[data-side="right"]');

 if(!document.pictureInPictureEnabled)pipButton.hidden=true;

 const showControls=()=>{
  ui.dataset.active='true';
  clearTimeout(hideTimer);
  if(settings.hidden&&ui.dataset.scrubbing!=='true')hideTimer=setTimeout(()=>{if(settings.hidden&&ui.dataset.scrubbing!=='true')ui.dataset.active='false'},3000);
 };
 const hideControls=()=>{clearTimeout(hideTimer);if(settings.hidden&&ui.dataset.scrubbing!=='true')ui.dataset.active='false'};
 const toggleControls=()=>{if(ui.dataset.active==='true')hideControls();else showControls()};

 function triggerTapSeek(side,seconds){
  const el=side==='left'?tapLeft:tapRight,other=side==='left'?tapRight:tapLeft;
  other.classList.remove('is-animating');
  el.querySelector('[data-seek-text]').textContent=`${seconds}s`;
  el.classList.remove('is-animating');
  void el.offsetWidth;
  el.classList.add('is-animating');
  clearTimeout(tapSeekTimer);
  tapSeekTimer=setTimeout(()=>{el.classList.remove('is-animating')},700);
 }

 function applyCaptionStyle(){
  let fg=captionColors[captionStyle.color]||captionColors.white,bg=captionColors[captionStyle.background]||captionColors.black;
  host.style.setProperty('--mp-subtitle-scale',String(Number(captionStyle.size||100)/100));
  host.style.setProperty('--mp-subtitle-color',rgba(fg,captionStyle.textOpacity));
  host.style.setProperty('--mp-subtitle-background',rgba(bg,captionStyle.backgroundOpacity));
  host.style.setProperty('--mp-subtitle-font',captionFonts[captionStyle.font]||captionFonts.sans);
  host.style.setProperty('--mp-subtitle-shadow',captionEdges[captionStyle.edge]||captionEdges.shadow);
  ui.dataset.captionPosition=captionStyle.position||'bottom';
  for(let select of $$('[data-caption-style]'))select.value=captionStyle[select.dataset.captionStyle]||defaultCaptionStyle[select.dataset.captionStyle];
 }

 function manualTracks(){
  return Array.from(player.textTracks()||[]).filter(t=>(t.kind==='subtitles'||t.kind==='captions')&&!remoteTrackObjects.has(t));
 }
 function combinedTracks(){
  let manual=manualTracks().map((t,i)=>({kind:'manual',track:t,label:t.label||t.language||`Subtitle ${i+1}`}));
  let remote=remoteCatalog.map((entry,i)=>({kind:'remote',entry,label:entry.label||entry.language||`Subtitle ${manual.length+i+1}`}));
  return [...manual,...remote];
 }
 function disableAllNativeTracks(){
  for(let track of Array.from(player.textTracks()||[]))if(track.kind==='subtitles'||track.kind==='captions')track.mode='disabled';
 }
 function renderCaptions(){
  captionsEl.innerHTML='';
  if(!activeTrack?.activeCues?.length)return;
  const seen=new Set();
  for(let i=0;i<activeTrack.activeCues.length;i++){
   let text=String(activeTrack.activeCues[i].text||'').replace(/<[^>]+>/g,'').replace(/\{\\[^}]+\}/g,'').trim();
   if(!text||seen.has(text))continue;
   seen.add(text);
   let line=document.createElement('div'),span=document.createElement('span');
   line.className='mp-caption-cue';span.className='mp-caption-text';span.textContent=text;
   line.appendChild(span);captionsEl.appendChild(line);
  }
 }
 function bindActiveTrack(track){
  if(activeTrack&&captionCueHandler)activeTrack.removeEventListener('cuechange',captionCueHandler);
  activeTrack=track||null;
  if(activeTrack){
   activeTrack.mode='showing';
   captionCueHandler=()=>renderCaptions();
   activeTrack.addEventListener('cuechange',captionCueHandler);
  }
  renderCaptions();
 }
 function selectSubtitle(index){
  disableAllNativeTracks();
  let items=combinedTracks(),chosen=index>=0?items[index]:null;
  selectedTrackKey=chosen?index:-1;
  if(!chosen){
   bindActiveTrack(null);
  }else if(chosen.kind==='manual'){
   bindActiveTrack(chosen.track);
  }else if(chosen.kind==='remote'){
   let entry=chosen.entry;
   if(entry.loadedTrack){
    bindActiveTrack(entry.loadedTrack);
   }else{
    bindActiveTrack(null);
    let el=player.addRemoteTextTrack({kind:entry.kind||'subtitles',src:entry.src,label:entry.label,language:entry.language||'und',default:false},false);
    let tr=el?.track||el;
    if(tr){
     remoteTrackObjects.add(tr);
     entry.loadedTrack=tr;
     tr.mode='showing';
     if(el?.addEventListener)el.addEventListener('load',()=>{if(selectedTrackKey===index)renderCaptions()},{once:true});
     bindActiveTrack(tr);
    }
   }
  }
  let on=selectedTrackKey>=0;
  ccButton.innerHTML=on?icons.ccOn:icons.ccOff;
  ccButton.classList.toggle('on',on);
  let tab=$('[data-tab="cc"]');if(tab)tab.innerHTML=on?icons.ccOn:icons.ccOff;
  renderTracks();
 }
 function renderTracks(){
  let items=combinedTracks(),list=$('.mp-track-list');
  list.innerHTML=`<button type="button" class="mp-list-row ${selectedTrackKey<0?'selected':''}" data-track="-1"><span>Off</span></button>`+items.map((item,i)=>`<button type="button" class="mp-list-row ${selectedTrackKey===i?'selected':''}" data-track="${i}"><span>${esc(item.label)}</span></button>`).join('');
 }

 function qualityLevels(){return player.qualityLevels?.()||null}
 function uniqueQualities(){
  let levels=qualityLevels();if(!levels||!levels.length)return [];
  let byHeight=new Map();
  for(let i=0;i<levels.length;i++){
   let level=levels[i],height=Number(level.height)||0;if(!height)continue;
   if(!byHeight.has(height))byHeight.set(height,[]);
   byHeight.get(height).push(i);
  }
  return [...byHeight.entries()].sort((a,b)=>b[0]-a[0]);
 }
 function selectedQuality(){
  let levels=qualityLevels();if(!levels||!levels.length)return 'auto';
  let enabled=[];for(let i=0;i<levels.length;i++)if(levels[i].enabled)enabled.push(levels[i]);
  if(!enabled.length||enabled.length===levels.length)return 'auto';
  let heights=new Set(enabled.map(x=>Number(x.height)||0).filter(Boolean));
  return heights.size===1?String([...heights][0]):'auto';
 }
 function selectQuality(value){
  let levels=qualityLevels();if(!levels)return;
  for(let i=0;i<levels.length;i++)levels[i].enabled=value==='auto'||String(levels[i].height)===String(value);
  try{localStorage.setItem('moscowtv-quality',String(value))}catch{}
  renderQuality();
 }
 function renderQuality(){
  let rows=uniqueQualities(),current=selectedQuality(),list=$('.mp-quality-list'),activeHeight=player.videoHeight?.()||0;
  let autoHint=current==='auto'&&activeHeight?`<b>${activeHeight}p</b>`:'';
  list.innerHTML=rows.length?`<button type="button" class="mp-list-row ${current==='auto'?'selected':''}" data-quality="auto"><span>Auto</span>${autoHint}</button>`+rows.map(([h])=>`<button type="button" class="mp-list-row ${current===String(h)?'selected':''}" data-quality="${h}"><span>${h}p</span>${h>=1080?'<b>HD</b>':''}</button>`).join(''):`<div class="mp-empty">${activeHeight?`Direct ${activeHeight}p stream`:'Stream quality managed automatically'}</div>`;
  const serverSection=$('.mp-server-section'),serverList=$('.mp-server-list');
  if(isAnime){
   serverSection.innerHTML='<h3>Stream Source</h3><p>MegaPlay HLS stream. Switch Japanese Sub or English Dub in the Audio tab.</p>';
  }else{
   let currentServer=options.server||'default';
   serverList.innerHTML=servers.map(([key,name,hint])=>`<button type="button" class="mp-list-row ${currentServer===key?'selected':''}" data-server-choice="${key}"><span>${esc(name)}</span><b>${esc(hint.split(' ')[0])}</b></button>`).join('');
  }
 }

 function renderAudio(){
  const list=$('.mp-audio-list');
  if(isAnime){
   let currentLang=options.lang||'sub';
   list.innerHTML=[['sub','Sub','Japanese'],['dub','Dub','English']].map(([key,label,hint])=>`<button type="button" class="mp-list-row ${currentLang===key?'selected':''}" data-audio-choice="${key}"><span>${label}</span><b>${hint}</b></button>`).join('');
   return;
  }
  let tracks=Array.from(player.audioTracks?.()||[]);
  if(tracks.length>1){
   list.innerHTML=tracks.map((track,i)=>`<button type="button" class="mp-list-row ${track.enabled?'selected':''}" data-audio-track="${i}"><span>${esc(track.label||track.language||`Audio ${i+1}`)}</span></button>`).join('');
  }else{
   list.innerHTML='<div class="mp-empty">Original stream audio active. Alternate server streams live in the Quality tab.</div>';
  }
 }

 function renderPlaybackSettings(){
  let rate=Number(player.playbackRate()||1),rates=[0.5,0.75,1,1.25,1.5,2];
  let autoplay=localStorage.getItem('moscowtv-autoplay')!=='false',autonext=localStorage.getItem('moscowtv-autonext')!=='false',autoskip=localStorage.getItem('moscowtv-autoskip')==='true';
  $('.mp-speed-list').innerHTML=rates.map(v=>`<button type="button" class="mp-list-row ${Math.abs(rate-v)<.01?'selected':''}" data-rate="${v}"><span>${v===1?'Normal':v+'x'}</span></button>`).join('')+`
   <div class="mp-server-section"><h3>Preferences</h3>
    <button type="button" class="mp-list-row ${autoplay?'selected':''}" data-playback-setting="autoplay"><span>Auto Play</span><b>${autoplay?'On':'Off'}</b></button>
    <button type="button" class="mp-list-row ${autonext?'selected':''}" data-playback-setting="autonext"><span>Auto Next</span><b>${autonext?'On':'Off'}</b></button>
    <button type="button" class="mp-list-row ${autoskip?'selected':''}" data-playback-setting="autoskip"><span>Auto Skip Intro/Outro</span><b>${autoskip?'On':'Off'}</b></button>
   </div>`;
 }

 function ensureBoost(value){
  boostPercent=Math.max(100,Math.min(400,Number(value)||100));
  $('[data-boost-label]').textContent=`${boostPercent}%`;
  $('[data-boost-input]').value=String(boostPercent);
  if(boostPercent===100&&!audioContext)return;
  try{
   const Ctx=window.AudioContext||window.webkitAudioContext;
   if(!Ctx)return;
   if(!audioContext){
    audioContext=new Ctx();
    let mediaEl=player.tech({IWillNotUseThisInPlugins:true})?.el?.()||host.querySelector('video');
    let source=audioContext.createMediaElementSource(mediaEl);
    gainNode=audioContext.createGain();
    source.connect(gainNode);gainNode.connect(audioContext.destination);
   }
   if(audioContext.state==='suspended')audioContext.resume().catch(()=>{});
   if(gainNode)gainNode.gain.value=boostPercent/100;
  }catch{}
 }

 function openSettings(tab='cc'){
  settings.hidden=false;
  showPanel(tab);
  renderTracks();renderAudio();renderQuality();renderPlaybackSettings();
  ui.dataset.active='true';clearTimeout(hideTimer);
 }
 function closeSettings(){settings.hidden=true;showControls()}
 function showPanel(name){
  for(let tab of $$('.mp-tab'))tab.classList.toggle('active',tab.dataset.tab===(name==='caption-style'?'cc':name));
  for(let panel of $$('[data-panel]'))panel.hidden=panel.dataset.panel!==name;
 }

 function updateLoading(){
  let preStart=!player.hasStarted()&&ui.dataset.autoplay==='true';
  let isSeeking=Boolean(player.seeking());
  let isBuffering=Boolean(!player.error()&&(player.hasClass('vjs-waiting')||(isSeeking&&player.readyState()<3)||(!player.paused()&&player.hasStarted()&&player.readyState()<2)));
  ui.dataset.seeking=String(isSeeking);
  if(preStart){
   clearTimeout(loaderTimer);loaderTimer=null;
   ui.dataset.loading='true';
  }else if(isBuffering){
   if(ui.dataset.loading!=='true'&&!loaderTimer){
    loaderTimer=setTimeout(()=>{loaderTimer=null;updateLoading()},140);
   }
  }else{
   clearTimeout(loaderTimer);loaderTimer=null;
   ui.dataset.loading='false';
  }
 }
 function updatePlay(){
  if(player.hasStarted())ui.dataset.autoplay='false';
  let paused=player.paused();
  ui.dataset.paused=String(paused);
  updateLoading();
  playButton.innerHTML=paused?icons.play:icons.pause;
  playButton.setAttribute('aria-label',paused?'Play':'Pause');
  centerPlay.innerHTML=icons.play;
  centerPlay.setAttribute('aria-label',player.currentTime()>0?'Resume':'Play');
 }
 function updateVolume(){
  let muted=player.muted()||player.volume()===0;
  muteButton.innerHTML=muted?icons.mute:icons.volume;
  muteButton.setAttribute('aria-label',muted?'Unmute':'Mute');
 }
 function placeMarker(el,range,duration){
  let start=Number(range?.start),end=Number(range?.end);
  if(!(duration>0&&Number.isFinite(start)&&Number.isFinite(end)&&end>start&&start<duration)){el.hidden=true;return}
  let left=Math.max(0,Math.min(100,start/duration*100)),right=Math.max(left,Math.min(100,end/duration*100));
  el.style.left=`${left}%`;el.style.width=`${Math.max(.6,right-left)}%`;el.hidden=false;
 }
 function updateSkip(){
  let current=player.currentTime()||0,intro=data.intro,outro=data.outro;
  skipIntro.hidden=!(Number(intro?.end)>Number(intro?.start)&&current>=Number(intro.start)&&current<Number(intro.end)-.4);
  skipOutro.hidden=!(Number(outro?.end)>Number(outro?.start)&&current>=Number(outro.start)&&current<Number(outro.end)-.4);
 }
 function updateTime(){
  let duration=player.duration(),current=player.currentTime()||0;
  currentEl.textContent=formatClock(current);
  if(Number.isFinite(duration)&&duration>0){
   durationEl.textContent=formatClock(duration);
   if(ui.dataset.scrubbing!=='true'){
    let pct=Math.max(0,Math.min(100,current/duration*100));
    seekProgress.style.width=`${pct}%`;
    seekInput.value=String(Math.round(pct*10));
   }
   let buffered=player.buffered();
   let end=buffered?.length?buffered.end(buffered.length-1):0;
   seekBuffer.style.width=`${Math.max(0,Math.min(100,end/duration*100))}%`;
   placeMarker(introMarker,data.intro,duration);
   placeMarker(outroMarker,data.outro,duration);
  }
  updateSkip();
 }

 function ensurePreviewPlayer(){
  if(previewPlayer||disposed||!data.src)return;
  const holder=document.createElement('video');
  holder.className='video-js mp-preview-source';
  holder.muted=true;holder.playsInline=true;holder.preload='metadata';
  holder.setAttribute('aria-hidden','true');
  host.appendChild(holder);
  previewPlayer=window.videojs(holder,{
   controls:false,muted:true,preload:'metadata',inactivityTimeout:0,
   html5:{vhs:{overrideNative:true,enableLowInitialPlaylist:true,limitRenditionByPlayerDimensions:true,bandwidth:280000,goalBufferLength:2,maxGoalBufferLength:4,backBufferLength:2},nativeAudioTracks:false,nativeTextTracks:false}
  });
  previewPlayer.src({src:data.src,type:data.type||'application/x-mpegURL'});
  previewPlayer.one('loadedmetadata',()=>{
   let levels=previewPlayer.qualityLevels?.();
   if(levels?.length){
    let minIndex=0,minScore=Infinity;
    for(let i=0;i<levels.length;i++){let score=(levels[i].height||9999)*10000+(levels[i].bandwidth||0);if(score<minScore){minScore=score;minIndex=i}}
    for(let i=0;i<levels.length;i++)levels[i].enabled=i===minIndex;
   }
   previewReady=true;
   if(queuedPreviewTime!==null)drawPreviewAt(queuedPreviewTime);
  });
 }
 function drawFromVideo(videoEl){
  if(!videoEl||videoEl.readyState<2||!videoEl.videoWidth)return false;
  const ctx=previewCanvas.getContext('2d');
  ctx.drawImage(videoEl,0,0,previewCanvas.width,previewCanvas.height);
  seekPreview.classList.add('has-frame');
  return true;
 }
 function drawPreviewAt(targetTime){
  if(disposed||ui.dataset.scrubbing!=='true')return;
  queuedPreviewTime=targetTime;
  ensurePreviewPlayer();
  const mainVideo=host.querySelector('video.vjs-tech');
  if(Math.abs((player.currentTime()||0)-targetTime)<1.2&&drawFromVideo(mainVideo))return;
  if(!previewReady||previewBusy||Math.abs(targetTime-lastPreviewTime)<.75)return;
  previewBusy=true;lastPreviewTime=targetTime;
  const previewVideo=previewPlayer.el().querySelector('video')||previewPlayer.tech({IWillNotUseThisInPlugins:true})?.el?.();
  const finish=()=>{
   clearTimeout(previewTimer);
   drawFromVideo(previewVideo);
   previewBusy=false;
   if(queuedPreviewTime!==null&&Math.abs(queuedPreviewTime-targetTime)>=1)drawPreviewAt(queuedPreviewTime);
  };
  previewTimer=setTimeout(finish,1200);
  previewPlayer.one('seeked',finish);
  try{previewPlayer.currentTime(targetTime)}catch{finish()}
 }
 function updateScrubVisual(percent){
  let duration=player.duration();if(!(Number.isFinite(duration)&&duration>0))return 0;
  let clamped=Math.max(0,Math.min(1,percent)),time=clamped*duration;
  seekArea.style.setProperty('--mp-scrub-percent',`${clamped*100}%`);
  seekProgress.style.width=`${clamped*100}%`;
  seekInput.value=String(Math.round(clamped*1000));
  previewTime.textContent=formatClock(time);
  let areaWidth=seekArea.clientWidth||320,cardHalf=(seekPreview.offsetWidth||160)/2;
  let px=Math.max(cardHalf,Math.min(areaWidth-cardHalf,clamped*areaWidth));
  seekPreview.style.left=`${px}px`;
  if(scrubHoldReady){seekPreview.hidden=false;drawPreviewAt(time)}
  return time;
 }
 function percentFromClientX(clientX){
  let rect=seekArea.getBoundingClientRect();
  return rect.width?Math.max(0,Math.min(1,(clientX-rect.left)/rect.width)):0;
 }
 function beginScrub(event){
  let duration=player.duration();if(!(Number.isFinite(duration)&&duration>0))return;
  scrubPointerId=event.pointerId;
  scrubStartX=event.clientX;
  scrubHoldReady=false;
  ui.dataset.scrubbing='true';
  ui.dataset.active='true';
  clearTimeout(hideTimer);
  seekInput.setPointerCapture?.(event.pointerId);
  scrubPendingPercent=percentFromClientX(event.clientX);
  updateScrubVisual(scrubPendingPercent);
  clearTimeout(seekArea._holdTimer);
  seekArea._holdTimer=setTimeout(()=>{if(ui.dataset.scrubbing==='true'){scrubHoldReady=true;updateScrubVisual(scrubPendingPercent)}},110);
 }
 function moveScrub(event){
  if(ui.dataset.scrubbing!=='true'||(scrubPointerId!==null&&event.pointerId!==scrubPointerId))return;
  scrubPendingPercent=percentFromClientX(event.clientX);
  if(Math.abs(event.clientX-scrubStartX)>5)scrubHoldReady=true;
  updateScrubVisual(scrubPendingPercent);
 }
 function endScrub(event){
  if(ui.dataset.scrubbing!=='true'||(event?.pointerId!==undefined&&scrubPointerId!==null&&event.pointerId!==scrubPointerId))return;
  clearTimeout(seekArea._holdTimer);
  let pct=event?.clientX!==undefined?percentFromClientX(event.clientX):Number(seekInput.value)/1000;
  let duration=player.duration();
  ui.dataset.scrubbing='false';
  seekPreview.hidden=true;
  scrubPointerId=null;scrubHoldReady=false;
  if(Number.isFinite(duration)&&duration>0){player.currentTime(pct*duration);updateLoading()}
  updateTime();showControls();
 }
 const documentPointerUp=event=>endScrub(event);
 document.addEventListener('pointerup',documentPointerUp,true);
 document.addEventListener('pointercancel',documentPointerUp,true);
 seekInput.addEventListener('pointerdown',beginScrub);
 seekInput.addEventListener('pointermove',moveScrub);
 seekInput.addEventListener('pointerup',endScrub);
 seekInput.addEventListener('pointercancel',endScrub);
 seekInput.addEventListener('input',()=>{if(ui.dataset.scrubbing!=='true'){let d=player.duration();if(d>0)player.currentTime(Number(seekInput.value)/1000*d)}});

 const togglePlayback=()=>{if(player.paused())player.play().catch(()=>{});else player.pause()};
 playButton.addEventListener('click',()=>{togglePlayback();showControls()});
 centerPlay.addEventListener('click',()=>{player.play().catch(()=>{});showControls()});
 $('.mp-rewind').addEventListener('click',()=>{player.currentTime(Math.max(0,player.currentTime()-10));updateLoading();showControls()});
 $('.mp-forward').addEventListener('click',()=>{player.currentTime(Math.min(player.duration()||Infinity,player.currentTime()+10));updateLoading();showControls()});
 muteButton.addEventListener('click',()=>{player.muted(!player.muted());if(!player.muted()&&player.volume()===0)player.volume(1);showControls()});
 ccButton.addEventListener('click',()=>settings.hidden?openSettings('cc'):closeSettings());
 $('.mp-settings-button').addEventListener('click',()=>settings.hidden?openSettings('cc'):closeSettings());
 $('.mp-settings-close').addEventListener('click',closeSettings);
 skipIntro.addEventListener('click',()=>{if(Number(data.intro?.end)>0)player.currentTime(Number(data.intro.end));showControls()});
 skipOutro.addEventListener('click',()=>{if(Number(data.outro?.end)>0)player.currentTime(Number(data.outro.end));showControls()});
 pipButton.addEventListener('click',async()=>{
  try{
   const video=host.querySelector('video');
   if(document.pictureInPictureElement)await document.exitPictureInPicture();
   else if(video?.requestPictureInPicture)await video.requestPictureInPicture();
  }catch{}
  showControls();
 });

 async function toggleFullscreen(){
  const container=host.closest('#player')||host;
  const active=document.fullscreenElement||document.webkitFullscreenElement||player.isFullscreen();
  if(active){
   try{if(document.fullscreenElement)await document.exitFullscreen();else if(player.isFullscreen())player.exitFullscreen()}catch{}
   if(orientationLocked){orientationLocked=false;try{screen.orientation?.unlock?.()}catch{}}
   return;
  }
  try{
   if(container.requestFullscreen)await container.requestFullscreen({navigationUI:'hide'});
   else player.requestFullscreen();
  }catch{try{player.requestFullscreen()}catch{}}
  const mobileViewport=window.matchMedia?.('(max-width: 920px)')?.matches||navigator.maxTouchPoints>0;
  if(mobileViewport&&screen.orientation?.lock){
   try{await screen.orientation.lock('landscape');orientationLocked=true}catch{}
  }
 }
 function updateFullscreen(){
  const container=host.closest('#player')||host;
  const active=document.fullscreenElement===container||document.fullscreenElement===host||player.isFullscreen();
  ui.classList.toggle('mp-is-fullscreen',Boolean(active));
  fullscreenButton.innerHTML=active?icons.exitFullscreen:icons.fullscreen;
  fullscreenButton.setAttribute('aria-label',active?'Exit Fullscreen':'Fullscreen');
  if(!active&&orientationLocked){orientationLocked=false;try{screen.orientation?.unlock?.()}catch{}}
 }
 fullscreenButton.addEventListener('click',()=>{toggleFullscreen();showControls()});
 document.addEventListener('fullscreenchange',updateFullscreen);
 player.on('fullscreenchange',updateFullscreen);

 settings.addEventListener('click',event=>{
  let tab=event.target.closest('[data-tab]');if(tab){showPanel(tab.dataset.tab);return}
  if(event.target.closest('[data-open-caption-style]')){showPanel('caption-style');return}
  if(event.target.closest('[data-back-cc]')){showPanel('cc');return}
  if(event.target.closest('[data-reset-caption-style]')){captionStyle={...defaultCaptionStyle};saveCaptionStyle(captionStyle);applyCaptionStyle();return}
  let track=event.target.closest('[data-track]');if(track){selectSubtitle(Number(track.dataset.track));return}
  let quality=event.target.closest('[data-quality]');if(quality){selectQuality(quality.dataset.quality);closeSettings();return}
  let server=event.target.closest('[data-server-choice]');if(server){let value=server.dataset.serverChoice;closeSettings();options.onServerChange?.(value);return}
  let audioChoice=event.target.closest('[data-audio-choice]');if(audioChoice){let value=audioChoice.dataset.audioChoice;closeSettings();options.onAudioChange?.(value);return}
  let audioTrack=event.target.closest('[data-audio-track]');if(audioTrack){
   let selectedIndex=Number(audioTrack.dataset.audioTrack),tracks=Array.from(player.audioTracks());
   if(tracks[selectedIndex]&&!tracks[selectedIndex].enabled){
    let anchorTime=Number(player.currentTime())||0,wasPaused=player.paused(),switchedAt=Date.now();
    tracks.forEach((item,index)=>{item.enabled=index===selectedIndex});
    if(anchorTime>0){
     let done=false;
     const syncAudioPosition=()=>{if(disposed||done)return;let elapsed=wasPaused?0:Math.min(1.5,Math.max(0,(Date.now()-switchedAt)/1000)),expected=anchorTime+elapsed;if(Math.abs((Number(player.currentTime())||0)-expected)>1.2){try{player.currentTime(anchorTime)}catch{}}};
     const onSwitchCanplay=()=>{syncAudioPosition();cleanup();if(!wasPaused)player.play().catch(()=>{})};
     const cleanup=()=>{if(done)return;done=true;clearTimeout(disarmTimer);clearTimeout(checkTimer);player.off('canplay',onSwitchCanplay)};
     const disarmTimer=setTimeout(cleanup,2500);
     const checkTimer=setTimeout(()=>{syncAudioPosition();if(!player.seeking()&&player.readyState()>=3)cleanup()},400);
     player.on('canplay',onSwitchCanplay);
     try{player.currentTime(anchorTime);updateLoading()}catch{}
    }
   }
   renderAudio();closeSettings();return;
  }
  let rate=event.target.closest('[data-rate]');if(rate){player.playbackRate(Number(rate.dataset.rate));renderPlaybackSettings();return}
  let pref=event.target.closest('[data-playback-setting]');if(pref){
   let key='moscowtv-'+pref.dataset.playbackSetting,current=pref.dataset.playbackSetting==='autoskip'?localStorage.getItem(key)==='true':localStorage.getItem(key)!=='false';
   try{localStorage.setItem(key,String(!current))}catch{}
   renderPlaybackSettings();
  }
 });
 settings.addEventListener('change',event=>{
  let styleControl=event.target.closest('[data-caption-style]');
  if(styleControl){captionStyle[styleControl.dataset.captionStyle]=styleControl.value;saveCaptionStyle(captionStyle);applyCaptionStyle()}
 });
 $('[data-boost-input]').addEventListener('input',event=>ensureBoost(event.target.value));

 // Unified Touch & Mouse Surface Gestures:
 // - Single tap/click outside center: toggle controls (works on Android Chrome touch + desktop mouse!)
 // - Double tap/click Left (<34%): rewind 10s with < 10s animation, controls stay hidden
 // - Double tap/click Right (>66%): forward 10s with > 10s animation, controls stay hidden
 // - Single tap/click in Estimated Center (36%..64% x, 28%..72% y): pause/resume video
 function isControlElement(target){
  return Boolean(target?.closest?.('.mp-bottom, .mp-settings, .mp-center-play, .mp-skip'));
 }
 function handleSurfaceTap(clientX,clientY){
  if(disposed||ui.dataset.scrubbing==='true')return;
  if(!settings.hidden){closeSettings();showControls();return}
  const rect=host.getBoundingClientRect();
  if(!rect.width||!rect.height)return;
  const rx=(clientX-rect.left)/rect.width,ry=(clientY-rect.top)/rect.height;
  const now=Date.now();
  if((rx<0.34||rx>0.66)&&ry>=0.25&&ry<=0.85){
   const side=rx<0.34?'left':'right';
   const isDouble=(lastSideTap.side===side&&now-lastSideTap.time<300)||(activeSkipSide===side&&now-lastSkipAt<650);
   if(isDouble){
    clearTimeout(singleTapTimer);singleTapTimer=null;
    lastSideTap={side:'',time:0};
    hideControls();
    skipAccum=(activeSkipSide===side&&now-lastSkipAt<650)?skipAccum+10:10;
    activeSkipSide=side;lastSkipAt=now;
    let delta=side==='right'?10:-10,dur=Number(player.duration()),cur=Number(player.currentTime())||0;
    let target=Math.max(0,Number.isFinite(dur)&&dur>0?Math.min(dur,cur+delta):cur+delta);
    player.currentTime(target);
    updateTime();
    triggerTapSeek(side,skipAccum);
    return;
   }
   lastSideTap={side,time:now};
   clearTimeout(singleTapTimer);
   singleTapTimer=setTimeout(()=>{
    singleTapTimer=null;
    lastSideTap={side:'',time:0};
    toggleControls();
   },220);
   return;
  }
  clearTimeout(singleTapTimer);singleTapTimer=null;lastSideTap={side:'',time:0};
  if(rx>=0.36&&rx<=0.64&&ry>=0.28&&ry<=0.72){
   if(!player.paused()){player.pause();showControls()}
   else{player.play().catch(()=>{});showControls()}
   return;
  }
  toggleControls();
 }

 let lastMouseX=-1,lastMouseY=-1;
 const onHostPointerDown=event=>{
  if(event.button>0)return;
  if(isControlElement(event.target)){showControls();pointerStart=null;return}
  pointerStart={id:event.pointerId,x:event.clientX,y:event.clientY,time:Date.now()};
 };
 const onHostPointerUp=event=>{
  if(!pointerStart||event.pointerId!==pointerStart.id)return;
  let dist=Math.hypot(event.clientX-pointerStart.x,event.clientY-pointerStart.y),dt=Date.now()-pointerStart.time;
  let {x,y}=pointerStart;pointerStart=null;
  if(dist<20&&dt<500&&!isControlElement(event.target)){
   lastPointerUpAt=Date.now();
   handleSurfaceTap(x,y);
  }
 };
 host.addEventListener('pointerdown',onHostPointerDown);
 host.addEventListener('pointerup',onHostPointerUp);
 host.addEventListener('pointermove',event=>{
  if(event.pointerType!=='mouse'||pointerStart||Date.now()-lastPointerUpAt<350||Date.now()-lastSkipAt<800)return;
  if(lastMouseX>=0&&Math.hypot(event.clientX-lastMouseX,event.clientY-lastMouseY)>4)showControls();
  lastMouseX=event.clientX;lastMouseY=event.clientY;
 });

 const videoEl=player.tech({}).el(),techFallbackClick=event=>{if(Date.now()-lastPointerUpAt>400)handleSurfaceTap(event.clientX,event.clientY)};
 videoEl.addEventListener('click',techFallbackClick);

 const nativeLoadingEvents=['loadstart','waiting','seeking','seeked','canplay','playing','pause','stalled'];
 for(let ev of nativeLoadingEvents)videoEl.addEventListener(ev,updateLoading);

 player.on(['play','playing'],()=>{updatePlay();if(ui.dataset.active==='true'&&Date.now()-lastSkipAt>800)showControls()});
 player.on(['pause','ended'],()=>{updatePlay();showControls()});
 player.on(['loadstart','waiting','seeking','seeked','canplay','canplaythrough','loadeddata','error'],updateLoading);
 player.on(['volumechange'],updateVolume);
 player.on(['timeupdate','progress','durationchange','loadedmetadata','seeking','seeked'],()=>{updateTime();updateSkip()});
 player.on('timeupdate',renderCaptions);
 player.on('loadedmetadata',()=>{renderQuality();renderAudio();updateTime();updateLoading()});

 let levels=qualityLevels();if(levels?.on){levels.on('addqualitylevel',renderQuality);levels.on('change',renderQuality)}
 let savedQuality=localStorage.getItem('moscowtv-quality');if(savedQuality)player.one('loadedmetadata',()=>selectQuality(savedQuality));
 let textTracks=player.textTracks();textTracks.addEventListener?.('addtrack',()=>{renderTracks()});
 let audioTracks=player.audioTracks();audioTracks.addEventListener?.('addtrack',renderAudio);audioTracks.addEventListener?.('change',renderAudio);

 player.one('dispose',()=>{
  disposed=true;
  clearTimeout(hideTimer);clearTimeout(loaderTimer);clearTimeout(tapSeekTimer);clearTimeout(singleTapTimer);clearTimeout(previewTimer);
  document.removeEventListener('fullscreenchange',updateFullscreen);
  document.removeEventListener('pointerup',documentPointerUp,true);
  document.removeEventListener('pointercancel',documentPointerUp,true);
  host.removeEventListener('pointerdown',onHostPointerDown);
  host.removeEventListener('pointerup',onHostPointerUp);
  videoEl?.removeEventListener('click',techFallbackClick);
  for(let ev of nativeLoadingEvents)videoEl?.removeEventListener(ev,updateLoading);
  if(activeTrack&&captionCueHandler)activeTrack.removeEventListener('cuechange',captionCueHandler);
  if(orientationLocked)try{screen.orientation?.unlock?.()}catch{}
  if(previewPlayer&&!previewPlayer.isDisposed())previewPlayer.dispose();
  if(audioContext)audioContext.close().catch(()=>{});
  ui.remove();
 });

 applyCaptionStyle();disableAllNativeTracks();updatePlay();updateVolume();updateTime();renderTracks();renderAudio();renderQuality();renderPlaybackSettings();showControls();
 player.megaUI={ui,showControls,hideControls,openSettings,closeSettings,selectSubtitle,selectQuality,onAutoplayBlocked:()=>{ui.dataset.autoplay='false';ui.dataset.paused='true';updateLoading();showControls()}};
 return player.megaUI;
}

window.MegaPlayUI={create};
})();
