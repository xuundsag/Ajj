import { chromium } from 'playwright';

const UA='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
let browserPromise=null,active=0;
const waiting=[],cache=new Map(),inflight=new Map(),CACHE_MS=15*60_000;

async function browser(){
 if(!browserPromise){
  browserPromise=chromium.launch({headless:true,args:['--no-sandbox','--autoplay-policy=no-user-gesture-required']});
  browserPromise.then(b=>b.on('disconnected',()=>{browserPromise=null})).catch(()=>{browserPromise=null});
 }
 return browserPromise;
}
export function warmCineSrcBrowser(){return browser().catch(()=>null)}

async function acquire(){if(active>=3)await new Promise(r=>waiting.push(r));active++}
function release(){active--;waiting.shift()?.()}

function embedPath({type,id,season,episode},server){
 let path=type==='tv'?`/embed/tv/${id}?s=${season}&e=${episode}`:`/embed/movie/${id}?`;
 return 'https://cinesrc.st'+path+(path.includes('?')?'&':'?')+new URLSearchParams({autoplay:'true',muted:'true',controls:'false',lastserver:server,prioritize:'true'});
}

async function verifyMasterPlaylist(masterUrl,masterText){
 let variantLine=masterText.split(/\r?\n/).find(l=>{let t=l.trim();return t&&!t.startsWith('#')});
 if(!variantLine)return masterText.startsWith('#EXTM3U');
 let subUrl=new URL(variantLine.trim(),masterUrl).href;
 let r=await fetch(subUrl,{headers:{'User-Agent':UA,Referer:'https://cinesrc.st/'},signal:AbortSignal.timeout(5000)});
 if(!r.ok)return false;
 let subText=await r.text();
 return subText.trimStart().startsWith('#EXTM3U');
}

async function resolveWithServer(input,server){
 await acquire();
 let page;
 try{
  let b=await browser();
  page=await b.newPage({viewport:{width:960,height:540}});
  let settled=false,resolveFound,rejectFound;
  const foundPromise=new Promise((res,rej)=>{resolveFound=res;rejectFound=rej});
  await page.route('**/*',route=>{
   let reqUrl=route.request().url(),host='';
   try{host=new URL(reqUrl).hostname}catch{}
   if(/google-analytics|googletagmanager|doubleclick|cloudflareinsights|rapidadexchange|mc\.yandex|id5-sync|pippio/i.test(host))return route.abort();
   if(settled||(host&&!host.endsWith('cinesrc.st')&&/\.(?:m4s|ts|woff2?)(?:\?|$)/i.test(reqUrl)))return route.abort();
   return route.continue();
  });
  page.on('response',response=>{
   if(settled||!/\.m3u8(?:\?|$)/i.test(response.url()))return;
   response.text().then(async text=>{
    if(settled||!text.trimStart().startsWith('#EXTM3U'))return;
    let isMaster=/#EXT-X-(?:STREAM-INF|MEDIA)/.test(text);
    if(!isMaster)return;
    let ok=await verifyMasterPlaylist(response.url(),text).catch(()=>false);
    if(ok&&!settled){settled=true;resolveFound({url:response.url(),server})}
   }).catch(()=>{});
  });
  page.goto(embedPath(input,server),{waitUntil:'commit',timeout:15_000}).catch(err=>{if(!settled)rejectFound(err)});
  let timer;
  const timeoutPromise=new Promise((_,rej)=>{timer=setTimeout(()=>rej(Error('CineSrc timed out resolving stream.')),9500)});
  try{return await Promise.race([foundPromise,timeoutPromise])}
  finally{settled=true;clearTimeout(timer)}
 }finally{
  await page?.close().catch(()=>{});
  release();
 }
}

export function resolveCineSrc(input,provider='default'){
 let key=[input.type,input.id,input.season,input.episode,provider].join(':'),cached=cache.get(key);
 if(cached&&Date.now()-cached.time<CACHE_MS)return Promise.resolve(cached.value);
 if(inflight.has(key))return inflight.get(key);
 let promise=(async()=>{
  let servers=provider==='second'?['wave','orbit','light']:['nebula','orbit'],lastError;
  for(let server of servers){
   try{let value=await resolveWithServer(input,server);cache.set(key,{value,time:Date.now()});return value}
   catch(error){lastError=error}
  }
  throw Error('CineSrc could not resolve a playable stream. '+(lastError?.message||''));
 })().finally(()=>inflight.delete(key));
 inflight.set(key,promise);
 return promise;
}

const subtitleCache=new Map();
export async function cinesrcSubtitles(input){
 let key=[input.type,input.id,input.season,input.episode].join(':'),cached=subtitleCache.get(key);if(cached&&Date.now()-cached.time<6*60*60_000)return cached.tracks;
 let body=input.type==='tv'?{tmdbId:String(input.id),season:Number(input.season),episode:Number(input.episode),builtInSubtitles:[]}:{tmdbId:String(input.id),builtInSubtitles:[]};
 let response=await fetch('https://cinesrc.st/api/subtitles/search',{method:'POST',headers:{'Content-Type':'application/json',Referer:'https://cinesrc.st/',Accept:'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(8_000)});
 if(!response.ok)throw Error('CineSrc subtitle search failed ('+response.status+').');
 let data=await response.json(),best=new Map(),badRelease=/(?:^|[.\s_-])(?:cam|hdcam|ts|hdts|telesync|tc|dvdscr|screener|r5|r6)(?:[.\s_-]|$)/i;
 for(let track of data.subtitles||[]){
  if(track.format!=='srt'||!track.language||!track.display||!/^https:\/\//.test(track.url||'')||track.isCommentary||track.isSignsAndSongs)continue;
  let release=String(track.release||''),score=Number(track.matchScore)||0;
  score+=Number(track.community?.score||0)*10+(track.isHearingImpaired?0:3)+(/blu.?ray|web|hdtv|dvdrip/i.test(release)?8:0)-(badRelease.test(release)?35:0);
  let previous=best.get(track.language);if(!previous||score>previous.score)best.set(track.language,{src:track.url,label:String(track.display).slice(0,60),language:String(track.language).slice(0,12),kind:'subtitles',default:false,score});
 }
 let tracks=[...best.values()].sort((a,b)=>({en:0,hi:1}[a.language]??2)-({en:0,hi:1}[b.language]??2)||a.label.localeCompare(b.label)).slice(0,30).map(({score,...track})=>track);
 subtitleCache.set(key,{tracks,time:Date.now()});return tracks;
}
