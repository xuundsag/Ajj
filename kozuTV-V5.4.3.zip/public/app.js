const app=document.getElementById('app'),searchInput=document.getElementById('search'),searchBox=document.querySelector('.searchbox'),headerEl=document.querySelector('.header'),mainMenu=document.getElementById('main-menu'),menuToggle=document.querySelector('.menu-toggle');
const genres=['Action','Adventure','Animation','Comedy','Crime','Documentary','Drama','Family','Fantasy','History','Horror','Mecha','Music','Mystery','Psychological','Romance','Sci-Fi','Slice of Life','Sports','Supernatural','Thriller','War','Western'];
const catalogLanguages=[
 {code:'en',name:'English'},{code:'hi',name:'Hindi'},{code:'ko',name:'Korean'},{code:'ja',name:'Japanese'},
 {code:'es',name:'Spanish'},{code:'fr',name:'French'},{code:'ta',name:'Tamil'},{code:'te',name:'Telugu'},
 {code:'ml',name:'Malayalam'},{code:'kn',name:'Kannada'},{code:'bn',name:'Bengali'},{code:'zh',name:'Chinese'},
 {code:'de',name:'German'},{code:'tr',name:'Turkish'},{code:'th',name:'Thai'},{code:'it',name:'Italian'},
 {code:'pt',name:'Portuguese'},{code:'ru',name:'Russian'}
];
const ottServers=[['vidcore','VidCore'],['embedwave','EmbedWave'],['cinesrc','CineSrc'],['vidlink','VidLink'],['vidsrc','VidSrc']];
const icons={
 play:'<svg class="ui-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13l10.5-6.5z"/></svg>',
 star:'<svg class="ui-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 3.6 2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 17l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/></svg>',
 tv:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M8 21h8M12 18v3"/></svg>',
 calendar:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>',
 bookmark:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>',
 trending:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 17 6-6 4 4 7-7"/><path d="M14 8h6v6"/></svg>',
 clock:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>',
 spark:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/></svg>',
 film:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 8h4M17 8h4M3 12h18M3 16h4M17 16h4"/></svg>',
 grid:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
 search:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
 filter:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h16M7 12h10M10 18h4"/></svg>',
 shuffle:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/></svg>',
 home:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg>',
 down:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>',
 arrowRight:'<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
 server:'<svg class="control-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="6" rx="1.6"/><rect x="3" y="14" width="18" height="6" rx="1.6"/><path d="M7 7h.01M7 17h.01"/></svg>',
 prev:'<svg class="control-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 20 9 12l10-8v16zM5 19V5"/></svg>',
 next:'<svg class="control-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 4 10 8-10 8V4zM19 5v14"/></svg>'
};

const icon=name=>icons[name]||'';
const sectionTitle=(name,text,tag='h2')=>`<${tag} class="section-title"><span class="section-icon">${icon(name)}</span><span>${text}</span></${tag}>`;
const slugify=s=>String(s||'item').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'item';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtNum=n=>{const v=Number(n)||0;return v>0?v.toLocaleString('en-US'):'0'};
const posterFallbackUri=(title,type)=>{
 const t=String(title||'Title').replace(/[&<>"]/g,'').slice(0,36);
 const b=type==='tv'?'SERIES':(type==='anime'?'ANIME':'MOVIE');
 return 'data:image/svg+xml;utf8,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600"><rect width="400" height="600" fill="#181b24"/><rect x="28" y="36" width="40" height="4" rx="2" fill="#ff731c"/><text x="28" y="505" fill="#ff731c" font-family="sans-serif" font-size="14" font-weight="700" letter-spacing="2">${b}</text><text x="28" y="540" fill="#f2f4f8" font-family="sans-serif" font-size="22" font-weight="800">${t}</text></svg>`);
};

let state={watchlist:[],history:[]},heroTimer=null,searchTimer=null,currentRoute=0,videoAssetsPromise=null,activePlayerHandle=null;

function destroyPlayer(){
 if(activePlayerHandle){try{activePlayerHandle.dispose()}catch{}activePlayerHandle=null}
}
function loadScript(src){
 return new Promise((resolve,reject)=>{
  let existing=document.querySelector(`script[src="${src}"]`);
  if(existing){if(existing.dataset.loaded)return resolve();existing.addEventListener('load',()=>resolve(),{once:true});existing.addEventListener('error',()=>reject(Error('Player failed to load')),{once:true});return}
  let s=document.createElement('script');s.src=src;s.async=true;
  s.onload=()=>{s.dataset.loaded='1';resolve()};
  s.onerror=()=>reject(Error('Player failed to load'));
  document.head.appendChild(s);
 });
}
function ensureVideoAssets(){
 if(window.videojs&&window.MegaPlayUI)return Promise.resolve();
 videoAssetsPromise=videoAssetsPromise||loadScript('/vendor/video.min.js').then(()=>loadScript('/megaplay-controls.js?v=5.4.3'));
 return videoAssetsPromise;
}

const getJSON=url=>fetch(url,{credentials:'same-origin'}).then(async r=>{let t=await r.text(),d={};try{d=t?JSON.parse(t):{}}catch{throw Error('A catalog service returned an invalid response.')}if(!r.ok)throw Error(d.error||'Request failed');return d});
const postJSON=(url,body)=>fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(async r=>{let d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Request failed');return d});
const saved=(id,type)=>state.watchlist.some(x=>String(x.id)===String(id)&&x.type===type);
const detailPath=item=>`/title/${item.type}/${item.id}-${slugify(item.title)}`;
const watchPath=(item,ep=1,season=1)=>item.type==='anime'?`/watch/${item.id}-${slugify(item.title)}/ep-${ep}`:`/watch/${item.type}/${item.id}-${slugify(item.title)}?season=${season}&ep=${ep}`;
const isEpisodicItem=item=>item.type==='tv'||(item.type==='anime'&&!item.isMovie&&String(item.format||'').toUpperCase()!=='MOVIE');
const resumeProgress=item=>state.history.find(x=>String(x.id)===String(item.id)&&x.type===item.type);
const formatTime=sec=>{sec=Math.max(0,Math.floor(Number(sec)||0));let h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;return h?`${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`};
const readSetting=(k,fallback=true)=>{let v=localStorage.getItem('moscowtv-'+k);return v===null?fallback:v==='true'};
const writeSetting=(k,v)=>localStorage.setItem('moscowtv-'+k,String(Boolean(v)));
const cleanDescription=text=>String(text||'').replace(/\s*\(?\bSource:\s*[^)\n]+\)?\s*$/i,'').replace(/\n{3,}/g,'\n\n').trim();
const shortCount=n=>{const v=Number(n)||0;if(v>=1000)return Math.floor(v/1000).toLocaleString('en-US')+'k+';return String(v)};

function updateActiveNav(pathname){
 const p=pathname||location.pathname;
 document.querySelectorAll('.header-nav a[data-nav]').forEach(a=>{
  const key=a.dataset.nav;
  const isAct=(key==='browse'&&(p==='/'||p==='/browse'))||(key==='movies'&&p==='/movies')||(key==='series'&&(p==='/series'||p==='/tv'))||(key==='anime'&&p==='/anime');
  a.classList.toggle('active',Boolean(isAct));
 });
}

function hydrateMenuIcons(){
 const home=mainMenu.querySelector('.menu-home');
 if(home&&!home.querySelector('svg'))home.innerHTML=`${icon('home')}<span>Home</span>`;
 const map={
  '/movies':['film','Movies'],
  '/series':['tv','TV Shows'],
  '/anime':['spark','Anime'],
  '/filters':['filter','All Filters'],
  '/schedule':['calendar','Anime Schedule'],
  '/random':['shuffle','Random Title']
 };
 mainMenu.querySelectorAll('.menu-catalogs a, .menu-explore a').forEach(a=>{
  const entry=map[a.getAttribute('href')];
  if(entry&&!a.querySelector('svg'))a.innerHTML=`${icon(entry[0])}<span>${entry[1]}</span>`;
 });
}

document.getElementById('genre-menu').innerHTML=genres.map(g=>`<a href="/genre/${slugify(g)}">${icon('grid')}<span>${esc(g)}</span></a>`).join('');
hydrateMenuIcons();

function setMenu(open){mainMenu.hidden=!open;menuToggle.setAttribute('aria-expanded',String(open))}
menuToggle.onclick=e=>{e.stopPropagation();setMenu(mainMenu.hidden)};
searchBox?.addEventListener('click',e=>{
 if(window.matchMedia('(max-width:650px)').matches&&!searchBox.classList.contains('open')){
  e.preventDefault();setMenu(false);searchBox.classList.add('open');headerEl?.classList.add('search-open');searchInput.focus();
 }
});
searchInput.addEventListener('focus',()=>{headerEl?.classList.add('search-open')});
searchInput.addEventListener('blur',()=>{if(!searchInput.value.trim()){searchBox?.classList.remove('open');headerEl?.classList.remove('search-open')}});
document.addEventListener('click',e=>{
 if(!mainMenu.hidden&&!mainMenu.contains(e.target)&&!menuToggle.contains(e.target))setMenu(false);
 if(searchBox?.classList.contains('open')&&!searchBox.contains(e.target)&&!searchInput.value.trim()){searchBox.classList.remove('open');headerEl?.classList.remove('search-open')}
});
document.addEventListener('keydown',e=>{
 if(e.key==='/'&&document.activeElement!==searchInput&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)){
  e.preventDefault();searchBox?.classList.add('open');headerEl?.classList.add('search-open');searchInput.focus();
 }
 if(e.key==='Escape'){setMenu(false);searchBox?.classList.remove('open');headerEl?.classList.remove('search-open');document.body.classList.remove('light-off')}
});
document.addEventListener('click',e=>{
 let a=e.target.closest('a[href]');
 if(!a||a.target||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
 let u=new URL(a.href,location.origin);
 if(u.origin===location.origin&&!u.pathname.startsWith('/api/')){e.preventDefault();go(u.pathname+u.search)}
});

// Automatic SVG poster fallback if any external image fails to load
document.addEventListener('error',e=>{
 const img=e.target;
 if(img&&img.tagName==='IMG'&&!img.dataset.fallbackApplied&&img.closest('.poster, .detail-layout, .continue-image, .schedule-row')){
  img.dataset.fallbackApplied='1';
  img.src=posterFallbackUri(img.alt||'kozuTV',img.dataset.mediaType||'movie');
 }
},true);

searchInput.addEventListener('input',()=>{
 clearTimeout(searchTimer);
 let q=searchInput.value.trim();
 searchTimer=setTimeout(()=>{if(q)go('/search?q='+encodeURIComponent(q),location.pathname==='/search');else if(location.pathname==='/search')go('/browse',true)},260);
});

function go(url,replace=false){
 setMenu(false);
 document.body.classList.remove('light-off');
 history[replace?'replaceState':'pushState'](null,'',url);
 route();
 window.scrollTo({top:0,behavior:'instant'});
}

function card(item){
 let typeLabel=item.type==='anime'?(item.isMovie||item.format==='MOVIE'?'Anime Movie':'Anime'):item.type==='tv'?'Series':'Movie';
 let posterSrc=item.poster||posterFallbackUri(item.title,item.type);
 return `<article class="card" data-open="${esc(detailPath(item))}"><div class="poster"><img src="${esc(posterSrc)}" data-media-type="${esc(item.type)}" alt="${esc(item.title)}" loading="lazy">${item.rating?`<span class="rating">${icon('star')}${esc(item.rating)}</span>`:''}</div><h3>${esc(item.title)}</h3><p>${esc([typeLabel,item.year].filter(Boolean).join(' • '))}</p></article>`;
}
function bindCards(root=app){
 root.querySelectorAll('[data-open]').forEach(el=>{
  if(el.dataset.boundOpen)return;
  el.dataset.boundOpen='1';
  el.onclick=()=>go(el.dataset.open);
 });
}

function renderHero(items){
 let picks=items.filter(x=>x.backdrop||x.poster).slice(0,8);
 if(!picks.length)return '';
 return `<section class="hero" id="hero"></section>`;
}
function mountHero(items){
 let hero=document.getElementById('hero');
 if(!hero)return;
 let picks=items.filter(x=>x.backdrop||x.poster).slice(0,8),i=0;
 const restartTimer=()=>{clearInterval(heroTimer);heroTimer=setInterval(()=>draw((i+1)%picks.length),6500)};
 const draw=n=>{
  i=n;let x=picks[i],isSaved=saved(x.id,x.type),typeLabel=x.type==='anime'?(x.isMovie||x.format==='MOVIE'?'Anime Movie':'TV'):x.type==='tv'?'Series':'Movie';
  let desktopArt=x.backdrop||x.poster,mobileArt=x.poster||x.backdrop;
  hero.dataset.heroOpen=detailPath(x);
  hero.innerHTML=`<div class="hero-image" style="background-image:url('${esc(desktopArt)}')"></div><img class="hero-image-mobile" src="${esc(mobileArt)}" alt="" decoding="async"><div class="container hero-content"><div class="hero-copy"><h1>${esc(x.title)}</h1><div class="meta hero-meta"><span>${icon('tv')}${esc(typeLabel)}</span>${x.episodes?`<span>${esc(x.episodes)} eps</span>`:''}<span><b class="quality">HD</b></span>${x.year?`<span>${icon('calendar')}${esc(x.year)}</span>`:''}${x.rating?`<span>${icon('star')}${esc(x.rating)}</span>`:''}</div><p class="description">${esc(cleanDescription(x.description)||'Stream instantly on kozuTV.')}</p><div class="hero-actions"><a class="btn hero-watch" href="${esc(watchPath(x))}"><span class="desktop-action">Watch now</span><span class="mobile-action">Watch</span> ${icon('play')}</a><button class="hero-save ${isSaved?'saved':''}" id="hero-save" aria-label="${isSaved?'Saved in Watchlist':'Save to Watchlist'}" title="${isSaved?'Saved in Watchlist':'Save to Watchlist'}">${icon('bookmark')}</button></div><div class="dots">${picks.map((_,idx)=>`<button class="${idx===i?'active':''}" data-dot="${idx}" aria-label="Spotlight ${idx+1}"></button>`).join('')}</div></div></div>`;
  document.getElementById('hero-save').onclick=async e=>{e.stopPropagation();await saveItem(x,!saved(x.id,x.type));draw(i);restartTimer()};
  hero.querySelectorAll('[data-dot]').forEach(b=>b.onclick=e=>{e.stopPropagation();draw(Number(b.dataset.dot));restartTimer()});
 };
 hero.onclick=e=>{if(e.target.closest('a,button,.dots'))return;if(hero.dataset.heroOpen)go(hero.dataset.heroOpen)};
 draw(0);
 restartTimer();
}

async function saveItem(item,add){
 state=await postJSON('/api/watchlist',{...item,remove:!add});
}

function renderHistorySection(items,limit=4,home=false){
 if(!items.length)return '';
 return `<section class="${home?'home-continue':'continue-section'}">${sectionTitle('clock','Continue <span class="pink">watching</span>')}<div class="continue-grid">${items.slice(0,limit).map(x=>{
  let pct=x.duration>0?Math.min(98,Math.max(4,Math.round(x.currentTime/x.duration*100))):0;
  let epLabel=isEpisodicItem(x)?(x.type==='tv'?`S${x.season||1} Ep ${x.episode||1}`:`Ep ${x.episode||1}`):'Movie';
  let timeLabel=x.duration>0?`${formatTime(x.currentTime)} / ${formatTime(x.duration)}`:'Resume';
  return `<article class="continue-card" data-open="${esc(watchPath(x,x.episode||1,x.season||1))}"><div class="continue-image"><img src="${esc(x.poster||posterFallbackUri(x.title,x.type))}" data-media-type="${esc(x.type)}" alt="${esc(x.title)}" loading="lazy"></div><div class="continue-foot"><div class="continue-progress" style="width:${pct}%"></div><span>${esc(epLabel)}</span><span>${esc(timeLabel)}</span></div><h3>${esc(x.title)}</h3></article>`;
 }).join('')}</div></section>`;
}

function getCategoryStep(){return window.matchMedia('(max-width:650px)').matches?6:(window.matchMedia('(max-width:1050px)').matches?10:12)}

function renderHomeCategory({key,iconName,label,items,viewAllHref,viewAllText}){
 if(!items||!items.length)return '';
 const step=getCategoryStep(),shown=items.slice(0,step);
 return `<section class="genre-section" data-home-cat="${esc(key)}"><div class="section-head">${sectionTitle(iconName,label)}${viewAllHref?`<a class="section-view-all" href="${esc(viewAllHref)}"><span>${esc(viewAllText||'Explore all')}</span>${icon('arrowRight')}</a>`:''}</div><div class="grid">${shown.map(card).join('')}</div><div class="category-more"><button type="button" class="category-more-button" data-home-more="${esc(key)}"><span>Show more</span>${icon('down')}</button></div></section>`;
}

function bindHomeCategories(sectionPools){
 app.querySelectorAll('[data-home-more]').forEach(btn=>{
  const key=btn.dataset.homeMore;
  const stateObj=sectionPools[key];
  if(!stateObj)return;
  const sectionEl=btn.closest('[data-home-cat]');
  const gridEl=sectionEl?.querySelector('.grid');
  const wrapEl=btn.closest('.category-more');
  btn.onclick=async()=>{
   if(btn.disabled)return;
   const step=getCategoryStep();
   const nextTarget=stateObj.visible+step;
   if(nextTarget>stateObj.items.length&&stateObj.hasMore){
    btn.disabled=true;
    const prevHtml=btn.innerHTML;
    btn.innerHTML='<span class="button-loader" aria-hidden="true"></span>';
    try{
     const nextPage=stateObj.page+1;
     const d=await getJSON(`/api/category-page?section=${encodeURIComponent(key)}&page=${nextPage}`);
     stateObj.page=nextPage;
     stateObj.hasMore=Boolean(d.hasMore);
     for(const it of d.items||[]){
      const k=`${it.type}:${it.id}`;
      if(!stateObj.seen.has(k)){stateObj.seen.add(k);stateObj.items.push(it)}
     }
    }catch{}
    btn.innerHTML=prevHtml;
    btn.disabled=false;
   }
   const prevVis=stateObj.visible;
   stateObj.visible=Math.min(stateObj.items.length,prevVis+step);
   const slice=stateObj.items.slice(prevVis,stateObj.visible);
   if(slice.length&&gridEl){
    gridEl.insertAdjacentHTML('beforeend',slice.map(card).join(''));
    bindCards(gridEl);
   }
   if(stateObj.visible>=stateObj.items.length&&!stateObj.hasMore){
    wrapEl?.remove();
   }
  };
 });
}

async function renderBrowse(token){
 let d=await getJSON('/api/browse');
 if(token!==currentRoute)return;
 const totals=d.totals||{movies:160000,tv:146000,anime:7765,all:313765};
 const sec=d.sections||{};
 const rawPools={
  trendingMovies:sec.trendingMovies||d.items.filter(x=>x.type==='movie'),
  trendingTv:sec.trendingTv||d.items.filter(x=>x.type==='tv'),
  popularAnime:sec.popularAnime||d.items.filter(x=>x.type==='anime'),
  popularMovies:sec.popularMovies||[],
  popularTv:sec.popularTv||[],
  latestAnime:sec.latestAnime||[],
  topRatedMovies:sec.topRatedMovies||[],
  topRatedTv:sec.topRatedTv||[],
  airingAnime:sec.airingAnime||[]
 };
 const sectionPools={};
 for(const [k,arr] of Object.entries(rawPools)){
  const seen=new Set(arr.map(x=>`${x.type}:${x.id}`));
  sectionPools[k]={items:[...arr],seen,visible:Math.min(arr.length,getCategoryStep()),page:1,hasMore:arr.length>=16};
 }

 const hubHtml=`<section class="catalog-hub" aria-label="Full catalog shortcuts">
  <a class="hub-card" href="/movies"><div class="hub-card-info"><strong>Movies</strong><span>${fmtNum(totals.movies)}+ streamable films</span></div><span class="hub-card-arrow">${icon('arrowRight')}</span></a>
  <a class="hub-card" href="/series"><div class="hub-card-info"><strong>TV Shows</strong><span>${fmtNum(totals.tv)}+ web series &amp; shows</span></div><span class="hub-card-arrow">${icon('arrowRight')}</span></a>
  <a class="hub-card" href="/anime"><div class="hub-card-info"><strong>Anime</strong><span>${fmtNum(totals.anime)} Sub &amp; Dub titles</span></div><span class="hub-card-arrow">${icon('arrowRight')}</span></a>
  <a class="hub-card" href="/filters"><div class="hub-card-info"><strong>All Filters</strong><span>${shortCount(totals.all)} titles by language &amp; year</span></div><span class="hub-card-arrow">${icon('filter')}</span></a>
 </section>`;

 app.innerHTML=`${renderHero(d.spotlight?.length?d.spotlight:d.items)}<div class="container content">${hubHtml}${renderHistorySection(state.history,4,true)}${d.hasPreferences&&d.suggestions?.length?`<section class="suggestions" style="border-top:0;margin-top:0;padding-top:0">${sectionTitle('spark','Picked <span class="pink">for you</span>')}<div class="grid">${d.suggestions.slice(0,6).map(card).join('')}</div></section>`:''}${renderHomeCategory({key:'trendingMovies',iconName:'trending',label:'Trending <span class="pink">Movies</span>',items:rawPools.trendingMovies,viewAllHref:'/movies?sort=trending',viewAllText:`All ${shortCount(totals.movies)} Movies`})}${renderHomeCategory({key:'trendingTv',iconName:'tv',label:'Trending <span class="pink">TV Shows</span>',items:rawPools.trendingTv,viewAllHref:'/series?sort=trending',viewAllText:`All ${shortCount(totals.tv)} Shows`})}${renderHomeCategory({key:'popularAnime',iconName:'spark',label:'Popular <span class="pink">Anime</span>',items:rawPools.popularAnime,viewAllHref:'/anime',viewAllText:`All ${fmtNum(totals.anime)} Anime`})}${renderHomeCategory({key:'popularMovies',iconName:'film',label:'Popular <span class="pink">Movies</span>',items:rawPools.popularMovies,viewAllHref:'/movies',viewAllText:'Browse Movies'})}${renderHomeCategory({key:'popularTv',iconName:'tv',label:'Popular <span class="pink">Series</span>',items:rawPools.popularTv,viewAllHref:'/series',viewAllText:'Browse Series'})}${renderHomeCategory({key:'latestAnime',iconName:'clock',label:'Latest <span class="pink">Anime Episodes</span>',items:rawPools.latestAnime,viewAllHref:'/anime?sort=newest',viewAllText:'Latest Anime'})}${renderHomeCategory({key:'topRatedMovies',iconName:'star',label:'Top Rated <span class="pink">Movies</span>',items:rawPools.topRatedMovies,viewAllHref:'/movies?sort=rating',viewAllText:'Top Rated Movies'})}${renderHomeCategory({key:'topRatedTv',iconName:'star',label:'Top Rated <span class="pink">Series</span>',items:rawPools.topRatedTv,viewAllHref:'/series?sort=rating',viewAllText:'Top Rated Series'})}${renderHomeCategory({key:'airingAnime',iconName:'trending',label:'Top Airing <span class="pink">Anime</span>',items:rawPools.airingAnime,viewAllHref:'/anime?status=releasing',viewAllText:'Airing Anime'})}</div>`;
 mountHero(d.spotlight?.length?d.spotlight:d.items);
 bindCards();
 bindHomeCategories(sectionPools);
}

function buildYearOptions(selected){
 const maxY=new Date().getFullYear();
 const eras=[['2020s','2020s (2020–Now)'],['2010s','2010s (2010–2019)'],['2000s','2000s (2000–2009)'],['1990s','1990s (1990–1999)'],['1980s','1980s (1980–1989)'],['classic','Classic (Pre-1980)']];
 let html='<option value="">All Years</option>';
 html+='<optgroup label="Decades &amp; Eras">'+eras.map(([v,lbl])=>`<option value="${v}" ${selected===v?'selected':''}>${lbl}</option>`).join('')+'</optgroup>';
 html+='<optgroup label="Release Year">';
 for(let y=maxY;y>=1970;y--)html+=`<option value="${y}" ${String(selected)===String(y)?'selected':''}>${y}</option>`;
 html+='</optgroup>';
 return html;
}

async function renderCatalogExplorer(fixedType,qParams,token){
 const type=fixedType||(['all','movie','tv','anime'].includes(qParams.get('type'))?qParams.get('type'):'all');
 const genre=genres.includes(qParams.get('genre'))?qParams.get('genre'):'';
 const year=qParams.get('year')||'';
 const lang=qParams.get('lang')||'';
 const sort=['popularity','trending','rating','newest','title'].includes(qParams.get('sort'))?qParams.get('sort'):'popularity';
 const status=['releasing','finished'].includes(qParams.get('status'))?qParams.get('status'):'';
 const dub=qParams.get('dub')==='1'||qParams.get('dub')==='true';
 const kw=(qParams.get('q')||'').trim();

 const apiQuery=page=>{
  if(kw){
   const sp=new URLSearchParams({q:kw,type,page:String(page)});
   return `/api/search-all?${sp}`;
  }
  const sp=new URLSearchParams({type,sort,page:String(page)});
  if(genre)sp.set('genre',genre);
  if(year)sp.set('year',year);
  if(lang&&type!=='anime')sp.set('lang',lang);
  if(status&&(type==='anime'||type==='all'))sp.set('status',status);
  if(dub&&type==='anime')sp.set('dub','1');
  return `/api/filter?${sp}`;
 };

 const d=await getJSON(apiQuery(1));
 if(token!==currentRoute)return;

 const headingMeta={
  movie:{icon:'film',title:'Explore <span class="pink">Movies</span>'},
  tv:{icon:'tv',title:'Explore <span class="pink">TV Shows</span>'},
  anime:{icon:'spark',title:'Explore <span class="pink">Anime</span>'},
  all:{icon:'filter',title:'Catalog <span class="pink">Explorer</span>'}
 }[type]||{icon:'filter',title:'Catalog <span class="pink">Explorer</span>'};

 const showTypeSelect=!fixedType;
 const showLangSelect=type!=='anime';
 const showAnimeControls=type==='anime'||type==='all';

 const countNum=Number(d.totalResults)||d.items.length;
 const basePath=fixedType==='movie'?'/movies':fixedType==='tv'?'/series':fixedType==='anime'?'/anime':'/filters';

 app.innerHTML=`<div class="container content">
  <div class="page-title-row">
   ${sectionTitle(headingMeta.icon,headingMeta.title,'h1')}
   <div class="catalog-count-badge" id="cat-count-badge"><b>${fmtNum(countNum)}${countNum>=1000?'+':''}</b> <span>streamable titles</span></div>
  </div>
  ${!fixedType?`<div class="type-pills" id="cat-type-pills">
   ${[['all','All Catalogs'],['movie','Movies'],['tv','TV Shows'],['anime','Anime']].map(([val,lbl])=>`<button type="button" class="type-pill ${type===val?'active':''}" data-type-pill="${val}">${lbl}</button>`).join('')}
  </div>`:''}
  <form class="catalog-toolbar" id="catalog-form">
   <label>Keyword<input name="q" value="${esc(kw)}" placeholder="Filter by title..."></label>
   ${showTypeSelect?`<input type="hidden" name="type" value="${esc(type)}">`:''}
   <label>Genre<select name="genre"><option value="">All Genres</option>${genres.map(g=>`<option value="${esc(g)}" ${genre===g?'selected':''}>${esc(g)}</option>`).join('')}</select></label>
   ${showLangSelect?`<label>Language<select name="lang"><option value="">All Languages</option>${catalogLanguages.map(l=>`<option value="${l.code}" ${lang===l.code?'selected':''}>${esc(l.name)}</option>`).join('')}</select></label>`:''}
   <label>Year / Era<select name="year">${buildYearOptions(year)}</select></label>
   ${showAnimeControls?`<label>Status<select name="status"><option value="">Any Status</option><option value="releasing" ${status==='releasing'?'selected':''}>Currently Airing</option><option value="finished" ${status==='finished'?'selected':''}>Finished</option></select></label>`:''}
   ${type==='anime'?`<label>Audio<select name="dub"><option value="">Sub &amp; Dub</option><option value="1" ${dub?'selected':''}>English Dub Available</option></select></label>`:''}
   <label>Sort By<select name="sort">
    <option value="popularity" ${sort==='popularity'?'selected':''}>Most Popular</option>
    <option value="trending" ${sort==='trending'?'selected':''}>Trending Weekly</option>
    <option value="rating" ${sort==='rating'?'selected':''}>Top Rated</option>
    <option value="newest" ${sort==='newest'?'selected':''}>Newest Releases</option>
    <option value="title" ${sort==='title'?'selected':''}>Title (A–Z)</option>
   </select></label>
   <button class="btn" type="submit">Apply</button>
  </form>
  ${d.items.length?`<div class="grid" id="catalog-grid">${d.items.map(card).join('')}</div>`:`<div class="empty"><h2>No matching titles</h2><p>Try clearing one of the filters or choosing another year or language.</p></div>`}
  ${d.hasMore?`<div class="load-more-wrap" id="catalog-more-wrap"><button type="button" class="load-more-btn" id="catalog-more-btn">Load more titles</button><span class="load-more-sub" id="catalog-more-sub">Showing ${fmtNum(d.items.length)} of ${fmtNum(countNum)}+</span></div>`:''}
 </div>`;

 bindCards();

 const submitFilters=overrideType=>{
  const f=document.getElementById('catalog-form');
  if(!f)return;
  const fd=new FormData(f);
  const nextParams=new URLSearchParams();
  const chosenType=overrideType||(fixedType||fd.get('type')||'all');
  if(!fixedType&&chosenType&&chosenType!=='all')nextParams.set('type',chosenType);
  for(const k of ['q','genre','lang','year','status','dub','sort']){
   const v=String(fd.get(k)||'').trim();
   if(!v||(k==='sort'&&v==='popularity'))continue;
   nextParams.set(k,v);
  }
  const qs=nextParams.toString();
  go(basePath+(qs?'?'+qs:''));
 };

 const formEl=document.getElementById('catalog-form');
 formEl.onsubmit=e=>{e.preventDefault();submitFilters()};
 formEl.querySelectorAll('select').forEach(sel=>{sel.onchange=()=>submitFilters()});
 app.querySelectorAll('[data-type-pill]').forEach(btn=>{btn.onclick=()=>submitFilters(btn.dataset.typePill)});

 let curPage=1;
 let seenKeys=new Set(d.items.map(x=>`${x.type}:${x.id}`));
 let shownCount=d.items.length;
 const moreBtn=document.getElementById('catalog-more-btn');
 if(moreBtn){
  moreBtn.onclick=async()=>{
   if(moreBtn.disabled)return;
   moreBtn.disabled=true;
   const prevText=moreBtn.textContent;
   moreBtn.innerHTML='<span class="button-loader" aria-hidden="true"></span>';
   try{
    const nextPage=curPage+1;
    const nextData=await getJSON(apiQuery(nextPage));
    curPage=nextPage;
    const fresh=[];
    for(const it of nextData.items||[]){
     const k=`${it.type}:${it.id}`;
     if(!seenKeys.has(k)){seenKeys.add(k);fresh.push(it)}
    }
    const grid=document.getElementById('catalog-grid');
    if(fresh.length&&grid){
     grid.insertAdjacentHTML('beforeend',fresh.map(card).join(''));
     bindCards(grid);
     shownCount+=fresh.length;
    }
    const sub=document.getElementById('catalog-more-sub');
    if(sub)sub.textContent=`Showing ${fmtNum(shownCount)} of ${fmtNum(Math.max(shownCount,countNum))}+`;
    if(!nextData.hasMore||!(nextData.items||[]).length){
     document.getElementById('catalog-more-wrap')?.remove();
     return;
    }
   }catch{}
   moreBtn.textContent=prevText;
   moreBtn.disabled=false;
  };
 }
}

async function renderGenre(slug,qParams,token){
 let g=genres.find(x=>slugify(x)===slug);
 if(!g){app.innerHTML='<div class="container content"><div class="empty"><h2>Genre not found</h2></div></div>';return}
 const type=['all','movie','tv','anime'].includes(qParams.get('type'))?qParams.get('type'):'all';
 const sort=['popularity','rating','newest','title'].includes(qParams.get('sort'))?qParams.get('sort'):'popularity';
 const buildUrl=p=>`/api/genre?name=${encodeURIComponent(g)}&type=${encodeURIComponent(type)}&sort=${encodeURIComponent(sort)}&page=${p}`;
 let d=await getJSON(buildUrl(1));
 if(token!==currentRoute)return;
 const total=Number(d.totalResults)||d.items.length;

 app.innerHTML=`<div class="container content">
  <div class="page-title-row">
   ${sectionTitle('grid',`${esc(g)} <span class="pink">Titles</span>`,'h1')}
   <div class="catalog-count-badge"><b>${fmtNum(total)}${total>=1000?'+':''}</b> <span>in ${esc(g)}</span></div>
  </div>
  <div class="type-pills">
   ${[['all','All'],['movie','Movies'],['tv','TV Shows'],['anime','Anime']].map(([val,lbl])=>`<button type="button" class="type-pill ${type===val?'active':''}" data-genre-type="${val}">${lbl}</button>`).join('')}
   <select id="genre-sort" style="margin-left:auto;height:36px;padding:0 12px;border:1px solid #383c48;border-radius:999px;background:#181a22;color:#eef0f5;font-size:12.5px">
    <option value="popularity" ${sort==='popularity'?'selected':''}>Most Popular</option>
    <option value="rating" ${sort==='rating'?'selected':''}>Top Rated</option>
    <option value="newest" ${sort==='newest'?'selected':''}>Newest</option>
    <option value="title" ${sort==='title'?'selected':''}>Title (A–Z)</option>
   </select>
  </div>
  ${d.items.length?`<div class="grid" id="genre-grid">${d.items.map(card).join('')}</div>`:`<div class="empty"><h2>No titles in ${esc(g)}</h2></div>`}
  ${d.hasMore?`<div class="load-more-wrap" id="genre-more-wrap"><button type="button" class="load-more-btn" id="genre-more-btn">Load more ${esc(g)}</button><span class="load-more-sub" id="genre-more-sub">Showing ${fmtNum(d.items.length)} of ${fmtNum(total)}+</span></div>`:''}
 </div>`;
 bindCards();

 const navGenre=(nextType,nextSort)=>{
  const sp=new URLSearchParams();
  if(nextType&&nextType!=='all')sp.set('type',nextType);
  if(nextSort&&nextSort!=='popularity')sp.set('sort',nextSort);
  const qs=sp.toString();
  go(`/genre/${slug}`+(qs?'?'+qs:''));
 };
 app.querySelectorAll('[data-genre-type]').forEach(b=>{b.onclick=()=>navGenre(b.dataset.genreType,sort)});
 document.getElementById('genre-sort')?.addEventListener('change',e=>navGenre(type,e.target.value));

 let curPage=1,shown=d.items.length,seen=new Set(d.items.map(x=>`${x.type}:${x.id}`));
 const moreBtn=document.getElementById('genre-more-btn');
 if(moreBtn){
  moreBtn.onclick=async()=>{
   if(moreBtn.disabled)return;
   moreBtn.disabled=true;
   const txt=moreBtn.textContent;
   moreBtn.innerHTML='<span class="button-loader" aria-hidden="true"></span>';
   try{
    const next=await getJSON(buildUrl(++curPage));
    const fresh=(next.items||[]).filter(it=>{const k=`${it.type}:${it.id}`;if(seen.has(k))return false;seen.add(k);return true});
    const grid=document.getElementById('genre-grid');
    if(fresh.length&&grid){grid.insertAdjacentHTML('beforeend',fresh.map(card).join(''));bindCards(grid);shown+=fresh.length}
    const sub=document.getElementById('genre-more-sub');
    if(sub)sub.textContent=`Showing ${fmtNum(shown)} of ${fmtNum(Math.max(shown,total))}+`;
    if(!next.hasMore||!(next.items||[]).length){document.getElementById('genre-more-wrap')?.remove();return}
   }catch{}
   moreBtn.textContent=txt;
   moreBtn.disabled=false;
  };
 }
}

async function renderSearch(qParams,token){
 const q=(qParams.get('q')||'').trim();
 const type=['all','movie','tv','anime'].includes(qParams.get('type'))?qParams.get('type'):'all';
 searchInput.value=q;
 if(!q)return go('/browse',true);
 const buildUrl=p=>`/api/search-all?q=${encodeURIComponent(q)}&type=${encodeURIComponent(type)}&page=${p}`;
 let d=await getJSON(buildUrl(1));
 if(token!==currentRoute)return;
 const total=Number(d.totalResults)||d.items.length;

 app.innerHTML=`<div class="container content">
  <div class="page-title-row">
   ${sectionTitle('search',`Results for <span class="pink">${esc(q)}</span>`,'h1')}
   <div class="catalog-count-badge"><b>${fmtNum(total)}</b> <span>matching titles</span></div>
  </div>
  <div class="type-pills">
   ${[['all','All Results'],['movie','Movies'],['tv','TV Shows'],['anime','Anime']].map(([val,lbl])=>`<button type="button" class="type-pill ${type===val?'active':''}" data-search-type="${val}">${lbl}</button>`).join('')}
  </div>
  ${d.items.length?`<div class="grid" id="search-grid">${d.items.map(card).join('')}</div>`:`<div class="empty"><h2>No matches found</h2><p>Try another title, actor, or browse Movies, TV Shows &amp; Anime above.</p></div>`}
  ${d.hasMore?`<div class="load-more-wrap" id="search-more-wrap"><button type="button" class="load-more-btn" id="search-more-btn">Load more results</button><span class="load-more-sub" id="search-more-sub">Showing ${fmtNum(d.items.length)} of ${fmtNum(total)}</span></div>`:''}
 </div>`;
 bindCards();

 app.querySelectorAll('[data-search-type]').forEach(b=>{
  b.onclick=()=>{
   const sp=new URLSearchParams({q});
   if(b.dataset.searchType!=='all')sp.set('type',b.dataset.searchType);
   go('/search?'+sp.toString(),true);
  };
 });

 let curPage=1,shown=d.items.length,seen=new Set(d.items.map(x=>`${x.type}:${x.id}`));
 const moreBtn=document.getElementById('search-more-btn');
 if(moreBtn){
  moreBtn.onclick=async()=>{
   if(moreBtn.disabled)return;
   moreBtn.disabled=true;
   const txt=moreBtn.textContent;
   moreBtn.innerHTML='<span class="button-loader" aria-hidden="true"></span>';
   try{
    const next=await getJSON(buildUrl(++curPage));
    const fresh=(next.items||[]).filter(it=>{const k=`${it.type}:${it.id}`;if(seen.has(k))return false;seen.add(k);return true});
    const grid=document.getElementById('search-grid');
    if(fresh.length&&grid){grid.insertAdjacentHTML('beforeend',fresh.map(card).join(''));bindCards(grid);shown+=fresh.length}
    const sub=document.getElementById('search-more-sub');
    if(sub)sub.textContent=`Showing ${fmtNum(shown)} of ${fmtNum(Math.max(shown,total))}`;
    if(!next.hasMore||!(next.items||[]).length){document.getElementById('search-more-wrap')?.remove();return}
   }catch{}
   moreBtn.textContent=txt;
   moreBtn.disabled=false;
  };
 }
}

function renderAnimeSeasonSelect(seasons,currentId,mode){
 if(!Array.isArray(seasons)||seasons.length<2)return '';
 return `<div class="season-section">${sectionTitle('tv','Seasons')}<select class="season-select" id="anime-season-select">${seasons.map((s,idx)=>`<option value="${esc(s.id)}" data-slug="${esc(slugify(s.name))}" ${String(s.id)===String(currentId)?'selected':''}>Season ${idx+1}: ${esc(s.name)}${s.episodes?` (${s.episodes} eps)`:''}</option>`).join('')}</select></div>`;
}
function bindAnimeSeasonSelect(mode){
 let sel=document.getElementById('anime-season-select');
 if(!sel)return;
 sel.onchange=()=>{
  let opt=sel.selectedOptions[0],targetId=sel.value,slug=opt?.dataset.slug||'anime';
  go(mode==='watch'?`/watch/${targetId}-${slug}/ep-1`:`/title/anime/${targetId}-${slug}`);
 };
}

function mountAnimeEpisodeBrowser({item,containerId,selectedEp=0,initialPage=1}){
 let box=document.getElementById(containerId);
 if(!box)return;
 let page=initialPage,loaded=[],hasNext=false,loadingMore=false;
 const draw=()=>{
  box.innerHTML=`<div class="episode-detail-list">${loaded.map(e=>`<button class="episode-row ${Number(e.number)===Number(selectedEp)?'selected':''}" data-ep="${e.number}"><img src="${esc(e.still||item.backdrop||item.poster||posterFallbackUri(item.title,'anime'))}" data-media-type="anime" alt="" loading="lazy"><span><strong>Ep ${e.number} • ${esc(e.title||`Episode ${e.number}`)}</strong>${e.description?`<small>${esc(e.description)}</small>`:''}</span></button>`).join('')}</div>${hasNext?`<div class="anime-pagination"><button class="btn secondary" id="${containerId}-more" ${loadingMore?'disabled':''}>${loadingMore?'<span class="button-loader" aria-hidden="true"></span>':'Show more'}</button></div>`:''}`;
  box.querySelectorAll('[data-ep]').forEach(b=>b.onclick=()=>go(watchPath(item,b.dataset.ep,1)));
  let more=document.getElementById(`${containerId}-more`);
  if(more)more.onclick=()=>loadPage(page+1,true);
 };
 const loadPage=async(targetPage,append)=>{
  loadingMore=true;
  if(append)draw();else box.innerHTML='<div class="loading">Loading episodes...</div>';
  try{
   let d=await getJSON(`/api/anime-episodes?id=${item.id}&page=${targetPage}`);
   page=d.page;hasNext=d.hasNext;
   loaded=append?[...loaded,...d.episodes]:d.episodes;
   loadingMore=false;draw();
  }catch(e){
   loadingMore=false;
   box.innerHTML=`<p class="error">${esc(e.message)}</p>`;
  }
 };
 loadPage(initialPage,false);
}

async function renderDetail(type,id,token){
 let d=await getJSON(`/api/detail?type=${type}&id=${id}`);
 if(token!==currentRoute)return;
 let x=d.item,isSaved=saved(x.id,x.type),showAnimeEpisodes=x.type==='anime'&&!x.isMovie&&x.format!=='MOVIE',desc=cleanDescription(x.description),prog=resumeProgress(x);
 let watchHref=prog&&isEpisodicItem(x)?watchPath(x,prog.episode||1,prog.season||1):watchPath(x,1,d.seasons?.[0]?.number||1);
 let watchLabel=prog&&isEpisodicItem(x)?`Resume Ep ${prog.episode||1}`:'Watch Now';
 app.innerHTML=`<div class="container content detail"><div class="detail-layout"><img class="detail-poster" src="${esc(x.poster||posterFallbackUri(x.title,x.type))}" data-media-type="${esc(x.type)}" alt="${esc(x.title)}"><div class="detail-heading"><h1>${esc(x.title)}</h1><div class="meta"><span>${esc(x.type==='anime'?(x.isMovie||x.format==='MOVIE'?'Anime Movie':'Anime Series'):x.type==='tv'?'Web Series':'Movie')}</span>${x.year?`<span>${icon('calendar')}${esc(x.year)}</span>`:''}${x.rating?`<span>${icon('star')}${esc(x.rating)}</span>`:''}${x.episodes?`<span>${esc(x.episodes)} episodes</span>`:''}</div></div><div class="detail-body">${desc?`<p class="detail-description" id="detail-description" title="Click to expand or collapse">${esc(desc)}</p>`:''}<div class="chips">${(x.genres||[]).map(g=>`<a class="chip" href="/genre/${slugify(g)}">${esc(g)}</a>`).join('')}</div><div class="actions"><a class="btn" href="${esc(watchHref)}">${icon('play')} ${esc(watchLabel)}</a><button class="btn secondary" id="detail-save">${icon('bookmark')} ${isSaved?'In Watchlist':'Add to Watchlist'}</button></div></div></div>${x.type==='anime'?renderAnimeSeasonSelect(d.seasons,x.id,'detail'):''}${d.seasons?.length&&x.type==='tv'?`<div class="season-section">${sectionTitle('tv','Seasons &amp; Episodes')}<select class="season-select" id="season-select">${d.seasons.map(s=>`<option value="${s.number}">${esc(s.name)} (${s.episodes} eps)</option>`).join('')}</select><div id="season-episodes" class="episode-detail-list"></div></div>`:''}${showAnimeEpisodes?`<div class="season-section">${sectionTitle('tv','Episodes')}<div id="anime-episodes" class="anime-episodes"></div></div>`:''}</div>`;
 let descEl=document.getElementById('detail-description');
 if(descEl)descEl.onclick=()=>{if(String(window.getSelection?.()||'').length)return;descEl.classList.toggle('expanded')};
 document.getElementById('detail-save').onclick=async()=>{await saveItem(x,!saved(x.id,x.type));renderDetail(type,id,token)};
 bindAnimeSeasonSelect('detail');
 if(d.seasons?.length&&x.type==='tv'){
  let sel=document.getElementById('season-select'),box=document.getElementById('season-episodes');
  const loadSeason=async n=>{
   box.innerHTML='<div class="loading">Loading episodes...</div>';
   let s=await getJSON(`/api/season?id=${x.id}&season=${n}`);
   box.innerHTML=s.episodes.length?s.episodes.map(e=>`<button class="episode-row" data-ep="${e.number}"><img src="${esc(e.still||x.backdrop||x.poster||posterFallbackUri(x.title,'tv'))}" data-media-type="tv" alt="" loading="lazy"><span><strong>Ep ${e.number} • ${esc(e.title)}</strong>${e.description?`<small>${esc(cleanDescription(e.description))}</small>`:''}</span></button>`).join(''):'<p class="muted">No aired episodes in this season yet.</p>';
   box.querySelectorAll('[data-ep]').forEach(b=>b.onclick=()=>go(watchPath(x,b.dataset.ep,n)));
  };
  sel.onchange=()=>loadSeason(sel.value);
  loadSeason(sel.value);
 }
 if(showAnimeEpisodes)mountAnimeEpisodeBrowser({item:x,containerId:'anime-episodes',selectedEp:prog?.episode||0,initialPage:1});
}

async function renderWatch(type,id,episode,season,token){
 let d=await getJSON(`/api/detail?type=${type}&id=${id}`);
 if(token!==currentRoute)return;
 let x=d.item,ep=Math.max(1,Number(episode)||1),sn=Math.max(1,Number(season)||1);
 let isEpisodic=isEpisodicItem(x),savedEntry=resumeProgress(x);
 let resumeAt=savedEntry&&Number(savedEntry.episode||1)===ep&&Number(savedEntry.season||1)===sn?Number(savedEntry.currentTime)||0:0;
 state=await postJSON('/api/history',{...x,episode:ep,season:sn,currentTime:resumeAt||undefined});
 if(token!==currentRoute)return;
 let lang=localStorage.getItem('moscowtv-lang')==='dub'?'dub':'sub';
 if(type==='anime'&&lang==='dub'&&x.dub===false)lang='sub';
 let storedServer=localStorage.getItem('moscowtv-ott-server');
 let server=ottServers.some(([k])=>k===storedServer)?storedServer:'vidcore';
 let autoPlay=readSetting('autoplay',true),autoNext=readSetting('autonext',true);

 let tvSeasonEpisodes=[];
 if(type==='tv'&&d.seasons?.length){
  let validSeason=d.seasons.some(s=>Number(s.number)===sn)?sn:d.seasons[0].number;
  sn=Number(validSeason)||1;
  let sData=await getJSON(`/api/season?id=${x.id}&season=${sn}`).catch(()=>({episodes:[]}));
  if(token!==currentRoute)return;
  tvSeasonEpisodes=sData.episodes||[];
 }

 const episodeHasNext=()=>{
  if(!isEpisodic)return false;
  if(type==='anime')return x.episodes?ep<x.episodes:true;
  if(type==='tv')return tvSeasonEpisodes.some(e=>Number(e.number)>ep)||(d.seasons||[]).some(s=>Number(s.number)>sn);
  return false;
 };
 const goNextEpisode=()=>{
  if(!isEpisodic)return;
  if(type==='anime')return go(watchPath(x,ep+1,1));
  let nextInSeason=tvSeasonEpisodes.find(e=>Number(e.number)>ep);
  if(nextInSeason)return go(watchPath(x,nextInSeason.number,sn));
  let nextSeason=(d.seasons||[]).find(s=>Number(s.number)>sn);
  if(nextSeason)return go(watchPath(x,1,nextSeason.number));
 };
 const goPrevEpisode=()=>{if(ep>1)go(watchPath(x,ep-1,sn))};

 const currentLabel=()=>type==='anime'?(lang==='dub'?'MegaPlay (Dub)':'MegaPlay (Sub)'):(ottServers.find(([k])=>k===server)?.[1]||'VidCore');

 app.innerHTML=`<div class="container content"><div class="player-wrap"><h1 class="watch-title" id="watch-title" hidden>${esc(x.title)}</h1><div class="player" id="player"><div class="loading">Preparing stream...</div></div><div class="player-controls reference-controls"><div class="control-row"><button type="button" data-setting="autoplay" class="${autoPlay?'on':''}">Auto Play <span class="setting-check">${autoPlay?'✓':'•'}</span></button>${isEpisodic?`<button type="button" data-setting="autonext" class="${autoNext?'on':''}">Auto Next <span class="setting-check">${autoNext?'✓':'•'}</span></button>`:''}<button type="button" id="light-toggle">Light</button><span class="spacer"></span>${isEpisodic?`<button type="button" class="player-icon" id="prev-ep" ${ep<=1?'disabled':''} aria-label="Previous episode" title="Previous episode">${icons.prev}</button><button type="button" class="player-icon" id="next-ep" ${!episodeHasNext()?'disabled':''} aria-label="Next episode" title="Next episode">${icons.next}</button>`:''}<button type="button" class="player-icon ${saved(x.id,x.type)?'on':''}" data-save title="Save to Watchlist">${icon('bookmark')}</button></div><div class="control-row">${type==='anime'?'':`<button type="button" id="server-btn">${icons.server} Server</button>`}<span class="spacer"></span></div></div><p class="watching-note" id="watching-note">You are watching <strong>${esc(isEpisodic?`Episode ${ep}`:x.title)}</strong> on <strong>${esc(currentLabel())}</strong>.${type==='anime'?' Use the <strong>Sub / Dub</strong> button inside the player to switch audio.':' If a server buffers, tap the gear or <strong>Server</strong> button to switch.'}</p>${type==='anime'?'':`<div class="server-panel" id="server-panel" hidden><div class="server-list">${ottServers.map(([k,n])=>`<button type="button" data-server="${k}" class="${server===k?'active':''}">${esc(n)}</button>`).join('')}</div></div>`}</div>${type==='anime'?renderAnimeSeasonSelect(d.seasons,x.id,'watch'):''}${type==='tv'&&d.seasons?.length?`<div class="season-section">${sectionTitle('tv','Seasons &amp; Episodes')}<select class="season-select" id="watch-season-select">${d.seasons.map(s=>`<option value="${s.number}" ${Number(s.number)===sn?'selected':''}>${esc(s.name)} (${s.episodes} eps)</option>`).join('')}</select><div id="watch-season-episodes" class="episode-detail-list"></div></div>`:''}${type==='anime'&&isEpisodic?`<div class="season-section">${sectionTitle('tv','Episodes')}<div id="watch-anime-episodes" class="anime-episodes"></div></div>`:''}</div>`;

 bindAnimeSeasonSelect('watch');
 if(type==='anime'&&isEpisodic){
  mountAnimeEpisodeBrowser({item:x,containerId:'watch-anime-episodes',selectedEp:ep,initialPage:Math.max(1,Math.ceil(ep/20))});
 }
 if(type==='tv'&&d.seasons?.length){
  let sel=document.getElementById('watch-season-select'),box=document.getElementById('watch-season-episodes');
  const drawTvEps=eps=>{
   box.innerHTML=eps.length?eps.map(e=>`<button class="episode-row ${Number(e.number)===ep&&Number(sel.value)===sn?'selected':''}" data-ep="${e.number}"><img src="${esc(e.still||x.backdrop||x.poster||posterFallbackUri(x.title,'tv'))}" data-media-type="tv" alt="" loading="lazy"><span><strong>Ep ${e.number} • ${esc(e.title)}</strong>${e.description?`<small>${esc(cleanDescription(e.description))}</small>`:''}</span></button>`).join(''):'<p class="muted">No aired episodes in this season yet.</p>';
   box.querySelectorAll('[data-ep]').forEach(b=>b.onclick=()=>go(watchPath(x,b.dataset.ep,sel.value)));
  };
  drawTvEps(tvSeasonEpisodes);
  sel.onchange=async()=>{
   box.innerHTML='<div class="loading">Loading episodes...</div>';
   let s=await getJSON(`/api/season?id=${x.id}&season=${sel.value}`);
   drawTvEps(s.episodes||[]);
  };
 }

 const updateNote=provLabel=>{
  let note=document.getElementById('watching-note');
  if(note)note.innerHTML=`You are watching <strong>${esc(isEpisodic?`Episode ${ep}`:x.title)}</strong> on <strong>${esc(provLabel||currentLabel())}</strong>.${type==='anime'?' Use the <strong>Sub / Dub</strong> button inside the player to switch audio.':' If a server buffers, tap the gear or <strong>Server</strong> button to switch.'}`;
 };

 let lastSavedSec=0;
 const reportProgress=(cur,dur)=>{
  if(Math.abs(cur-lastSavedSec)<8&&cur<dur-3)return;
  lastSavedSec=cur;
  postJSON('/api/history',{...x,episode:ep,season:sn,currentTime:Math.floor(cur),duration:Math.floor(dur||0)}).then(s=>{state=s}).catch(()=>{});
 };

 const loadStream=async()=>{
  destroyPlayer();
  let box=document.getElementById('player');
  if(!box)return;
  box.innerHTML='<div class="loading">Preparing stream...</div>';
  try{
   let q=`/api/play?type=${type}&id=${id}&episode=${ep}&season=${sn}&lang=${lang}&provider=${server}${x.anilistId?`&anilistId=${x.anilistId}`:''}`;
   let [playData]=await Promise.all([getJSON(q),ensureVideoAssets()]);
   if(token!==currentRoute||!document.getElementById('player'))return;
   if(type!=='anime'&&playData.sourceKey&&ottServers.some(([k])=>k===playData.sourceKey)){
    server=playData.sourceKey;
    app.querySelectorAll('[data-server]').forEach(b=>b.classList.toggle('active',b.dataset.server===server));
   }
   document.getElementById('watch-title')?.removeAttribute('hidden');
   updateNote(type==='anime'?`${playData.provider||'MegaPlay'} (${lang==='dub'?'Dub':'Sub'})`:(playData.provider||currentLabel()));
   box.innerHTML='<video id="vjs-player" class="video-js" playsinline preload="auto"></video>';
   let vjs=window.videojs('vjs-player',{controls:false,autoplay:autoPlay,preload:'auto',fluid:false,responsive:false,html5:{vhs:{overrideNative:true,enableLowInitialPlaylist:false,smoothQualityChange:true,bandwidth:16000000,limitRenditionByPlayerDimensions:false}}});
   let uiHandle=window.MegaPlayUI.create(vjs,{
    data:playData,
    item:x,
    lang,
    server,
    autoplay:autoPlay,
    hasPrevEpisode:isEpisodic&&ep>1,
    hasNextEpisode:episodeHasNext(),
    onPrevEpisode:goPrevEpisode,
    onNextEpisode:goNextEpisode,
    onAudioChange:nextLang=>{lang=nextLang;localStorage.setItem('moscowtv-lang',lang);resumeAt=Number(vjs.currentTime?.())||resumeAt;loadStream()},
    onServerChange:nextSrv=>{server=nextSrv;localStorage.setItem('moscowtv-ott-server',server);app.querySelectorAll('[data-server]').forEach(b=>b.classList.toggle('active',b.dataset.server===server));resumeAt=Number(vjs.currentTime?.())||resumeAt;loadStream()}
   });
   vjs.src({src:playData.src,type:playData.type||'application/x-mpegURL'});
   if(resumeAt>3){
    vjs.one('loadedmetadata',()=>{try{let dur=Number(vjs.duration())||0;if(!dur||resumeAt<dur-8)vjs.currentTime(resumeAt)}catch{}});
   }
   vjs.on('timeupdate',()=>{try{reportProgress(Number(vjs.currentTime())||0,Number(vjs.duration())||0)}catch{}});
   vjs.on('ended',()=>{if(autoNext&&episodeHasNext())goNextEpisode()});
   if(autoPlay){vjs.play().catch(()=>uiHandle?.onAutoplayBlocked?.())}
   activePlayerHandle={dispose:()=>{try{vjs.dispose()}catch{}}};
  }catch(e){
   if(token!==currentRoute||!document.getElementById('player'))return;
   if(type==='anime'&&/availableLang|not available/i.test(e.message||'')){
    let alt=lang==='dub'?'sub':'dub';
    if(!box.dataset.retriedLang){
     box.dataset.retriedLang='1';
     lang=alt;localStorage.setItem('moscowtv-lang',lang);
     return loadStream();
    }
   }
   document.getElementById('watch-title')?.removeAttribute('hidden');
   box.innerHTML=`<div class="empty player-error"><strong>Stream Unavailable</strong><span>${esc(e.message||'Could not load this stream right now.')}</span><button class="btn" id="retry-stream">Retry</button></div>`;
   let rb=document.getElementById('retry-stream');if(rb)rb.onclick=()=>loadStream();
  }
 };

 app.querySelectorAll('[data-setting]').forEach(btn=>btn.onclick=()=>{
  let k=btn.dataset.setting,next=!(k==='autoplay'?autoPlay:autoNext);
  if(k==='autoplay')autoPlay=next;else autoNext=next;
  writeSetting(k,next);
  btn.classList.toggle('on',next);
  btn.querySelector('.setting-check').textContent=next?'✓':'•';
 });
 document.getElementById('light-toggle').onclick=()=>document.body.classList.toggle('light-off');
 let prevBtn=document.getElementById('prev-ep');if(prevBtn)prevBtn.onclick=goPrevEpisode;
 let nextBtn=document.getElementById('next-ep');if(nextBtn)nextBtn.onclick=goNextEpisode;
 let saveBtn=app.querySelector('[data-save]');
 if(saveBtn)saveBtn.onclick=async()=>{await saveItem(x,!saved(x.id,x.type));saveBtn.classList.toggle('on',saved(x.id,x.type))};
 let srvBtn=document.getElementById('server-btn'),srvPanel=document.getElementById('server-panel');
 if(srvBtn&&srvPanel){
  srvBtn.onclick=()=>{srvPanel.hidden=!srvPanel.hidden};
  srvPanel.querySelectorAll('[data-server]').forEach(b=>b.onclick=()=>{
   server=b.dataset.server;localStorage.setItem('moscowtv-ott-server',server);
   srvPanel.querySelectorAll('[data-server]').forEach(el=>el.classList.toggle('active',el===b));
   srvPanel.hidden=true;
   loadStream();
  });
 }
 loadStream();
}

async function renderWatchlist(){
 app.innerHTML=`<div class="container content">${sectionTitle('bookmark','Your <span class="pink">Watchlist</span>','h1')}${state.watchlist.length?`<div class="grid">${state.watchlist.map(card).join('')}</div>`:'<div class="empty"><h2>Your watchlist is empty</h2><p>Bookmark any anime, movie or web series to keep it handy here.</p></div>'}${renderHistorySection(state.history,8,false)}</div>`;
 bindCards();
}

async function renderSchedule(token){
 let d=await getJSON('/api/schedule');
 if(token!==currentRoute)return;
 let groups=new Map();
 for(let e of d.entries||[]){
  let dt=new Date(e.airingAt*1000),dayKey=dt.toLocaleDateString(undefined,{weekday:'long',month:'short',day:'numeric'});
  if(!groups.has(dayKey))groups.set(dayKey,[]);
  groups.get(dayKey).push({...e,timeStr:dt.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'})});
 }
 app.innerHTML=`<div class="container content">${sectionTitle('calendar','Airing <span class="pink">Schedule</span>','h1')}${groups.size?[...groups.entries()].map(([day,rows])=>`<div class="schedule-day"><h2>${esc(day)}</h2>${rows.map(r=>`<div class="schedule-row" data-open="${esc(detailPath(r.item))}"><img src="${esc(r.item.poster||posterFallbackUri(r.item.title,'anime'))}" data-media-type="anime" alt="" loading="lazy"><div><strong>${esc(r.item.title)}</strong><span>Episode ${esc(r.episode)}</span></div><b>${esc(r.timeStr)}</b></div>`).join('')}</div>`).join(''):'<div class="empty"><h2>No upcoming schedule slots</h2></div>'}</div>`;
 bindCards();
}

async function renderRandom(token){
 let d=await getJSON('/api/random');
 if(token!==currentRoute)return;
 go(detailPath(d.item),true);
}

async function route(){
 let token=++currentRoute;
 clearInterval(heroTimer);
 destroyPlayer();
 document.body.classList.remove('route-ready');
 let p=location.pathname,q=new URLSearchParams(location.search);
 updateActiveNav(p);
 if(p!=='/search'&&searchInput.value)searchInput.value='';
 app.innerHTML='<div class="loading">Loading...</div>';
 try{
  if(!state.loaded){let s=await getJSON('/api/state');state={...s,loaded:true}}
  if(p==='/'||p==='/browse'){await renderBrowse(token)}
  else if(p==='/movies'){await renderCatalogExplorer('movie',q,token)}
  else if(p==='/series'||p==='/tv'){await renderCatalogExplorer('tv',q,token)}
  else if(p==='/anime'){await renderCatalogExplorer('anime',q,token)}
  else if(p==='/filters'){await renderCatalogExplorer(null,q,token)}
  else if(p==='/search'){await renderSearch(q,token)}
  else if(p.startsWith('/genre/')){await renderGenre(p.slice(7),q,token)}
  else if(p==='/watchlist'){await renderWatchlist()}
  else if(p==='/schedule'){await renderSchedule(token)}
  else if(p==='/random'){await renderRandom(token)}
  else if(/^\/title\/(anime|movie|tv)\/\d+/.test(p)){
   let [,type,rest]=p.split('/').slice(1);
   await renderDetail(type,rest.split('-')[0],token);
  }else if(/^\/watch\/(movie|tv)\/\d+/.test(p)){
   let [,type,rest]=p.split('/').slice(1);
   await renderWatch(type,rest.split('-')[0],q.get('ep')||'1',q.get('season')||'1',token);
  }else if(/^\/watch\/\d+/.test(p)){
   let [,slugPart,epPart]=p.split('/').slice(1);
   await renderWatch('anime',slugPart.split('-')[0],(epPart||'ep-1').replace(/^ep-/,''),'1',token);
  }else{
   await renderBrowse(token);
  }
 }catch(e){
  if(token!==currentRoute)return;
  app.innerHTML=`<div class="container content"><div class="empty"><h2>Something went wrong</h2><p class="error">${esc(e.message||'Unable to load page')}</p><div style="margin-top:16px"><a class="btn" href="/browse">Back to Home</a></div></div></div>`;
 }finally{
  if(token===currentRoute)document.body.classList.add('route-ready');
 }
}
window.addEventListener('popstate',route);
route();
